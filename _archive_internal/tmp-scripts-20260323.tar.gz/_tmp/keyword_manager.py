# -*- coding: utf-8 -*-
"""
통합 키워드 관리 프로그램
- Rawdata 파싱 및 업체 정보 확인
- 키워드 그룹 생성
- 키워드 조합기
- 키워드 검색 체크
- 결과 저장 및 관리
"""
import os
import sys
import json
import re
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
from pathlib import Path
from datetime import datetime
from urllib.parse import quote
import threading
import csv
import time
import random
import pandas as pd
from itertools import permutations
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
from selenium.common.exceptions import NoSuchWindowException, WebDriverException, InvalidSessionIdException
import undetected_chromedriver as uc

# 로컬 모듈 임포트
try:
    from parse_comprehensive_info import parse_comprehensive_info
    from keyword_group_generator import KeywordGroupGenerator
except ImportError:
    print("⚠️ parse_comprehensive_info 또는 keyword_group_generator 모듈을 찾을 수 없습니다.")
    sys.exit(1)

try:
    import pyautogui
    PYAUTOGUI_AVAILABLE = True
except ImportError:
    PYAUTOGUI_AVAILABLE = False


class IntegratedKeywordManager:
    """통합 키워드 관리 프로그램"""
    
    def __init__(self, root):
        self.root = root
        self.root.title("통합 키워드 관리 프로그램 v1.0")
        self.root.geometry("1600x1000")
        
        # ========== exe 빌드 시 경로 처리 ==========
        if getattr(sys, 'frozen', False):
            # PyInstaller로 빌드된 exe 실행 중
            self.BASE_DIR = Path(sys.executable).parent  # exe가 있는 폴더
            self.RESOURCE_DIR = Path(sys._MEIPASS) if hasattr(sys, '_MEIPASS') else self.BASE_DIR
        else:
            # 일반 Python 실행
            self.BASE_DIR = Path(__file__).parent
            self.RESOURCE_DIR = self.BASE_DIR
        
        # ========== 공통 변수 ==========
        self.rawdata_dir = None
        self.parsed_data = {}  # {파일경로: 파싱결과}
        self.current_file = None
        self.reward_data = {}  # {URL: {'keywords': [...], 'main_keyword': ''}}
        self.keyword_generator = KeywordGroupGenerator()
        self.json_data_dir = None  # JSON 파일들이 있는 폴더
        
        # ========== 검색 체크 관련 변수 ==========
        self.driver = None
        self.is_running = False
        self.target_mid = None
        self.batch_mode = False
        self.batch_tasks = []
        self.check_top = tk.BooleanVar(value=False)
        self.check_cpc = tk.BooleanVar(value=False)
        self.check_single = tk.BooleanVar(value=False)  # 단일 키워드 체크
        self.max_rank = 5
        self.rank_mode = tk.IntVar(value=5)
        self.search_history = {}  # 검색 이력
        self.history_file = str(self.BASE_DIR / "keyword_history.json")
        self.results = []  # 검색 결과
        
        # ========== 키워드 조합기 관련 변수 ==========
        self.combined_keywords = []
        
        # ========== 대기 목록 관련 변수 ==========
        self.queue_tasks = []  # 대기 목록에 추가된 업체들의 정보
        
        # Reward_data CSV 파일 로드 (기본 경로 시도)
        default_csv_path = self.BASE_DIR / 'Reward_data' / '▶▶▶스마일 내부 통합 (파파인원들만 보는곳) - 트래픽.csv'
        if default_csv_path.exists():
            try:
                self.load_reward_data(str(default_csv_path))
            except:
                pass  # 실패해도 계속 진행
        self.load_search_history()
        
        # 기본 JSON 폴더 경로 설정
        default_json_dir = self.BASE_DIR / "rawdata_json"
        if default_json_dir.exists():
            self.json_data_dir = str(default_json_dir)
        
        # UI 설정
        self.setup_ui()
        
        # JSON 폴더 경로 초기화
        if hasattr(self, 'json_folder_path_var') and self.json_data_dir:
            self.json_folder_path_var.set(self.json_data_dir)
        
        # 종료 처리
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)
    
    def log(self, message, level="INFO"):
        """실시간 로그 출력"""
        if not hasattr(self, 'log_text'):
            print(f"[{level}] {message}")  # GUI 없으면 콘솔에만 출력
            return
        
        timestamp = datetime.now().strftime("%H:%M:%S.%f")[:-3]
        
        # 레벨별 색상
        colors = {
            "INFO": "#00ff00",      # 녹색
            "DEBUG": "#00bfff",     # 파란색  
            "WARN": "#ffff00",      # 노란색
            "ERROR": "#ff0000",     # 빨간색
            "SUCCESS": "#00ff7f"    # 밝은 녹색
        }
        
        log_line = f"[{timestamp}] [{level:7s}] {message}\n"
        
        try:
            self.log_text.config(state=tk.NORMAL)
            self.log_text.insert(tk.END, log_line)
            
            # 색상 적용
            if level in colors:
                line_start = self.log_text.index("end-2l")
                line_end = self.log_text.index("end-1l")
                tag_name = f"{level}_{timestamp}"
                self.log_text.tag_add(tag_name, line_start, line_end)
                self.log_text.tag_config(tag_name, foreground=colors[level])
            
            # 자동 스크롤 (항상 최신 로그가 보이도록)
            self.log_text.see(tk.END)
            self.log_text.config(state=tk.DISABLED)
            
            # GUI 업데이트
            self.root.update_idletasks()
        except Exception as e:
            print(f"로그 출력 오류: {e}")
        
        # 콘솔에도 출력
        print(log_line.strip())
    
    def create_responsive_button_grid(self, parent, buttons_data, max_cols=3):
        """반응형 버튼 그리드 생성 (1열, 2열, 3열 자동 조정) - 모든 버튼 누락 없이 표시"""
        button_frame = ttk.Frame(parent)
        button_frame.pack(fill=tk.X, pady=2)
        
        def update_button_layout(event=None):
            # 버튼 프레임의 모든 위젯 제거
            for widget in button_frame.winfo_children():
                widget.destroy()
            
            # 현재 너비 계산
            button_frame.update_idletasks()
            available_width = button_frame.winfo_width()
            if available_width < 100:
                try:
                    available_width = parent.winfo_width() - 20
                except:
                    available_width = 300  # 기본값
            
            # 버튼 너비 추정 (텍스트 길이 + 패딩)
            button_widths = []
            for btn_text, _ in buttons_data:
                # 한글 1자당 약 10픽셀, 영문 1자당 약 6픽셀, 패딩 30픽셀
                text_width = len(btn_text) * 10 + 30
                button_widths.append(text_width)
            
            # 열 수 결정 (1~3열)
            total_buttons = len(buttons_data)
            cols = 1
            if available_width > 600 and total_buttons > 2:
                cols = min(3, total_buttons)
            elif available_width > 400 and total_buttons > 1:
                cols = min(2, total_buttons)
            else:
                cols = 1
            
            # 그리드에 배치
            for idx, (btn_text, btn_cmd) in enumerate(buttons_data):
                btn = ttk.Button(button_frame, text=btn_text, command=btn_cmd)
                row = idx // cols
                col = idx % cols
                btn.grid(row=row, column=col, padx=2, pady=2, sticky="ew")
            
            # 열에 균등한 가중치 부여
            for col in range(cols):
                button_frame.grid_columnconfigure(col, weight=1)
            
            # 필요한 행 수 계산
            rows_needed = (total_buttons + cols - 1) // cols
            for row in range(rows_needed):
                button_frame.grid_rowconfigure(row, weight=0)
        
        # 초기 배치
        button_frame.after_idle(update_button_layout)
        
        # 창 크기 변경 시 업데이트
        def on_parent_configure(event=None):
            button_frame.after_idle(update_button_layout)
        
        parent.bind("<Configure>", on_parent_configure)
        button_frame.bind("<Configure>", update_button_layout)
        
        return button_frame
    
    def setup_ui(self):
        """통합 UI 설정 - 4개 주요 섹션으로 구분"""
        # 상태바 (최하단)
        self.status_var = tk.StringVar(value="준비")
        status_bar = ttk.Label(self.root, textvariable=self.status_var, relief=tk.SUNKEN)
        status_bar.pack(side=tk.BOTTOM, fill=tk.X)
        
        # 상단: 폴더 선택 및 저장/로드 버튼 (반응형)
        top_frame = ttk.Frame(self.root)
        top_frame.pack(fill=tk.X, padx=10, pady=5)
        
        # 폴더 입력 영역
        folder_row = ttk.Frame(top_frame)
        folder_row.pack(fill=tk.X, pady=2)
        ttk.Label(folder_row, text="Rawdata 폴더:", font=('맑은 고딕', 10)).pack(side=tk.LEFT, padx=5)
        self.folder_path_var = tk.StringVar()
        folder_entry = ttk.Entry(folder_row, textvariable=self.folder_path_var)
        folder_entry.pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)
        
        # 상단 버튼들 (반응형)
        top_buttons = [
            ("폴더 선택", self.select_folder),
            ("전체 파싱", self.parse_all),
            ("Reward_data 재로드", self.load_reward_data),
            ("JSON 폴더 선택", self.select_json_folder),
            ("누락된 keyword_json 생성", self.create_missing_keyword_json_files),
            ("Excel 저장", self.save_to_excel),
            ("JSON 저장", self.save_to_json),
            ("각 업체 JSON 저장", self.save_individual_jsons)
        ]
        top_button_frame = self.create_responsive_button_grid(top_frame, top_buttons)
        
        # ========== 메인 Notebook (메인 탭 + 검색 탭) ==========
        self.main_notebook = ttk.Notebook(self.root)
        self.main_notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=(0, 10))
        
        # ========== 메인 탭: 섹션 1, 2, 3 ==========
        main_tab = ttk.Frame(self.main_notebook)
        self.main_notebook.add(main_tab, text="📋 메인")
        
        # 메인 탭 내부: 좌우 분할
        main_paned = ttk.PanedWindow(main_tab, orient=tk.HORIZONTAL)
        main_paned.pack(fill=tk.BOTH, expand=True)
        
        # 왼쪽: 업체 목록 섹션 (반응형)
        left_section = ttk.Frame(main_paned)
        left_section.pack_propagate(False)  # 자식 크기에 맞춰지지 않도록
        main_paned.add(left_section, weight=1)
        
        # 오른쪽: 섹션 2, 3 세로 배치 (비율 조정 가능)
        right_paned = ttk.PanedWindow(main_paned, orient=tk.VERTICAL)
        main_paned.add(right_paned, weight=3)
        
        # ========== 섹션 1: 업체 목록 (왼쪽) - 반응형 ==========
        section1_frame = ttk.LabelFrame(left_section, text="📋 섹션 1: 업체 목록", padding="5")
        section1_frame.pack(fill=tk.BOTH, expand=True)
        
        # 업체 목록 - Canvas로 감싸서 가로/세로 스크롤 가능하게 (반응형)
        list_canvas = tk.Canvas(section1_frame, highlightthickness=1, highlightbackground="gray")
        list_v_scrollbar = ttk.Scrollbar(section1_frame, orient=tk.VERTICAL, command=list_canvas.yview)
        list_h_scrollbar = ttk.Scrollbar(section1_frame, orient=tk.HORIZONTAL, command=list_canvas.xview)
        list_scrollable = ttk.Frame(list_canvas)
        
        # 스크롤 영역 자동 업데이트
        def update_list_scroll_region(event=None):
            list_canvas.update_idletasks()
            list_canvas.configure(scrollregion=list_canvas.bbox("all"))
        
        list_scrollable.bind("<Configure>", update_list_scroll_region)
        list_canvas_window = list_canvas.create_window((0, 0), window=list_scrollable, anchor="nw")
        
        # Canvas 크기 변경 시 내부 프레임 너비 자동 조정 (반응형)
        def on_list_canvas_configure(event):
            canvas_width = event.width
            canvas_height = event.height
            list_canvas.itemconfig(list_canvas_window, width=canvas_width)
            # 높이도 업데이트하여 전체 영역 사용
            update_list_scroll_region()
        
        list_canvas.bind("<Configure>", on_list_canvas_configure)
        list_canvas.configure(yscrollcommand=list_v_scrollbar.set, xscrollcommand=list_h_scrollbar.set)
        
        # 헤더
        list_header = ttk.Label(list_scrollable, text="업체 목록", font=('맑은 고딕', 12, 'bold'))
        list_header.pack(pady=5, fill=tk.X)
        
        # 검색 프레임 (반응형)
        search_frame = ttk.Frame(list_scrollable)
        search_frame.pack(fill=tk.X, padx=5, pady=5)
        
        # 검색 입력 영역
        search_input_frame = ttk.Frame(search_frame)
        search_input_frame.pack(fill=tk.X, pady=2)
        ttk.Label(search_input_frame, text="검색:").pack(side=tk.LEFT, padx=2)
        self.search_var = tk.StringVar()
        try:
            self.search_var.trace_add('write', lambda *args: self.filter_places())
        except AttributeError:
            # Python 3.6 이하 호환
            self.search_var.trace('w', self.filter_places)
        search_entry = ttk.Entry(search_input_frame, textvariable=self.search_var)
        search_entry.pack(side=tk.LEFT, padx=2, fill=tk.X, expand=True)
        
        # 버튼 프레임 (반응형 그리드)
        section1_buttons = [
            ("검색어 저장", self.save_search_keywords),
            ("검색어 로드", self.load_search_keywords)
        ]
        section1_button_frame = self.create_responsive_button_grid(search_frame, section1_buttons, max_cols=2)
        
        # 리스트 프레임 (반응형 - 남은 공간 모두 사용)
        list_frame = ttk.Frame(list_scrollable)
        list_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Listbox와 스크롤바 (반응형)
        scrollbar = ttk.Scrollbar(list_frame, orient=tk.VERTICAL)
        self.place_listbox = tk.Listbox(list_frame, yscrollcommand=scrollbar.set, font=('맑은 고딕', 10))
        self.place_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self.place_listbox.bind('<<ListboxSelect>>', self.on_place_selected)
        scrollbar.config(command=self.place_listbox.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Canvas와 스크롤바 배치 (반응형)
        list_canvas.grid(row=0, column=0, sticky="nsew")
        list_v_scrollbar.grid(row=0, column=1, sticky="ns")
        list_h_scrollbar.grid(row=1, column=0, sticky="ew")
        
        # 그리드 가중치 설정 (반응형)
        section1_frame.grid_rowconfigure(0, weight=1)
        section1_frame.grid_columnconfigure(0, weight=1)
        
        # 마우스 휠 스크롤
        def _on_mousewheel_list(event):
            list_canvas.yview_scroll(int(-1*(event.delta/120)), "units")
        list_canvas.bind_all("<MouseWheel>", _on_mousewheel_list)
        
        # 창 크기 변경 시 스크롤 영역 업데이트
        def on_section1_resize(event=None):
            update_list_scroll_region()
        
        section1_frame.bind("<Configure>", on_section1_resize)
        left_section.bind("<Configure>", on_section1_resize)
        
        self.all_place_files = []
        self.filtered_place_files = []
        
        # ========== 섹션 2: 업체 정보 (오른쪽 상단) ==========
        section2_frame = ttk.LabelFrame(right_paned, text="📋 섹션 2: 업체 정보", padding="5")
        right_paned.add(section2_frame, weight=2)  # 비율 2
        
        # 업체 정보 - Canvas로 감싸서 가로/세로 스크롤 가능하게
        info_canvas = tk.Canvas(section2_frame, highlightthickness=1, highlightbackground="gray")
        info_v_scrollbar = ttk.Scrollbar(section2_frame, orient=tk.VERTICAL, command=info_canvas.yview)
        info_h_scrollbar = ttk.Scrollbar(section2_frame, orient=tk.HORIZONTAL, command=info_canvas.xview)
        info_scrollable = ttk.Frame(info_canvas)
        
        def update_info_scroll_region(event=None):
            # 여러 번 호출되어도 안전하도록 처리
            try:
                info_canvas.update_idletasks()
                # Canvas 내부 위젯들의 실제 크기 계산
                bbox = info_canvas.bbox("all")
                if bbox:
                    # Canvas의 너비는 사용 가능한 너비로, 높이는 내부 위젯의 실제 높이로 설정
                    canvas_width = info_canvas.winfo_width()
                    if canvas_width > 1:
                        info_canvas.configure(scrollregion=(
                            0, 0, 
                            max(bbox[2], canvas_width),  # 너비는 Canvas 크기 또는 내용 중 큰 값
                            bbox[3]  # 높이는 내부 위젯의 실제 높이 (제한 없음)
                        ))
                    else:
                        info_canvas.configure(scrollregion=info_canvas.bbox("all"))
                else:
                    info_canvas.configure(scrollregion=(0, 0, 1, 1))
            except Exception:
                pass
        
        # 인스턴스 변수로 저장하여 다른 곳에서도 접근 가능하도록
        self.update_info_scroll_region = update_info_scroll_region
        
        info_scrollable.bind("<Configure>", lambda e: self.root.after_idle(update_info_scroll_region))
        info_canvas_window = info_canvas.create_window((0, 0), window=info_scrollable, anchor="nw")
        
        def on_info_canvas_configure(event):
            canvas_width = event.width
            info_canvas.itemconfig(info_canvas_window, width=canvas_width)
            # 스크롤 영역 업데이트 (약간의 딜레이로 안정화)
            self.root.after_idle(update_info_scroll_region)
        
        info_canvas.bind("<Configure>", on_info_canvas_configure)
        info_canvas.configure(yscrollcommand=info_v_scrollbar.set, xscrollcommand=info_h_scrollbar.set)
        
        # 함수를 먼저 정의
        def _on_mousewheel_info(event):
            # 섹션 2 Canvas 영역 내에서만 스크롤
            info_canvas.yview_scroll(int(-1*(event.delta/120)), "units")
        
        self.place_notebook = ttk.Notebook(info_scrollable)
        self.place_notebook.pack(fill=tk.BOTH, expand=True)
        
        info_canvas.grid(row=0, column=0, sticky="nsew")
        info_v_scrollbar.grid(row=0, column=1, sticky="ns")
        info_h_scrollbar.grid(row=1, column=0, sticky="ew")
        section2_frame.grid_rowconfigure(0, weight=1)
        section2_frame.grid_columnconfigure(0, weight=1)
        
        # bind_all 제거하고 Canvas와 내부 위젯에 직접 바인딩
        info_canvas.bind("<MouseWheel>", _on_mousewheel_info)
        info_scrollable.bind("<MouseWheel>", _on_mousewheel_info)
        self.place_notebook.bind("<MouseWheel>", _on_mousewheel_info)
        
        # PanedWindow 및 섹션 2 크기 변경 시 스크롤 영역 업데이트
        def on_section2_resize(event=None):
            # 약간의 딜레이로 안정화
            self.root.after(10, update_info_scroll_region)
        
        section2_frame.bind("<Configure>", on_section2_resize)
        right_paned.bind("<Configure>", lambda e: self.root.after(10, update_info_scroll_region))
        
        # 탭 변경 시 스크롤 영역 업데이트
        def on_tab_changed(event=None):
            self.root.after(50, update_info_scroll_region)
        
        self.place_notebook.bind("<<NotebookTabChanged>>", on_tab_changed)
        
        # 내부 위젯들의 크기 변경도 감지
        self.place_notebook.bind("<Configure>", lambda e: self.root.after(10, update_info_scroll_region))
        
        # ========== 섹션 3: 키워드 조합기 (오른쪽 하단) ==========
        section3_frame = ttk.LabelFrame(right_paned, text="🔗 섹션 3: 키워드 조합기", padding="5")
        right_paned.add(section3_frame, weight=5)  # 비율 5
        
        # 키워드 조합기 - Canvas로 감싸서 가로/세로 스크롤 가능하게
        combiner_canvas = tk.Canvas(section3_frame, highlightthickness=1, highlightbackground="gray")
        combiner_v_scrollbar = ttk.Scrollbar(section3_frame, orient=tk.VERTICAL, command=combiner_canvas.yview)
        combiner_h_scrollbar = ttk.Scrollbar(section3_frame, orient=tk.HORIZONTAL, command=combiner_canvas.xview)
        combiner_scrollable = ttk.Frame(combiner_canvas)
        
        combiner_scrollable.bind("<Configure>", lambda e: combiner_canvas.configure(scrollregion=combiner_canvas.bbox("all")))
        combiner_canvas_window = combiner_canvas.create_window((0, 0), window=combiner_scrollable, anchor="nw")
        
        def on_combiner_canvas_configure(event):
            canvas_width = event.width
            combiner_canvas.itemconfig(combiner_canvas_window, width=canvas_width)
        
        combiner_canvas.bind("<Configure>", on_combiner_canvas_configure)
        combiner_canvas.configure(yscrollcommand=combiner_v_scrollbar.set, xscrollcommand=combiner_h_scrollbar.set)
        
        self.combiner_tab = combiner_scrollable
        
        combiner_canvas.grid(row=0, column=0, sticky="nsew")
        combiner_v_scrollbar.grid(row=0, column=1, sticky="ns")
        combiner_h_scrollbar.grid(row=1, column=0, sticky="ew")
        section3_frame.grid_rowconfigure(0, weight=1)
        section3_frame.grid_columnconfigure(0, weight=1)
        
        def _on_mousewheel_combiner(event):
            # 섹션 3 Canvas 영역 내에서만 스크롤
            combiner_canvas.yview_scroll(int(-1*(event.delta/120)), "units")
        
        # bind_all 제거하고 Canvas와 내부 위젯에 직접 바인딩
        combiner_canvas.bind("<MouseWheel>", _on_mousewheel_combiner)
        combiner_scrollable.bind("<MouseWheel>", _on_mousewheel_combiner)
        
        # ========== 검색 탭: 섹션 4 (키워드 검색 체크) ==========
        search_tab = ttk.Frame(self.main_notebook)
        self.main_notebook.add(search_tab, text="🔍 키워드 검색 체크")
        
        # 키워드 검색 체크 - Canvas로 감싸서 가로/세로 스크롤 가능하게
        checker_canvas = tk.Canvas(search_tab, highlightthickness=1, highlightbackground="gray")
        checker_v_scrollbar = ttk.Scrollbar(search_tab, orient=tk.VERTICAL, command=checker_canvas.yview)
        checker_h_scrollbar = ttk.Scrollbar(search_tab, orient=tk.HORIZONTAL, command=checker_canvas.xview)
        checker_scrollable = ttk.Frame(checker_canvas)
        
        # 스크롤 영역 업데이트 함수 (Canvas 높이 제한 포함)
        def update_checker_scroll_region(event=None):
            try:
                checker_canvas.update_idletasks()
                bbox = checker_canvas.bbox("all")
                if bbox:
                    canvas_width = checker_canvas.winfo_width()
                    if canvas_width > 1:
                        checker_canvas.configure(scrollregion=(
                            0, 0, 
                            max(bbox[2], canvas_width),  # 너비는 Canvas 크기 또는 내용 중 큰 값
                            bbox[3]  # 높이는 내부 위젯의 실제 높이 (제한 없음)
                        ))
                    else:
                        checker_canvas.configure(scrollregion=checker_canvas.bbox("all"))
                else:
                    checker_canvas.configure(scrollregion=(0, 0, 1, 1))
            except Exception:
                pass
        
        # 인스턴스 변수로 저장
        self.update_checker_scroll_region = update_checker_scroll_region
        
        checker_scrollable.bind("<Configure>", lambda e: self.root.after_idle(update_checker_scroll_region))
        checker_canvas_window = checker_canvas.create_window((0, 0), window=checker_scrollable, anchor="nw")
        
        def on_checker_canvas_configure(event):
            canvas_width = event.width
            checker_canvas.itemconfig(checker_canvas_window, width=canvas_width)
            # 스크롤 영역 업데이트
            self.root.after_idle(update_checker_scroll_region)
        
        checker_canvas.bind("<Configure>", on_checker_canvas_configure)
        checker_canvas.configure(yscrollcommand=checker_v_scrollbar.set, xscrollcommand=checker_h_scrollbar.set)
        
        self.checker_tab = checker_scrollable
        
        checker_canvas.grid(row=0, column=0, sticky="nsew")
        checker_v_scrollbar.grid(row=0, column=1, sticky="ns")
        checker_h_scrollbar.grid(row=1, column=0, sticky="ew")
        search_tab.grid_rowconfigure(0, weight=1)
        search_tab.grid_columnconfigure(0, weight=1)
        
        # bind_all 제거하고 Canvas와 내부 위젯에 직접 바인딩
        def _on_mousewheel_checker(event):
            # 섹션 4 Canvas 영역 내에서만 스크롤
            checker_canvas.yview_scroll(int(-1*(event.delta/120)), "units")
        
        checker_canvas.bind("<MouseWheel>", _on_mousewheel_checker)
        checker_scrollable.bind("<MouseWheel>", _on_mousewheel_checker)
        
        # 각 섹션의 Canvas 참조 저장 (나중에 업데이트용)
        self.section1_canvas = list_canvas
        self.section1_scrollable = list_scrollable
        self.section2_canvas = info_canvas
        self.section2_scrollable = info_scrollable
        self.section3_canvas = combiner_canvas
        self.section3_scrollable = combiner_scrollable
        self.section4_canvas = checker_canvas
        self.section4_scrollable = checker_scrollable
        
        # 탭 설정 (각 섹션 내부에 추가)
        self.setup_place_info_tabs()
        self.setup_combiner_tab()
        self.setup_checker_tab()
        
        # Canvas 업데이트 함수 추가 (섹션 내용 변경 시 스크롤 영역 갱신)
        def update_section_canvas(section_num):
            if section_num == 1:
                self.section1_canvas.update_idletasks()
                self.section1_canvas.configure(scrollregion=self.section1_canvas.bbox("all"))
            elif section_num == 2:
                self.section2_canvas.update_idletasks()
                self.section2_canvas.configure(scrollregion=self.section2_canvas.bbox("all"))
            elif section_num == 3:
                self.section3_canvas.update_idletasks()
                self.section3_canvas.configure(scrollregion=self.section3_canvas.bbox("all"))
            elif section_num == 4:
                self.section4_canvas.update_idletasks()
                self.section4_canvas.configure(scrollregion=self.section4_canvas.bbox("all"))
        
        self.update_section_canvas = update_section_canvas
        
        # setup_place_info_tabs() 후에 키워드 상태 탭의 모든 위젯에 스크롤 영역 업데이트 연결
        # (나중에 키워드 상태 업데이트 시에도 자동으로 호출됨)
    
    # ========== 섹션 2: 업체 정보 ==========
    def setup_place_info_tabs(self):
        """업체 정보 탭 설정"""
        # place_notebook은 이미 setup_ui에서 생성되었으므로 여기서는 탭만 추가
        
        # 요약 보기 탭
        self.summary_tab = ttk.Frame(self.place_notebook)
        self.place_notebook.add(self.summary_tab, text="요약 보기")
        
        summary_frame = ttk.Frame(self.summary_tab)
        summary_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        columns = ('업체명', 'MID', '전화번호', '역', '아파트', '랜드마크', '메뉴', 'URL')
        self.summary_tree = ttk.Treeview(summary_frame, columns=columns, show='headings', height=20)
        
        for col in columns:
            self.summary_tree.heading(col, text=col)
            self.summary_tree.column(col, width=120)
        
        summary_scroll = ttk.Scrollbar(summary_frame, orient=tk.VERTICAL, command=self.summary_tree.yview)
        self.summary_tree.configure(yscrollcommand=summary_scroll.set)
        self.summary_tree.bind('<Double-1>', self.on_summary_double_click)
        
        self.summary_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        summary_scroll.pack(side=tk.RIGHT, fill=tk.Y)
        
        # 기본 정보, 주소, 주변 정보, 메뉴, 소개글, 기타 탭
        self.basic_tab = ttk.Frame(self.place_notebook)
        self.place_notebook.add(self.basic_tab, text="기본 정보")
        self.basic_text = scrolledtext.ScrolledText(self.basic_tab, wrap=tk.WORD, font=('맑은 고딕', 10))
        self.basic_text.pack(fill=tk.BOTH, expand=True)
        
        self.address_tab = ttk.Frame(self.place_notebook)
        self.place_notebook.add(self.address_tab, text="주소")
        self.address_text = scrolledtext.ScrolledText(self.address_tab, wrap=tk.WORD, font=('맑은 고딕', 10))
        self.address_text.pack(fill=tk.BOTH, expand=True)
        
        self.around_tab = ttk.Frame(self.place_notebook)
        self.place_notebook.add(self.around_tab, text="주변 정보")
        self.around_text = scrolledtext.ScrolledText(self.around_tab, wrap=tk.WORD, font=('맑은 고딕', 10))
        self.around_text.pack(fill=tk.BOTH, expand=True)
        
        self.menu_tab = ttk.Frame(self.place_notebook)
        self.place_notebook.add(self.menu_tab, text="메뉴")
        self.menu_text = scrolledtext.ScrolledText(self.menu_tab, wrap=tk.WORD, font=('맑은 고딕', 10))
        self.menu_text.pack(fill=tk.BOTH, expand=True)
        
        self.intro_tab = ttk.Frame(self.place_notebook)
        self.place_notebook.add(self.intro_tab, text="소개글")
        self.intro_text = scrolledtext.ScrolledText(self.intro_tab, wrap=tk.WORD, font=('맑은 고딕', 10))
        self.intro_text.pack(fill=tk.BOTH, expand=True)
        
        self.other_tab = ttk.Frame(self.place_notebook)
        self.place_notebook.add(self.other_tab, text="기타")
        self.other_text = scrolledtext.ScrolledText(self.other_tab, wrap=tk.WORD, font=('맑은 고딕', 10))
        self.other_text.pack(fill=tk.BOTH, expand=True)
        
        # 작업 키워드 탭
        self.work_keywords_tab = ttk.Frame(self.place_notebook)
        self.place_notebook.add(self.work_keywords_tab, text="작업 키워드")
        
        work_keywords_frame = ttk.Frame(self.work_keywords_tab)
        work_keywords_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        existing_label = ttk.Label(work_keywords_frame, text="기존 작업 키워드:", font=('맑은 고딕', 10, 'bold'))
        existing_label.pack(anchor=tk.W, pady=(0, 5))
        
        self.existing_keywords_text = scrolledtext.ScrolledText(work_keywords_frame, wrap=tk.WORD, 
                                                              font=('맑은 고딕', 10), height=5)
        self.existing_keywords_text.pack(fill=tk.X, pady=(0, 10))
        
        groups_label = ttk.Label(work_keywords_frame, text="생성된 키워드 그룹:", font=('맑은 고딕', 10, 'bold'))
        groups_label.pack(anchor=tk.W, pady=(0, 5))
        
        group_notebook = ttk.Notebook(work_keywords_frame)
        group_notebook.pack(fill=tk.BOTH, expand=True)
        
        group1_tab = ttk.Frame(group_notebook)
        group_notebook.add(group1_tab, text="그룹 1: 지역키")
        self.group1_text = scrolledtext.ScrolledText(group1_tab, wrap=tk.WORD, font=('맑은 고딕', 10))
        self.group1_text.pack(fill=tk.BOTH, expand=True)
        
        group2_tab = ttk.Frame(group_notebook)
        group_notebook.add(group2_tab, text="그룹 2: 메뉴키")
        self.group2_text = scrolledtext.ScrolledText(group2_tab, wrap=tk.WORD, font=('맑은 고딕', 10))
        self.group2_text.pack(fill=tk.BOTH, expand=True)
        
        group3_tab = ttk.Frame(group_notebook)
        group_notebook.add(group3_tab, text="그룹 3: 업종키")
        self.group3_text = scrolledtext.ScrolledText(group3_tab, wrap=tk.WORD, font=('맑은 고딕', 10))
        self.group3_text.pack(fill=tk.BOTH, expand=True)
        
        # 키워드 상태 탭 (필터 기반 조회 및 복사)
        self.keyword_status_tab = ttk.Frame(self.place_notebook)
        self.place_notebook.add(self.keyword_status_tab, text="키워드 상태")
        
        keyword_status_frame = ttk.Frame(self.keyword_status_tab)
        keyword_status_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # ==================== 폴더 설정 ====================
        folder_frame = ttk.LabelFrame(keyword_status_frame, text="데이터 폴더")
        folder_frame.pack(fill='x', padx=5, pady=5)
        
        # rawdata_json (업체 정보)
        ttk.Label(folder_frame, text="업체정보:").grid(row=0, column=0, sticky='w', padx=5, pady=2)
        self.rawdata_json_path_var = tk.StringVar(value=str(Path(__file__).parent / "rawdata_json"))
        ttk.Entry(folder_frame, textvariable=self.rawdata_json_path_var, width=70).grid(row=0, column=1, padx=5, pady=2)
        ttk.Button(folder_frame, text="선택", command=lambda: self.select_kw_folder(self.rawdata_json_path_var)).grid(row=0, column=2, padx=5)
        
        # rawdata_keyword_json (키워드)
        ttk.Label(folder_frame, text="키워드:").grid(row=1, column=0, sticky='w', padx=5, pady=2)
        self.keyword_json_path_var = tk.StringVar(value=str(Path(__file__).parent / "rawdata_keyword_json"))
        ttk.Entry(folder_frame, textvariable=self.keyword_json_path_var, width=70).grid(row=1, column=1, padx=5, pady=2)
        ttk.Button(folder_frame, text="선택", command=lambda: self.select_kw_folder(self.keyword_json_path_var)).grid(row=1, column=2, padx=5)
        
        # 기존 호환성 유지
        self.json_folder_path_var = self.rawdata_json_path_var
        
        # ==================== 필터 옵션 ====================
        filter_frame = ttk.LabelFrame(keyword_status_frame, text="필터 옵션")
        filter_frame.pack(fill='x', padx=5, pady=5)
        
        # 첫 번째 줄
        row1 = ttk.Frame(filter_frame)
        row1.pack(fill='x', padx=5, pady=3)
        
        ttk.Label(row1, text="순위:").pack(side='left', padx=(0, 5))
        self.filter_rank_var = tk.StringVar(value="전체")
        rank_combo = ttk.Combobox(row1, textvariable=self.filter_rank_var, width=10, state='readonly')
        rank_combo['values'] = ['전체', '1-5위', '6-10위', '10위밖', '순위권밖']
        rank_combo.pack(side='left', padx=(0, 15))
        
        self.filter_top_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(row1, text="최상단", variable=self.filter_top_var).pack(side='left', padx=5)
        
        self.filter_no_cpc_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(row1, text="CPC없음", variable=self.filter_no_cpc_var).pack(side='left', padx=5)
        
        self.filter_single_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(row1, text="단일", variable=self.filter_single_var).pack(side='left', padx=5)
        
        self.filter_task_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(row1, text="구동중", variable=self.filter_task_var).pack(side='left', padx=5)
        
        self.filter_not_task_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(row1, text="미구동", variable=self.filter_not_task_var).pack(side='left', padx=5)
        
        # 두 번째 줄 (버튼)
        row2 = ttk.Frame(filter_frame)
        row2.pack(fill='x', padx=5, pady=3)
        
        ttk.Button(row2, text="필터 적용", command=self.apply_keyword_filter).pack(side='left', padx=5)
        ttk.Button(row2, text="초기화", command=self.reset_keyword_filter).pack(side='left', padx=5)
        ttk.Button(row2, text="전체 로드", command=self.load_all_keywords).pack(side='left', padx=5)
        
        ttk.Label(row2, text="프리셋:").pack(side='left', padx=(20, 5))
        self.preset_var = tk.StringVar(value="선택")
        preset_combo = ttk.Combobox(row2, textvariable=self.preset_var, width=25, state='readonly')
        preset_combo['values'] = ['선택', '성공조건(5위+최상단+CPC없음)', '단일+최상단', '단일만', '순위권밖']
        preset_combo.pack(side='left', padx=5)
        preset_combo.bind('<<ComboboxSelected>>', self.apply_preset_filter)
        
        # 결과 카운트
        self.filter_result_label = ttk.Label(row2, text="결과: 0개", font=('맑은 고딕', 10, 'bold'))
        self.filter_result_label.pack(side='right', padx=10)
        
        # ==================== 결과 리스트 ====================
        result_frame = ttk.LabelFrame(keyword_status_frame, text="키워드 목록")
        result_frame.pack(fill='both', expand=True, padx=5, pady=5)
        
        # 복사 버튼
        copy_frame = ttk.Frame(result_frame)
        copy_frame.pack(fill='x', padx=5, pady=3)
        
        ttk.Button(copy_frame, text="선택 복사", command=self.copy_selected_keywords).pack(side='left', padx=5)
        ttk.Button(copy_frame, text="전체 복사", command=self.copy_all_keywords).pack(side='left', padx=5)
        ttk.Button(copy_frame, text="전체 선택", command=self.select_all_keywords).pack(side='left', padx=5)
        ttk.Button(copy_frame, text="선택 해제", command=self.deselect_all_keywords).pack(side='left', padx=5)
        
        self.copy_mode_var = tk.StringVar(value="키워드만")
        copy_mode = ttk.Combobox(copy_frame, textvariable=self.copy_mode_var, width=15, state='readonly')
        copy_mode['values'] = ['키워드만', '키워드+순위', '전체정보']
        copy_mode.pack(side='left', padx=10)
        
        # Treeview
        tree_frame = ttk.Frame(result_frame)
        tree_frame.pack(fill='both', expand=True, padx=5, pady=5)
        
        columns = ('select', 'keyword', 'rank', 'is_top', 'has_cpc', 'place_count', 'is_single', 'section')
        self.keyword_tree = ttk.Treeview(tree_frame, columns=columns, show='headings', height=15)
        
        self.keyword_tree.heading('select', text='✓')
        self.keyword_tree.heading('keyword', text='키워드')
        self.keyword_tree.heading('rank', text='순위')
        self.keyword_tree.heading('is_top', text='최상단')
        self.keyword_tree.heading('has_cpc', text='CPC')
        self.keyword_tree.heading('place_count', text='업체수')
        self.keyword_tree.heading('is_single', text='단일')
        self.keyword_tree.heading('section', text='섹션')
        
        self.keyword_tree.column('select', width=30, anchor='center')
        self.keyword_tree.column('keyword', width=200)
        self.keyword_tree.column('rank', width=50, anchor='center')
        self.keyword_tree.column('is_top', width=60, anchor='center')
        self.keyword_tree.column('has_cpc', width=50, anchor='center')
        self.keyword_tree.column('place_count', width=60, anchor='center')
        self.keyword_tree.column('is_single', width=50, anchor='center')
        self.keyword_tree.column('section', width=80, anchor='center')
        
        # 스크롤바
        scrollbar_y = ttk.Scrollbar(tree_frame, orient='vertical', command=self.keyword_tree.yview)
        scrollbar_x = ttk.Scrollbar(tree_frame, orient='horizontal', command=self.keyword_tree.xview)
        self.keyword_tree.configure(yscrollcommand=scrollbar_y.set, xscrollcommand=scrollbar_x.set)
        
        scrollbar_y.pack(side='right', fill='y')
        scrollbar_x.pack(side='bottom', fill='x')
        self.keyword_tree.pack(fill='both', expand=True)
        
        # 클릭으로 선택 토글
        self.keyword_tree.bind('<ButtonRelease-1>', self.toggle_keyword_selection)
        
        # 선택 상태 저장
        self.selected_keywords = set()
        self.current_keywords = []
        self.current_mid = ''
        
        # 기존 호환성 위한 더미 위젯들
        self.keyword_stats_text = scrolledtext.ScrolledText(ttk.Frame(), wrap=tk.WORD)
        self.task_keywords_text = scrolledtext.ScrolledText(ttk.Frame(), wrap=tk.WORD)
        self.searched_keywords_text = scrolledtext.ScrolledText(ttk.Frame(), wrap=tk.WORD)
        self.success_main_included_text = scrolledtext.ScrolledText(ttk.Frame(), wrap=tk.WORD)
        self.success_main_not_included_text = scrolledtext.ScrolledText(ttk.Frame(), wrap=tk.WORD)
        self.failed_keywords_text = scrolledtext.ScrolledText(ttk.Frame(), wrap=tk.WORD)
        self.failed_top5_main_included_text = scrolledtext.ScrolledText(ttk.Frame(), wrap=tk.WORD)
        self.failed_top5_main_not_included_text = scrolledtext.ScrolledText(ttk.Frame(), wrap=tk.WORD)
        self.remaining_keywords_text = scrolledtext.ScrolledText(ttk.Frame(), wrap=tk.WORD)
        self.main_keyword_text = scrolledtext.ScrolledText(ttk.Frame(), wrap=tk.WORD)
    
    # ========== 섹션 3: 키워드 조합기 ==========
    def setup_combiner_tab(self):
        """키워드 조합기 탭 설정"""
        from itertools import permutations
        
        # self.combiner_tab은 이미 setup_ui에서 combiner_scrollable로 설정됨
        # 외부 Canvas가 이미 있으므로 내부에서 직접 요소 추가
        
        main_frame = ttk.Frame(self.combiner_tab, padding="10")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # 상단: 키워드 입력 영역
        input_frame = ttk.LabelFrame(main_frame, text="키워드 입력 (각 그룹 최대 100개, 총 200개 제한)", padding="10")
        input_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # 키워드 개수 표시
        count_frame = ttk.Frame(input_frame)
        count_frame.pack(fill=tk.X, pady=(0, 10))
        
        self.total_count_label = ttk.Label(count_frame, text="입력한 총 키워드 개수: 0/200", font=("Arial", 10, "bold"))
        self.total_count_label.pack(side=tk.LEFT)
        
        ttk.Label(count_frame, text="※ 키워드는 1줄에 하나씩 입력하세요", foreground="gray").pack(side=tk.LEFT, padx=10)
        
        # 키워드 입력 필드들 (4개)
        keyword_inputs_frame = ttk.Frame(input_frame)
        keyword_inputs_frame.pack(fill=tk.BOTH, expand=True)
        
        self.keyword_inputs = []
        for i in range(4):
            group_frame = ttk.LabelFrame(keyword_inputs_frame, text=f"키워드 {i+1}", padding="5")
            group_frame.grid(row=0, column=i, padx=5, pady=5, sticky="nsew")
            
            keyword_text = scrolledtext.ScrolledText(group_frame, height=8, width=25)
            keyword_text.pack(fill=tk.BOTH, expand=True)
            initial_text = f"# 키워드 {i+1} 입력 (최대 100개)\n# 1줄에 하나씩"
            keyword_text.insert("1.0", initial_text)
            
            # 키워드 개수 라벨
            count_label = ttk.Label(group_frame, text="0개", foreground="blue")
            count_label.pack(fill=tk.X, pady=(5, 0))
            
            self.keyword_inputs.append({
                'text': keyword_text,
                'count_label': count_label,
                'initial_text': initial_text
            })
            
            # 초기 텍스트 삭제 및 키워드 입력 처리
            def on_key_press(event, idx=i):
                text_widget = self.keyword_inputs[idx]['text']
                current_text = text_widget.get("1.0", tk.END).strip()
                initial_txt = self.keyword_inputs[idx]['initial_text']
                # 초기 텍스트만 있고 키를 누르면 삭제
                if current_text == initial_txt.strip():
                    text_widget.delete("1.0", tk.END)
            
            keyword_text.bind('<KeyPress>', on_key_press)
            keyword_text.bind('<KeyRelease>', lambda e, idx=i: self.update_keyword_count(idx))
        
        keyword_inputs_frame.grid_columnconfigure(0, weight=1)
        keyword_inputs_frame.grid_columnconfigure(1, weight=1)
        keyword_inputs_frame.grid_columnconfigure(2, weight=1)
        keyword_inputs_frame.grid_columnconfigure(3, weight=1)
        
        rule_frame = ttk.LabelFrame(main_frame, text="키워드 조합 규칙 설정", padding="10")
        rule_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        rule_canvas = tk.Canvas(rule_frame, highlightthickness=0)
        rule_scrollbar = ttk.Scrollbar(rule_frame, orient="vertical", command=rule_canvas.yview)
        rule_scrollable = ttk.Frame(rule_canvas)
        
        rule_scrollable.bind("<Configure>", lambda e: rule_canvas.configure(scrollregion=rule_canvas.bbox("all")))
        rule_canvas.create_window((0, 0), window=rule_scrollable, anchor="nw")
        rule_canvas.configure(yscrollcommand=rule_scrollbar.set)
        
        def on_canvas_configure(event):
            canvas_width = event.width
            rule_canvas.itemconfig(rule_canvas.find_all()[0], width=canvas_width)
        
        rule_canvas.bind("<Configure>", on_canvas_configure)
        rule_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        rule_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        def _on_mousewheel_rule(event):
            # 섹션 3 규칙 Canvas 영역 내에서만 스크롤
            rule_canvas.yview_scroll(int(-1*(event.delta/120)), "units")
        
        # bind_all 제거하고 Canvas와 내부 위젯에 직접 바인딩
        rule_canvas.bind("<MouseWheel>", _on_mousewheel_rule)
        rule_scrollable.bind("<MouseWheel>", _on_mousewheel_rule)
        
        self.combine_vars = {}
        
        single_box = ttk.LabelFrame(rule_scrollable, text="단독 키워드", padding="10")
        single_box.pack(fill=tk.X, padx=5, pady=5)
        
        single_inner = ttk.Frame(single_box)
        single_inner.pack(fill=tk.X)
        
        for i in range(4):
            var = tk.BooleanVar(value=False)  # 기본값 False로 변경
            self.combine_vars[f'single_{i+1}'] = var
            ttk.Checkbutton(single_inner, text=str(i+1), variable=var).grid(row=0, column=i, padx=5, pady=2)
        
        button_frame = ttk.Frame(single_box)
        button_frame.pack(fill=tk.X, pady=(5, 0))
        ttk.Button(button_frame, text="전체선택", command=lambda: self.select_all_single(True)).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="전체해제", command=lambda: self.select_all_single(False)).pack(side=tk.LEFT, padx=2)
        
        two_box = ttk.LabelFrame(rule_scrollable, text="2개 조합 (12가지)", padding="10")
        two_box.pack(fill=tk.X, padx=5, pady=5)
        
        two_inner = ttk.Frame(two_box)
        two_inner.pack(fill=tk.X)
        
        two_combinations = ['1+2', '1+3', '1+4', '2+1', '2+3', '2+4', '3+1', '3+2', '3+4', '4+1', '4+2', '4+3']
        cols = 6
        for idx, combo in enumerate(two_combinations):
            # 기본값: 1+2, 1+3만 True
            default_value = combo in ['1+2', '1+3']
            var = tk.BooleanVar(value=default_value)
            self.combine_vars[f'two_{combo}'] = var
            row = idx // cols
            col = idx % cols
            ttk.Checkbutton(two_inner, text=combo, variable=var).grid(row=row, column=col, padx=3, pady=2, sticky=tk.W)
        
        two_button_frame = ttk.Frame(two_box)
        two_button_frame.pack(fill=tk.X, pady=(5, 0))
        ttk.Button(two_button_frame, text="전체선택", command=lambda: self.select_all_combination('two', True)).pack(side=tk.LEFT, padx=5)
        ttk.Button(two_button_frame, text="전체해제", command=lambda: self.select_all_combination('two', False)).pack(side=tk.LEFT, padx=2)
        
        three_box = ttk.LabelFrame(rule_scrollable, text="3개 조합 (24가지)", padding="10")
        three_box.pack(fill=tk.X, padx=5, pady=5)
        
        three_inner = ttk.Frame(three_box)
        three_inner.pack(fill=tk.X)
        
        three_combinations = ['1+2+3', '1+2+4', '1+3+2', '1+3+4', '1+4+2', '1+4+3',
                              '2+1+3', '2+1+4', '2+3+1', '2+3+4', '2+4+1', '2+4+3',
                              '3+1+2', '3+1+4', '3+2+1', '3+2+4', '3+4+1', '3+4+2',
                              '4+1+2', '4+1+3', '4+2+1', '4+2+3', '4+3+1', '4+3+2']
        cols = 6
        for idx, combo in enumerate(three_combinations):
            # 기본값: 1+2+3, 1+3+2만 True
            default_value = combo in ['1+2+3', '1+3+2']
            var = tk.BooleanVar(value=default_value)
            self.combine_vars[f'three_{combo}'] = var
            row = idx // cols
            col = idx % cols
            ttk.Checkbutton(three_inner, text=combo, variable=var).grid(row=row, column=col, padx=3, pady=2, sticky=tk.W)
        
        three_button_frame = ttk.Frame(three_box)
        three_button_frame.pack(fill=tk.X, pady=(5, 0))
        ttk.Button(three_button_frame, text="전체선택", command=lambda: self.select_all_combination('three', True)).pack(side=tk.LEFT, padx=5)
        ttk.Button(three_button_frame, text="전체해제", command=lambda: self.select_all_combination('three', False)).pack(side=tk.LEFT, padx=2)
        
        four_box = ttk.LabelFrame(rule_scrollable, text="4개 조합 (24가지)", padding="10")
        four_box.pack(fill=tk.X, padx=5, pady=5)
        
        four_inner = ttk.Frame(four_box)
        four_inner.pack(fill=tk.X)
        
        four_combinations = ['1+2+3+4', '1+2+4+3', '1+3+2+4', '1+3+4+2', '1+4+2+3', '1+4+3+2',
                            '2+1+3+4', '2+1+4+3', '2+3+1+4', '2+3+4+1', '2+4+1+3', '2+4+3+1',
                            '3+1+2+4', '3+1+4+2', '3+2+1+4', '3+2+4+1', '3+4+1+2', '3+4+2+1',
                            '4+1+2+3', '4+1+3+2', '4+2+1+3', '4+2+3+1', '4+3+1+2', '4+3+2+1']
        cols = 6
        for idx, combo in enumerate(four_combinations):
            var = tk.BooleanVar(value=False)  # 기본값 False로 변경
            self.combine_vars[f'four_{combo}'] = var
            row = idx // cols
            col = idx % cols
            ttk.Checkbutton(four_inner, text=combo, variable=var).grid(row=row, column=col, padx=3, pady=2, sticky=tk.W)
        
        four_button_frame = ttk.Frame(four_box)
        four_button_frame.pack(fill=tk.X, pady=(5, 0))
        ttk.Button(four_button_frame, text="전체선택", command=lambda: self.select_all_combination('four', True)).pack(side=tk.LEFT, padx=5)
        ttk.Button(four_button_frame, text="전체해제", command=lambda: self.select_all_combination('four', False)).pack(side=tk.LEFT, padx=2)
        
        result_frame = ttk.LabelFrame(main_frame, text="조합 완료 키워드", padding="10")
        result_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        option_frame = ttk.Frame(result_frame)
        option_frame.pack(fill=tk.X, pady=(0, 5))
        
        self.add_space_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(option_frame, text="키워드 사이 공백 추가", variable=self.add_space_var).pack(side=tk.LEFT, padx=5)
        
        self.combined_count_label = ttk.Label(option_frame, text="조합된 키워드 개수: 0", foreground="blue", font=("Arial", 10, "bold"))
        self.combined_count_label.pack(side=tk.LEFT, padx=20)
        
        ttk.Label(option_frame, text="중복되는 키워드는 자동 제거됩니다.", foreground="gray").pack(side=tk.LEFT, padx=10)
        
        self.combined_result_text = scrolledtext.ScrolledText(result_frame, height=15, width=100)
        self.combined_result_text.pack(fill=tk.BOTH, expand=True)
        self.combined_result_text.insert("1.0", "조합된 키워드가 출력됩니다.")
        
        # 섹션 3 버튼들 (반응형)
        section3_buttons = [
            ("키워드 조합하기", self.combine_keywords),
            ("다운받기", self.save_combined_keywords),
            ("검색 체크 탭으로 전송", self.send_to_checker_tab),
            ("초기화", self.clear_combiner)
        ]
        button_frame2 = self.create_responsive_button_grid(result_frame, section3_buttons)
        button_frame2.pack(fill=tk.X, pady=(10, 0))
    
    def load_from_excel(self):
        """엑셀에서 키워드만 가져오기 (단일 모드)"""
        filename = filedialog.askopenfilename(
            title="엑셀 파일 선택 (키워드만)",
            filetypes=[("Excel 파일", "*.xlsx *.xls"), ("모든 파일", "*.*")]
        )
        
        if not filename:
            return
        
        try:
            df = pd.read_excel(filename)
            
            # 키워드 컬럼 찾기
            if '키워드' in df.columns:
                keywords_raw = df['키워드'].dropna().tolist()
            elif 'keyword' in df.columns:
                keywords_raw = df['keyword'].dropna().tolist()
            else:
                keywords_raw = df.iloc[:, 0].dropna().tolist()
            
            # 콤마로 구분된 키워드 처리
            keywords = []
            for kw in keywords_raw:
                kw_str = str(kw).strip()
                if not kw_str:
                    continue
                
                if ',' in kw_str or '，' in kw_str:
                    separated = kw_str.replace('，', ',').split(',')
                    for kw_item in separated:
                        kw_item = kw_item.strip()
                        if kw_item:
                            keywords.append(kw_item)
                else:
                    keywords.append(kw_str)
            
            keywords = list(set(keywords))  # 중복 제거
            
            # 이력에 있는 키워드 제외 (중복 방지)
            filtered_keywords, duplicate_count = self.filter_duplicate_keywords(keywords)
            
            if not filtered_keywords:
                msg = f"모든 키워드({len(keywords)}개)가 이미 검색된 이력이 있습니다.\n\n"
                msg += "계속 진행하시겠습니까? (중복 키워드 포함하여 모두 검색합니다)"
                
                if messagebox.askyesno("중복 키워드", msg):
                    filtered_keywords = keywords
                    duplicate_count = 0
                else:
                    return
            elif duplicate_count > 0:
                msg = f"엑셀에서 {len(keywords)}개의 키워드를 가져왔습니다.\n\n"
                msg += f"이력에 있는 키워드: {duplicate_count}개\n"
                msg += f"새로운 키워드: {len(filtered_keywords)}개\n\n"
                msg += "어떻게 진행하시겠습니까?\n"
                msg += "• 예: 중복 제외하고 새로운 키워드만 사용\n"
                msg += "• 아니오: 중복 포함하여 모든 키워드 사용"
                
                if messagebox.askyesno("중복 키워드", msg):
                    pass
                else:
                    filtered_keywords = keywords
                    duplicate_count = 0
            
            # 키워드 영역 업데이트
            self.keyword_text.delete("1.0", tk.END)
            self.keyword_text.insert("1.0", "\n".join(filtered_keywords))
            
            # 결과 안내
            if duplicate_count > 0:
                msg = f"중복 키워드 {duplicate_count}개를 제외하여 {len(filtered_keywords)}개의 키워드를 추가했습니다."
                messagebox.showinfo("완료", msg)
            elif len(filtered_keywords) == len(keywords):
                msg = f"{len(filtered_keywords)}개의 키워드를 추가했습니다. (중복 포함)"
                messagebox.showinfo("완료", msg)
            
            # 일괄 처리 모드 해제
            self.batch_mode = False
            self.batch_tasks = []
            
            if hasattr(self, 'status_var'):
                self.status_var.set(f"엑셀에서 {len(filtered_keywords)}개의 키워드 로드 완료")
            
        except Exception as e:
            messagebox.showerror("오류", f"엑셀 파일 읽기 실패: {e}")
    
    def load_batch_from_excel(self):
        """엑셀에서 여러 업체 + 여러 키워드 가져오기 (일괄 처리 모드)"""
        filename = filedialog.askopenfilename(
            title="엑셀 파일 선택 (일괄 처리: URL, MID, 키워드)",
            filetypes=[("Excel 파일", "*.xlsx *.xls"), ("모든 파일", "*.*")]
        )
        
        if not filename:
            return
        
        try:
            df = pd.read_excel(filename)
            df.columns = df.columns.str.strip()
            
            # 컬럼 찾기
            agency_col = None
            url_col = None
            mid_col = None
            keyword_col = None
            top_col = None
            cpc_col = None
            condition_col = None
            main_key_region_col = None
            main_key_category_col = None
            work_key_col = None
            
            for col in df.columns:
                col_lower = col.lower()
                col_clean = col.strip()
                if '대행사' in col_clean or 'agency' in col_lower:
                    agency_col = col
                elif 'url' in col_lower or '플레이스' in col or '주소' in col:
                    url_col = col
                elif 'mid' in col_lower:
                    mid_col = col
                elif '키워드' in col or 'keyword' in col_lower:
                    keyword_col = col
                elif '최상단' in col_clean or 'top' in col_lower:
                    top_col = col
                elif 'cpc' in col_lower or '광고' in col_clean:
                    cpc_col = col
                elif '조건' in col_clean or 'condition' in col_lower:
                    condition_col = col
                elif '메인키' in col_clean and ('지역' in col_clean or 'region' in col_lower):
                    main_key_region_col = col
                elif '메인키' in col_clean and ('업종' in col_clean or 'category' in col_lower or '종류' in col_clean):
                    main_key_category_col = col
                elif '작업키' in col_clean or 'work' in col_lower:
                    work_key_col = col
            
            if not keyword_col:
                keyword_col = df.columns[0]
            
            if not url_col:
                messagebox.showerror("오류", "엑셀에 'URL' 또는 '플레이스URL' 컬럼이 없습니다.")
                return
            
            # MID 기준으로 그룹화 (같은 MID의 여러 행을 하나로 합침)
            mid_to_task = {}
            
            for idx, row in df.iterrows():
                try:
                    url = str(row[url_col]).strip() if pd.notna(row[url_col]) else ""
                    if not url:
                        continue
                    
                    mid = None
                    if mid_col and pd.notna(row[mid_col]):
                        mid_value = row[mid_col]
                        # 숫자인 경우 정수로 변환 후 문자열로 (1954591375.0 → "1954591375")
                        if isinstance(mid_value, (int, float)):
                            mid = str(int(mid_value))
                        else:
                            mid = str(mid_value).strip()
                            # .0으로 끝나는 경우 제거 (문자열로 입력된 경우 대비)
                            if mid.endswith('.0'):
                                mid = mid[:-2]
                    else:
                        mid_match = re.search(r'/(?:place|restaurant|hospital|hairshop|attraction|nailshop|waxing|pension|parking|law|academy|animalhospital|curtain|moving|cleaning|health|pilates|shaped|etc)/(\d+)', url, re.IGNORECASE)
                        if mid_match:
                            mid = mid_match.group(1)
                    
                    if not mid:
                        continue
                    
                    keywords_raw = str(row[keyword_col]).strip() if pd.notna(row[keyword_col]) else ""
                    if not keywords_raw:
                        continue
                    
                    # 키워드 파싱 (쉼표 구분 또는 단일)
                    keywords = []
                    if ',' in keywords_raw or '，' in keywords_raw:
                        separated = keywords_raw.replace('，', ',').split(',')
                        for kw in separated:
                            kw = kw.strip()
                            if kw:
                                keywords.append(kw)
                    else:
                        keywords.append(keywords_raw)
                    
                    agency_name = str(row[agency_col]).strip() if agency_col and pd.notna(row[agency_col]) else ""
                    conditions = self.parse_conditions(row, top_col, cpc_col, condition_col)
                    main_key_region = str(row[main_key_region_col]).strip() if main_key_region_col and pd.notna(row[main_key_region_col]) else ""
                    main_key_category = str(row[main_key_category_col]).strip() if main_key_category_col and pd.notna(row[main_key_category_col]) else ""
                    work_key_raw = str(row[work_key_col]).strip() if work_key_col and pd.notna(row[work_key_col]) else ""
                    
                    work_keys = []
                    if work_key_raw:
                        if ',' in work_key_raw or '，' in work_key_raw:
                            separated = work_key_raw.replace('，', ',').split(',')
                            for wk in separated:
                                wk = wk.strip()
                                if wk:
                                    work_keys.append(wk)
                        else:
                            work_keys.append(work_key_raw)
                    
                    if keywords:
                        if mid in mid_to_task:
                            # 기존 MID에 키워드 추가 (중복 제거)
                            existing_keywords = set(mid_to_task[mid]['keywords'])
                            for kw in keywords:
                                if kw not in existing_keywords:
                                    mid_to_task[mid]['keywords'].append(kw)
                                    existing_keywords.add(kw)
                            # 작업키도 추가 (중복 제거)
                            existing_work_keys = set(mid_to_task[mid]['work_keys'])
                            for wk in work_keys:
                                if wk not in existing_work_keys:
                                    mid_to_task[mid]['work_keys'].append(wk)
                                    existing_work_keys.add(wk)
                        else:
                            # 새 MID 작업 생성
                            mid_to_task[mid] = {
                                'agency_name': agency_name,
                                'url': url,
                                'mid': mid,
                                'keywords': keywords,
                                'conditions': conditions,
                                'main_key_region': main_key_region,
                                'main_key_category': main_key_category,
                                'work_keys': work_keys
                            }
                
                except Exception as e:
                    print(f"행 {idx+1} 처리 실패: {e}")
                    continue
            
            # 딕셔너리를 리스트로 변환
            batch_tasks = list(mid_to_task.values())
            
            if not batch_tasks:
                messagebox.showwarning("경고", "엑셀에서 유효한 작업을 찾을 수 없습니다.")
                return
            
            self.batch_mode = True
            self.batch_tasks = batch_tasks
            
            total_keywords = sum(len(task['keywords']) for task in batch_tasks)
            messagebox.showinfo("완료", f"일괄 처리 모드 활성화\n업체: {len(batch_tasks)}개\n키워드: {total_keywords}개")
            self.status_var.set(f"일괄 처리 준비: {len(batch_tasks)}개 업체, {total_keywords}개 키워드")
            
            summary = f"# 일괄 처리 모드 활성화\n# 업체: {len(batch_tasks)}개\n# 키워드: {total_keywords}개\n#\n# '검색 시작' 버튼을 클릭하면 일괄 처리가 시작됩니다.\n"
            for i, task in enumerate(batch_tasks[:5], 1):
                summary += f"# {i}. {task['url']} (MID: {task['mid']}) - 키워드 {len(task['keywords'])}개\n"
            if len(batch_tasks) > 5:
                summary += f"# ... 외 {len(batch_tasks)-5}개 업체\n"
            
            self.keyword_text.delete("1.0", tk.END)
            self.keyword_text.insert("1.0", summary)
        
        except Exception as e:
            messagebox.showerror("오류", f"엑셀 파일 읽기 실패: {e}")
            import traceback
            traceback.print_exc()
    
    def parse_conditions(self, row, top_col, cpc_col, condition_col):
        """엑셀 행에서 조건 파싱 (단일 키워드 조건 추가)"""
        conditions = {
            'check_top': False,
            'check_cpc': False,
            'check_single': False
        }
        
        if top_col and pd.notna(row[top_col]):
            value = str(row[top_col]).strip().upper()
            conditions['check_top'] = value in ['TRUE', 'Y', 'YES', '1', '예', 'O']
        
        if cpc_col and pd.notna(row[cpc_col]):
            value = str(row[cpc_col]).strip().upper()
            conditions['check_cpc'] = value in ['TRUE', 'Y', 'YES', '1', '예', 'O']
        
        if condition_col and pd.notna(row[condition_col]):
            value = str(row[condition_col]).strip()
            if '최상단' in value or 'top' in value.lower():
                conditions['check_top'] = True
            if 'cpc' in value.lower() or '광고' in value or '없음' in value:
                conditions['check_cpc'] = True
            if '단일' in value or '독점' in value or 'single' in value.lower():
                conditions['check_single'] = True
        
        return conditions
    
    def process_batch_tasks(self):
        """일괄 처리 작업 실행"""
        total_success = 0
        total_fail = 0
        total_keyword_count = 0  # 전체 키워드 카운터 추가
        
        self.log(f"📦 일괄 처리 시작: {len(self.batch_tasks)}개 업체", "INFO")
        
        for task_idx, task in enumerate(self.batch_tasks, 1):
            if not self.is_running:
                self.log("⏸️ 사용자가 중지함", "WARN")
                break
            
            url = task['url']
            mid = task['mid']
            keywords = task['keywords']
            
            self.log(f"▶ 업체 {task_idx}/{len(self.batch_tasks)}: MID {mid} ({len(keywords)}개 키워드)", "INFO")
            
            self.url_entry.delete(0, tk.END)
            self.url_entry.insert(0, url)
            self.target_mid = mid
            self.mid_label.config(text=mid)
            
            self.status_var.set(f"업체 {task_idx}/{len(self.batch_tasks)} - MID: {mid} ({len(keywords)}개 키워드)")
            self.root.update()
            
            for kw_idx, keyword in enumerate(keywords, 1):
                if not self.is_running:
                    break
                
                total_keyword_count += 1  # 전체 카운터 증가
                
                # 100개마다 브라우저 세션 초기화 (3단계)
                if total_keyword_count > 1 and (total_keyword_count - 1) % 100 == 0:
                    try:
                        self.log(f"🔄 세션 초기화 시작 ({total_keyword_count}번째 키워드)", "WARN")
                        self.status_var.set(f"🔄 세션 초기화 중... ({total_keyword_count}번째)")
                        self.root.update()
                        
                        # 1단계: 쿠키 삭제
                        try:
                            self.driver.delete_all_cookies()
                            time.sleep(1)
                            self.log("  ✓ 1단계: 쿠키 삭제 완료", "DEBUG")
                        except Exception as e:
                            self.log(f"  ✗ 1단계: 쿠키 삭제 실패 - {e}", "ERROR")
                        
                        # 2단계: 페이지 새로고침
                        try:
                            self.driver.refresh()
                            time.sleep(2)
                            self.log("  ✓ 2단계: 페이지 새로고침 완료", "DEBUG")
                        except Exception as e:
                            self.log(f"  ✗ 2단계: 페이지 새로고침 실패 - {e}", "ERROR")
                        
                        # 3단계: 브라우저 완전 재시작
                        try:
                            if self.driver:
                                try:
                                    self.driver.quit()
                                except:
                                    pass
                                self.driver = None
                            
                            time.sleep(3)
                            
                            if not self.init_browser():
                                self.log("  ✗ 3단계: 브라우저 재시작 실패", "ERROR")
                                self.is_running = False
                                return
                            
                            time.sleep(2)
                            self.log("  ✓ 3단계: 브라우저 재시작 완료", "SUCCESS")
                        except Exception as e:
                            self.log(f"  ✗ 3단계: 브라우저 재시작 오류 - {e}", "ERROR")
                        
                        self.log(f"✅ 세션 초기화 완료, 검색 재개 ({total_keyword_count})", "SUCCESS")
                    except Exception as e:
                        self.log(f"세션 초기화 오류: {e}", "ERROR")
                
                try:
                    self.add_to_history(keyword)
                    self.log(f"[{kw_idx}/{len(keywords)}] 검색: {keyword}", "INFO")
                    self.status_var.set(f"업체 {task_idx}/{len(self.batch_tasks)} - 키워드 {kw_idx}/{len(keywords)}: {keyword}")
                    self.root.update()
                    
                    if not self.search_keyword(keyword):
                        self.log(f"  ✗ 검색 실패: {keyword}", "ERROR")
                        self.add_result(keyword, "오류", "-", "-", "-", "검색 실패", "", url=url, mid=mid, total_places=0)
                        total_fail += 1
                        continue
                    
                    has_section, section_status, total_places = self.check_place_section()
                    if not has_section:
                        self.log(f"  - 플레이스 섹션 없음: {keyword} ({section_status})", "WARN")
                        self.add_result(keyword, "없음", "-", "-", "-", section_status, "", url=url, mid=mid, total_places=0)
                        total_fail += 1
                        time.sleep(0.5)
                        continue
                    
                    has_cpc_ad, cpc_count = self.check_cpc_ads()
                    rank, company_name, status = self.find_rank(mid)
                    
                    if rank:
                        self.log(f"  ✓ 순위 발견: {keyword} → {rank}위 ({company_name}) [업체 {total_places}개]", "SUCCESS")
                    else:
                        self.log(f"  - 순위권 밖: {keyword} ({status}) [업체 {total_places}개]", "WARN")
                    
                    conditions = task.get('conditions', {'check_top': False, 'check_cpc': False, 'check_single': False})
                    conditions_met, conditions_msg = self.check_conditions(
                        rank, section_status, has_cpc_ad, conditions, total_places
                    )
                    
                    rank_str = f"{rank}위" if rank else "-"
                    top_str = "✅" if section_status == "최상단" else "❌"
                    cpc_str = f"있음({cpc_count}개)" if has_cpc_ad else "없음"
                    
                    self.add_result(keyword, section_status, top_str, cpc_str, rank_str, conditions_msg, company_name or "", url=url, mid=mid, total_places=total_places)
                    
                    if conditions_met:
                        total_success += 1
                    else:
                        total_fail += 1
                    
                    time.sleep(0.5)
                
                except Exception as e:
                    self.log(f"  ✗ 검색 중 오류 발생: {keyword} - {str(e)}", "ERROR")
                    print(f"오류 ({task_idx}-{kw_idx}): {e}")
                    self.add_result(keyword, "오류", "-", "-", "-", f"오류: {e}", "", url=url, mid=mid, total_places=0)
                    total_fail += 1
                    continue
        
        self.is_running = False
        self.batch_mode = False  # 일괄 처리 모드 해제
        self.batch_tasks = []    # 작업 목록 초기화
        self.log(f"🎉 일괄 처리 완료 - 성공: {total_success}개, 실패: {total_fail}개", "SUCCESS")
        self.status_var.set(f"완료 - 성공: {total_success}개, 실패: {total_fail}개")
        if self.driver:
            messagebox.showinfo("완료", f"모든 일괄 처리가 완료되었습니다.\n성공: {total_success}개\n실패: {total_fail}개")
    
    def init_browser(self):
        """브라우저 초기화"""
        if self.driver:
            return True
        try:
            self.status_var.set("브라우저 초기화 중...")
            self.root.update()
            options = Options()
            options.add_argument("--disable-blink-features=AutomationControlled")
            self.driver = uc.Chrome(options=options, use_subprocess=True, version_main=145)
            self.driver.set_window_size(375, 812)
            return True
        except Exception as e:
            messagebox.showerror("오류", f"브라우저 초기화 실패: {e}")
            return False
    
    def search_keyword(self, keyword):
        """키워드 검색 실행"""
        try:
            if not self.driver:
                return False
            try:
                self.driver.current_window_handle
            except:
                return False
            
            encoded_keyword = quote(keyword)
            search_url = f"https://m.search.naver.com/search.naver?query={encoded_keyword}"
            self.driver.get(search_url)
            try:
                WebDriverWait(self.driver, 3).until(
                    EC.presence_of_element_located((By.TAG_NAME, "body"))
                )
            except NoSuchWindowException:
                return False
            except:
                pass
            time.sleep(0.5)
            return True
        except Exception as e:
            print(f"검색 실패: {e}")
            return False
    
    def _find_place_section(self):
        """플레이스 섹션 찾기 - 새로운 구조 지원"""
        try:
            # 방법 1: data-laim-exp-id 속성으로 찾기 (새로운 방법)
            place_sections = self.driver.find_elements(By.CSS_SELECTOR, 
                "div.place_section[data-laim-exp-id='loc_plc'], div[data-laim-exp-id='loc_plc']")
            for section in place_sections:
                try:
                    if section.is_displayed():
                        return section
                except:
                    continue
            
            # 방법 2: place_section 클래스로 찾기
            place_sections = self.driver.find_elements(By.CSS_SELECTOR, "div.place_section")
            for section in place_sections:
                try:
                    if section.is_displayed():
                        # 플레이스 섹션인지 확인 (제목이 "플레이스"인지)
                        try:
                            title = section.find_element(By.CSS_SELECTOR, 
                                ".place_section_header_title, h3.place_section_header div")
                            if title and "플레이스" in title.text:
                                return section
                        except:
                            pass
                except:
                    continue
            
            # 방법 3: 텍스트 기반 (기존 호환)
            place_sections = self.driver.find_elements(By.XPATH, 
                "//*[contains(text(), '플레이스')]/ancestor::div[contains(@class, 'section') or contains(@class, 'Place') or contains(@class, 'place')]")
            if place_sections:
                for section in place_sections:
                    try:
                        if section.is_displayed():
                            return section
                    except:
                        continue
            
            place_text_elements = self.driver.find_elements(By.XPATH, "//*[contains(text(), '플레이스')]")
            for elem in place_text_elements:
                try:
                    if elem.is_displayed():
                        parent = elem.find_element(By.XPATH, "./ancestor::div[contains(@class, 'section') or contains(@class, 'Place') or contains(@class, 'place')][1]")
                        if parent and parent.is_displayed():
                            return parent
                except:
                    continue
            
            # 방법 4: 플레이스 아이템의 부모 찾기 (기존 방법 + 새로운 구조)
            place_items = self.driver.find_elements(By.CSS_SELECTOR, 
                "div.CHC5F, div.UEzoS, li.VLTHu[data-loc_plc-doc-id]")
            if place_items:
                try:
                    first_item = place_items[0]
                    parent = first_item.find_element(By.XPATH, 
                        "./ancestor::div[contains(@class, 'place_section') or contains(@class, 'section') or contains(@class, 'Place') or contains(@class, 'place')][1]")
                    if parent and parent.is_displayed():
                        return parent
                except:
                    pass
            return None
        except Exception as e:
            print(f"플레이스 섹션 찾기 오류: {e}")
            return None
    
    def check_place_section(self):
        """플레이스 섹션 존재 확인 및 최상단 체크 (업체 수 카운트 추가)"""
        try:
            if not self.driver:
                return False, "브라우저 창이 닫혔습니다", 0
            try:
                self.driver.current_window_handle
            except:
                return False, "브라우저 창이 닫혔습니다", 0
            try:
                WebDriverWait(self.driver, 3).until(
                    EC.presence_of_element_located((By.TAG_NAME, "body"))
                )
            except NoSuchWindowException:
                return False, "브라우저 창이 닫혔습니다", 0
            except Exception as e:
                try:
                    self.driver.current_window_handle
                except:
                    return False, "브라우저 창이 닫혔습니다", 0
                pass
            
            self.driver.execute_script("window.scrollTo(0, 0);")
            time.sleep(0.5)
            
            place_section = self._find_place_section()
            if not place_section:
                return False, "플레이스 섹션 없음", 0
            
            # 플레이스 업체 수 카운트 (단일 키워드 체크용)
            total_places = 0
            try:
                place_items = place_section.find_elements(By.CSS_SELECTOR, "li.UEzoS.rIj4c, div.CHC5F, li.VLTHu")
                total_places = len(place_items)
            except Exception as e:
                self.log(f"업체 수 카운트 실패: {e}", "DEBUG")
            
            try:
                search_input = self.driver.find_element(By.CSS_SELECTOR, 
                    "input.search_input, input[type='search']")
                base_y = search_input.location['y']
            except:
                base_y = 0
            
            try:
                place_y = place_section.location['y']
                distance = place_y - base_y
                is_top = distance < 250
                return True, "최상단" if is_top else "하단", total_places
            except:
                return True, "하단", total_places
        except Exception as e:
            print(f"플레이스 섹션 체크 실패: {e}")
            import traceback
            traceback.print_exc()
            return False, f"오류: {e}", 0
    
    def check_conditions(self, rank, section_status, has_cpc_ad, conditions, total_places=0):
        """조건 충족 여부 확인 (단일 키워드 5가지 케이스 지원)"""
        if not rank or rank > self.max_rank:
            return False, f"{self.max_rank}위 이내 아님"
        
        conditions_met = []
        conditions_failed = []
        is_top = section_status == "최상단"
        
        # 단일 키워드 모드: 5가지 케이스 분류
        if conditions.get('check_single', False):
            is_single = (total_places == 1 and rank == 1)
            
            if is_single and is_top:
                # 케이스 1: 단일 + 최상단 (완벽)
                conditions_met.append("단일+최상단")
            elif is_single and not is_top:
                # 케이스 2: 단일 + 최상단아님
                conditions_met.append("단일")
                conditions_failed.append("최상단아님")
            elif not is_single and is_top:
                # 케이스 3: 비단일 + 최상단
                conditions_failed.append(f"비단일(업체{total_places}개)+최상단")
            else:
                # 케이스 4: 비단일 + 최상단아님
                conditions_failed.append(f"비단일(업체{total_places}개)+최상단아님")
        else:
            # 기존 로직: 최상단/CPC 개별 체크
            if conditions.get('check_top', False):
                if is_top:
                    conditions_met.append("최상단")
                else:
                    conditions_failed.append("최상단 아님")
            
            if conditions.get('check_cpc', False):
                if not has_cpc_ad:
                    conditions_met.append("CPC없음")
                else:
                    conditions_failed.append("CPC광고 있음")
        
        if len(conditions_failed) == 0:
            if len(conditions_met) == 0:
                msg = f"{self.max_rank}위 이내"
            else:
                msg = f"{self.max_rank}위 이내 + {', '.join(conditions_met)}"
            return True, msg
        else:
            # 수정: conditions_met도 메시지에 포함 (단일 키워드 분류용)
            if len(conditions_met) > 0:
                msg = f"{self.max_rank}위 이내 + {', '.join(conditions_met)}, 하지만 {', '.join(conditions_failed)}"
            else:
                msg = f"{self.max_rank}위 이내, 하지만 {', '.join(conditions_failed)}"
            return False, msg
    
    def check_cpc_ads(self):
        """플레이스 섹션 내 CPC 광고 체크"""
        try:
            place_section = self._find_place_section()
            if not place_section:
                return False, 0
            
            ad_badges = []
            try:
                ad_badges = place_section.find_elements(By.CSS_SELECTOR, "a.gU6bV")
            except:
                pass
            
            if not ad_badges:
                try:
                    # 새로운 구조와 기존 구조 모두 지원
                    place_items = place_section.find_elements(By.CSS_SELECTOR, 
                        "div.CHC5F, div.UEzoS, li.VLTHu[data-loc_plc-doc-id]")
                    for item in place_items:
                        try:
                            item_class = item.get_attribute("class") or ""
                            if "cZnHG" in item_class:
                                ad_badges.append(item)
                        except:
                            continue
                except:
                    pass
            
            ad_count = 0
            for badge in ad_badges:
                try:
                    if badge.is_displayed() and badge.location['y'] >= 0:
                        ad_count += 1
                except:
                    continue
            
            return ad_count > 0, ad_count
        except Exception as e:
            print(f"CPC 광고 체크 실패: {e}")
            return False, 0
    
    def find_rank(self, target_mid):
        """플레이스 섹션 내 순위 찾기"""
        try:
            if not self.driver:
                return None, None, "브라우저 창이 닫혔습니다"
            try:
                self.driver.current_window_handle
            except (NoSuchWindowException, InvalidSessionIdException):
                return None, None, "브라우저 세션이 종료되었습니다"
            except:
                return None, None, "브라우저 창이 닫혔습니다"
            
            try:
                place_section = self._find_place_section()
            except (NoSuchWindowException, InvalidSessionIdException):
                return None, None, "브라우저 세션이 종료되었습니다"
            except Exception as e:
                place_section = None
            
            rank, company_name, status = self._find_rank_in_section(place_section, target_mid)
            if rank:
                return rank, company_name, status
            
            more_button_clicked = False
            if self.max_rank == 100 and place_section:
                try:
                    expand_buttons = place_section.find_elements(By.XPATH, 
                        ".//*[contains(text(), '펼쳐서 더보기') or contains(text(), '펼쳐보기')]")
                    if not expand_buttons:
                        all_buttons = place_section.find_elements(By.CSS_SELECTOR, "button, a, span[role='button']")
                        expand_buttons = [btn for btn in all_buttons if '펼쳐서 더보기' in btn.text or '펼쳐보기' in btn.text]
                    
                    if expand_buttons:
                        for btn in expand_buttons:
                            try:
                                if btn.is_displayed():
                                    self.driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", btn)
                                    time.sleep(0.3)
                                    btn.click()
                                    time.sleep(0.8)
                                    break
                            except:
                                continue
                    
                    time.sleep(0.5)
                    more_buttons = []
                    if place_section:
                        try:
                            more_buttons = place_section.find_elements(By.XPATH, 
                                ".//*[contains(text(), '더보기') and not(contains(text(), '펼쳐서'))]")
                        except:
                            pass
                        if not more_buttons:
                            all_buttons = place_section.find_elements(By.CSS_SELECTOR, "button, a, span[role='button']")
                            more_buttons = [btn for btn in all_buttons if '더보기' in btn.text and '펼쳐서' not in btn.text]
                    
                    if more_buttons:
                        for btn in more_buttons:
                            try:
                                if btn.is_displayed():
                                    self.driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", btn)
                                    time.sleep(0.3)
                                    btn.click()
                                    more_button_clicked = True
                                    time.sleep(1.0)
                                    break
                            except:
                                continue
                    
                    if more_button_clicked and PYAUTOGUI_AVAILABLE:
                        try:
                            window_rect = self.driver.get_window_rect()
                            window_x = window_rect['x'] + window_rect['width'] // 2
                            window_y = window_rect['y'] + window_rect['height'] // 2
                            pyautogui.moveTo(window_x, window_y, duration=0)
                            
                            last_height = self.driver.execute_script("return document.body.scrollHeight")
                            scroll_count = 0
                            max_scrolls = 100
                            no_change_count = 0
                            
                            while scroll_count < max_scrolls:
                                try:
                                    self.driver.current_window_handle
                                except:
                                    break
                                
                                for _ in range(5):
                                    pyautogui.scroll(-20000, x=window_x, y=window_y)
                                time.sleep(0.0001)
                                
                                try:
                                    new_height = self.driver.execute_script("return document.body.scrollHeight")
                                except:
                                    break
                                
                                scroll_count += 1
                                if new_height == last_height:
                                    no_change_count += 1
                                    if no_change_count >= 2:
                                        break
                                else:
                                    no_change_count = 0
                                last_height = new_height
                        except:
                            pass
                    
                    if more_button_clicked:
                        place_section = None
                        rank, company_name, status = self._find_rank_in_section(place_section, target_mid)
                        if rank:
                            return rank, company_name, status
                except (NoSuchWindowException, InvalidSessionIdException):
                    return None, None, "브라우저 세션이 종료되었습니다"
                except:
                    pass
            
            rank, company_name, status = self._find_rank_in_section(place_section, target_mid)
            return rank, company_name, status
            
        except (NoSuchWindowException, InvalidSessionIdException):
            return None, None, "브라우저 세션이 종료되었습니다"
        except Exception as e:
            print(f"순위 찾기 실패: {e}")
            return None, None, f"오류: {e}"
    
    def _find_rank_in_section(self, place_section, target_mid):
        """플레이스 섹션 내에서 순위 찾기"""
        try:
            전체_엘리먼트들 = []
            타겟_업체_인덱스 = -1
            
            last_height = 0
            scroll_count = 0
            max_scrolls = 20
            no_new_items_count = 0
            max_no_new_items = 3
            
            try:
                last_height = self.driver.execute_script("return document.body.scrollHeight")
            except:
                last_height = 0
            
            while scroll_count < max_scrolls:
                try:
                    self.driver.current_window_handle
                except (NoSuchWindowException, InvalidSessionIdException):
                    return None, None, "브라우저 세션이 종료되었습니다"
                except:
                    pass
                
                엘리먼트들 = []
                
                # 새로운 구조 우선 시도: data-loc_plc-doc-id 속성 가진 요소
                try:
                    if place_section:
                        엘리먼트들 = place_section.find_elements(By.CSS_SELECTOR, 
                            "li[data-loc_plc-doc-id], li.VLTHu[data-loc_plc-doc-id]")
                    else:
                        엘리먼트들 = self.driver.find_elements(By.CSS_SELECTOR, 
                            "li[data-loc_plc-doc-id], li.VLTHu[data-loc_plc-doc-id]")
                except:
                    pass
                
                # 기존 구조 시도 1: UEzoS 클래스
                if not 엘리먼트들:
                    try:
                        if place_section:
                            엘리먼트들 = place_section.find_elements(By.CLASS_NAME, "UEzoS")
                        else:
                            엘리먼트들 = self.driver.find_elements(By.CLASS_NAME, "UEzoS")
                    except:
                        pass
                
                # 기존 구조 시도 2: CHC5F 클래스
                if not 엘리먼트들:
                    try:
                        if place_section:
                            엘리먼트들 = place_section.find_elements(By.CSS_SELECTOR, "div.CHC5F")
                        else:
                            엘리먼트들 = self.driver.find_elements(By.CSS_SELECTOR, "div.CHC5F")
                    except:
                        pass
                
                # 새로운 구조 추가 시도: VLTHu 클래스 (data 속성 없어도)
                if not 엘리먼트들:
                    try:
                        if place_section:
                            엘리먼트들 = place_section.find_elements(By.CSS_SELECTOR, "li.VLTHu")
                        else:
                            엘리먼트들 = self.driver.find_elements(By.CSS_SELECTOR, "li.VLTHu")
                    except:
                        pass
                
                if not 엘리먼트들:
                    if scroll_count == 0:
                        return None, None, "검색 결과 없음"
                    no_new_items_count += 1
                    if no_new_items_count >= max_no_new_items:
                        break
                
                처리할_엘리먼트들 = 엘리먼트들[:100] if len(엘리먼트들) > 100 else 엘리먼트들
                이전_개수 = len(전체_엘리먼트들)
                checked_mids = set()
                
                for 엘리먼트 in 처리할_엘리먼트들:
                    try:
                        if 엘리먼트 in 전체_엘리먼트들:
                            continue
                        
                        found_mid = None
                        
                        # 방법 1: 새로운 구조 - data-loc_plc-doc-id 속성에서 MID 추출 (가장 확실)
                        try:
                            doc_id = 엘리먼트.get_attribute("data-loc_plc-doc-id")
                            if doc_id and doc_id.strip():
                                found_mid = doc_id.strip()
                        except:
                            pass
                        
                        # 방법 2: 기존 방법 - URL에서 MID 추출
                        if not found_mid:
                            href = ""
                            try:
                                link = 엘리먼트.find_element(By.TAG_NAME, "a")
                                href = link.get_attribute("href") or ""
                            except:
                                try:
                                    links = 엘리먼트.find_elements(By.TAG_NAME, "a")
                                    for link in links:
                                        href = link.get_attribute("href") or ""
                                        if href and ('/place/' in href or '/restaurant/' in href or '/hospital/' in href):
                                            break
                                except:
                                    pass
                            
                            if href:
                                mid_match = re.search(
                                    r'/(?:place|restaurant|hospital|hairshop|attraction|nailshop|waxing|pension|parking|law|academy|animalhospital|curtain|moving|cleaning|health|pilates|shaped|etc)/(\d+)', 
                                    href, re.IGNORECASE)
                                if mid_match:
                                    found_mid = mid_match.group(1)
                        
                        if not found_mid:
                            continue
                        
                        if found_mid in checked_mids:
                            continue
                        
                        checked_mids.add(found_mid)
                        전체_엘리먼트들.append(엘리먼트)
                        
                        if found_mid == target_mid:
                            타겟_업체_인덱스 = len(전체_엘리먼트들) - 1
                            break
                        
                        if self.max_rank == 5 and len(전체_엘리먼트들) >= self.max_rank:
                            break
                    except Exception as e:
                        print(f"엘리먼트 처리 오류: {e}")
                        continue
                
                if 타겟_업체_인덱스 != -1:
                    break
                
                현재_개수 = len(전체_엘리먼트들)
                if 현재_개수 > 이전_개수:
                    no_new_items_count = 0
                else:
                    no_new_items_count += 1
                
                if no_new_items_count >= max_no_new_items:
                    break
                
                if self.max_rank == 5:
                    break
                
                if len(전체_엘리먼트들) >= self.max_rank:
                    break
                
                try:
                    self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
                    time.sleep(1.5)
                    
                    new_height = self.driver.execute_script("return document.body.scrollHeight")
                    if new_height == last_height:
                        if len(전체_엘리먼트들) > 이전_개수:
                            last_height = new_height
                            scroll_count += 1
                            continue
                        else:
                            break
                    last_height = new_height
                    scroll_count += 1
                except (NoSuchWindowException, InvalidSessionIdException):
                    return None, None, "브라우저 세션이 종료되었습니다"
                except:
                    break
            
            if 타겟_업체_인덱스 == -1:
                return None, None, f"{len(전체_엘리먼트들)}위까지 확인, 미발견"
            
            rank = 타겟_업체_인덱스 + 1
            
            company_name = None
            try:
                타겟_엘리먼트 = 전체_엘리먼트들[타겟_업체_인덱스]
                # 새로운 구조: YwYLL 클래스 (업체명)
                try:
                    name_elem = 타겟_엘리먼트.find_element(By.CSS_SELECTOR, 
                        "span.YwYLL, .place_bluelink .YwYLL, a.place_bluelink .YwYLL")
                    company_name = name_elem.text.strip()
                except:
                    try:
                        # 기존 구조
                        company_name = 타겟_엘리먼트.find_element(By.CLASS_NAME, "place_bluelink").text.strip()
                    except:
                        try:
                            company_name = 타겟_엘리먼트.find_element(By.CSS_SELECTOR, "span.TYaxT").text.strip()
                        except:
                            try:
                                company_name = 타겟_엘리먼트.find_element(By.CSS_SELECTOR, "span.place_name, a.place_name").text.strip()
                            except:
                                try:
                                    company_name = 타겟_엘리먼트.text.strip().split('\n')[0]
                                except:
                                    company_name = "이름없음"
            except:
                company_name = "이름없음"
            
            return rank, company_name, "발견"
            
        except (NoSuchWindowException, InvalidSessionIdException):
            return None, None, "브라우저 세션이 종료되었습니다"
        except Exception as e:
            print(f"순위 찾기 실패: {e}")
            return None, None, f"오류: {e}"
    
    def start_checking(self):
        """검색 시작"""
        if self.is_running:
            messagebox.showwarning("경고", "이미 검색이 진행 중입니다.")
            return
        
        self.max_rank = self.rank_mode.get()
        
        if self.batch_mode and self.batch_tasks:
            if not self.init_browser():
                return
            self.is_running = True
            # 스레드에서 실행하여 GUI 먹통 방지
            threading.Thread(target=self.process_batch_tasks, daemon=True).start()
            return
        
        if not hasattr(self, 'target_mid') or not self.target_mid:
            self.extract_mid()
            if not hasattr(self, 'target_mid') or not self.target_mid:
                messagebox.showerror("오류", "먼저 URL에서 MID를 추출하세요.")
                return
        
        keywords_text = self.keyword_text.get("1.0", tk.END).strip()
        if not keywords_text:
            messagebox.showwarning("경고", "키워드를 입력하세요.")
            return
        
        keywords_raw = [kw.strip() for kw in keywords_text.split('\n') if kw.strip() and not kw.strip().startswith('#')]
        keywords, duplicate_count = self.filter_duplicate_keywords(keywords_raw)
        
        if not keywords:
            msg = f"입력한 모든 키워드({len(keywords_raw)}개)가 이미 검색된 이력이 있습니다.\n\n계속 진행하시겠습니까?"
            if messagebox.askyesno("중복 키워드", msg):
                keywords = keywords_raw
                duplicate_count = 0
            else:
                return
        elif duplicate_count > 0:
            msg = f"입력한 키워드: {len(keywords_raw)}개\n\n이력에 있는 키워드: {duplicate_count}개\n새로운 키워드: {len(keywords)}개\n\n어떻게 진행하시겠습니까?"
            if not messagebox.askyesno("중복 키워드", msg):
                keywords = keywords_raw
                duplicate_count = 0
        
        if not keywords:
            messagebox.showwarning("경고", "유효한 키워드가 없습니다.")
            return
        
        self.main_key_region = self.main_key_region_entry.get().strip() if hasattr(self, 'main_key_region_entry') else ""
        self.main_key_category = self.main_key_category_entry.get().strip() if hasattr(self, 'main_key_category_entry') else ""
        work_key_raw = self.work_key_entry.get().strip() if hasattr(self, 'work_key_entry') else ""
        if work_key_raw:
            if ',' in work_key_raw or '，' in work_key_raw:
                self.work_keys = [wk.strip() for wk in work_key_raw.replace('，', ',').split(',') if wk.strip()]
            else:
                self.work_keys = [work_key_raw] if work_key_raw else []
        else:
            self.work_keys = []
        
        if not self.init_browser():
            return
        
        self.is_running = True
        # 스레드에서 실행하여 GUI 먹통 방지
        threading.Thread(target=self.check_keywords, args=(keywords,), daemon=True).start()
    
    def check_keywords(self, keywords):
        """키워드들 체크"""
        total_keywords = len(keywords)
        success_count = 0
        fail_count = 0
        
        self.log(f"🚀 검색 시작: 총 {total_keywords}개 키워드", "INFO")
        self.log(f"대상 MID: {self.target_mid}", "INFO")
        
        for idx, keyword in enumerate(keywords, 1):
            if not self.is_running:
                break
            
            # 100개마다 브라우저 세션 초기화 (3단계: 쿠키삭제 + 새로고침 + 재시작)
            if idx > 1 and (idx - 1) % 100 == 0:
                try:
                    self.log(f"🔄 세션 초기화 시작 ({idx}번째 키워드)", "WARN")
                    self.root.after(0, lambda i=idx: 
                                   self.status_var.set(f"🔄 세션 초기화 중... ({i}번째 키워드)"))
                    
                    # 1단계: 쿠키 삭제
                    try:
                        self.driver.delete_all_cookies()
                        time.sleep(1)
                        self.log("  ✓ 1단계: 쿠키 삭제 완료", "DEBUG")
                    except Exception as e:
                        self.log(f"  ✗ 1단계: 쿠키 삭제 실패 - {e}", "ERROR")
                    
                    # 2단계: 페이지 새로고침
                    try:
                        self.driver.refresh()
                        time.sleep(2)
                        self.log("  ✓ 2단계: 페이지 새로고침 완료", "DEBUG")
                    except Exception as e:
                        self.log(f"  ✗ 2단계: 페이지 새로고침 실패 - {e}", "ERROR")
                    
                    # 3단계: 브라우저 완전 재시작 (fallback)
                    try:
                        # 기존 브라우저 종료
                        if self.driver:
                            try:
                                self.driver.quit()
                            except:
                                pass
                            self.driver = None
                        
                        # 네이버 블락 방지 대기
                        time.sleep(3)
                        
                        # 브라우저 재시작
                        if not self.init_browser():
                            self.log("  ✗ 3단계: 브라우저 재시작 실패", "ERROR")
                            self.root.after(0, lambda: 
                                           messagebox.showerror("오류", "브라우저 재시작 실패"))
                            break
                        
                        # 재시작 후 안정화 대기
                        time.sleep(2)
                        self.log("  ✓ 3단계: 브라우저 재시작 완료", "SUCCESS")
                    except Exception as e:
                        self.log(f"  ✗ 3단계: 브라우저 재시작 오류 - {e}", "ERROR")
                    
                    self.log(f"✅ 세션 초기화 완료, 검색 재개 ({idx}/{total_keywords})", "SUCCESS")
                    self.root.after(0, lambda i=idx, t=total_keywords: 
                                   self.status_var.set(f"✅ 세션 초기화 완료, 검색 재개... ({i}/{t})"))
                except Exception as e:
                    self.log(f"세션 초기화 오류: {e}", "ERROR")
            
            try:
                # 스레드에서 안전하게 GUI 업데이트
                self.log(f"[{idx}/{total_keywords}] 검색: {keyword}", "INFO")
                self.root.after(0, lambda k=keyword, i=idx, t=total_keywords: 
                               self.status_var.set(f"검색 중... ({i}/{t}) - {k}"))
                
                if not self.search_keyword(keyword):
                    self.log(f"  ✗ 검색 실패: {keyword}", "ERROR")
                    self.add_result(keyword, "오류", "-", "-", "-", "검색 실패", "", total_places=0)
                    fail_count += 1
                    continue
                
                has_section, section_status, total_places = self.check_place_section()
                if not has_section:
                    self.log(f"  - 플레이스 섹션 없음: {keyword} ({section_status})", "WARN")
                    self.add_result(keyword, "없음", "-", "-", "-", section_status, "", total_places=0)
                    fail_count += 1
                    time.sleep(random.uniform(0.5, 1.5))  # 랜덤 대기 (블락 방지)
                    continue
                
                has_cpc_ad, cpc_count = self.check_cpc_ads()
                rank, company_name, status = self.find_rank(self.target_mid)
                
                if rank:
                    self.log(f"  ✓ 순위 발견: {keyword} → {rank}위 ({company_name}) [업체 {total_places}개]", "SUCCESS")
                else:
                    self.log(f"  - 순위권 밖: {keyword} ({status}) [업체 {total_places}개]", "WARN")
                
                conditions = {
                    'check_top': self.check_top.get(),
                    'check_cpc': self.check_cpc.get(),
                    'check_single': self.check_single.get()  # GUI 체크박스 값 사용
                }
                conditions_met, conditions_msg = self.check_conditions(
                    rank, section_status, has_cpc_ad, conditions, total_places
                )
                
                rank_str = f"{rank}위" if rank else "-"
                top_str = "✅" if section_status == "최상단" else "❌"
                cpc_str = f"있음({cpc_count}개)" if has_cpc_ad else "없음"
                
                self.add_result(keyword, section_status, top_str, cpc_str, rank_str, conditions_msg, company_name or "", total_places=total_places)
                success_count += 1
                
                self.add_to_history(keyword)
                time.sleep(random.uniform(0.5, 1.5))  # 랜덤 대기 (블락 방지)
                
            except Exception as e:
                self.log(f"  ✗ 검색 중 오류 발생: {keyword} - {str(e)}", "ERROR")
                print(f"오류 ({idx}/{total_keywords}): {e}")
                self.add_result(keyword, "오류", "-", "-", "-", f"오류: {e}", "", total_places=0)
                fail_count += 1
                continue
        
        self.is_running = False
        self.log(f"🎉 전체 검색 완료 - 성공: {success_count}개, 실패: {fail_count}개, 총: {total_keywords}개", "SUCCESS")
        # 스레드에서 안전하게 GUI 업데이트
        self.root.after(0, lambda s=success_count, f=fail_count, t=total_keywords: 
                       self.status_var.set(f"완료 ({s}개 성공, {f}개 실패 / 총 {t}개)"))
        if self.driver:
            self.root.after(0, lambda s=success_count, f=fail_count, t=total_keywords:
                          messagebox.showinfo("완료", f"모든 키워드 검색이 완료되었습니다.\n\n성공: {s}개\n실패: {f}개\n총: {t}개"))
    
    def add_result(self, keyword, section_status, top_status, cpc_status, rank, condition_status, company_name, url=None, mid=None, total_places=None, cpc_count=0):
        """결과 추가 - 원본 데이터 저장 (통합 구조)"""
        url_str = url if url else (self.url_entry.get().strip() if hasattr(self, 'url_entry') else "")
        mid_str = str(mid) if mid else (str(self.target_mid) if self.target_mid else "")
        
        # 원본 데이터 변환
        place_count = total_places if total_places else 0
        
        # 순위 숫자 추출
        rank_num = None
        if rank and rank != "-":
            try:
                rank_num = int(str(rank).replace("위", "").strip())
            except:
                rank_num = None
        
        # 최상단 여부 (TRUE/FALSE)
        is_top = (section_status == "최상단") or (top_status == "✅")
        
        # CPC 광고 여부 및 개수
        has_cpc = False
        cpc_cnt = cpc_count if cpc_count else 0
        if cpc_status and cpc_status != "-":
            if "없음" in str(cpc_status):
                has_cpc = False
                cpc_cnt = 0
            elif "있음" in str(cpc_status):
                has_cpc = True
                # "있음(2개)" 형식에서 숫자 추출
                match = re.search(r'\((\d+)개\)', str(cpc_status))
                if match:
                    cpc_cnt = int(match.group(1))
        
        # 단일 여부
        is_single = (place_count == 1 and rank_num == 1)
        
        # 작업키워드 여부 (Reward_data에서 확인)
        is_task_keyword = False
        reward_info = {}
        if mid_str and mid_str in self.reward_data:
            reward_info = self.reward_data[mid_str]
            task_keywords = reward_info.get('keywords', [])
            is_task_keyword = keyword in task_keywords
        
        # GUI 테이블에 추가 (새 컬럼 순서)
        self.result_tree.insert("", tk.END, values=(
            mid_str, 
            company_name or "", 
            keyword, 
            rank_num if rank_num else "", 
            "TRUE" if is_top else "FALSE", 
            "TRUE" if has_cpc else "FALSE",
            cpc_cnt,
            place_count, 
            "TRUE" if is_single else "FALSE",
            section_status,
            "TRUE" if is_task_keyword else "FALSE",
            reward_info.get('is_used', False) and "TRUE" or "FALSE",
            reward_info.get('start_date', ''),
            reward_info.get('end_date', '')
        ))
        
        # 메타 정보 가져오기
        agency_name = ""
        main_key_region = ""
        main_key_category = ""
        work_keys = []
        
        if self.batch_mode:
            for task in self.batch_tasks:
                if task.get('mid') == mid_str:
                    agency_name = task.get('agency_name', '')
                    main_key_region = task.get('main_key_region', '')
                    main_key_category = task.get('main_key_category', '')
                    work_keys = task.get('work_keys', [])
                    break
        else:
            agency_name = ""
            main_key_region = getattr(self, 'main_key_region', '')
            main_key_category = getattr(self, 'main_key_category', '')
            work_keys = getattr(self, 'work_keys', [])
        
        # 결과 저장 (원본 데이터 구조)
        self.results.append({
            'MID': mid_str,
            '업체명': company_name or "",
            '업체URL': url_str,
            '키워드': keyword,
            '순위': rank_num,
            '최상단': is_top,
            'CPC광고': has_cpc,
            'CPC개수': cpc_cnt,
            '업체수': place_count,
            '단일': is_single,
            '섹션상태': section_status,
            '검색시간': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            '작업키워드': is_task_keyword,
            '사용중': reward_info.get('is_used', False),
            '시작일': reward_info.get('start_date', ''),
            '종료일': reward_info.get('end_date', ''),
            '사용일수': reward_info.get('used_days', 0),
            '대행사명': agency_name,
            '메인키(지역)': main_key_region,
            '메인키(업종)': main_key_category,
            '작업키': ','.join(work_keys) if work_keys else ""
        })
        
        self.result_tree.see(self.result_tree.get_children()[-1])
    
    def stop_checking(self):
        """검색 중지"""
        self.is_running = False
        self.status_var.set("중지됨")
    
    def generate_parser_sheet(self):
        """파서 시트 데이터 생성 - 원본 데이터 기반"""
        if not self.results:
            return []
        
        company_stats = {}
        
        for result in self.results:
            mid = result.get('MID', '')
            url = result.get('업체URL', '')
            company_name = result.get('업체명', '')
            agency_name = result.get('대행사명', '')
            keyword = result.get('키워드', '')
            main_key_region = result.get('메인키(지역)', '')
            main_key_category = result.get('메인키(업종)', '')
            
            # 원본 데이터에서 성공 여부 판단 (5위 이내 + 최상단 + CPC없음)
            rank = result.get('순위')
            is_top = result.get('최상단', False)
            has_cpc = result.get('CPC광고', False)
            
            is_in_top5 = rank is not None and rank <= 5
            is_success = is_in_top5 and is_top and not has_cpc
            
            if mid not in company_stats:
                company_stats[mid] = {
                    '대행사명': agency_name,
                    '업체명': company_name,
                    '업체URL': url,
                    '업체MID값': mid,
                    '검색키워드수': 0,
                    '5위이내키수': 0,
                    '5위이내키': [],
                    '최상단키수': 0,
                    '최상단키': [],
                    '단일키수': 0,
                    '단일키': [],
                    '순위권밖키수': 0,
                    '순위권밖키': []
                }
            
            stats = company_stats[mid]
            stats['검색키워드수'] += 1
            
            if is_in_top5:
                stats['5위이내키수'] += 1
                stats['5위이내키'].append(keyword)
            else:
                stats['순위권밖키수'] += 1
                stats['순위권밖키'].append(keyword)
            
            if is_top:
                stats['최상단키수'] += 1
                stats['최상단키'].append(keyword)
            
            if result.get('단일', False):
                stats['단일키수'] += 1
                stats['단일키'].append(keyword)
        
        parser_data = []
        for mid, stats in company_stats.items():
            parser_data.append({
                '대행사명': stats.get('대행사명', ''),
                '업체명': stats['업체명'],
                '업체URL': stats['업체URL'],
                '업체MID값': stats['업체MID값'],
                '검색키워드수': stats['검색키워드수'],
                '5위이내키수': stats['5위이내키수'],
                '5위이내키': ','.join(stats['5위이내키'][:20]),  # 최대 20개
                '최상단키수': stats['최상단키수'],
                '최상단키': ','.join(stats['최상단키'][:20]),
                '단일키수': stats['단일키수'],
                '단일키': ','.join(stats['단일키'][:20]),
                '순위권밖키수': stats['순위권밖키수']
            })
        
        return parser_data
    
    def save_results(self):
        """결과 저장 - 통합 컬럼 구조"""
        if not self.results:
            messagebox.showwarning("경고", "저장할 결과가 없습니다.")
            return
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")[:-3]
        default_filename = f"키워드검색결과_{timestamp}.xlsx"
        
        filename = filedialog.asksaveasfilename(
            title="결과 저장",
            defaultextension=".xlsx",
            initialfile=default_filename,
            filetypes=[("Excel 파일", "*.xlsx"), ("CSV 파일", "*.csv"), ("모든 파일", "*.*")]
        )
        
        if filename:
            try:
                # 통합 컬럼 순서 정의
                column_order = [
                    'MID', '업체명', '업체URL', '키워드', '순위', 
                    '최상단', 'CPC광고', 'CPC개수', '업체수', '단일', '섹션상태',
                    '검색시간', '작업키워드', '사용중', '시작일', '종료일', '사용일수',
                    '대행사명', '메인키(지역)', '메인키(업종)', '작업키'
                ]
                
                # DataFrame 생성 및 컬럼 순서 정렬
                df = pd.DataFrame(self.results)
                # 존재하는 컬럼만 선택
                existing_cols = [col for col in column_order if col in df.columns]
                df = df[existing_cols]
                
                if filename.endswith('.csv'):
                    df.to_csv(filename, index=False, encoding='utf-8-sig')
                else:
                    from collections import defaultdict
                    
                    company_groups = defaultdict(list)
                    
                    for result in self.results:
                        mid = str(result.get('MID', '')).strip()
                        if not mid or mid == '-':
                            mid = '알수없음'
                        
                        company_name = result.get('업체명', '').strip()
                        
                        if company_name and company_name != '이름없음' and company_name != '':
                            if len(company_name) > 25:
                                sheet_name = f"{company_name[:25]}_{mid[:5]}"
                            else:
                                sheet_name = company_name
                        else:
                            sheet_name = f"업체_{mid}"
                        
                        invalid_chars = ['/', '\\', '?', '*', '[', ']', ':', "'", '"']
                        for char in invalid_chars:
                            sheet_name = sheet_name.replace(char, '_')
                        
                        sheet_name = sheet_name.strip()[:31]
                        company_groups[mid].append({
                            'sheet_name': sheet_name,
                            'data': result
                        })
                    
                    used_sheet_names = set()
                    
                    with pd.ExcelWriter(filename, engine='openpyxl') as writer:
                        df.to_excel(writer, sheet_name='전체결과', index=False)
                        used_sheet_names.add('전체결과')
                        
                        for mid, items in company_groups.items():
                            if not items:
                                continue
                            
                            base_sheet_name = items[0]['sheet_name']
                            if not base_sheet_name or base_sheet_name.strip() == '':
                                base_sheet_name = f"업체_{mid}"
                            
                            final_sheet_name = base_sheet_name
                            sheet_counter = 1
                            while final_sheet_name in used_sheet_names:
                                final_sheet_name = f"{base_sheet_name[:25]}_{sheet_counter}"
                                sheet_counter += 1
                            
                            used_sheet_names.add(final_sheet_name)
                            
                            try:
                                company_df = pd.DataFrame([item['data'] for item in items])
                                company_df.to_excel(writer, sheet_name=final_sheet_name, index=False)
                            except:
                                continue
                        
                        parser_data = self.generate_parser_sheet()
                        if parser_data:
                            try:
                                parser_df = pd.DataFrame(parser_data)
                                parser_df.to_excel(writer, sheet_name='파서', index=False)
                            except:
                                pass
                
                messagebox.showinfo("완료", f"결과가 저장되었습니다:\n{filename}")
                self.status_var.set(f"결과 저장 완료: {filename}")
            except Exception as e:
                messagebox.showerror("오류", f"저장 실패: {e}")
                import traceback
                traceback.print_exc()
    
    def load_results_from_file(self):
        """CSV/Excel 파일에서 키워드 검색 결과 불러오기 - 새 구조"""
        file_path = filedialog.askopenfilename(
            title="검색 결과 파일 선택 (Excel/CSV)",
            filetypes=[("Excel 파일", "*.xlsx *.xls"), ("CSV 파일", "*.csv"), ("모든 파일", "*.*")]
        )
        if not file_path:
            return
        
        try:
            self.status_var.set("검색 결과 파일 로드 중...")
            self.root.update()
            
            if file_path.endswith('.csv'):
                df = pd.read_csv(file_path, encoding='utf-8-sig')
            else:
                df = pd.read_excel(file_path)
            
            # 컬럼 매핑
            col_map = {}
            for col in df.columns:
                col_str = str(col).strip().lower()
                col_clean = str(col).strip()
                
                if 'mid' in col_str:
                    col_map['mid'] = col
                elif 'url' in col_str:
                    col_map['url'] = col
                elif col_clean == '키워드':
                    col_map['keyword'] = col
                elif col_clean == '순위':
                    col_map['rank'] = col
                elif col_clean == '최상단':
                    col_map['is_top'] = col
                elif 'cpc광고' in col_clean.lower() or col_clean == 'CPC':
                    col_map['has_cpc'] = col
                elif 'cpc개수' in col_clean.lower():
                    col_map['cpc_count'] = col
                elif col_clean == '업체수':
                    col_map['place_count'] = col
                elif col_clean == '단일':
                    col_map['is_single'] = col
                elif col_clean in ['섹션상태', '섹션', '플레이스섹션']:
                    col_map['section'] = col
                elif col_clean == '업체명':
                    col_map['company'] = col
                elif '메인키' in col_clean and '지역' in col_clean:
                    col_map['main_region'] = col
                elif '메인키' in col_clean and '업종' in col_clean:
                    col_map['main_category'] = col
                elif col_clean == '작업키':
                    col_map['work_key'] = col
                elif col_clean == '작업키워드':
                    col_map['is_task'] = col
                elif col_clean == '사용중':
                    col_map['is_used'] = col
                elif col_clean == '시작일':
                    col_map['start_date'] = col
                elif col_clean == '종료일':
                    col_map['end_date'] = col
            
            if 'keyword' not in col_map:
                messagebox.showerror("오류", "키워드 컬럼을 찾을 수 없습니다.")
                return
            
            results = []
            for idx, row in df.iterrows():
                def get_val(key, default=''):
                    if key in col_map and pd.notna(row[col_map[key]]):
                        return row[col_map[key]]
                    return default
                
                keyword = str(get_val('keyword', '')).strip()
                if not keyword or keyword == 'nan':
                    continue
                
                # MID 추출
                mid = ''
                if 'mid' in col_map:
                    mid_val = get_val('mid', '')
                    try:
                        if isinstance(mid_val, (int, float)):
                            mid = str(int(float(mid_val)))
                        else:
                            mid = str(mid_val).replace('.0', '').strip()
                    except:
                        mid = str(mid_val).strip()
                elif 'url' in col_map:
                    url_str = str(get_val('url', ''))
                    mid_match = re.search(r'/(\d+)', url_str)
                    if mid_match:
                        mid = mid_match.group(1)
                
                if not mid or mid == 'nan':
                    continue
                
                # 순위 파싱
                rank_val = get_val('rank')
                rank_num = None
                if rank_val:
                    try:
                        if isinstance(rank_val, (int, float)):
                            rank_num = int(rank_val)
                        else:
                            rank_num = int(re.sub(r'[^\d]', '', str(rank_val)))
                    except:
                        pass
                
                # Boolean 값 파싱
                def parse_bool(val):
                    if isinstance(val, bool):
                        return val
                    val_str = str(val).upper().strip()
                    return val_str in ['TRUE', '1', 'O', '✅', 'Y', 'YES']
                
                is_top = parse_bool(get_val('is_top', False))
                has_cpc = parse_bool(get_val('has_cpc', False))
                is_single = parse_bool(get_val('is_single', False))
                is_task = parse_bool(get_val('is_task', False))
                is_used = parse_bool(get_val('is_used', False))
                
                # 숫자 값 파싱
                cpc_count = 0
                place_count = 0
                try:
                    cpc_count = int(get_val('cpc_count', 0))
                except:
                    pass
                try:
                    place_count = int(get_val('place_count', 0))
                except:
                    pass
                
                # 결과 생성 (새 구조)
                result_item = {
                    'MID': mid,
                    '업체명': str(get_val('company', '')),
                    '업체URL': str(get_val('url', '')),
                    '키워드': keyword,
                    '순위': rank_num,
                    '최상단': is_top,
                    'CPC광고': has_cpc,
                    'CPC개수': cpc_count,
                    '업체수': place_count,
                    '단일': is_single,
                    '섹션상태': str(get_val('section', '')),
                    '검색시간': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    '작업키워드': is_task,
                    '사용중': is_used,
                    '시작일': str(get_val('start_date', '')),
                    '종료일': str(get_val('end_date', '')),
                    '사용일수': 0,
                    '대행사명': '',
                    '메인키(지역)': str(get_val('main_region', '')),
                    '메인키(업종)': str(get_val('main_category', '')),
                    '작업키': str(get_val('work_key', ''))
                }
                results.append(result_item)
            
            # 기존 결과에 추가
            self.results.extend(results)
            
            # 트리뷰에 추가 (새 컬럼 구조)
            for r in results:
                self.result_tree.insert("", tk.END, values=(
                    r.get('MID', ''),
                    r.get('업체명', ''),
                    r.get('키워드', ''),
                    r.get('순위', ''),
                    "TRUE" if r.get('최상단') else "FALSE",
                    "TRUE" if r.get('CPC광고') else "FALSE",
                    r.get('CPC개수', 0),
                    r.get('업체수', 0),
                    "TRUE" if r.get('단일') else "FALSE",
                    r.get('섹션상태', ''),
                    "TRUE" if r.get('작업키워드') else "FALSE",
                    "TRUE" if r.get('사용중') else "FALSE",
                    r.get('시작일', ''),
                    r.get('종료일', '')
                ))
            
            self.status_var.set(f"검색 결과 로드 완료: {len(results)}개")
            messagebox.showinfo("완료", f"검색 결과 {len(results)}개 추가\n총 결과: {len(self.results)}개")
            
        except Exception as e:
            messagebox.showerror("오류", f"파일 로드 실패:\n{str(e)}")
            import traceback
            traceback.print_exc()


    def update_json_from_results(self):
        """검색 결과를 keyword_json 파일에 업데이트 - keywords 배열 구조"""
        if not self.results:
            messagebox.showwarning("경고", "업데이트할 검색 결과가 없습니다.")
            return
        
        keyword_json_dir = Path(__file__).parent / "rawdata_keyword_json"
        keyword_json_dir.mkdir(exist_ok=True)
        rawdata_json_dir = Path(__file__).parent / "rawdata_json"
        
        try:
            self.status_var.set("keyword_json 업데이트 중...")
            self.root.update()
            
            # MID별로 결과 그룹화 (원본 데이터 저장)
            mid_results = {}
            for result in self.results:
                mid = self.normalize_mid(result.get('MID', ''))
                if not mid or mid == '-' or mid == 'nan':
                    continue
                
                if mid not in mid_results:
                    mid_results[mid] = {
                        'keywords': [],
                        'company_name': result.get('업체명', ''),
                        'url': result.get('업체URL', ''),
                        'main_key_region': result.get('메인키(지역)', ''),
                        'main_key_category': result.get('메인키(업종)', ''),
                        'work_keys': set()
                    }
                
                keyword = result.get('키워드', '').strip()
                if not keyword:
                    continue
                
                # 작업키 추가
                work_keys_str = result.get('작업키', '')
                if work_keys_str:
                    for wk in work_keys_str.split(','):
                        if wk.strip():
                            mid_results[mid]['work_keys'].add(wk.strip())
                
                # Reward_data에서 정보 확인
                is_task_keyword = False
                reward_info = self.reward_data.get(mid, {})
                if reward_info:
                    task_keywords = reward_info.get('keywords', [])
                    is_task_keyword = keyword in task_keywords
                
                # 키워드 원본 데이터 저장
                keyword_data = {
                    'keyword': keyword,
                    'rank': result.get('순위'),
                    'is_top': result.get('최상단', False),
                    'has_cpc': result.get('CPC광고', False),
                    'cpc_count': result.get('CPC개수', 0),
                    'place_count': result.get('업체수', 0),
                    'is_single': result.get('단일', False),
                    'section_status': result.get('섹션상태', ''),
                    'searched_at': result.get('검색시간', ''),
                    'is_task_keyword': is_task_keyword or result.get('작업키워드', False),
                    'is_used': reward_info.get('is_used', False),
                    'start_date': reward_info.get('start_date', ''),
                    'end_date': reward_info.get('end_date', ''),
                    'used_days': reward_info.get('used_days', 0)
                }
                mid_results[mid]['keywords'].append(keyword_data)
            
            updated_count = 0
            created_count = 0
            
            for mid, result_data in mid_results.items():
                company_name = result_data.get('company_name', '') or f"업체_{mid}"
                
                # JSON 파일 찾기
                json_file = None
                json_files = list(keyword_json_dir.glob(f"*{mid}.json"))
                if json_files:
                    json_file = json_files[0]
                    try:
                        with open(json_file, 'r', encoding='utf-8') as f:
                            existing_data = json.load(f)
                        company_name = existing_data.get('company_name', company_name)
                    except:
                        pass
                else:
                    # rawdata_json에서 업체명 가져오기
                    rawdata_json_files = list(rawdata_json_dir.glob(f"*_{mid}.json"))
                    if rawdata_json_files:
                        try:
                            with open(rawdata_json_files[0], 'r', encoding='utf-8') as f:
                                rawdata = json.load(f)
                            company_name = rawdata.get('name', company_name)
                        except:
                            pass
                    
                    safe_name = re.sub(r'[<>:"/\\|?*\n\r\t]', '_', company_name).strip()
                    safe_name = re.sub(r'\s+', ' ', safe_name) or f"업체_{mid}"
                    json_file = keyword_json_dir / f"{safe_name}_키워드검색결과_{mid}.json"
                    created_count += 1
                
                try:
                    # 기존 데이터 로드
                    if json_file.exists():
                        with open(json_file, 'r', encoding='utf-8') as f:
                            data = json.load(f)
                    else:
                        data = {
                            "mid": mid,
                            "company_name": company_name,
                            "url": result_data.get('url', ''),
                            "main_keyword": {"full": None, "sido": None, "region": None, "category": None},
                            "keywords": [],
                            "reward_info": {},
                            "statistics": {},
                            "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                        }
                    
                    # 기존 keywords 배열 가져오기
                    existing_keywords = data.get('keywords', [])
                    existing_kw_map = {kw.get('keyword'): kw for kw in existing_keywords if isinstance(kw, dict)}
                    
                    # 새 키워드 병합
                    for new_kw in result_data['keywords']:
                        kw_name = new_kw.get('keyword')
                        if kw_name in existing_kw_map:
                            existing_kw_map[kw_name].update(new_kw)
                        else:
                            existing_kw_map[kw_name] = new_kw
                    
                    # 메인 키워드 정보 업데이트
                    sido = result_data['main_key_region'] or data.get('main_keyword', {}).get('sido', '')
                    category = result_data['main_key_category'] or data.get('main_keyword', {}).get('category', '')
                    region = data.get('main_keyword', {}).get('region', '')
                    full_kw = ' '.join([p for p in [sido, region, category] if p])
                    
                    data['main_keyword'] = {
                        "full": full_kw or None,
                        "sido": sido or None,
                        "region": region or None,
                        "category": category or None
                    }
                    
                    # Reward_data 정보 업데이트
                    reward_info = self.reward_data.get(mid, {})
                    if reward_info:
                        data['reward_info'] = {
                            'agency_name': reward_info.get('agency_name', ''),
                            'start_date': reward_info.get('start_date', ''),
                            'end_date': reward_info.get('end_date', ''),
                            'daily_traffic': reward_info.get('daily_traffic', 0),
                            'product': reward_info.get('product', ''),
                            'is_used': reward_info.get('is_used', False),
                            'task_keywords': reward_info.get('keywords', [])
                        }
                    
                    # keywords 배열 저장
                    final_keywords = list(existing_kw_map.values())
                    data['keywords'] = final_keywords
                    
                    # 통계 계산
                    total = len(final_keywords)
                    searched = len([k for k in final_keywords if k.get('rank') is not None])
                    in_top5 = len([k for k in final_keywords if k.get('rank') and k['rank'] <= 5])
                    is_top = len([k for k in final_keywords if k.get('is_top')])
                    is_single = len([k for k in final_keywords if k.get('is_single')])
                    no_cpc = len([k for k in final_keywords if not k.get('has_cpc')])
                    
                    data['statistics'] = {
                        'total_keywords': total,
                        'searched_count': searched,
                        'in_top5_count': in_top5,
                        'is_top_count': is_top,
                        'is_single_count': is_single,
                        'no_cpc_count': no_cpc
                    }
                    
                    data['updated_at'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    
                    # JSON 저장
                    with open(json_file, 'w', encoding='utf-8') as f:
                        json.dump(data, f, ensure_ascii=False, indent=2)
                    
                    updated_count += 1
                    
                except Exception as e:
                    print(f"JSON 업데이트 실패 ({json_file}): {e}")
                    import traceback
                    traceback.print_exc()
                    continue
            
            self.status_var.set(f"keyword_json 업데이트 완료: {updated_count}개")
            messagebox.showinfo("완료", f"keyword_json 업데이트 완료!\n\n업데이트: {updated_count}개\n신규 생성: {created_count}개")
            
        except Exception as e:
            messagebox.showerror("오류", f"JSON 업데이트 실패:\n{str(e)}")
            import traceback
            traceback.print_exc()



    def apply_result_filter(self):
        """결과 테이블에 필터 적용"""
        # 현재 결과 저장 (필터 전)
        if not hasattr(self, '_all_results'):
            self._all_results = self.results.copy()
        
        filtered = self._all_results.copy()
        
        # 순위 필터
        rank_filter = self.filter_rank.get()
        if rank_filter == "1-5위":
            filtered = [r for r in filtered if r.get('순위') and r['순위'] <= 5]
        elif rank_filter == "6-10위":
            filtered = [r for r in filtered if r.get('순위') and 6 <= r['순위'] <= 10]
        elif rank_filter == "순위권밖":
            filtered = [r for r in filtered if not r.get('순위')]
        
        # 체크박스 필터 (True인 경우만 필터링)
        if self.filter_top.get():
            filtered = [r for r in filtered if r.get('최상단')]
        if self.filter_no_cpc.get():
            filtered = [r for r in filtered if not r.get('CPC광고')]
        if self.filter_single.get():
            filtered = [r for r in filtered if r.get('단일')]
        if self.filter_task.get():
            filtered = [r for r in filtered if r.get('작업키워드')]
        if self.filter_used.get():
            filtered = [r for r in filtered if r.get('사용중')]
        
        # 테이블 갱신
        self._update_result_tree(filtered)
        self.status_var.set(f"필터 적용: {len(filtered)}개 / 전체 {len(self._all_results)}개")
    
    def reset_result_filter(self):
        """필터 초기화"""
        self.filter_rank.set("전체")
        self.filter_top.set(False)
        self.filter_no_cpc.set(False)
        self.filter_single.set(False)
        self.filter_task.set(False)
        self.filter_used.set(False)
        
        if hasattr(self, '_all_results'):
            self._update_result_tree(self._all_results)
            self.status_var.set(f"필터 초기화: 전체 {len(self._all_results)}개")
    
    def apply_preset_filter(self, preset):
        """프리셋 필터 적용"""
        # 먼저 초기화
        self.reset_result_filter()
        
        if preset == 'success':
            self.filter_rank.set("1-5위")
            self.filter_top.set(True)
            self.filter_no_cpc.set(True)
        elif preset == 'single_top':
            self.filter_single.set(True)
            self.filter_top.set(True)
        elif preset == 'replace':
            self.filter_rank.set("순위권밖")
        
        self.apply_result_filter()
    
    def _update_result_tree(self, results):
        """결과 트리뷰 갱신"""
        # 기존 항목 삭제
        for item in self.result_tree.get_children():
            self.result_tree.delete(item)
        
        # 새 항목 추가
        for r in results:
            self.result_tree.insert("", tk.END, values=(
                r.get('MID', ''),
                r.get('업체명', ''),
                r.get('키워드', ''),
                r.get('순위', ''),
                "TRUE" if r.get('최상단') else "FALSE",
                "TRUE" if r.get('CPC광고') else "FALSE",
                r.get('CPC개수', 0),
                r.get('업체수', 0),
                "TRUE" if r.get('단일') else "FALSE",
                r.get('섹션상태', ''),
                "TRUE" if r.get('작업키워드') else "FALSE",
                "TRUE" if r.get('사용중') else "FALSE",
                r.get('시작일', ''),
                r.get('종료일', '')
            ))

    def clear_results(self):
        """결과 초기화"""
        if messagebox.askyesno("확인", "결과를 모두 삭제하시겠습니까?"):
            for item in self.result_tree.get_children():
                self.result_tree.delete(item)
            self.results = []
            
            # 로그도 초기화
            if hasattr(self, 'log_text'):
                self.log_text.config(state=tk.NORMAL)
                self.log_text.delete("1.0", tk.END)
                self.log_text.insert("1.0", "=== 실시간 로그 준비 완료 ===\n")
                self.log_text.config(state=tk.DISABLED)
            
            self.status_var.set("초기화 완료")
            self.log("🗑️ 결과 및 로그 초기화 완료", "INFO")
    
    def merge_results(self):
        """결과 폴더의 엑셀 파일들을 통합"""
        from openpyxl import load_workbook, Workbook
        from openpyxl.styles import PatternFill, Font, Alignment, Border
        import glob
        
        input_folder = filedialog.askdirectory(title="결과 폴더 선택 (엑셀 파일들이 있는 폴더)")
        if not input_folder:
            return
        
        excel_files = glob.glob(os.path.join(input_folder, "*.xlsx"))
        excel_files = [f for f in excel_files if not os.path.basename(f).startswith("~$")]
        
        if not excel_files:
            messagebox.showwarning("경고", "엑셀 파일을 찾을 수 없습니다.")
            return
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        default_filename = f"통합결과_{timestamp}.xlsx"
        
        output_file = filedialog.asksaveasfilename(
            title="통합 파일 저장",
            defaultextension=".xlsx",
            initialfile=default_filename,
            filetypes=[("Excel 파일", "*.xlsx"), ("모든 파일", "*.*")]
        )
        
        if not output_file:
            return
        
        try:
            self.status_var.set("통합 중...")
            self.root.update()
            
            merged_wb = Workbook()
            merged_ws = merged_wb.active
            merged_ws.title = "통합 결과"
            
            header_written = False
            current_row = 1
            
            def copy_cell_style(source_cell, target_cell):
                """셀 스타일 복사"""
                if source_cell.has_style:
                    if source_cell.fill and source_cell.fill.patternType:
                        target_cell.fill = PatternFill(
                            start_color=source_cell.fill.start_color,
                            end_color=source_cell.fill.end_color,
                            fill_type=source_cell.fill.fill_type
                        )
                    if source_cell.font:
                        target_cell.font = Font(
                            name=source_cell.font.name,
                            size=source_cell.font.size,
                            bold=source_cell.font.bold,
                            italic=source_cell.font.italic,
                            color=source_cell.font.color
                        )
                    if source_cell.alignment:
                        target_cell.alignment = Alignment(
                            horizontal=source_cell.alignment.horizontal,
                            vertical=source_cell.alignment.vertical,
                            wrap_text=source_cell.alignment.wrap_text
                        )
                    if source_cell.border:
                        target_cell.border = Border(
                            left=source_cell.border.left,
                            right=source_cell.border.right,
                            top=source_cell.border.top,
                            bottom=source_cell.border.bottom
                        )
            
            for file_path in excel_files:
                try:
                    self.status_var.set(f"처리 중: {os.path.basename(file_path)}")
                    self.root.update()
                    
                    wb = load_workbook(file_path, data_only=False)
                    
                    for sheet_name in wb.sheetnames:
                        ws = wb[sheet_name]
                        
                        if not header_written and ws.max_row > 0:
                            for col_idx, cell in enumerate(ws[1], 1):
                                target_cell = merged_ws.cell(row=current_row, column=col_idx)
                                target_cell.value = cell.value
                                copy_cell_style(cell, target_cell)
                            header_written = True
                            current_row += 1
                        
                        for row_idx in range(2, ws.max_row + 1):
                            for col_idx, cell in enumerate(ws[row_idx], 1):
                                target_cell = merged_ws.cell(row=current_row, column=col_idx)
                                target_cell.value = cell.value
                                copy_cell_style(cell, target_cell)
                            current_row += 1
                    
                    wb.close()
                except Exception as e:
                    print(f"파일 처리 실패: {os.path.basename(file_path)} - {e}")
                    continue
            
            merged_wb.save(output_file)
            merged_wb.close()
            
            messagebox.showinfo("완료", f"통합 완료!\n\n파일: {len(excel_files)}개\n저장: {output_file}")
            self.status_var.set(f"통합 완료: {len(excel_files)}개 파일")
        except Exception as e:
            messagebox.showerror("오류", f"통합 실패: {e}")
            import traceback
            traceback.print_exc()
    
    # ========== place_data_parser_gui.py의 메서드들 ==========
    def select_folder(self):
        """Rawdata 폴더 선택"""
        folder = filedialog.askdirectory(title="Rawdata 폴더 선택", initialdir=os.path.dirname(__file__))
        if folder:
            self.rawdata_dir = folder
            self.folder_path_var.set(folder)
            self.scan_place_files()
    
    def scan_place_files(self):
        """폴더에서 merged.txt 파일 스캔"""
        if not self.rawdata_dir:
            return
        
        self.status_var.set("파일 스캔 중...")
        self.root.update()
        
        rawdata_path = Path(self.rawdata_dir)
        merged_files = list(rawdata_path.glob("*_merged.txt"))
        
        self.all_place_files = []
        for file in merged_files:
            name = file.stem.replace('_merged', '').replace('place_', '')
            if name.startswith('place_'):
                name = f"업체_{name}"
            self.all_place_files.append((str(file), name))
        
        self.all_place_files.sort(key=lambda x: x[1])
        self.filtered_place_files = self.all_place_files.copy()
        
        self.update_place_list()
        self.update_summary_table()
        self.status_var.set(f"파일 {len(self.all_place_files)}개 발견")
    
    def filter_places(self, *args):
        """업체 목록 필터링"""
        search_term = self.search_var.get().lower()
        if not search_term:
            self.filtered_place_files = self.all_place_files.copy()
        else:
            self.filtered_place_files = [
                (path, name) for path, name in self.all_place_files
                if search_term in name.lower() or search_term in Path(path).name.lower()
            ]
        self.update_place_list()
    
    def update_place_list(self):
        """업체 목록 업데이트"""
        self.place_listbox.delete(0, tk.END)
        for file_path, name in self.filtered_place_files:
            status = "✅" if file_path in self.parsed_data else "⏳"
            display_name = f"{status} {name}"
            self.place_listbox.insert(tk.END, display_name)
    
    def on_place_selected(self, event):
        """업체 선택 시 정보 표시"""
        selection = self.place_listbox.curselection()
        if not selection:
            return
        idx = selection[0]
        file_path, name = self.filtered_place_files[idx]
        self.current_file = file_path
        if file_path not in self.parsed_data:
            self.parse_single_file(file_path)
        else:
            self.display_info(file_path)
    
    def parse_single_file(self, file_path):
        """단일 파일 파싱"""
        self.status_var.set(f"파싱 중: {Path(file_path).name}")
        self.root.update()
        try:
            mid = None
            mid_match = re.search(r'place[_\s]*(\d+)', Path(file_path).name)
            if mid_match:
                mid = mid_match.group(1)
            around_path = None
            if mid:
                rawdata_dir = Path(file_path).parent
                around_files = list(rawdata_dir.glob(f"*{mid}*around*.txt"))
                if around_files:
                    around_path = str(around_files[0])
            result = parse_comprehensive_info(file_path, around_path)
            if result:
                self.parsed_data[file_path] = result
                self.update_place_list()
                self.update_summary_table()
                self.display_info(file_path)
                self.status_var.set(f"파싱 완료: {result.get('name', '알 수 없음')}")
            else:
                messagebox.showerror("오류", "파싱에 실패했습니다.")
                self.status_var.set("파싱 실패")
        except Exception as e:
            messagebox.showerror("오류", f"파싱 중 오류 발생:\n{str(e)}")
            self.status_var.set("오류 발생")
            import traceback
            traceback.print_exc()
    
    def parse_all(self):
        """전체 파일 파싱 (스레드로 실행)"""
        if not self.rawdata_dir:
            messagebox.showwarning("경고", "먼저 폴더를 선택하세요.")
            return
        if not self.all_place_files:
            messagebox.showinfo("정보", "파싱할 파일이 없습니다.")
            return
        def parse_thread():
            total = len(self.all_place_files)
            for idx, (file_path, name) in enumerate(self.all_place_files, 1):
                if file_path in self.parsed_data:
                    continue
                self.root.after(0, lambda f=file_path, n=name, i=idx, t=total: 
                               self.status_var.set(f"파싱 중 ({i}/{t}): {n}"))
                try:
                    mid = None
                    mid_match = re.search(r'place[_\s]*(\d+)', Path(file_path).name)
                    if mid_match:
                        mid = mid_match.group(1)
                    around_path = None
                    if mid:
                        rawdata_dir = Path(file_path).parent
                        around_files = list(rawdata_dir.glob(f"*{mid}*around*.txt"))
                        if around_files:
                            around_path = str(around_files[0])
                    result = parse_comprehensive_info(file_path, around_path)
                    if result:
                        self.parsed_data[file_path] = result
                        self.root.after(0, self.update_place_list)
                        self.root.after(0, self.update_summary_table)
                except Exception as e:
                    print(f"파싱 오류 ({file_path}): {e}")
            self.root.after(0, lambda: self.status_var.set(f"전체 파싱 완료 ({len(self.parsed_data)}/{total}개)"))
            self.root.after(0, messagebox.showinfo, "완료", f"파싱 완료: {len(self.parsed_data)}/{total}개")
        threading.Thread(target=parse_thread, daemon=True).start()
    
    def display_info(self, file_path):
        """정보 표시"""
        if file_path not in self.parsed_data:
            return
        data = self.parsed_data[file_path]
        basic_info_text = f"""업체명: {data.get('name', '')}
플레이스 URL: {data.get('url', '')}
플레이스 MID: {data.get('mid', '')}
카테고리: {data.get('category', '')}

대표 키워드:
"""
        for kw in data.get('keyword_list', []):
            basic_info_text += f"  • {kw}\n"
        self.basic_text.delete(1.0, tk.END)
        self.basic_text.insert(1.0, basic_info_text)
        address_text = f"""지번 주소:
{data.get('address', '')}

도로명 주소:
{data.get('road_address', '')}
"""
        self.address_text.delete(1.0, tk.END)
        self.address_text.insert(1.0, address_text)
        around_places = data.get('around_places', {})
        around_text = "=== 역 정보 ===\n"
        for station in around_places.get('stations', [])[:20]:
            name = station.get('name', '')
            distance = station.get('distance', '')
            line = station.get('line', '')
            exit_info = station.get('exit', '')
            around_text += f"• {name}"
            if line:
                around_text += f" ({line})"
            if exit_info:
                around_text += f" - {exit_info}"
            if distance:
                around_text += f" - {distance}"
            around_text += "\n"
        around_text += "\n=== 아파트 ===\n"
        for apt in around_places.get('apartments', [])[:20]:
            around_text += f"• {apt.get('name', '')}"
            if apt.get('distance'):
                around_text += f" - {apt.get('distance', '')}"
            around_text += "\n"
        around_text += "\n=== 랜드마크 ===\n"
        for landmark in around_places.get('landmarks', [])[:20]:
            around_text += f"• {landmark.get('name', '')}"
            if landmark.get('type'):
                around_text += f" ({landmark.get('type', '')})"
            if landmark.get('distance'):
                around_text += f" - {landmark.get('distance', '')}"
            around_text += "\n"
        self.around_text.delete(1.0, tk.END)
        self.around_text.insert(1.0, around_text)
        menus = data.get('menus', [])
        menu_text = f"메뉴 개수: {len(menus)}개\n\n"
        for menu in menus:
            menu_text += f"메뉴명: {menu.get('name', '')}\n"
            if menu.get('price'):
                menu_text += f"가격: {menu.get('price', '')}\n"
            if menu.get('description'):
                menu_text += f"설명: {menu.get('description', '')}\n"
            menu_text += "-" * 50 + "\n"
        self.menu_text.delete(1.0, tk.END)
        self.menu_text.insert(1.0, menu_text)
        intro = data.get('introduction', '')
        if not intro:
            intro = "(소개글이 없습니다)"
        self.intro_text.delete(1.0, tk.END)
        self.intro_text.insert(1.0, intro)
        other_tabs = data.get('other_tabs', {})
        other_text = "=== 기타 탭 정보 ===\n\n"
        for tab, info in other_tabs.items():
            exists = info.get('exists', False)
            other_text += f"{tab.upper()}: {'있음' if exists else '없음'}\n"
            if exists and 'stats' in info:
                stats = info['stats']
                other_text += f"  - 방문자 리뷰: {stats.get('visitor_review_count', 0)}\n"
                other_text += f"  - 블로그 리뷰: {stats.get('blog_review_count', 0)}\n"
            other_text += "\n"
        self.other_text.delete(1.0, tk.END)
        self.other_text.insert(1.0, other_text)
        self.update_work_keywords(file_path)
        self.update_keyword_status(file_path, data)
    
    def load_reward_data(self, file_path=None):
        """Reward_data CSV/Excel 파일 로드 - 확장된 정보 추출"""
        if file_path is None:
            # 파일 선택 대화상자
            default_dir = Path(__file__).parent / 'Reward_data'
            file_path = filedialog.askopenfilename(
                title="Reward_data 파일 선택 (Excel/CSV)",
                initialdir=str(default_dir) if default_dir.exists() else os.path.dirname(__file__),
                filetypes=[
                    ("Excel 파일", "*.xlsx *.xls"),
                    ("CSV 파일", "*.csv"),
                    ("모든 파일", "*.*")
                ]
            )
            if not file_path:
                return
        
        self.reward_data = {}  # 기존 데이터 초기화
        
        try:
            if file_path.endswith('.csv'):
                # CSV 파일 처리
                with open(file_path, 'r', encoding='utf-8') as f:
                    reader = csv.reader(f)
                    rows = list(reader)
                header_idx = 11
                if len(rows) > header_idx:
                    header = rows[header_idx]
                    
                    # 컬럼 인덱스 찾기 (확장)
                    def find_col_idx(name, default=None):
                        try:
                            return header.index(name)
                        except ValueError:
                            return default
                    
                    url_idx = find_col_idx('플레이스 URL', 9)
                    keyword_idx = find_col_idx('작업키워드', 8)
                    main_keyword_idx = find_col_idx('메인키워드', 12)
                    agency_idx = find_col_idx('업체명/대행사명', 0)
                    start_date_idx = find_col_idx('시작일', 2)
                    end_date_idx = find_col_idx('종료일', 3)
                    used_days_idx = find_col_idx('구동일', 4)
                    daily_traffic_idx = find_col_idx('일 구동 수량', 6)
                    total_traffic_idx = find_col_idx('총 구동 수량', 5)
                    is_running_idx = find_col_idx('현재구동여부', 14)
                    product_idx = find_col_idx('진행중인 상품', 22)
                    replace_date_idx = find_col_idx('키워드 변경일', 23)
                    replace_keyword_idx = find_col_idx('변경 키워드', 24)
                    
                    for row in rows[header_idx + 1:]:
                        if len(row) > max(url_idx, keyword_idx):
                            url = row[url_idx].strip() if url_idx < len(row) else ""
                            keywords_str = row[keyword_idx].strip() if keyword_idx < len(row) else ""
                            if url:
                                url_id_match = re.search(r'/(\d+)', url)
                                keywords = []
                                if keywords_str:
                                    keywords = [kw.strip() for kw in keywords_str.split(',') if kw.strip()]
                                main_keyword_str = row[main_keyword_idx].strip() if main_keyword_idx and main_keyword_idx < len(row) else ''
                                
                                # 메인키워드 파싱
                                sido, region, category = self.parse_main_keyword(main_keyword_str) if main_keyword_str else ('', '', '')
                                
                                # 확장 정보 추출
                                agency_name = row[agency_idx].strip() if agency_idx < len(row) else ''
                                start_date = row[start_date_idx].strip() if start_date_idx and start_date_idx < len(row) else ''
                                end_date = row[end_date_idx].strip() if end_date_idx and end_date_idx < len(row) else ''
                                used_days = row[used_days_idx].strip() if used_days_idx and used_days_idx < len(row) else ''
                                daily_traffic = row[daily_traffic_idx].strip() if daily_traffic_idx and daily_traffic_idx < len(row) else ''
                                total_traffic = row[total_traffic_idx].strip() if total_traffic_idx and total_traffic_idx < len(row) else ''
                                is_running = row[is_running_idx].strip() if is_running_idx and is_running_idx < len(row) else ''
                                product = row[product_idx].strip() if product_idx and product_idx < len(row) else ''
                                replace_date = row[replace_date_idx].strip() if replace_date_idx and replace_date_idx < len(row) else ''
                                replace_keyword = row[replace_keyword_idx].strip() if replace_keyword_idx and replace_keyword_idx < len(row) else ''
                                
                                # 숫자 변환
                                try:
                                    used_days_num = int(used_days.replace(',', '')) if used_days else 0
                                except:
                                    used_days_num = 0
                                try:
                                    daily_traffic_num = int(daily_traffic.replace(',', '')) if daily_traffic else 0
                                except:
                                    daily_traffic_num = 0
                                
                                # 사용 여부 판단
                                is_used = is_running.upper() != 'X' if is_running else False
                                
                                reward_info = {
                                    'keywords': keywords,
                                    'main_keyword': {
                                        'full': main_keyword_str,
                                        'sido': sido,
                                        'region': region,
                                        'category': category
                                    },
                                    'id': url_id_match.group(1) if url_id_match else '',
                                    'agency_name': agency_name,
                                    'start_date': start_date,
                                    'end_date': end_date,
                                    'used_days': used_days_num,
                                    'daily_traffic': daily_traffic_num,
                                    'is_used': is_used,
                                    'product': product,
                                    'replace_date': replace_date,
                                    'replace_keyword': replace_keyword,
                                    'url': url
                                }
                                
                                self.reward_data[url] = reward_info
                                if url_id_match:
                                    place_id = url_id_match.group(1)
                                    if place_id not in self.reward_data:
                                        self.reward_data[place_id] = reward_info
            else:
                # Excel 파일 처리
                df = pd.read_excel(file_path)
                
                # 컬럼 찾기 (확장)
                col_map = {}
                for col in df.columns:
                    col_str = str(col).strip()
                    col_lower = col_str.lower()
                    if 'url' in col_lower or '플레이스 url' in col_str.lower():
                        col_map['url'] = col
                    elif '작업키워드' in col_str:
                        col_map['keyword'] = col
                    elif '메인키워드' in col_str:
                        col_map['main_keyword'] = col
                    elif '업체명' in col_str or '대행사' in col_str:
                        col_map['agency'] = col
                    elif col_str == '시작일':
                        col_map['start_date'] = col
                    elif col_str == '종료일':
                        col_map['end_date'] = col
                    elif col_str == '구동일':
                        col_map['used_days'] = col
                    elif '일 구동' in col_str:
                        col_map['daily_traffic'] = col
                    elif '현재구동' in col_str:
                        col_map['is_running'] = col
                    elif '진행중인 상품' in col_str:
                        col_map['product'] = col
                    elif '키워드 변경일' in col_str:
                        col_map['replace_date'] = col
                    elif '변경 키워드' in col_str:
                        col_map['replace_keyword'] = col
                
                if 'url' not in col_map or 'keyword' not in col_map:
                    messagebox.showerror("오류", "필수 컬럼을 찾을 수 없습니다.\n필요한 컬럼: 플레이스 URL, 작업키워드")
                    return
                
                for idx, row in df.iterrows():
                    try:
                        url = str(row[col_map['url']]).strip() if pd.notna(row[col_map['url']]) else ""
                        keywords_str = str(row[col_map['keyword']]).strip() if pd.notna(row[col_map['keyword']]) else ""
                        
                        if url and 'naver.com' in url:
                            url_id_match = re.search(r'/(\d+)', url)
                            keywords = []
                            if keywords_str:
                                keywords = [kw.strip() for kw in str(keywords_str).split(',') if kw.strip()]
                            
                            # 확장 정보 추출
                            def get_val(key, default=''):
                                if key in col_map and pd.notna(row[col_map[key]]):
                                    return str(row[col_map[key]]).strip()
                                return default
                            
                            main_keyword_str = get_val('main_keyword')
                            sido, region, category = self.parse_main_keyword(main_keyword_str) if main_keyword_str else ('', '', '')
                            
                            # 숫자 변환
                            used_days_str = get_val('used_days', '0')
                            daily_traffic_str = get_val('daily_traffic', '0')
                            try:
                                used_days_num = int(str(used_days_str).replace(',', ''))
                            except:
                                used_days_num = 0
                            try:
                                daily_traffic_num = int(str(daily_traffic_str).replace(',', ''))
                            except:
                                daily_traffic_num = 0
                            
                            # 사용 여부
                            is_running_str = get_val('is_running')
                            is_used = is_running_str.upper() != 'X' if is_running_str else False
                            
                            reward_info = {
                                'keywords': keywords,
                                'main_keyword': {
                                    'full': main_keyword_str,
                                    'sido': sido,
                                    'region': region,
                                    'category': category
                                },
                                'id': url_id_match.group(1) if url_id_match else '',
                                'agency_name': get_val('agency'),
                                'start_date': get_val('start_date'),
                                'end_date': get_val('end_date'),
                                'used_days': used_days_num,
                                'daily_traffic': daily_traffic_num,
                                'is_used': is_used,
                                'product': get_val('product'),
                                'replace_date': get_val('replace_date'),
                                'replace_keyword': get_val('replace_keyword'),
                                'url': url
                            }
                            
                            self.reward_data[url] = reward_info
                            if url_id_match:
                                place_id = url_id_match.group(1)
                                if place_id not in self.reward_data:
                                    self.reward_data[place_id] = reward_info
                    except Exception as e:
                        continue
            
            if hasattr(self, 'status_var'):
                self.status_var.set(f"Reward_data 로드 완료: {len(self.reward_data)}개")
            if hasattr(self, 'root') and self.root:
                messagebox.showinfo("완료", f"Reward_data 로드 완료:\n{len(self.reward_data)}개 업체")
            else:
                print(f"Reward_data 로드 완료: {len(self.reward_data)}개")
            
        except Exception as e:
            error_msg = f"Reward_data 로드 실패:\n{str(e)}"
            if hasattr(self, 'root') and self.root:
                messagebox.showerror("오류", error_msg)
            else:
                print(f"오류: {error_msg}")
            import traceback
            traceback.print_exc()
    
    def update_work_keywords(self, file_path):
        """작업 키워드 탭 업데이트"""
        if file_path not in self.parsed_data:
            return
        data = self.parsed_data[file_path]
        url = data.get('url', '')
        mid = data.get('mid', '')
        existing_keywords = []
        main_keyword = ''
        if mid:
            if mid in self.reward_data:
                reward_data = self.reward_data[mid]
                existing_keywords = reward_data.get('keywords', [])
                main_keyword_dict = reward_data.get('main_keyword', {})
                main_keyword = main_keyword_dict.get('full', '') if isinstance(main_keyword_dict, dict) else main_keyword_dict
            else:
                for reward_url, reward_data in self.reward_data.items():
                    url_id = reward_data.get('id', '')
                    if url_id == mid:
                        existing_keywords = reward_data.get('keywords', [])
                        main_keyword_dict = reward_data.get('main_keyword', {})
                        main_keyword = main_keyword_dict.get('full', '') if isinstance(main_keyword_dict, dict) else main_keyword_dict
                        break
        if not existing_keywords and url:
            url_variants = [
                url,
                url.replace('https://m.place.naver.com/', ''),
                url.replace('https://map.naver.com/', ''),
                url.replace('https://m.place.naver.com/', '').replace('/', ''),
            ]
            for variant in url_variants:
                if variant in self.reward_data:
                    existing_keywords = self.reward_data[variant].get('keywords', [])
                    main_keyword_dict = self.reward_data[variant].get('main_keyword', {})
                    main_keyword = main_keyword_dict.get('full', '') if isinstance(main_keyword_dict, dict) else main_keyword_dict
                    break
        self.existing_keywords_text.delete(1.0, tk.END)
        if existing_keywords:
            keyword_text = f"메인 키워드: {main_keyword}\n\n" if main_keyword else ""
            keyword_text += f"작업 키워드 ({len(existing_keywords)}개):\n"
            for kw in existing_keywords:
                keyword_text += f"{kw}\n"
        else:
            keyword_text = "작업 키워드 정보가 없습니다."
        self.existing_keywords_text.insert(1.0, keyword_text)
        if data:
            groups = self.keyword_generator.generate_all_groups(data, existing_keywords)
            self.group1_text.delete(1.0, tk.END)
            if groups['group1']:
                group1_text = f"지역키 ({len(groups['group1'])}개):\n\n"
                for kw in groups['group1']:
                    group1_text += f"{kw}\n"
            else:
                group1_text = "생성된 지역키가 없습니다."
            self.group1_text.insert(1.0, group1_text)
            self.group2_text.delete(1.0, tk.END)
            if groups['group2']:
                group2_text = f"메뉴키 ({len(groups['group2'])}개):\n\n"
                for kw in groups['group2']:
                    group2_text += f"{kw}\n"
            else:
                group2_text = "생성된 메뉴키가 없습니다."
            self.group2_text.insert(1.0, group2_text)
            self.group3_text.delete(1.0, tk.END)
            if groups['group3']:
                group3_text = f"업종키 ({len(groups['group3'])}개):\n\n"
                for kw in groups['group3']:
                    group3_text += f"{kw}\n"
            else:
                group3_text = "생성된 업종키가 없습니다."
            self.group3_text.insert(1.0, group3_text)
    
    def select_json_folder(self):
        """JSON 파일 폴더 선택"""
        folder = filedialog.askdirectory(
            title="JSON 파일 폴더 선택",
            initialdir=Path(__file__).parent / "rawdata_json" if Path(__file__).parent.exists() else os.path.dirname(__file__)
        )
        if folder:
            self.json_data_dir = folder
            self.json_folder_path_var.set(folder)
            # 현재 선택된 업체의 키워드 상태 업데이트
            if self.current_file:
                data = self.parsed_data.get(self.current_file)
                if data:
                    self.update_keyword_status(self.current_file, data)
    
    # ==================== 키워드 필터 함수들 ====================
    
    def select_kw_folder(self, var):
        """폴더 선택 다이얼로그"""
        folder = filedialog.askdirectory()
        if folder:
            var.set(folder)
    
    def load_keywords_for_mid(self, mid):
        """MID로 키워드 데이터 로드"""
        if not mid:
            return []
        keyword_dir = Path(self.keyword_json_path_var.get())
        if not keyword_dir.exists():
            return []
        
        for json_file in keyword_dir.glob(f"*_{mid}.json"):
            try:
                with open(json_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                return data.get('keywords', [])
            except:
                pass
        return []
    
    def load_all_keywords(self):
        """현재 업체의 전체 키워드 로드"""
        if hasattr(self, 'current_file') and self.current_file:
            data = self.parsed_data.get(self.current_file)
            if data:
                mid = data.get('mid', '')
                if mid:
                    self.current_mid = mid
                    keywords = self.load_keywords_for_mid(mid)
                    if keywords:
                        self.display_keywords(keywords)
                        self.filter_result_label.config(text=f"결과: {len(keywords)}개")
                        return
        messagebox.showinfo("알림", "먼저 업체를 선택하세요")
    
    def apply_keyword_filter(self):
        """필터 적용"""
        # 현재 선택된 업체의 MID 가져오기
        if not self.current_mid:
            if hasattr(self, 'current_file') and self.current_file:
                data = self.parsed_data.get(self.current_file)
                if data:
                    self.current_mid = data.get('mid', '')
        
        if not self.current_mid:
            messagebox.showwarning("경고", "먼저 업체를 선택하세요")
            return
        
        # 키워드 로드
        all_keywords = self.load_keywords_for_mid(self.current_mid)
        if not all_keywords:
            messagebox.showinfo("알림", "키워드 데이터가 없습니다")
            return
        
        # 필터 적용
        filtered = all_keywords
        
        # 순위 필터
        rank_filter = self.filter_rank_var.get()
        if rank_filter == '1-5위':
            filtered = [k for k in filtered if k.get('rank') is not None and k['rank'] <= 5]
        elif rank_filter == '6-10위':
            filtered = [k for k in filtered if k.get('rank') is not None and 6 <= k['rank'] <= 10]
        elif rank_filter == '10위밖':
            filtered = [k for k in filtered if k.get('rank') is not None and k['rank'] > 10]
        elif rank_filter == '순위권밖':
            filtered = [k for k in filtered if k.get('rank') is None]
        
        # 체크박스 필터
        if self.filter_top_var.get():
            filtered = [k for k in filtered if k.get('is_top') == True]
        if self.filter_no_cpc_var.get():
            filtered = [k for k in filtered if k.get('has_cpc') == False]
        if self.filter_single_var.get():
            filtered = [k for k in filtered if k.get('is_single') == True]
        if self.filter_task_var.get():
            filtered = [k for k in filtered if k.get('is_task_keyword') == True]
        if self.filter_not_task_var.get():
            filtered = [k for k in filtered if k.get('is_task_keyword') == False]
        
        # 결과 표시
        self.display_keywords(filtered)
        self.filter_result_label.config(text=f"결과: {len(filtered)}개")
    
    def reset_keyword_filter(self):
        """필터 초기화"""
        self.filter_rank_var.set("전체")
        self.filter_top_var.set(False)
        self.filter_no_cpc_var.set(False)
        self.filter_single_var.set(False)
        self.filter_task_var.set(False)
        self.filter_not_task_var.set(False)
        self.preset_var.set("선택")
        if self.current_mid:
            self.apply_keyword_filter()
    
    def apply_preset_filter(self, event=None):
        """프리셋 적용"""
        preset = self.preset_var.get()
        
        # 초기화
        self.filter_rank_var.set("전체")
        self.filter_top_var.set(False)
        self.filter_no_cpc_var.set(False)
        self.filter_single_var.set(False)
        self.filter_task_var.set(False)
        self.filter_not_task_var.set(False)
        
        if preset == '성공조건(5위+최상단+CPC없음)':
            self.filter_rank_var.set("1-5위")
            self.filter_top_var.set(True)
            self.filter_no_cpc_var.set(True)
        elif preset == '단일+최상단':
            self.filter_single_var.set(True)
            self.filter_top_var.set(True)
        elif preset == '단일만':
            self.filter_single_var.set(True)
        elif preset == '순위권밖':
            self.filter_rank_var.set("순위권밖")
        
        if self.current_mid:
            self.apply_keyword_filter()
    
    def display_keywords(self, keywords):
        """키워드 목록 표시"""
        self.keyword_tree.delete(*self.keyword_tree.get_children())
        self.current_keywords = keywords
        self.selected_keywords.clear()
        
        for kw in keywords:
            rank_str = str(kw.get('rank')) if kw.get('rank') is not None else '-'
            is_top_str = '✅' if kw.get('is_top') == True else '❌'
            has_cpc_str = '✅' if kw.get('has_cpc') == True else '❌'
            is_single_str = '✅' if kw.get('is_single') == True else '❌'
            
            self.keyword_tree.insert('', 'end', values=(
                '☐',
                kw.get('keyword', ''),
                rank_str,
                is_top_str,
                has_cpc_str,
                kw.get('place_count', 0),
                is_single_str,
                kw.get('section_status', '')
            ))
    
    def toggle_keyword_selection(self, event):
        """키워드 선택 토글"""
        item = self.keyword_tree.identify_row(event.y)
        if not item:
            return
        
        values = list(self.keyword_tree.item(item, 'values'))
        keyword = values[1]
        
        if keyword in self.selected_keywords:
            self.selected_keywords.remove(keyword)
            values[0] = '☐'
        else:
            self.selected_keywords.add(keyword)
            values[0] = '☑'
        
        self.keyword_tree.item(item, values=values)
    
    def select_all_keywords(self):
        """전체 선택"""
        for item in self.keyword_tree.get_children():
            values = list(self.keyword_tree.item(item, 'values'))
            keyword = values[1]
            self.selected_keywords.add(keyword)
            values[0] = '☑'
            self.keyword_tree.item(item, values=values)
    
    def deselect_all_keywords(self):
        """선택 해제"""
        self.selected_keywords.clear()
        for item in self.keyword_tree.get_children():
            values = list(self.keyword_tree.item(item, 'values'))
            values[0] = '☐'
            self.keyword_tree.item(item, values=values)
    
    def copy_selected_keywords(self):
        """선택한 키워드 복사"""
        if not self.selected_keywords:
            messagebox.showinfo("알림", "선택된 키워드가 없습니다")
            return
        
        mode = self.copy_mode_var.get()
        lines = []
        
        for kw in self.current_keywords:
            if kw.get('keyword') in self.selected_keywords:
                if mode == '키워드만':
                    lines.append(kw.get('keyword', ''))
                elif mode == '키워드+순위':
                    rank = kw.get('rank') if kw.get('rank') is not None else '-'
                    lines.append(f"{kw.get('keyword', '')}\t{rank}")
                else:  # 전체정보
                    rank = kw.get('rank') if kw.get('rank') is not None else '-'
                    top = 'O' if kw.get('is_top') else 'X'
                    cpc = 'O' if kw.get('has_cpc') else 'X'
                    single = 'O' if kw.get('is_single') else 'X'
                    lines.append(f"{kw.get('keyword', '')}\t{rank}\t{top}\t{cpc}\t{kw.get('place_count', 0)}\t{single}")
        
        text = '\n'.join(lines)
        self.root.clipboard_clear()
        self.root.clipboard_append(text)
        messagebox.showinfo("복사 완료", f"{len(lines)}개 키워드가 클립보드에 복사되었습니다")
    
    def copy_all_keywords(self):
        """전체 키워드 복사"""
        self.select_all_keywords()
        self.copy_selected_keywords()
    
    def create_missing_keyword_json_files(self):
        """rawdata_json에 있지만 rawdata_keyword_json에 없는 업체들의 기본 파일 생성"""
        rawdata_json_dir = Path(__file__).parent / "rawdata_json"
        keyword_json_dir = Path(__file__).parent / "rawdata_keyword_json"
        
        keyword_json_dir.mkdir(exist_ok=True)
        
        # rawdata_json의 모든 파일 읽기
        rawdata_files = list(rawdata_json_dir.glob("*.json"))
        if not rawdata_files:
            messagebox.showwarning("경고", "rawdata_json 폴더에 파일이 없습니다.")
            return
        
        # rawdata_keyword_json의 기존 파일 MID 수집
        existing_mids = set()
        for keyword_file in keyword_json_dir.glob("*_키워드검색결과_*.json"):
            mid_match = re.search(r'_키워드검색결과_(\d+)\.json$', keyword_file.name)
            if mid_match:
                existing_mids.add(mid_match.group(1))
        
        created_count = 0
        skipped_count = 0
        error_count = 0
        
        self.status_var.set("누락된 keyword_json 파일 생성 중...")
        self.root.update()
        
        for rawdata_file in rawdata_files:
            try:
                # rawdata_json 파일 읽기
                with open(rawdata_file, 'r', encoding='utf-8') as f:
                    rawdata = json.load(f)
                
                mid = self.normalize_mid(rawdata.get('mid', ''))
                if not mid:
                    continue
                
                # 이미 keyword_json 파일이 있는지 확인
                if mid in existing_mids:
                    skipped_count += 1
                    continue
                
                # 업체명 가져오기
                company_name = rawdata.get('name', f"업체_{mid}")
                
                # 메인 키워드 정보 가져오기 (rawdata_json의 keyword_status.main_keyword에서)
                main_keyword_info = {}
                keyword_status_from_raw = rawdata.get('keyword_status', {})
                if keyword_status_from_raw:
                    main_keyword_from_raw = keyword_status_from_raw.get('main_keyword', {})
                    if main_keyword_from_raw:
                        main_keyword_info = {
                            "full": main_keyword_from_raw.get('full', None),
                            "sido": main_keyword_from_raw.get('sido', None),
                            "region": main_keyword_from_raw.get('region', None),
                            "category": main_keyword_from_raw.get('category', None)
                        }
                
                # 메인 키워드가 없으면 빈 값
                if not main_keyword_info or not main_keyword_info.get('full'):
                    main_keyword_info = {
                        "full": None,
                        "sido": None,
                        "region": None,
                        "category": None
                    }
                
                # 파일명 생성
                safe_company_name = re.sub(r'[<>:"/\\|?*\n\r\t]', '_', company_name).strip()
                safe_company_name = re.sub(r'\s+', ' ', safe_company_name)
                if not safe_company_name:
                    safe_company_name = f"업체_{mid}"
                
                keyword_json_file = keyword_json_dir / f"{safe_company_name}_키워드검색결과_{mid}.json"
                
                # 기본 keyword_json 구조 생성
                keyword_json_data = {
                    "mid": mid,
                    "company_name": company_name,
                    "main_keyword": main_keyword_info,
                    "total_keywords_from_excel": 0,
                    "excel_keywords": [],
                    "keyword_status": {
                        "success_keywords": [],
                        "failed_in_top5_keywords": [],
                        "failed_cpc_keywords": [],
                        "failed_not_top_keywords": [],
                        "failed_not_top_cpc_keywords": [],
                        "failed_out_of_top5_keywords": [],
                        "not_place_keywords": [],
                        "searched_keywords": [],
                        "main_keyword": main_keyword_info,
                        "task_keywords": [],
                        "updated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                        "source": "initial_creation"
                    },
                    "search_results": {
                        "success_keywords": [],
                        "failed_in_top5_keywords": [],
                        "failed_cpc_keywords": [],
                        "failed_not_top_keywords": [],
                        "failed_not_top_cpc_keywords": [],
                        "failed_out_of_top5_keywords": [],
                        "not_place_keywords": []
                    },
                    "statistics": {
                        "total_success": 0,
                        "total_failed_in_top5": 0,
                        "total_failed_cpc": 0,
                        "total_failed_not_top": 0,
                        "total_failed_not_top_cpc": 0,
                        "total_failed_out_of_top5": 0,
                        "total_not_place_keywords": 0
                    },
                    "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                }
                
                # 파일 저장
                with open(keyword_json_file, 'w', encoding='utf-8') as f:
                    json.dump(keyword_json_data, f, ensure_ascii=False, indent=2)
                
                created_count += 1
                
                if created_count % 10 == 0:
                    self.status_var.set(f"생성 중... {created_count}개 완료")
                    self.root.update()
                
            except Exception as e:
                error_count += 1
                print(f"오류 ({rawdata_file.name}): {e}")
                continue
        
        self.status_var.set(f"완료: {created_count}개 생성, {skipped_count}개 스킵")
        messagebox.showinfo("완료", 
            f"누락된 keyword_json 파일 생성 완료!\n\n신규 생성: {created_count}개\n기존 파일 (스킵): {skipped_count}개\n오류: {error_count}개\n총 rawdata_json 파일: {len(rawdata_files)}개")
    
    def update_keyword_status(self, file_path, parsed_data):
        """키워드 상태 정보 업데이트 (JSON에서 로드) - rawdata_keyword_json 우선"""
        mid = parsed_data.get('mid', '')
        name = parsed_data.get('name', '')
        
        # current_mid 설정 및 키워드 자동 로드
        if mid:
            self.current_mid = mid
            keywords = self.load_keywords_for_mid(mid)
            if keywords:
                self.display_keywords(keywords)
                self.filter_result_label.config(text=f"결과: {len(keywords)}개")
        
        # rawdata_keyword_json 폴더 우선 시도
        keyword_json_dir = Path(__file__).parent / "rawdata_keyword_json"
        json_file = None
        
        if mid:
            # MID로 찾기 (예: 가얏골감자탕_키워드검색결과_21239074.json)
            json_files = list(keyword_json_dir.glob(f"*{mid}.json"))
            if json_files:
                json_file = json_files[0]
        
        # rawdata_keyword_json에 없으면 rawdata_json 시도
        if not json_file:
            if not self.json_data_dir:
                default_json_dir = Path(__file__).parent / "rawdata_json"
                if default_json_dir.exists():
                    self.json_data_dir = str(default_json_dir)
                    if hasattr(self, 'json_folder_path_var'):
                        self.json_folder_path_var.set(str(default_json_dir))
            
            if self.json_data_dir:
                json_dir_path = Path(self.json_data_dir)
                if json_dir_path.exists():
                    if mid:
                        json_files = list(json_dir_path.glob(f"*_{mid}.json"))
                        if json_files:
                            json_file = json_files[0]
                    
                    if not json_file and name:
                        safe_name = re.sub(r'[<>:"/\\|?*]', '_', name)
                        json_files = list(json_dir_path.glob(f"{safe_name}*.json"))
                        if json_files:
                            json_file = json_files[0]
                    
                    if not json_file:
                        # 모든 JSON 파일 검색하여 MID나 이름으로 매칭
                        for json_path in json_dir_path.glob("*.json"):
                            try:
                                with open(json_path, 'r', encoding='utf-8') as f:
                                    json_data = json.load(f)
                                json_mid = json_data.get('mid', '')
                                json_name = json_data.get('name', '')
                                
                                if mid and json_mid == mid:
                                    json_file = json_path
                                    break
                                if name and json_name == name:
                                    json_file = json_path
                                    break
                            except:
                                continue
        
        if not json_file:
            self.clear_keyword_status()
            return
        
        # JSON 파일 로드 및 표시
        try:
            with open(json_file, 'r', encoding='utf-8') as f:
                json_data = json.load(f)
            
            # 새로운 구조 (rawdata_keyword_json) 또는 기존 구조 (rawdata_json) 지원
            keyword_status = json_data.get('keyword_status', {})

            # 새 구조 감지 (keywords 배열)
            keywords_array = json_data.get('keywords', [])
            is_new_structure = (isinstance(keywords_array, list) and 
                len(keywords_array) > 0 and isinstance(keywords_array[0], dict))
            
            if is_new_structure:
                all_kw = keywords_array
                # 명시적 비교로 None 문제 해결
                in_top5 = [k for k in all_kw if k.get('rank') is not None and k['rank'] <= 5]
                top_kw = [k for k in all_kw if k.get('is_top') == True]
                single_kw = [k for k in all_kw if k.get('is_single') == True]
                no_cpc = [k for k in all_kw if k.get('has_cpc') == False]
                has_cpc_kw = [k for k in all_kw if k.get('has_cpc') == True]
                task_kw = [k for k in all_kw if k.get('is_task_keyword') == True]
                out_of_rank = [k for k in all_kw if k.get('rank') is None]
                success_kw = [k for k in all_kw if k.get('rank') is not None and k['rank'] <= 5 
                    and k.get('is_top') == True and k.get('has_cpc') == False]
                
                stats_text = f"""📊 키워드 통계
{'='*60}

전체: {len(all_kw)}개 | 5위이내: {len(in_top5)}개 | 최상단: {len(top_kw)}개
단일: {len(single_kw)}개 | CPC없음: {len(no_cpc)}개 | 작업키: {len(task_kw)}개
성공(5위+최상단+CPC없음): {len(success_kw)}개 | 순위권밖: {len(out_of_rank)}개
"""
                self.keyword_stats_text.delete(1.0, tk.END)
                self.keyword_stats_text.insert(1.0, stats_text)
                
                task_text = f"작업 키워드 ({len(task_kw)}개):\n\n"
                for k in task_kw:
                    r = f"{k['rank']}위" if k.get('rank') else "순위권밖"
                    task_text += f"{k['keyword']} ({r})\n"
                self.task_keywords_text.delete(1.0, tk.END)
                self.task_keywords_text.insert(1.0, task_text)
                
                in5_text = f"5위 이내 ({len(in_top5)}개):\n\n"
                for k in sorted(in_top5, key=lambda x: x.get('rank', 999)):
                    tags = []
                    if k.get('is_top'): tags.append("최상단")
                    if k.get('has_cpc'): tags.append("CPC")
                    if k.get('is_single'): tags.append("단일")
                    in5_text += f"{k['keyword']} ({k['rank']}위) {' '.join(tags)}\n"
                self.searched_keywords_text.delete(1.0, tk.END)
                self.searched_keywords_text.insert(1.0, in5_text)
                
                suc_text = f"성공 키워드 ({len(success_kw)}개):\n\n"
                for k in success_kw:
                    suc_text += f"{k['keyword']} ({k['rank']}위)\n"
                self.success_main_included_text.delete(1.0, tk.END)
                self.success_main_included_text.insert(1.0, suc_text)
                self.success_main_not_included_text.delete(1.0, tk.END)
                
                out_text = f"순위권 밖 ({len(out_of_rank)}개):\n\n"
                for k in out_of_rank:
                    out_text += f"{k['keyword']}\n"
                self.failed_keywords_text.delete(1.0, tk.END)
                self.failed_keywords_text.insert(1.0, out_text)
                
                top_text = f"최상단 ({len(top_kw)}개):\n\n"
                for k in top_kw:
                    r = f"{k['rank']}위" if k.get('rank') else ""
                    top_text += f"{k['keyword']} {r}\n"
                self.failed_top5_main_included_text.delete(1.0, tk.END)
                self.failed_top5_main_included_text.insert(1.0, top_text)
                
                single_text = f"단일 키워드 ({len(single_kw)}개):\n\n"
                for k in single_kw:
                    r = f"{k['rank']}위" if k.get('rank') else ""
                    single_text += f"{k['keyword']} {r}\n"
                self.failed_top5_main_not_included_text.delete(1.0, tk.END)
                self.failed_top5_main_not_included_text.insert(1.0, single_text)
                
                self.remaining_keywords_text.delete(1.0, tk.END)
                main_kw = json_data.get('main_keyword', {})
                self.main_keyword_text.delete(1.0, tk.END)
                self.main_keyword_text.insert(1.0, f"메인: {main_kw.get('full', '없음')}")
                return
            

            
            # statistics는 search_results나 statistics 필드에서 가져오기
            statistics = json_data.get('statistics', {})
            if not statistics:
                statistics = json_data.get('keyword_statistics', {})
            
            # main_keyword는 keyword_status 안에 있거나 최상위에 있음
            main_keyword_info = keyword_status.get('main_keyword', {})
            if not main_keyword_info:
                main_keyword_info = json_data.get('main_keyword', {})
            
            # JSON에 메인키워드 정보가 없으면 reward_data (CSV)에서 가져오기
            if not main_keyword_info or not main_keyword_info.get('full'):
                mid = json_data.get('mid', '')
                
                # MID로 reward_data 검색
                if mid:
                    # 직접 MID 키로 찾기
                    if mid in self.reward_data:
                        reward_main_keyword = self.reward_data[mid].get('main_keyword', {})
                        if isinstance(reward_main_keyword, dict) and reward_main_keyword.get('full'):
                            main_keyword_info = reward_main_keyword
                    
                    # URL로 찾기 (reward_data에 URL 키로 저장된 경우)
                    if not main_keyword_info or not main_keyword_info.get('full'):
                        for key, value in self.reward_data.items():
                            if value.get('id', '') == mid:
                                reward_main_keyword = value.get('main_keyword', {})
                                if isinstance(reward_main_keyword, dict) and reward_main_keyword.get('full'):
                                    main_keyword_info = reward_main_keyword
                                    break
            
            # 여전히 없으면 빈 딕셔너리로 초기화
            if not main_keyword_info:
                main_keyword_info = {}
            
            # 통계 탭 (새로운 구조 지원)
            total_keywords = json_data.get('total_keywords_from_excel', 0)
            if not total_keywords:
                total_keywords = len(json_data.get('excel_keywords', []))
            
            stats_text = f"""📊 키워드 통계
{'='*60}

Excel 키워드 수: {total_keywords}개
검색 키워드: {len(keyword_status.get('searched_keywords', []))}개
성공 키워드: {statistics.get('total_success', len(keyword_status.get('success_keywords', [])))}개
실패 키워드 (5위 이내): {statistics.get('total_failed_in_top5', len(keyword_status.get('failed_in_top5_keywords', [])))}개
실패 키워드 (CPC): {statistics.get('total_failed_cpc', len(keyword_status.get('failed_cpc_keywords', [])))}개
실패 키워드 (최상단 아님): {statistics.get('total_failed_not_top', len(keyword_status.get('failed_not_top_keywords', [])))}개
실패 키워드 (최상단 아님 + CPC): {statistics.get('total_failed_not_top_cpc', len(keyword_status.get('failed_not_top_cpc_keywords', [])))}개
실패 키워드 (5위 밖): {statistics.get('total_failed_out_of_top5', len(keyword_status.get('failed_out_of_top5_keywords', [])))}개
플레이스 섹션 없음: {statistics.get('total_not_place_keywords', len(keyword_status.get('not_place_keywords', [])))}개

마지막 업데이트: {keyword_status.get('updated_at', keyword_status.get('last_updated', '정보 없음'))}
"""
            self.keyword_stats_text.delete(1.0, tk.END)
            self.keyword_stats_text.insert(1.0, stats_text)
            
            # 작업 키워드
            task_keywords = keyword_status.get('task_keywords', [])
            task_text = f"작업 키워드 ({len(task_keywords)}개):\n\n"
            for kw in task_keywords:
                task_text += f"{kw}\n"
            self.task_keywords_text.delete(1.0, tk.END)
            self.task_keywords_text.insert(1.0, task_text)
            
            # 검색 키워드
            searched_keywords = keyword_status.get('searched_keywords', [])
            searched_text = f"검색 키워드 ({len(searched_keywords)}개):\n\n"
            for kw in searched_keywords:  # 제한 없음 - 모든 키워드 표시
                searched_text += f"{kw}\n"
            self.searched_keywords_text.delete(1.0, tk.END)
            self.searched_keywords_text.insert(1.0, searched_text)
            
            # 성공 키워드 (새로운 구조에서는 메인키 포함/미포함 분리 없음, 전체만 표시)
            success_keywords = keyword_status.get('success_keywords', [])
            # 메인키 포함/미포함 분류 시도 (기존 구조 호환)
            success_main_included = keyword_status.get('success_keywords_main_included', [])
            success_main_not_included = keyword_status.get('success_keywords_main_not_included', [])
            
            if not success_main_included and not success_main_not_included:
                # 메인키 포함/미포함 분류가 없으면 전체를 표시
                success_included_text = f"성공 키워드 ({len(success_keywords)}개)\n(변형이 적은 순으로 정렬됨)\n\n"
                for kw in success_keywords:
                    success_included_text += f"{kw}\n"
                self.success_main_included_text.delete(1.0, tk.END)
                self.success_main_included_text.insert(1.0, success_included_text)
                self.success_main_not_included_text.delete(1.0, tk.END)
                self.success_main_not_included_text.insert(1.0, "메인키 미포함 분류 정보가 없습니다.")
            else:
                success_included_text = f"성공 키워드 - 메인키 포함 ({len(success_main_included)}개)\n(변형이 적은 순으로 정렬됨)\n\n"
                for kw in success_main_included:
                    success_included_text += f"{kw}\n"
                self.success_main_included_text.delete(1.0, tk.END)
                self.success_main_included_text.insert(1.0, success_included_text)
                
                success_not_included_text = f"성공 키워드 - 메인키 미포함 ({len(success_main_not_included)}개):\n\n"
                for kw in success_main_not_included:
                    success_not_included_text += f"{kw}\n"
                self.success_main_not_included_text.delete(1.0, tk.END)
                self.success_main_not_included_text.insert(1.0, success_not_included_text)
            
            # 실패 키워드 (새로운 7가지 분류 모두 표시)
            failed_in_top5 = keyword_status.get('failed_in_top5_keywords', [])
            failed_cpc = keyword_status.get('failed_cpc_keywords', [])
            failed_not_top = keyword_status.get('failed_not_top_keywords', [])
            failed_not_top_cpc = keyword_status.get('failed_not_top_cpc_keywords', [])
            failed_out_of_top5 = keyword_status.get('failed_out_of_top5_keywords', [])
            not_place = keyword_status.get('not_place_keywords', [])
            
            # 전체 실패 키워드 (모든 분류 합치기)
            all_failed = set(failed_in_top5) | set(failed_cpc) | set(failed_not_top) | set(failed_not_top_cpc) | set(failed_out_of_top5) | set(not_place)
            failed_text = f"실패 키워드 (전체) ({len(all_failed)}개):\n\n"
            failed_text += f"  - 5위 이내: {len(failed_in_top5)}개\n"
            failed_text += f"  - CPC 광고: {len(failed_cpc)}개\n"
            failed_text += f"  - 최상단 아님: {len(failed_not_top)}개\n"
            failed_text += f"  - 최상단 아님 + CPC: {len(failed_not_top_cpc)}개\n"
            failed_text += f"  - 5위 밖: {len(failed_out_of_top5)}개\n"
            failed_text += f"  - 플레이스 섹션 없음: {len(not_place)}개\n\n"
            
            for kw in list(all_failed):  # 제한 없음 - 모든 키워드 표시
                failed_text += f"{kw}\n"
            self.failed_keywords_text.delete(1.0, tk.END)
            self.failed_keywords_text.insert(1.0, failed_text)
            
            # 실패 키워드 (5위 이내, 메인키 포함/미포함) - 기존 구조 호환
            failed_top5_main_included = keyword_status.get('failed_in_top5_main_included', [])
            failed_top5_main_not_included = keyword_status.get('failed_in_top5_main_not_included', [])
            
            if not failed_top5_main_included and not failed_top5_main_not_included:
                # 메인키 포함/미포함 분류가 없으면 5위 이내 전체를 표시
                failed_top5_included_text = f"5위 이내 실패 키워드 ({len(failed_in_top5)}개)\n(변형이 적은 순으로 정렬됨)\n\n"
                for kw in failed_in_top5:
                    failed_top5_included_text += f"{kw}\n"
                self.failed_top5_main_included_text.delete(1.0, tk.END)
                self.failed_top5_main_included_text.insert(1.0, failed_top5_included_text)
                self.failed_top5_main_not_included_text.delete(1.0, tk.END)
                self.failed_top5_main_not_included_text.insert(1.0, "메인키 미포함 분류 정보가 없습니다.")
            else:
                failed_top5_included_text = f"5위 이내 실패 키워드 - 메인키 포함 ({len(failed_top5_main_included)}개)\n(변형이 적은 순으로 정렬됨)\n\n"
                for kw in failed_top5_main_included:
                    failed_top5_included_text += f"{kw}\n"
                self.failed_top5_main_included_text.delete(1.0, tk.END)
                self.failed_top5_main_included_text.insert(1.0, failed_top5_included_text)
                
                failed_top5_not_included_text = f"5위 이내 실패 키워드 - 메인키 미포함 ({len(failed_top5_main_not_included)}개):\n\n"
                for kw in failed_top5_main_not_included:
                    failed_top5_not_included_text += f"{kw}\n"
                self.failed_top5_main_not_included_text.delete(1.0, tk.END)
                self.failed_top5_main_not_included_text.insert(1.0, failed_top5_not_included_text)
            
            # 남은 키워드
            remaining_keywords = keyword_status.get('remaining_keywords', [])
            if not remaining_keywords:
                # task_keywords에서 searched_keywords를 뺀 값
                task_keywords = set(keyword_status.get('task_keywords', []))
                searched_keywords = set(keyword_status.get('searched_keywords', []))
                remaining_keywords = list(task_keywords - searched_keywords)
            
            remaining_text = f"남은 키워드 ({len(remaining_keywords)}개):\n\n"
            for kw in remaining_keywords:
                remaining_text += f"{kw}\n"
            self.remaining_keywords_text.delete(1.0, tk.END)
            self.remaining_keywords_text.insert(1.0, remaining_text)
            
            # 메인 키워드
            main_keyword_text = f"""메인 키워드 정보
{'='*60}

전체: {main_keyword_info.get('full', '정보 없음')}
시도: {main_keyword_info.get('sido', '없음')}
지역: {main_keyword_info.get('region', '없음')}
업종: {main_keyword_info.get('category', '없음')}

※ 메인키워드는 CSV의 M열(메인키워드 컬럼)에서 가져온 정보입니다.
"""
            self.main_keyword_text.delete(1.0, tk.END)
            self.main_keyword_text.insert(1.0, main_keyword_text)
            
            # 키워드 상태 업데이트 후 스크롤 영역 갱신
            if hasattr(self, 'update_info_scroll_region'):
                self.root.after_idle(self.update_info_scroll_region)
            
        except Exception as e:
            error_text = f"JSON 파일 로드 실패:\n{str(e)}"
            self.keyword_stats_text.delete(1.0, tk.END)
            self.keyword_stats_text.insert(1.0, error_text)
    
    def clear_keyword_status(self):
        """키워드 상태 탭 초기화"""
        self.keyword_stats_text.delete(1.0, tk.END)
        self.keyword_stats_text.insert(1.0, "JSON 폴더를 선택하고 업체를 선택하면 키워드 상태 정보가 표시됩니다.")
        self.task_keywords_text.delete(1.0, tk.END)
        self.searched_keywords_text.delete(1.0, tk.END)
        self.success_main_included_text.delete(1.0, tk.END)
        self.success_main_not_included_text.delete(1.0, tk.END)
        self.failed_keywords_text.delete(1.0, tk.END)
        self.failed_top5_main_included_text.delete(1.0, tk.END)
        self.failed_top5_main_not_included_text.delete(1.0, tk.END)
        self.remaining_keywords_text.delete(1.0, tk.END)
        self.main_keyword_text.delete(1.0, tk.END)
    
    def update_summary_table(self):
        """요약 테이블 업데이트"""
        for item in self.summary_tree.get_children():
            self.summary_tree.delete(item)
        for file_path, data in self.parsed_data.items():
            around = data.get('around_places', {})
            menus = data.get('menus', [])
            values = (
                data.get('name', ''),
                data.get('mid', ''),
                data.get('phone', ''),
                len(around.get('stations', [])),
                len(around.get('apartments', [])),
                len(around.get('landmarks', [])),
                len(menus),
                data.get('url', '')[:50] + '...' if len(data.get('url', '')) > 50 else data.get('url', '')
            )
            item = self.summary_tree.insert('', tk.END, values=values, tags=(file_path,))
        if self.parsed_data:
            self.status_var.set(f"파싱 완료: {len(self.parsed_data)}개 | 요약 테이블 업데이트 완료")
    
    def on_summary_double_click(self, event):
        """요약 테이블 더블클릭 시 해당 업체 상세 정보 표시"""
        selection = self.summary_tree.selection()
        if not selection:
            return
        item = selection[0]
        tags = self.summary_tree.item(item, 'tags')
        if tags:
            file_path = tags[0]
            for idx, (fp, name) in enumerate(self.filtered_place_files):
                if fp == file_path:
                    self.place_listbox.selection_clear(0, tk.END)
                    self.place_listbox.selection_set(idx)
                    self.place_listbox.see(idx)
                    self.on_place_selected(None)
                    self.place_notebook.select(1)
                    break
    
    def save_to_excel(self):
        """Excel 파일로 저장"""
        if not self.parsed_data:
            messagebox.showwarning("경고", "저장할 데이터가 없습니다. 먼저 파싱을 실행하세요.")
            return
        try:
            import pandas as pd
        except ImportError:
            messagebox.showerror("오류", "pandas와 openpyxl이 필요합니다.\npip install pandas openpyxl")
            return
        file_path = filedialog.asksaveasfilename(
            title="Excel 파일로 저장",
            defaultextension=".xlsx",
            filetypes=[("Excel 파일", "*.xlsx"), ("모든 파일", "*.*")]
        )
        if not file_path:
            return
        try:
            self.status_var.set("Excel 저장 중...")
            self.root.update()
            rows = []
            for file_path_key, data in self.parsed_data.items():
                around = data.get('around_places', {})
                menus = data.get('menus', [])
                row = {
                    '업체명': data.get('name', ''),
                    '플레이스URL': data.get('url', ''),
                    '플레이스MID': data.get('mid', ''),
                    '지번주소': data.get('address', ''),
                    '도로명주소': data.get('road_address', ''),
                    '역개수': len(around.get('stations', [])),
                    '역목록': ', '.join([s.get('name', '') for s in around.get('stations', [])[:10]]),
                    '아파트개수': len(around.get('apartments', [])),
                    '아파트목록': ', '.join([a.get('name', '') for a in around.get('apartments', [])[:10]]),
                    '랜드마크개수': len(around.get('landmarks', [])),
                    '랜드마크목록': ', '.join([l.get('name', '') for l in around.get('landmarks', [])[:10]]),
                    '메뉴개수': len(menus),
                    '메뉴목록': ', '.join([m.get('name', '') for m in menus[:10]]),
                    '소개글': data.get('introduction', '')[:500],
                    '카테고리': data.get('category', ''),
                    '대표키워드': ', '.join(data.get('keyword_list', []))
                }
                rows.append(row)
            df = pd.DataFrame(rows)
            df.to_excel(file_path, index=False, engine='openpyxl')
            self.status_var.set(f"Excel 저장 완료: {Path(file_path).name}")
            messagebox.showinfo("완료", f"저장 완료:\n{file_path}")
        except Exception as e:
            messagebox.showerror("오류", f"Excel 저장 중 오류 발생:\n{str(e)}")
            self.status_var.set("저장 실패")
            import traceback
            traceback.print_exc()
    
    def save_to_json(self):
        """JSON 파일로 저장 (전체 통합)"""
        if not self.parsed_data:
            messagebox.showwarning("경고", "저장할 데이터가 없습니다. 먼저 파싱을 실행하세요.")
            return
        file_path = filedialog.asksaveasfilename(
            title="JSON 파일로 저장",
            defaultextension=".json",
            filetypes=[("JSON 파일", "*.json"), ("모든 파일", "*.*")]
        )
        if not file_path:
            return
        try:
            self.status_var.set("JSON 저장 중...")
            self.root.update()
            save_data = {}
            for file_path_key, data in self.parsed_data.items():
                name = data.get('name', Path(file_path_key).stem)
                save_data[name] = data
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(save_data, f, ensure_ascii=False, indent=2)
            self.status_var.set(f"JSON 저장 완료: {Path(file_path).name}")
            messagebox.showinfo("완료", f"저장 완료:\n{file_path}")
        except Exception as e:
            messagebox.showerror("오류", f"JSON 저장 중 오류 발생:\n{str(e)}")
            self.status_var.set("저장 실패")
            import traceback
            traceback.print_exc()
    
    def save_search_keywords(self):
        """검색 키워드 저장"""
        search_keyword = self.search_var.get().strip()
        if not search_keyword:
            messagebox.showwarning("경고", "저장할 검색 키워드가 없습니다.")
            return
        file_path = filedialog.asksaveasfilename(
            title="검색 키워드 저장",
            defaultextension=".txt",
            filetypes=[("텍스트 파일", "*.txt"), ("모든 파일", "*.*")]
        )
        if not file_path:
            return
        try:
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(search_keyword)
            messagebox.showinfo("완료", f"검색 키워드 저장 완료:\n{file_path}")
            self.status_var.set(f"검색 키워드 저장 완료: {Path(file_path).name}")
        except Exception as e:
            messagebox.showerror("오류", f"검색 키워드 저장 중 오류 발생:\n{str(e)}")
    
    def load_search_keywords(self):
        """검색 키워드 로드"""
        file_path = filedialog.askopenfilename(
            title="검색 키워드 파일 선택",
            filetypes=[("텍스트 파일", "*.txt"), ("모든 파일", "*.*")]
        )
        if not file_path:
            return
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                keyword = f.read().strip()
            if keyword:
                self.search_var.set(keyword)
                self.filter_places()
                messagebox.showinfo("완료", f"검색 키워드 로드 완료:\n{keyword}")
                self.status_var.set(f"검색 키워드 로드 완료: {Path(file_path).name}")
            else:
                messagebox.showwarning("경고", "로드할 검색 키워드가 없습니다.")
        except Exception as e:
            messagebox.showerror("오류", f"검색 키워드 로드 중 오류 발생:\n{str(e)}")
    
    def save_individual_jsons(self):
        """각 업체별로 개별 JSON 파일 저장"""
        if not self.parsed_data:
            messagebox.showwarning("경고", "저장할 데이터가 없습니다. 먼저 파싱을 실행하세요.")
            return
        save_dir = filedialog.askdirectory(
            title="각 업체 JSON 저장 폴더 선택",
            initialdir=os.path.dirname(__file__)
        )
        if not save_dir:
            return
        try:
            self.status_var.set("각 업체 JSON 저장 중...")
            self.root.update()
            saved_count = 0
            save_dir_path = Path(save_dir)
            for file_path_key, data in self.parsed_data.items():
                name = data.get('name', Path(file_path_key).stem)
                mid = data.get('mid', '')
                safe_name = re.sub(r'[<>:"/\\|?*]', '_', name)
                if mid:
                    json_filename = f"{safe_name}_{mid}.json"
                else:
                    json_filename = f"{safe_name}.json"
                json_path = save_dir_path / json_filename
                save_data = data.copy()
                save_data['_metadata'] = {
                    'original_file': str(file_path_key),
                    'saved_at': str(Path(file_path_key).stat().st_mtime) if Path(file_path_key).exists() else ''
                }
                with open(json_path, 'w', encoding='utf-8') as f:
                    json.dump(save_data, f, ensure_ascii=False, indent=2)
                saved_count += 1
            self.status_var.set(f"각 업체 JSON 저장 완료: {saved_count}개")
            messagebox.showinfo("완료", f"저장 완료:\n{saved_count}개 파일이 저장되었습니다.\n{save_dir}")
        except Exception as e:
            messagebox.showerror("오류", f"각 업체 JSON 저장 중 오류 발생:\n{str(e)}")
            self.status_var.set("저장 실패")
            import traceback
            traceback.print_exc()
    
    def load_from_json(self):
        """기존 JSON 파일들 로드"""
        load_dir = filedialog.askdirectory(
            title="JSON 파일들이 있는 폴더 선택",
            initialdir=os.path.dirname(__file__)
        )
        if not load_dir:
            return
        try:
            self.status_var.set("JSON 로드 중...")
            self.root.update()
            load_dir_path = Path(load_dir)
            json_files = list(load_dir_path.glob("*.json"))
            if not json_files:
                messagebox.showinfo("정보", "JSON 파일이 없습니다.")
                return
            loaded_count = 0
            updated_count = 0
            for json_file in json_files:
                try:
                    with open(json_file, 'r', encoding='utf-8') as f:
                        data = json.load(f)
                    if '_metadata' in data:
                        data.pop('_metadata')
                    original_file = None
                    mid = data.get('mid', '')
                    name = data.get('name', '')
                    if self.rawdata_dir:
                        rawdata_path = Path(self.rawdata_dir)
                        if mid:
                            merged_files = list(rawdata_path.glob(f"*{mid}*merged*.txt"))
                            if merged_files:
                                original_file = str(merged_files[0])
                        else:
                            merged_files = list(rawdata_path.glob("*_merged.txt"))
                            for mf in merged_files:
                                if name and name in mf.stem:
                                    original_file = str(mf)
                                    break
                    file_key = original_file if original_file else str(json_file)
                    if file_key in self.parsed_data:
                        self.parsed_data[file_key].update(data)
                        updated_count += 1
                    else:
                        self.parsed_data[file_key] = data
                        loaded_count += 1
                except Exception as e:
                    print(f"JSON 로드 오류 ({json_file}): {e}")
                    continue
            self.update_place_list()
            self.update_summary_table()
            self.status_var.set(f"JSON 로드 완료: 신규 {loaded_count}개, 업데이트 {updated_count}개")
            messagebox.showinfo("완료", f"로드 완료:\n신규: {loaded_count}개\n업데이트: {updated_count}개")
        except Exception as e:
            messagebox.showerror("오류", f"JSON 로드 중 오류 발생:\n{str(e)}")
            self.status_var.set("로드 실패")
            import traceback
            traceback.print_exc()
    
    def update_json_files(self):
        """JSON 파일들을 현재 파싱된 데이터로 업데이트"""
        json_dir = filedialog.askdirectory(
            title="업데이트할 JSON 파일들이 있는 폴더 선택",
            initialdir=os.path.dirname(__file__)
        )
        if not json_dir:
            return
        if not self.parsed_data:
            messagebox.showwarning("경고", "업데이트할 파싱 데이터가 없습니다.")
            return
        try:
            self.status_var.set("JSON 업데이트 중...")
            self.root.update()
            json_dir_path = Path(json_dir)
            json_files = list(json_dir_path.glob("*.json"))
            if not json_files:
                messagebox.showinfo("정보", "JSON 파일이 없습니다.")
                return
            updated_count = 0
            not_found_count = 0
            parsed_by_mid = {}
            parsed_by_name = {}
            for file_key, data in self.parsed_data.items():
                mid = data.get('mid', '')
                name = data.get('name', '')
                if mid:
                    parsed_by_mid[mid] = data
                if name:
                    safe_name = re.sub(r'[<>:"/\\|?*]', '_', name)
                    parsed_by_name[safe_name] = data
            for json_file in json_files:
                try:
                    with open(json_file, 'r', encoding='utf-8') as f:
                        existing_data = json.load(f)
                    mid = existing_data.get('mid', '')
                    name = existing_data.get('name', '')
                    safe_name = re.sub(r'[<>:"/\\|?*]', '_', name) if name else ''
                    update_data = None
                    if mid and mid in parsed_by_mid:
                        update_data = parsed_by_mid[mid]
                    elif safe_name and safe_name in parsed_by_name:
                        update_data = parsed_by_name[safe_name]
                    else:
                        mid_match = re.search(r'(\d+)\.json$', json_file.name)
                        if mid_match and mid_match.group(1) in parsed_by_mid:
                            update_data = parsed_by_mid[mid_match.group(1)]
                    if update_data:
                        metadata = existing_data.get('_metadata', {})
                        updated_data = update_data.copy()
                        updated_data['_metadata'] = metadata
                        updated_data['_metadata']['updated_at'] = str(Path(json_file).stat().st_mtime) if Path(json_file).exists() else ''
                        with open(json_file, 'w', encoding='utf-8') as f:
                            json.dump(updated_data, f, ensure_ascii=False, indent=2)
                        updated_count += 1
                    else:
                        not_found_count += 1
                except Exception as e:
                    print(f"JSON 업데이트 오류 ({json_file}): {e}")
                    continue
            self.status_var.set(f"JSON 업데이트 완료: {updated_count}개, 매칭 실패 {not_found_count}개")
            messagebox.showinfo("완료", f"업데이트 완료:\n성공: {updated_count}개\n매칭 실패: {not_found_count}개")
        except Exception as e:
            messagebox.showerror("오류", f"JSON 업데이트 중 오류 발생:\n{str(e)}")
            self.status_var.set("업데이트 실패")
            import traceback
            traceback.print_exc()
    
    def update_keyword_count(self, idx):
        """키워드 입력 개수 업데이트"""
        text_widget = self.keyword_inputs[idx]['text']
        count_label = self.keyword_inputs[idx]['count_label']
        content = text_widget.get("1.0", tk.END).strip()
        lines = [line.strip() for line in content.split('\n') if line.strip() and not line.strip().startswith('#')]
        count = len(lines)
        count_label.config(text=f"{count}개")
        total = sum(len([line.strip() for line in self.keyword_inputs[i]['text'].get("1.0", tk.END).strip().split('\n') 
                        if line.strip() and not line.strip().startswith('#')]) for i in range(4))
        self.total_count_label.config(text=f"입력한 총 키워드 개수: {total}/200")
    
    def select_all_single(self, value):
        """단독 키워드 전체 선택/해제"""
        for i in range(4):
            self.combine_vars[f'single_{i+1}'].set(value)
    
    def select_all_combination(self, combo_type, value):
        """조합 타입별 전체 선택/해제"""
        for key in self.combine_vars.keys():
            if key.startswith(f'{combo_type}_'):
                self.combine_vars[key].set(value)
    
    def get_keywords_from_input(self, idx):
        """입력 필드에서 키워드 리스트 추출"""
        text_widget = self.keyword_inputs[idx]['text']
        content = text_widget.get("1.0", tk.END).strip()
        keywords = [line.strip() for line in content.split('\n') 
                   if line.strip() and not line.strip().startswith('#')]
        return keywords[:100]
    
    def combine_keywords(self):
        """키워드 조합 실행"""
        keyword_groups = []
        for i in range(4):
            keywords = self.get_keywords_from_input(i)
            keyword_groups.append(keywords)
        total = sum(len(kw) for kw in keyword_groups)
        if total > 200:
            messagebox.showwarning("경고", f"총 키워드 개수가 200개를 초과합니다. (현재: {total}개)")
            return
        if total == 0:
            messagebox.showwarning("경고", "입력된 키워드가 없습니다.")
            return
        combined = set()
        separator = " " if self.add_space_var.get() else ""
        for i in range(4):
            if self.combine_vars[f'single_{i+1}'].get():
                for kw in keyword_groups[i]:
                    if kw:
                        combined.add(kw)
        two_patterns = {
            '1+2': (0, 1), '1+3': (0, 2), '1+4': (0, 3),
            '2+1': (1, 0), '2+3': (1, 2), '2+4': (1, 3),
            '3+1': (2, 0), '3+2': (2, 1), '3+4': (2, 3),
            '4+1': (3, 0), '4+2': (3, 1), '4+3': (3, 2)
        }
        for pattern, (idx1, idx2) in two_patterns.items():
            var = self.combine_vars.get(f'two_{pattern}')
            if var and var.get():
                for kw1 in keyword_groups[idx1]:
                    for kw2 in keyword_groups[idx2]:
                        if kw1 and kw2:
                            combined.add(f"{kw1}{separator}{kw2}")
        three_patterns = {
            '1+2+3': (0, 1, 2), '1+2+4': (0, 1, 3), '1+3+2': (0, 2, 1), '1+3+4': (0, 2, 3),
            '1+4+2': (0, 3, 1), '1+4+3': (0, 3, 2),
            '2+1+3': (1, 0, 2), '2+1+4': (1, 0, 3), '2+3+1': (1, 2, 0), '2+3+4': (1, 2, 3),
            '2+4+1': (1, 3, 0), '2+4+3': (1, 3, 2),
            '3+1+2': (2, 0, 1), '3+1+4': (2, 0, 3), '3+2+1': (2, 1, 0), '3+2+4': (2, 1, 3),
            '3+4+1': (2, 3, 0), '3+4+2': (2, 3, 1),
            '4+1+2': (3, 0, 1), '4+1+3': (3, 0, 2), '4+2+1': (3, 1, 0), '4+2+3': (3, 1, 2),
            '4+3+1': (3, 2, 0), '4+3+2': (3, 2, 1)
        }
        for pattern, (idx1, idx2, idx3) in three_patterns.items():
            var = self.combine_vars.get(f'three_{pattern}')
            if var and var.get():
                for kw1 in keyword_groups[idx1]:
                    for kw2 in keyword_groups[idx2]:
                        for kw3 in keyword_groups[idx3]:
                            if kw1 and kw2 and kw3:
                                combined.add(f"{kw1}{separator}{kw2}{separator}{kw3}")
        four_patterns = {
            '1+2+3+4': (0, 1, 2, 3), '1+2+4+3': (0, 1, 3, 2), '1+3+2+4': (0, 2, 1, 3),
            '1+3+4+2': (0, 2, 3, 1), '1+4+2+3': (0, 3, 1, 2), '1+4+3+2': (0, 3, 2, 1),
            '2+1+3+4': (1, 0, 2, 3), '2+1+4+3': (1, 0, 3, 2), '2+3+1+4': (1, 2, 0, 3),
            '2+3+4+1': (1, 2, 3, 0), '2+4+1+3': (1, 3, 0, 2), '2+4+3+1': (1, 3, 2, 0),
            '3+1+2+4': (2, 0, 1, 3), '3+1+4+2': (2, 0, 3, 1), '3+2+1+4': (2, 1, 0, 3),
            '3+2+4+1': (2, 1, 3, 0), '3+4+1+2': (2, 3, 0, 1), '3+4+2+1': (2, 3, 1, 0),
            '4+1+2+3': (3, 0, 1, 2), '4+1+3+2': (3, 0, 2, 1), '4+2+1+3': (3, 1, 0, 2),
            '4+2+3+1': (3, 1, 2, 0), '4+3+1+2': (3, 2, 0, 1), '4+3+2+1': (3, 2, 1, 0)
        }
        for pattern, (idx1, idx2, idx3, idx4) in four_patterns.items():
            var = self.combine_vars.get(f'four_{pattern}')
            if var and var.get():
                for kw1 in keyword_groups[idx1]:
                    for kw2 in keyword_groups[idx2]:
                        for kw3 in keyword_groups[idx3]:
                            for kw4 in keyword_groups[idx4]:
                                if kw1 and kw2 and kw3 and kw4:
                                    combined.add(f"{kw1}{separator}{kw2}{separator}{kw3}{separator}{kw4}")
        self.combined_keywords = sorted(list(combined))
        self.combined_result_text.delete("1.0", tk.END)
        self.combined_result_text.insert("1.0", "\n".join(self.combined_keywords))
        count = len(self.combined_keywords)
        self.combined_count_label.config(text=f"조합된 키워드 개수: {count}")
        self.status_var.set(f"키워드 조합 완료: {count}개")
        messagebox.showinfo("완료", f"키워드 조합이 완료되었습니다.\n\n조합된 키워드: {count}개\n(중복 자동 제거됨)")
    
    def save_combined_keywords(self):
        """조합된 키워드 저장"""
        if not self.combined_keywords:
            messagebox.showwarning("경고", "저장할 키워드가 없습니다. 먼저 키워드를 조합하세요.")
            return
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        default_filename = f"키워드조합결과_{timestamp}.txt"
        filename = filedialog.asksaveasfilename(
            title="키워드 조합 결과 저장",
            defaultextension=".txt",
            initialfile=default_filename,
            filetypes=[("텍스트 파일", "*.txt"), ("Excel 파일", "*.xlsx"), ("모든 파일", "*.*")]
        )
        if filename:
            try:
                if filename.endswith('.xlsx'):
                    df = pd.DataFrame({'키워드': self.combined_keywords})
                    df.to_excel(filename, index=False, engine='openpyxl')
                else:
                    with open(filename, 'w', encoding='utf-8') as f:
                        f.write('\n'.join(self.combined_keywords))
                messagebox.showinfo("완료", f"키워드 조합 결과가 저장되었습니다:\n{filename}")
                self.status_var.set(f"저장 완료: {filename}")
            except Exception as e:
                messagebox.showerror("오류", f"저장 실패: {e}")
    
    def send_to_checker_tab(self):
        """조합된 키워드를 검색 체크 탭으로 전송"""
        if not self.combined_keywords:
            messagebox.showwarning("경고", "전송할 키워드가 없습니다. 먼저 키워드를 조합하세요.")
            return
        # 검색 탭으로 이동 및 키워드 전송
        if hasattr(self, 'main_notebook'):
            # 검색 탭(인덱스 1)으로 이동
            self.main_notebook.select(1)
        if hasattr(self, 'keyword_text'):
            self.keyword_text.delete("1.0", tk.END)
            self.keyword_text.insert("1.0", "\n".join(self.combined_keywords))
            messagebox.showinfo("완료", f"{len(self.combined_keywords)}개의 조합된 키워드가 검색 체크 탭으로 전송되었습니다.")
            self.status_var.set(f"키워드 전송 완료: {len(self.combined_keywords)}개")
        else:
            messagebox.showwarning("경고", "검색 체크 탭의 키워드 입력 필드를 찾을 수 없습니다.")
    
    def clear_combiner(self):
        """키워드 조합기 초기화"""
        if messagebox.askyesno("확인", "키워드 조합기를 초기화하시겠습니까?"):
            for i in range(4):
                self.keyword_inputs[i]['text'].delete("1.0", tk.END)
                self.keyword_inputs[i]['text'].insert("1.0", f"# 키워드 {i+1} 입력 (최대 100개)\n# 1줄에 하나씩")
                self.keyword_inputs[i]['count_label'].config(text="0개")
            self.combined_result_text.delete("1.0", tk.END)
            self.combined_result_text.insert("1.0", "조합된 키워드가 출력됩니다.")
            self.combined_keywords = []
            self.combined_count_label.config(text="조합된 키워드 개수: 0")
            self.total_count_label.config(text="입력한 총 키워드 개수: 0/200")
            self.status_var.set("키워드 조합기 초기화 완료")
    
    def setup_checker_tab(self):
        """키워드 검색 체크 탭 설정"""
        # self.checker_tab은 이미 setup_ui에서 checker_scrollable로 설정됨
        # 외부 Canvas가 이미 있으므로 내부에서 직접 요소 추가
        
        top_frame = ttk.Frame(self.checker_tab, padding="10")
        top_frame.pack(fill=tk.X)
        
        # URL 입력 행
        url_row = ttk.Frame(top_frame)
        url_row.pack(fill=tk.X, pady=2)
        ttk.Label(url_row, text="플레이스 URL:").pack(side=tk.LEFT, padx=5)
        self.url_entry = ttk.Entry(url_row)
        self.url_entry.pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)
        self.url_entry.insert(0, "https://m.place.naver.com/place/")
        ttk.Button(url_row, text="MID 추출", command=self.extract_mid).pack(side=tk.LEFT, padx=5)
        
        # MID 표시 행
        mid_row = ttk.Frame(top_frame)
        mid_row.pack(fill=tk.X, pady=2)
        ttk.Label(mid_row, text="MID:").pack(side=tk.LEFT, padx=5)
        self.mid_label = ttk.Label(mid_row, text="", foreground="blue")
        self.mid_label.pack(side=tk.LEFT, padx=5)
        
        # 메인키(지역) 입력 행
        main_key_region_row = ttk.Frame(top_frame)
        main_key_region_row.pack(fill=tk.X, pady=2)
        ttk.Label(main_key_region_row, text="메인키(지역):").pack(side=tk.LEFT, padx=5)
        self.main_key_region_entry = ttk.Entry(main_key_region_row, width=30)
        self.main_key_region_entry.pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)
        
        # 메인키(업종) 입력 행
        main_key_category_row = ttk.Frame(top_frame)
        main_key_category_row.pack(fill=tk.X, pady=2)
        ttk.Label(main_key_category_row, text="메인키(업종):").pack(side=tk.LEFT, padx=5)
        self.main_key_category_entry = ttk.Entry(main_key_category_row, width=30)
        self.main_key_category_entry.pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)
        
        # 작업키 입력 행
        work_key_row = ttk.Frame(top_frame)
        work_key_row.pack(fill=tk.X, pady=2)
        ttk.Label(work_key_row, text="작업키:").pack(side=tk.LEFT, padx=5)
        self.work_key_entry = ttk.Entry(work_key_row, width=30)
        self.work_key_entry.pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)
        ttk.Label(work_key_row, text="(쉼표로 구분)", foreground="gray", font=("Arial", 8)).pack(side=tk.LEFT, padx=5)
        
        keyword_frame = ttk.LabelFrame(self.checker_tab, text="키워드 입력", padding="10")
        keyword_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # 섹션 4 키워드 입력 버튼들 (반응형)
        keyword_buttons = [
            ("엑셀에서 가져오기", self.load_from_excel),
            ("일괄 처리 (엑셀)", self.load_batch_from_excel),
            ("검색결과 CSV/Excel 불러오기", self.load_results_from_file)
        ]
        keyword_btn_frame = self.create_responsive_button_grid(keyword_frame, keyword_buttons, max_cols=3)
        keyword_btn_frame.pack(fill=tk.X, pady=(0, 5))
        
        self.keyword_text = scrolledtext.ScrolledText(keyword_frame, height=10, width=80)
        self.keyword_text.pack(fill=tk.BOTH, expand=True)
        
        # 대기 목록 관리 섹션
        queue_frame = ttk.LabelFrame(self.checker_tab, text="📋 대기 목록 (여러 업체 키워드 모음)", padding="10")
        queue_frame.pack(fill=tk.BOTH, expand=False, padx=10, pady=5)
        
        # 대기 목록 테이블
        queue_tree_frame = ttk.Frame(queue_frame)
        queue_tree_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 5))
        
        queue_columns = ("URL", "MID", "키워드 수", "메인키(지역)", "메인키(업종)", "작업키")
        self.queue_tree = ttk.Treeview(queue_tree_frame, columns=queue_columns, show="headings", height=5)
        
        for col in queue_columns:
            self.queue_tree.heading(col, text=col)
            if col == "URL":
                self.queue_tree.column(col, width=200)
            elif col == "MID":
                self.queue_tree.column(col, width=100)
            elif col == "키워드 수":
                self.queue_tree.column(col, width=80)
            elif col == "메인키(지역)":
                self.queue_tree.column(col, width=100)
            elif col == "메인키(업종)":
                self.queue_tree.column(col, width=100)
            elif col == "작업키":
                self.queue_tree.column(col, width=150)
            else:
                self.queue_tree.column(col, width=120)
        
        queue_scroll = ttk.Scrollbar(queue_tree_frame, orient=tk.VERTICAL, command=self.queue_tree.yview)
        self.queue_tree.configure(yscrollcommand=queue_scroll.set)
        self.queue_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        queue_scroll.pack(side=tk.RIGHT, fill=tk.Y)
        
        # 대기 목록 버튼들
        queue_btn_frame = ttk.Frame(queue_frame)
        queue_btn_frame.pack(fill=tk.X)
        
        ttk.Button(queue_btn_frame, text="➕ 현재 정보 추가", command=self.add_to_queue).pack(side=tk.LEFT, padx=2)
        ttk.Button(queue_btn_frame, text="➖ 선택 항목 제거", command=self.remove_from_queue).pack(side=tk.LEFT, padx=2)
        ttk.Button(queue_btn_frame, text="🗑️ 전체 초기화", command=self.clear_queue).pack(side=tk.LEFT, padx=2)
        self.queue_count_label = ttk.Label(queue_btn_frame, text="대기 중: 0개 업체", foreground="blue")
        self.queue_count_label.pack(side=tk.RIGHT, padx=10)
        
        condition_frame = ttk.LabelFrame(self.checker_tab, text="검색 조건 선택 (단일 모드용)", padding="10")
        condition_frame.pack(fill=tk.X, padx=10, pady=5)
        
        # 순위 체크 모드 행
        rank_mode_row = ttk.Frame(condition_frame)
        rank_mode_row.pack(fill=tk.X, pady=2)
        ttk.Label(rank_mode_row, text="순위 체크 모드:", font=("Arial", 10, "bold")).pack(side=tk.LEFT, padx=5)
        rank_mode_frame = ttk.Frame(rank_mode_row)
        rank_mode_frame.pack(side=tk.LEFT, padx=5)
        
        def update_rank_mode():
            self.max_rank = self.rank_mode.get()
            self.required_label.config(text=f"플레이스 섹션 내 {self.max_rank}위 이내")
        
        ttk.Radiobutton(rank_mode_frame, text="5위까지 체크", variable=self.rank_mode, value=5,
                       command=update_rank_mode).pack(side=tk.LEFT, padx=5)
        ttk.Radiobutton(rank_mode_frame, text="100위까지 체크", variable=self.rank_mode, value=100,
                       command=update_rank_mode).pack(side=tk.LEFT, padx=5)
        
        # 필수 조건 행
        required_row = ttk.Frame(condition_frame)
        required_row.pack(fill=tk.X, pady=2)
        ttk.Label(required_row, text="필수 조건:", font=("Arial", 10, "bold")).pack(side=tk.LEFT, padx=5)
        self.required_label = ttk.Label(required_row, text="플레이스 섹션 내 5위 이내", foreground="gray")
        self.required_label.pack(side=tk.LEFT, padx=5)
        
        # 선택 조건 행
        optional_row = ttk.Frame(condition_frame)
        optional_row.pack(fill=tk.X, pady=2)
        ttk.Label(optional_row, text="선택 조건:", font=("Arial", 10, "bold")).pack(side=tk.LEFT, padx=5)
        ttk.Checkbutton(optional_row, text="플레이스 최상단 여부", 
                       variable=self.check_top).pack(side=tk.LEFT, padx=5)
        ttk.Checkbutton(optional_row, text="플레이스 섹션 내 CPC 광고 없음", 
                       variable=self.check_cpc).pack(side=tk.LEFT, padx=5)
        ttk.Checkbutton(optional_row, text="단일 키워드 (해당 업체만 존재)", 
                       variable=self.check_single).pack(side=tk.LEFT, padx=5)
        
        help_text = """# 키워드 입력 방법:
# 
# 🔥 방법 1: 직접 입력 (이 영역에 키워드 입력, 1줄에 하나씩)
# 🔥 방법 2: 엑셀에서 가져오기 - 키워드만 가져오기 (단일 모드)
# 🔥 방법 3: 일괄 처리 (엑셀) - 여러 업체 + 여러 키워드 (일괄 처리 모드)
#    엑셀 형식: URL | MID | 키워드 | 최상단 | CPC없음 | 메인키(지역) | 메인키(업종) | 작업키
#    예시:
#    https://m.place.naver.com/place/1206712616 | 1206712616 | 두정동 누수탐지 | TRUE | TRUE | 두정동 | 누수탐지 | 키워드1,키워드2
#    https://m.place.naver.com/place/1234567890 | 1234567890 | 강남 맛집 | FALSE | FALSE | 강남 | 맛집 | 키워드3
#    또는 조건 컬럼에: "최상단,CPC없음" 또는 "최상단" 등으로 입력
#    작업키는 쉼표로 구분하여 입력"""
        self.keyword_text.insert("1.0", help_text)
        
        # 섹션 4 검색/결과 버튼들 (반응형)
        section4_buttons = [
            ("검색 시작", self.start_checking),
            ("🚀 대기 목록 모두 검색", self.start_queue_checking),
            ("중지", self.stop_checking),
            ("결과 저장", self.save_results),
            ("JSON 업데이트", self.update_json_from_results),
            ("초기화", self.clear_results),
            ("결과 통합", self.merge_results)
        ]
        button_frame = self.create_responsive_button_grid(self.checker_tab, section4_buttons)
        button_frame.pack(fill=tk.X, pady=(0, 10))
        
        result_frame = ttk.LabelFrame(self.checker_tab, text="검색 결과", padding="10")
        result_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # 필터 UI 프레임
        filter_frame = ttk.Frame(result_frame)
        filter_frame.pack(fill=tk.X, pady=(0, 5))
        
        ttk.Label(filter_frame, text="필터:", font=("Arial", 10, "bold")).pack(side=tk.LEFT, padx=5)
        
        # 순위 필터
        ttk.Label(filter_frame, text="순위:").pack(side=tk.LEFT, padx=(10, 2))
        self.filter_rank = ttk.Combobox(filter_frame, values=["전체", "1-5위", "6-10위", "순위권밖"], width=10, state="readonly")
        self.filter_rank.set("전체")
        self.filter_rank.pack(side=tk.LEFT, padx=2)
        
        # 체크박스 필터
        self.filter_top = tk.BooleanVar(value=False)
        self.filter_no_cpc = tk.BooleanVar(value=False)
        self.filter_single = tk.BooleanVar(value=False)
        self.filter_task = tk.BooleanVar(value=False)
        self.filter_used = tk.BooleanVar(value=False)
        
        ttk.Checkbutton(filter_frame, text="최상단", variable=self.filter_top).pack(side=tk.LEFT, padx=5)
        ttk.Checkbutton(filter_frame, text="CPC없음", variable=self.filter_no_cpc).pack(side=tk.LEFT, padx=5)
        ttk.Checkbutton(filter_frame, text="단일", variable=self.filter_single).pack(side=tk.LEFT, padx=5)
        ttk.Checkbutton(filter_frame, text="작업키워드", variable=self.filter_task).pack(side=tk.LEFT, padx=5)
        ttk.Checkbutton(filter_frame, text="사용중", variable=self.filter_used).pack(side=tk.LEFT, padx=5)
        
        # 필터 버튼
        ttk.Button(filter_frame, text="필터 적용", command=self.apply_result_filter).pack(side=tk.LEFT, padx=10)
        ttk.Button(filter_frame, text="초기화", command=self.reset_result_filter).pack(side=tk.LEFT, padx=2)
        
        # 프리셋 버튼
        preset_frame = ttk.Frame(result_frame)
        preset_frame.pack(fill=tk.X, pady=(0, 5))
        ttk.Label(preset_frame, text="프리셋:", font=("Arial", 9)).pack(side=tk.LEFT, padx=5)
        ttk.Button(preset_frame, text="성공키워드 (5위+최상단+CPC없음)", 
                  command=lambda: self.apply_preset_filter('success')).pack(side=tk.LEFT, padx=2)
        ttk.Button(preset_frame, text="단일+최상단", 
                  command=lambda: self.apply_preset_filter('single_top')).pack(side=tk.LEFT, padx=2)
        ttk.Button(preset_frame, text="교체필요 (순위권밖)", 
                  command=lambda: self.apply_preset_filter('replace')).pack(side=tk.LEFT, padx=2)
        

        tree_container = ttk.Frame(result_frame)
        tree_container.pack(fill=tk.BOTH, expand=True)
        
        # 통합 컬럼 구조 (원본 데이터 기반)
        columns = ("MID", "업체명", "키워드", "순위", "최상단", "CPC", "CPC개수", "업체수", "단일", "섹션", "작업키워드", "사용중", "시작일", "종료일")
        self.result_tree = ttk.Treeview(tree_container, columns=columns, show="headings", height=15)
        
        # 컬럼 너비 설정
        column_widths = {
            "MID": 100, "업체명": 150, "키워드": 200, "순위": 50,
            "최상단": 60, "CPC": 50, "CPC개수": 60, "업체수": 60,
            "단일": 50, "섹션": 70, "작업키워드": 70, "사용중": 50,
            "시작일": 90, "종료일": 90
        }
        for col in columns:
            self.result_tree.heading(col, text=col)
            self.result_tree.column(col, width=column_widths.get(col, 80))
        
        v_scrollbar = ttk.Scrollbar(tree_container, orient=tk.VERTICAL, command=self.result_tree.yview)
        self.result_tree.configure(yscrollcommand=v_scrollbar.set)
        
        h_scrollbar = ttk.Scrollbar(tree_container, orient=tk.HORIZONTAL, command=self.result_tree.xview)
        self.result_tree.configure(xscrollcommand=h_scrollbar.set)
        
        self.result_tree.grid(row=0, column=0, sticky="nsew")
        v_scrollbar.grid(row=0, column=1, sticky="ns")
        h_scrollbar.grid(row=1, column=0, sticky="ew")
        
        tree_container.grid_rowconfigure(0, weight=1)
        tree_container.grid_columnconfigure(0, weight=1)
        
        # 실시간 로그 영역 추가
        log_frame = ttk.LabelFrame(result_frame, text="🔍 실시간 디버깅 로그", padding="5")
        log_frame.pack(fill=tk.BOTH, expand=False, pady=(10, 0))
        
        self.log_text = scrolledtext.ScrolledText(log_frame, height=10, width=100, 
                                                  bg="#1e1e1e", fg="#00ff00", 
                                                  font=("Consolas", 9))
        self.log_text.pack(fill=tk.BOTH, expand=True)
        self.log_text.insert("1.0", "=== 실시간 로그 준비 완료 ===\n")
        self.log_text.config(state=tk.DISABLED)  # 읽기 전용
        
        self.main_key_region = ""
        self.main_key_category = ""
        self.work_keys = []
    
    # ========== 대기 목록 관련 메서드 ==========
    def add_to_queue(self):
        """현재 입력된 정보를 대기 목록에 추가"""
        url = self.url_entry.get().strip()
        mid = self.target_mid
        
        if not mid:
            self.extract_mid()
            mid = self.target_mid
        
        if not mid:
            messagebox.showwarning("경고", "먼저 URL에서 MID를 추출하세요.")
            return
        
        keywords_text = self.keyword_text.get("1.0", tk.END).strip()
        keywords_raw = [kw.strip() for kw in keywords_text.split('\n') 
                       if kw.strip() and not kw.strip().startswith('#')]
        
        if not keywords_raw:
            messagebox.showwarning("경고", "키워드를 입력하세요.")
            return
        
        main_key_region = self.main_key_region_entry.get().strip()
        main_key_category = self.main_key_category_entry.get().strip()
        work_key_raw = self.work_key_entry.get().strip()
        
        work_keys = []
        if work_key_raw:
            work_keys = [wk.strip() for wk in work_key_raw.replace('，', ',').split(',') if wk.strip()]
        
        # 이미 같은 MID가 대기 목록에 있는지 확인
        existing_idx = None
        for idx, task in enumerate(self.queue_tasks):
            if task.get('mid') == mid:
                existing_idx = idx
                break
        
        # 대기 목록에 추가할 작업 정보
        task = {
            'url': url,
            'mid': mid,
            'keywords': keywords_raw,
            'main_key_region': main_key_region,
            'main_key_category': main_key_category,
            'work_keys': work_keys,
            'conditions': {
                'check_top': self.check_top.get(),
                'check_cpc': self.check_cpc.get(),
                'check_single': self.check_single.get()  # 단일 키워드 체크 추가
            }
        }
        
        if existing_idx is not None:
            # 기존 항목 업데이트
            self.queue_tasks[existing_idx] = task
            messagebox.showinfo("완료", f"대기 목록의 기존 항목이 업데이트되었습니다.\nMID: {mid}\n키워드: {len(keywords_raw)}개")
        else:
            # 새 항목 추가
            self.queue_tasks.append(task)
            messagebox.showinfo("완료", f"대기 목록에 추가되었습니다.\nMID: {mid}\n키워드: {len(keywords_raw)}개")
        
        self.update_queue_tree()
    
    def remove_from_queue(self):
        """대기 목록에서 선택된 항목 제거"""
        selection = self.queue_tree.selection()
        if not selection:
            messagebox.showwarning("경고", "제거할 항목을 선택하세요.")
            return
        
        # 역순으로 제거 (인덱스가 변경되지 않도록)
        indices = sorted([self.queue_tree.index(item) for item in selection], reverse=True)
        for idx in indices:
            if 0 <= idx < len(self.queue_tasks):
                self.queue_tasks.pop(idx)
        
        self.update_queue_tree()
        messagebox.showinfo("완료", f"{len(selection)}개 항목이 제거되었습니다.")
    
    def clear_queue(self):
        """대기 목록 전체 초기화"""
        if not self.queue_tasks:
            return
        
        if messagebox.askyesno("확인", f"대기 목록의 모든 항목({len(self.queue_tasks)}개)을 삭제하시겠습니까?"):
            self.queue_tasks = []
            self.update_queue_tree()
            messagebox.showinfo("완료", "대기 목록이 초기화되었습니다.")
    
    def update_queue_tree(self):
        """대기 목록 트리뷰 업데이트"""
        # 기존 항목 삭제
        for item in self.queue_tree.get_children():
            self.queue_tree.delete(item)
        
        # 대기 목록 항목 추가
        for task in self.queue_tasks:
            url_display = task['url'][:50] + '...' if len(task['url']) > 50 else task['url']
            work_keys_display = ','.join(task['work_keys']) if task['work_keys'] else ''
            
            self.queue_tree.insert("", tk.END, values=(
                url_display,
                task['mid'],
                len(task['keywords']),
                task['main_key_region'],
                task['main_key_category'],
                work_keys_display
            ))
        
        # 개수 표시 업데이트
        if hasattr(self, 'queue_count_label'):
            self.queue_count_label.config(text=f"대기 중: {len(self.queue_tasks)}개 업체")
    
    def start_queue_checking(self):
        """대기 목록의 모든 업체를 한번에 검색"""
        if not self.queue_tasks:
            messagebox.showwarning("경고", "대기 목록이 비어있습니다.")
            return
        
        if self.is_running:
            messagebox.showwarning("경고", "이미 검색이 진행 중입니다.")
            return
        
        # 확인 메시지
        total_keywords = sum(len(task['keywords']) for task in self.queue_tasks)
        msg = f"대기 목록의 모든 업체를 검색하시겠습니까?\n\n업체: {len(self.queue_tasks)}개\n키워드: {total_keywords}개"
        if not messagebox.askyesno("확인", msg):
            return
        
        # 대기 목록을 batch_tasks로 변환
        self.batch_tasks = []
        for task in self.queue_tasks:
            self.batch_tasks.append({
                'agency_name': '',
                'url': task['url'],
                'mid': task['mid'],
                'keywords': task['keywords'],
                'conditions': task['conditions'],
                'main_key_region': task['main_key_region'],
                'main_key_category': task['main_key_category'],
                'work_keys': task['work_keys']
            })
        
        self.max_rank = self.rank_mode.get()
        self.batch_mode = True
        
        if not self.init_browser():
            return
        
        self.is_running = True
        # 스레드로 실행
        threading.Thread(target=self.process_batch_tasks, daemon=True).start()
    
    def extract_mid(self):
        """URL에서 MID 추출"""
        url = self.url_entry.get().strip()
        if not url:
            messagebox.showwarning("경고", "URL을 입력하세요.")
            return
        mid_match = re.search(r'/(?:place|restaurant|hospital|hairshop|attraction|nailshop|waxing|pension|parking|law|academy|animalhospital|curtain|moving|cleaning|health|pilates|shaped|etc)/(\d+)', url, re.IGNORECASE)
        if mid_match:
            mid = mid_match.group(1)
            self.mid_label.config(text=mid)
            self.target_mid = mid
            if hasattr(self, 'status_var'):
                self.status_var.set(f"MID 추출 완료: {mid}")
        else:
            messagebox.showerror("오류", f"URL에서 MID를 찾을 수 없습니다.")
            self.mid_label.config(text="")
            self.target_mid = None
    
    def load_search_history(self):
        """검색 이력 로드"""
        if os.path.exists(self.history_file):
            try:
                with open(self.history_file, 'r', encoding='utf-8') as f:
                    self.search_history = json.load(f)
            except:
                self.search_history = {}
        else:
            self.search_history = {}
        return self.search_history
    
    def save_search_history(self):
        """검색 이력 저장"""
        try:
            with open(self.history_file, 'w', encoding='utf-8') as f:
                json.dump(self.search_history, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"검색 이력 저장 실패: {e}")
    
    def add_to_history(self, keyword):
        """검색 이력에 키워드 추가"""
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        if keyword in self.search_history:
            self.search_history[keyword]['last_searched'] = now
            self.search_history[keyword]['count'] = self.search_history[keyword].get('count', 0) + 1
        else:
            self.search_history[keyword] = {
                'first_searched': now,
                'last_searched': now,
                'count': 1
            }
        self.save_search_history()
    
    def filter_duplicate_keywords(self, keywords):
        """중복 키워드 필터링"""
        new_keywords = []
        duplicate_count = 0
        for kw in keywords:
            kw_clean = kw.strip()
            if not kw_clean:
                continue
            if kw_clean not in self.search_history:
                new_keywords.append(kw_clean)
            else:
                duplicate_count += 1
        return new_keywords, duplicate_count
    
    def show_history(self):
        """검색 이력 확인 창"""
        if not self.search_history:
            messagebox.showinfo("검색 이력", "검색 이력이 없습니다.")
            return
        history_window = tk.Toplevel(self.root)
        history_window.title("검색 이력")
        history_window.geometry("800x600")
        top_frame = ttk.Frame(history_window, padding="10")
        top_frame.pack(fill=tk.X)
        ttk.Label(top_frame, text=f"총 {len(self.search_history)}개의 키워드 검색 이력", 
                 font=("Arial", 12, "bold")).pack(side=tk.LEFT)
        ttk.Button(top_frame, text="이력 초기화", command=lambda: self.clear_history(history_window)).pack(side=tk.RIGHT, padx=5)
        ttk.Button(top_frame, text="닫기", command=history_window.destroy).pack(side=tk.RIGHT)
        tree_frame = ttk.Frame(history_window)
        tree_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        columns = ("키워드", "첫 검색", "마지막 검색", "검색 횟수")
        tree = ttk.Treeview(tree_frame, columns=columns, show="headings", height=20)
        for col in columns:
            tree.heading(col, text=col)
            if col == "키워드":
                tree.column(col, width=300)
            else:
                tree.column(col, width=150)
        scrollbar = ttk.Scrollbar(tree_frame, orient=tk.VERTICAL, command=tree.yview)
        tree.configure(yscrollcommand=scrollbar.set)
        tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        sorted_history = sorted(self.search_history.items(), 
                              key=lambda x: x[1].get('last_searched', ''), 
                              reverse=True)
        for keyword, info in sorted_history:
            tree.insert("", tk.END, values=(
                keyword,
                info.get('first_searched', '-'),
                info.get('last_searched', '-'),
                info.get('count', 0)
            ))
    
    def clear_history(self, window):
        """검색 이력 초기화"""
        if messagebox.askyesno("확인", "검색 이력을 모두 삭제하시겠습니까?\n\n이 작업은 되돌릴 수 없습니다."):
            self.search_history = {}
            self.save_search_history()
            messagebox.showinfo("완료", "검색 이력이 초기화되었습니다.")
            window.destroy()
    
    # ========== 키워드 검색 결과 JSON 관련 함수들 ==========
    def normalize_mid(self, mid):
        """MID 값을 정규화"""
        if pd.isna(mid):
            return None
        mid_str = str(mid).strip()
        if '.' in mid_str:
            mid_str = mid_str.split('.')[0]
        return mid_str
    
    def calculate_edit_distance(self, keyword, main_keyword):
        """편집 거리 계산 (작을수록 유사)"""
        if not main_keyword:
            return len(keyword) if keyword else 0
        if not keyword:
            return len(main_keyword)
        
        m, n = len(main_keyword), len(keyword)
        dp = [[0] * (n + 1) for _ in range(m + 1)]
        
        for i in range(m + 1):
            dp[i][0] = i
        for j in range(n + 1):
            dp[0][j] = j
        
        for i in range(1, m + 1):
            for j in range(1, n + 1):
                if main_keyword[i-1] == keyword[j-1]:
                    dp[i][j] = dp[i-1][j-1]
                else:
                    dp[i][j] = 1 + min(dp[i-1][j], dp[i][j-1], dp[i-1][j-1])
        
        return dp[m][n]
    
    def parse_main_keyword(self, full_keyword):
        """full 키워드를 파싱해서 sido, region, category로 분리
        상황별 처리:
        - 3개 단어: "경남 사천 맛집" -> sido: "경남", region: "사천", category: "맛집"
        - 2개 단어: "사천 맛집" -> sido: "사천", region: None, category: "맛집"
        - 2개 단어: "대전 침대" -> sido: "대전", region: None, category: "침대"
        - 붙어있음: "경남사천 맛집" -> sido: "경남", region: "사천", category: "맛집"
        """
        if not full_keyword:
            return '', '', ''
        
        # full 키워드를 공백으로 분리
        parts = full_keyword.strip().split()
        
        if len(parts) == 0:
            return '', '', ''
        
        # 업종 키워드 목록 (맛집, 학원, 병원 등)
        common_categories = ['맛집', '학원', '병원', '의원', '펜션', '카페', '식당', '치과', '뷰티', '헬스', 'PT', '보컬학원', '침대', '매트리스']
        
        # 시도 이름 패턴
        sido_patterns = ['경남', '경북', '전남', '전북', '충남', '충북', '강원', '제주', '서울', '인천', '대전', '대구', '부산', '울산', '광주', '세종']
        
        parsed_sido = ''
        parsed_region = ''
        parsed_category = ''
        
        # 마지막 부분이 카테고리인지 확인
        if parts[-1] in common_categories:
            parsed_category = parts[-1]
            parts = parts[:-1]  # 카테고리 제거
        else:
            # 마지막 부분이 카테고리가 아니면, 전체가 지역일 수 있음
            pass
        
        # 나머지 부분 처리
        if len(parts) == 0:
            # 카테고리만 있는 경우
            pass
        elif len(parts) == 1:
            # 단어가 1개: 지역1 (sido)
            first_part = parts[0]
            # "경남사천" 같이 붙어있는 경우 처리
            for pattern in sido_patterns:
                if first_part.startswith(pattern) and len(first_part) > len(pattern):
                    parsed_sido = pattern
                    parsed_region = first_part[len(pattern):]
                    break
            else:
                parsed_sido = first_part
        elif len(parts) == 2:
            # 단어가 2개: 지역1 지역2 또는 지역1 업종 (카테고리는 이미 제거됨)
            first_part = parts[0]
            second_part = parts[1]
            
            # 첫 번째가 시도 패턴으로 시작하는지 확인
            for pattern in sido_patterns:
                if first_part == pattern:
                    # "경남 사천" 같은 경우
                    parsed_sido = first_part
                    parsed_region = second_part
                    break
                elif first_part.startswith(pattern) and len(first_part) > len(pattern):
                    # "경남사천" 같이 붙어있는 경우
                    parsed_sido = pattern
                    parsed_region = first_part[len(pattern):]
                    # 두 번째 부분은 무시 (중복일 수 있음)
                    break
            else:
                # 시도 패턴이 아니면 첫 번째가 sido, 두 번째가 region
                parsed_sido = first_part
                parsed_region = second_part
        elif len(parts) >= 3:
            # 단어가 3개 이상: 지역1 지역2 업종
            parsed_sido = parts[0]
            parsed_region = parts[1]
            # 마지막 부분이 이미 카테고리로 분리되었을 수 있음
        
        # 결과 반환
        result_sido = parsed_sido if parsed_sido else ''
        result_region = parsed_region if parsed_region else ''
        result_category = parsed_category if parsed_category else ''
        
        # 중복 제거
        # 1. sido와 region이 같으면 region 제거
        if result_sido and result_region and result_sido == result_region:
            result_region = ''
        
        # 2. category와 region이 같으면 region 제거 (예: "대전 침대 침대" -> region: "침대" 제거)
        if result_region and result_category and result_region == result_category:
            result_region = ''
        
        return result_sido, result_region, result_category
    
    def sort_keywords_by_main_keyword(self, keywords, sido, region, category, full_keyword):
        """메인 키워드 기준으로 변형 적은 순으로 정렬
        우선순위:
        1. sido(지역 메인키)가 맨 앞에 있는 키워드
        2. sido 포함 여부
        3. region 포함 여부 (있는 경우)
        4. category 포함 여부
        5. 전체 메인 키워드와의 편집 거리
        """
        if not keywords:
            return []
        
        # 메인 키워드 구성 요소가 없으면 일반 정렬
        if not sido and not region and not category:
            return sorted(keywords)
        
        def sort_key(keyword):
            # 1. sido가 맨 앞에 있는지 체크
            starts_with_sido = keyword.startswith(sido) if sido else False
            
            # 2. 각 구성 요소 포함 여부
            contains_sido = (sido in keyword) if sido else False
            contains_region = (region in keyword) if region else False
            contains_category = (category in keyword) if category else False
            
            # 3. 전체 메인 키워드와의 편집 거리
            edit_dist = self.calculate_edit_distance(keyword, full_keyword) if full_keyword else 0
            
            # 정렬 키: (sido 맨 앞 아님, sido 포함 안함, region 포함 안함, category 포함 안함, 편집거리, 길이)
            return (
                not starts_with_sido,      # sido가 맨 앞에 있는 것 우선
                not contains_sido,         # sido 포함한 것 우선
                not contains_region if region else False,  # region 포함한 것 우선
                not contains_category,     # category 포함한 것 우선
                edit_dist,                 # 편집 거리 적은 것 우선
                len(keyword)               # 길이 짧은 것 우선
            )
        
        return sorted(keywords, key=sort_key)
    
    def on_closing(self):
        """종료 시 브라우저 닫기"""
        if self.driver:
            try:
                self.driver.quit()
            except:
                pass
        self.root.destroy()


if __name__ == '__main__':
    root = tk.Tk()
    app = IntegratedKeywordManager(root)
    root.mainloop()

