# -*- coding: utf-8 -*-
"""
플레이스 통합 관리 프로그램
- 다운로드, 파싱, 파일명 변경 기능 통합
"""
import os
import sys
import json
import re
import csv
import time
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
from pathlib import Path
import threading
import webbrowser
from collections import defaultdict
from datetime import datetime

# 모듈 경로 추가 (exe 빌드 시 경로 처리)
if getattr(sys, 'frozen', False):
    # PyInstaller로 빌드된 exe 실행 중
    BASE_DIR = Path(sys.executable).parent
    RESOURCE_DIR = Path(sys._MEIPASS) if hasattr(sys, '_MEIPASS') else BASE_DIR
else:
    # 일반 Python 실행
    BASE_DIR = Path(__file__).parent
    RESOURCE_DIR = BASE_DIR

# PlacePasser 경로 추가
placepasser_path = BASE_DIR.parent / 'PlacePasser'
if placepasser_path.exists() and str(placepasser_path) not in sys.path:
    sys.path.insert(0, str(placepasser_path))

# 현재 디렉토리 경로 추가
keyword_searcher_path = str(BASE_DIR)
if keyword_searcher_path not in sys.path:
    sys.path.insert(0, keyword_searcher_path)

# 모듈 import
try:
    from parse_comprehensive_info import parse_comprehensive_info
    from keyword_group_generator import KeywordGroupGenerator
except ImportError:
    parse_comprehensive_info = None
    KeywordGroupGenerator = None

try:
    from download_place_pages import download_place_sections, extract_place_id_and_name, extract_map_markers_from_page
    from merge_rawdata import merge_place_files
except ImportError:
    download_place_sections = None
    extract_place_id_and_name = None
    extract_map_markers_from_page = None
    merge_place_files = None

# 구글 드라이브 업로드 (선택적)
try:
    from google_drive_uploader import upload_file_to_drive, find_or_create_folder, HAS_GOOGLE_API
    HAS_DRIVE_UPLOAD = HAS_GOOGLE_API
except ImportError:
    HAS_DRIVE_UPLOAD = False
    upload_file_to_drive = None
    find_or_create_folder = None

class IntegratedPlaceManager:
    """통합 플레이스 관리 프로그램"""
    
    def __init__(self, root):
        self.root = root
        self.root.title("플레이스 통합 관리 프로그램")
        self.root.geometry("1400x900")
        
        # ========== exe 빌드 시 경로 처리 ==========
        if getattr(sys, 'frozen', False):
            # PyInstaller로 빌드된 exe 실행 중
            self.BASE_DIR = Path(sys.executable).parent  # exe가 있는 폴더
            self.RESOURCE_DIR = Path(sys._MEIPASS) if hasattr(sys, '_MEIPASS') else self.BASE_DIR
        else:
            # 일반 Python 실행
            self.BASE_DIR = Path(__file__).parent
            self.RESOURCE_DIR = self.BASE_DIR
        
        # 공통 변수
        self.rawdata_dir = str(self.BASE_DIR / 'rawdata')
        self.download_dir = str(self.BASE_DIR / 'downloaded_pages')
        
        # 다운로드 관련
        self.urls = []
        self.downloading = False
        self.excel_file_path = None
        self.excel_files = []
        self.excel_sheet_name = None
        self.place_id_map = {}
        
        # 파싱 관련
        self.parsed_data = {}
        self.current_file = None
        self.reward_data = {}
        self.all_place_files = []
        self.filtered_place_files = []
        if KeywordGroupGenerator:
            self.keyword_generator = KeywordGroupGenerator()
        else:
            self.keyword_generator = None
        
        # 파일명 변경 관련
        self.is_renaming = False
        self.preview_data = []
        
        # Reward_data 로드
        self.load_reward_data()
        
        # UI 설정
        self.setup_ui()
    
    def setup_ui(self):
        """통합 UI 설정"""
        # 메인 Notebook (탭)
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # 탭 1: 다운로드
        self.download_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.download_tab, text="1. 다운로드")
        self.setup_download_tab()
        
        # 탭 2: 파싱
        self.parse_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.parse_tab, text="2. 파싱")
        self.setup_parse_tab()
        
        # 탭 3: 파일명 변경
        self.rename_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.rename_tab, text="3. 파일명 변경")
        self.setup_rename_tab()
        
        # 하단 상태바
        self.status_var = tk.StringVar(value="준비")
        status_bar = ttk.Label(self.root, textvariable=self.status_var, relief=tk.SUNKEN)
        status_bar.pack(fill=tk.X, side=tk.BOTTOM)
    
    # ========== 탭 1: 다운로드 ==========
    def setup_download_tab(self):
        """다운로드 탭 UI 설정"""
        top_frame = ttk.Frame(self.download_tab, padding="10")
        top_frame.pack(fill=tk.BOTH, expand=True)
        
        # 최상단 버튼 프레임
        top_button_frame = ttk.Frame(top_frame)
        top_button_frame.pack(fill=tk.X, pady=5)
        
        self.download_button = ttk.Button(
            top_button_frame, 
            text="다운로드 및 취합 시작", 
            command=self.start_download
        )
        self.download_button.pack(side=tk.LEFT, padx=5)
        
        ttk.Button(top_button_frame, text="결과 폴더 열기", command=self.open_result_folder).pack(side=tk.LEFT, padx=5)
        
        # 다운로드 모드 선택
        mode_frame = ttk.LabelFrame(top_frame, text="다운로드 모드", padding="10")
        mode_frame.pack(fill=tk.X, pady=5)
        
        self.download_mode = tk.StringVar(value="full")
        ttk.Radiobutton(mode_frame, text="전체 다운로드 (신규 업체)", 
                        variable=self.download_mode, value="full").pack(side=tk.LEFT, padx=10)
        ttk.Radiobutton(mode_frame, text="주변 정보만 추가 (기존 업체)", 
                        variable=self.download_mode, value="around_only").pack(side=tk.LEFT, padx=10)
        
        # Excel 파일 등록
        excel_frame = ttk.LabelFrame(top_frame, text="Excel 파일 등록 (시트탭별, 여러 개 선택 가능)", padding="10")
        excel_frame.pack(fill=tk.X, pady=5)
        
        self.excel_path_var = tk.StringVar()
        ttk.Entry(excel_frame, textvariable=self.excel_path_var, width=40).pack(side=tk.LEFT, padx=5)
        ttk.Button(excel_frame, text="Excel 선택 (여러 개)", command=self.select_excel_files).pack(side=tk.LEFT, padx=5)
        ttk.Button(excel_frame, text="URL 로드", command=self.load_urls_from_excel).pack(side=tk.LEFT, padx=5)
        
        # 시트탭 선택
        sheet_frame = ttk.Frame(excel_frame)
        sheet_frame.pack(side=tk.LEFT, padx=10)
        ttk.Label(sheet_frame, text="시트:").pack(side=tk.LEFT, padx=5)
        self.sheet_var = tk.StringVar()
        self.sheet_combo = ttk.Combobox(sheet_frame, textvariable=self.sheet_var, width=20, state='readonly')
        self.sheet_combo.pack(side=tk.LEFT, padx=5)
        self.sheet_combo.bind('<<ComboboxSelected>>', self.on_sheet_selected)
        
        # CSV 파일 선택
        csv_frame = ttk.LabelFrame(top_frame, text="CSV 파일 선택 (1줄에 플레이스 URL 1개)", padding="10")
        csv_frame.pack(fill=tk.X, pady=5)
        
        self.csv_path_var = tk.StringVar()
        ttk.Entry(csv_frame, textvariable=self.csv_path_var, width=50).pack(side=tk.LEFT, padx=5)
        ttk.Button(csv_frame, text="찾아보기", command=self.select_csv_file).pack(side=tk.LEFT, padx=5)
        ttk.Button(csv_frame, text="로드", command=self.load_csv).pack(side=tk.LEFT, padx=5)
        
        # URL 직접 입력
        input_frame = ttk.LabelFrame(top_frame, text="URL 직접 입력 (1줄에 1개)", padding="10")
        input_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        
        self.url_text = scrolledtext.ScrolledText(input_frame, height=6, wrap=tk.WORD)
        self.url_text.pack(fill=tk.BOTH, expand=True)
        
        url_button_frame = ttk.Frame(input_frame)
        url_button_frame.pack(fill=tk.X, pady=5)
        
        ttk.Button(url_button_frame, text="URL 추가", command=self.add_urls_from_text).pack(side=tk.LEFT, padx=5)
        
        # 페이지 소스 보기 메뉴
        text_view_source_menu = tk.Menubutton(url_button_frame, text="페이지 소스 보기 ▼", relief=tk.RAISED)
        text_view_source_menu.pack(side=tk.LEFT, padx=5)
        text_view_source_dropdown = tk.Menu(text_view_source_menu, tearoff=0)
        text_view_source_menu.config(menu=text_view_source_dropdown)
        text_view_source_dropdown.add_command(label="Home", command=lambda: self.open_view_source_from_text('home'))
        text_view_source_dropdown.add_command(label="Review", command=lambda: self.open_view_source_from_text('review'))
        text_view_source_dropdown.add_command(label="Feed", command=lambda: self.open_view_source_from_text('feed'))
        text_view_source_dropdown.add_command(label="Menu", command=lambda: self.open_view_source_from_text('menu'))
        text_view_source_dropdown.add_command(label="List", command=lambda: self.open_view_source_from_text('list'))
        text_view_source_dropdown.add_command(label="Information", command=lambda: self.open_view_source_from_text('information'))
        text_view_source_dropdown.add_command(label="Ticket", command=lambda: self.open_view_source_from_text('ticket'))
        
        # URL 목록
        list_frame = ttk.LabelFrame(top_frame, text="다운로드할 URL 목록", padding="10")
        list_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        
        list_scroll = ttk.Scrollbar(list_frame)
        list_scroll.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.url_listbox = tk.Listbox(list_frame, yscrollcommand=list_scroll.set)
        self.url_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        list_scroll.config(command=self.url_listbox.yview)
        
        button_frame = ttk.Frame(list_frame)
        button_frame.pack(fill=tk.X, pady=5)
        
        ttk.Button(button_frame, text="선택 삭제", command=self.remove_selected).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="전체 삭제", command=self.clear_all).pack(side=tk.LEFT, padx=5)
        
        # 페이지 소스 보기 메뉴
        view_source_menu = tk.Menubutton(button_frame, text="페이지 소스 보기 ▼", relief=tk.RAISED)
        view_source_menu.pack(side=tk.LEFT, padx=5)
        view_source_dropdown = tk.Menu(view_source_menu, tearoff=0)
        view_source_menu.config(menu=view_source_dropdown)
        view_source_dropdown.add_command(label="Home", command=lambda: self.open_view_source_section('home'))
        view_source_dropdown.add_command(label="Review", command=lambda: self.open_view_source_section('review'))
        view_source_dropdown.add_command(label="Feed", command=lambda: self.open_view_source_section('feed'))
        view_source_dropdown.add_command(label="Menu", command=lambda: self.open_view_source_section('menu'))
        view_source_dropdown.add_command(label="List", command=lambda: self.open_view_source_section('list'))
        view_source_dropdown.add_command(label="Information", command=lambda: self.open_view_source_section('information'))
        view_source_dropdown.add_command(label="Ticket", command=lambda: self.open_view_source_section('ticket'))
        
        self.count_label = ttk.Label(button_frame, text="총 0개")
        self.count_label.pack(side=tk.LEFT, padx=10)
        
        self.url_listbox.bind('<Double-Button-1>', lambda e: self.open_view_source_section('home'))
        
        # 저장 경로 설정
        path_frame = ttk.LabelFrame(top_frame, text="저장 경로 설정", padding="10")
        path_frame.pack(fill=tk.X, pady=5)
        
        download_path_frame = ttk.Frame(path_frame)
        download_path_frame.pack(fill=tk.X, pady=2)
        ttk.Label(download_path_frame, text="다운로드 경로:", width=15).pack(side=tk.LEFT)
        self.download_path_var = tk.StringVar(value=self.download_dir)
        ttk.Entry(download_path_frame, textvariable=self.download_path_var, width=50).pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)
        ttk.Button(download_path_frame, text="찾아보기", command=self.select_download_path).pack(side=tk.LEFT, padx=5)
        
        rawdata_path_frame = ttk.Frame(path_frame)
        rawdata_path_frame.pack(fill=tk.X, pady=2)
        ttk.Label(rawdata_path_frame, text="RAWdata 경로:", width=15).pack(side=tk.LEFT)
        self.rawdata_path_var = tk.StringVar(value=self.rawdata_dir)
        ttk.Entry(rawdata_path_frame, textvariable=self.rawdata_path_var, width=50).pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)
        ttk.Button(rawdata_path_frame, text="찾아보기", command=self.select_rawdata_path).pack(side=tk.LEFT, padx=5)
        
        # 구글 드라이브 업로드 옵션
        if HAS_DRIVE_UPLOAD:
            drive_frame = ttk.LabelFrame(top_frame, text="구글 드라이브 업로드", padding="10")
            drive_frame.pack(fill=tk.X, pady=5)
            
            self.drive_upload_var = tk.BooleanVar(value=False)
            ttk.Checkbutton(drive_frame, text="다운로드 완료 후 구글 드라이브에 자동 업로드", 
                           variable=self.drive_upload_var).pack(side=tk.LEFT, padx=5)
            
            drive_folder_frame = ttk.Frame(drive_frame)
            drive_folder_frame.pack(fill=tk.X, pady=5)
            ttk.Label(drive_folder_frame, text="드라이브 폴더명:", width=15).pack(side=tk.LEFT)
            self.drive_folder_var = tk.StringVar(value="플레이스_다운로드")
            ttk.Entry(drive_folder_frame, textvariable=self.drive_folder_var, width=30).pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)
        else:
            self.drive_upload_var = tk.BooleanVar(value=False)
            self.drive_folder_var = tk.StringVar(value="플레이스_다운로드")
        
        # 진행 상황
        progress_frame = ttk.LabelFrame(top_frame, text="진행 상황", padding="10")
        progress_frame.pack(fill=tk.X, pady=5)
        
        self.progress_var = tk.StringVar(value="대기 중...")
        ttk.Label(progress_frame, textvariable=self.progress_var).pack(anchor=tk.W)
        
        self.progress_bar = ttk.Progressbar(progress_frame, mode='determinate')
        self.progress_bar.pack(fill=tk.X, pady=5)
        
        # 로그
        log_frame = ttk.LabelFrame(top_frame, text="로그", padding="10")
        log_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        
        self.download_log_text = scrolledtext.ScrolledText(log_frame, height=10, wrap=tk.WORD)
        self.download_log_text.pack(fill=tk.BOTH, expand=True)
        
        log_button_frame = ttk.Frame(log_frame)
        log_button_frame.pack(fill=tk.X, pady=(5, 0))
        ttk.Button(log_button_frame, text="로그 지우기", command=self.clear_download_log).pack(side=tk.LEFT, padx=5)
        ttk.Button(log_button_frame, text="로그 저장", command=self.save_download_log).pack(side=tk.LEFT, padx=5)
        ttk.Button(log_button_frame, text="플레이스별 취합", command=self.merge_by_place).pack(side=tk.LEFT, padx=5)
        ttk.Button(log_button_frame, text="누락 플레이스 확인", command=self.check_missing_places).pack(side=tk.LEFT, padx=5)
    
    # ========== 탭 2: 파싱 ==========
    def setup_parse_tab(self):
        """파싱 탭 UI 설정"""
        main_container = ttk.Frame(self.parse_tab)
        main_container.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # 상단: 폴더 선택
        top_frame = ttk.Frame(main_container)
        top_frame.pack(fill=tk.X, pady=(0, 10))
        
        ttk.Label(top_frame, text="Rawdata 폴더:", font=('맑은 고딕', 10)).pack(side=tk.LEFT, padx=5)
        self.folder_path_var = tk.StringVar()
        folder_entry = ttk.Entry(top_frame, textvariable=self.folder_path_var, width=60)
        folder_entry.pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)
        
        ttk.Button(top_frame, text="폴더 선택", command=self.select_folder).pack(side=tk.LEFT, padx=5)
        ttk.Button(top_frame, text="전체 파싱", command=self.parse_all).pack(side=tk.LEFT, padx=5)
        ttk.Button(top_frame, text="Reward_data 재로드", command=self.load_reward_data).pack(side=tk.LEFT, padx=5)
        
        # 저장/로드 버튼
        save_frame = ttk.Frame(top_frame)
        save_frame.pack(side=tk.LEFT, padx=10)
        ttk.Button(save_frame, text="Excel 저장", command=self.save_to_excel).pack(side=tk.LEFT, padx=2)
        ttk.Button(save_frame, text="JSON 저장", command=self.save_to_json).pack(side=tk.LEFT, padx=2)
        ttk.Button(save_frame, text="각 업체 JSON 저장", command=self.save_individual_jsons).pack(side=tk.LEFT, padx=2)
        ttk.Button(save_frame, text="JSON 로드", command=self.load_from_json).pack(side=tk.LEFT, padx=2)
        ttk.Button(save_frame, text="JSON 업데이트", command=self.update_json_files).pack(side=tk.LEFT, padx=2)
        
        # 하단: 왼쪽(업체 목록) + 오른쪽(정보 표시)
        bottom_container = ttk.PanedWindow(main_container, orient=tk.HORIZONTAL)
        bottom_container.pack(fill=tk.BOTH, expand=True)
        
        # 왼쪽 패널: 업체 목록
        left_panel = ttk.Frame(bottom_container)
        bottom_container.add(left_panel, weight=1)
        
        list_header = ttk.Label(left_panel, text="업체 목록", font=('맑은 고딕', 12, 'bold'))
        list_header.pack(pady=5)
        
        # 검색 박스
        search_frame = ttk.Frame(left_panel)
        search_frame.pack(fill=tk.X, padx=5, pady=5)
        ttk.Label(search_frame, text="검색:").pack(side=tk.LEFT, padx=2)
        self.search_var = tk.StringVar()
        self.search_var.trace_add('write', self.filter_places)
        search_entry = ttk.Entry(search_frame, textvariable=self.search_var, width=20)
        search_entry.pack(side=tk.LEFT, padx=2, fill=tk.X, expand=True)
        
        # 검색 키워드 저장/로드 버튼
        search_btn_frame = ttk.Frame(search_frame)
        search_btn_frame.pack(side=tk.LEFT, padx=2)
        ttk.Button(search_btn_frame, text="검색어 저장", command=self.save_search_keywords).pack(side=tk.LEFT, padx=1)
        ttk.Button(search_btn_frame, text="검색어 로드", command=self.load_search_keywords).pack(side=tk.LEFT, padx=1)
        
        # 업체 목록
        list_frame = ttk.Frame(left_panel)
        list_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        scrollbar = ttk.Scrollbar(list_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.place_listbox = tk.Listbox(list_frame, yscrollcommand=scrollbar.set, font=('맑은 고딕', 10))
        self.place_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self.place_listbox.bind('<<ListboxSelect>>', self.on_place_selected)
        scrollbar.config(command=self.place_listbox.yview)
        
        # 오른쪽 패널: 정보 표시
        right_panel = ttk.Frame(bottom_container)
        bottom_container.add(right_panel, weight=2)
        
        info_header = ttk.Label(right_panel, text="업체 정보", font=('맑은 고딕', 12, 'bold'))
        info_header.pack(pady=5)
        
        # 탭 위젯
        self.parse_notebook = ttk.Notebook(right_panel)
        self.parse_notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # 각 탭 프레임 생성
        self.setup_info_tabs()
    
    def setup_info_tabs(self):
        """정보 표시 탭 생성"""
        # 요약 보기 탭
        self.summary_tab = ttk.Frame(self.parse_notebook)
        self.parse_notebook.add(self.summary_tab, text="요약 보기", state='normal')
        
        summary_frame = ttk.Frame(self.summary_tab)
        summary_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        columns = ('업체명', 'MID', '역', '아파트', '랜드마크', '메뉴', 'URL')
        self.summary_tree = ttk.Treeview(summary_frame, columns=columns, show='headings', height=20)
        
        self.summary_tree.heading('업체명', text='업체명')
        self.summary_tree.heading('MID', text='MID')
        self.summary_tree.heading('역', text='역 개수')
        self.summary_tree.heading('아파트', text='아파트 개수')
        self.summary_tree.heading('랜드마크', text='랜드마크 개수')
        self.summary_tree.heading('메뉴', text='메뉴 개수')
        self.summary_tree.heading('URL', text='URL')
        
        self.summary_tree.column('업체명', width=150)
        self.summary_tree.column('MID', width=100)
        self.summary_tree.column('역', width=80)
        self.summary_tree.column('아파트', width=80)
        self.summary_tree.column('랜드마크', width=90)
        self.summary_tree.column('메뉴', width=80)
        self.summary_tree.column('URL', width=200)
        
        summary_scroll = ttk.Scrollbar(summary_frame, orient=tk.VERTICAL, command=self.summary_tree.yview)
        self.summary_tree.configure(yscrollcommand=summary_scroll.set)
        
        self.summary_tree.bind('<Double-1>', self.on_summary_double_click)
        
        self.summary_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        summary_scroll.pack(side=tk.RIGHT, fill=tk.Y)
        
        # 기본 정보 탭
        self.basic_tab = ttk.Frame(self.parse_notebook)
        self.parse_notebook.add(self.basic_tab, text="기본 정보")
        
        basic_text = scrolledtext.ScrolledText(self.basic_tab, wrap=tk.WORD, font=('맑은 고딕', 10))
        basic_text.pack(fill=tk.BOTH, expand=True)
        self.basic_text = basic_text
        
        # 주소 탭
        self.address_tab = ttk.Frame(self.parse_notebook)
        self.parse_notebook.add(self.address_tab, text="주소")
        
        address_text = scrolledtext.ScrolledText(self.address_tab, wrap=tk.WORD, font=('맑은 고딕', 10))
        address_text.pack(fill=tk.BOTH, expand=True)
        self.address_text = address_text
        
        # 주변 정보 탭
        self.around_tab = ttk.Frame(self.parse_notebook)
        self.parse_notebook.add(self.around_tab, text="주변 정보")
        
        around_text = scrolledtext.ScrolledText(self.around_tab, wrap=tk.WORD, font=('맑은 고딕', 10))
        around_text.pack(fill=tk.BOTH, expand=True)
        self.around_text = around_text
        
        # 메뉴 탭
        self.menu_tab = ttk.Frame(self.parse_notebook)
        self.parse_notebook.add(self.menu_tab, text="메뉴")
        
        menu_text = scrolledtext.ScrolledText(self.menu_tab, wrap=tk.WORD, font=('맑은 고딕', 10))
        menu_text.pack(fill=tk.BOTH, expand=True)
        self.menu_text = menu_text
        
        # 소개글 탭
        self.intro_tab = ttk.Frame(self.parse_notebook)
        self.parse_notebook.add(self.intro_tab, text="소개글")
        
        intro_text = scrolledtext.ScrolledText(self.intro_tab, wrap=tk.WORD, font=('맑은 고딕', 10))
        intro_text.pack(fill=tk.BOTH, expand=True)
        self.intro_text = intro_text
        
        # 기타 탭
        self.other_tab = ttk.Frame(self.parse_notebook)
        self.parse_notebook.add(self.other_tab, text="기타")
        
        other_text = scrolledtext.ScrolledText(self.other_tab, wrap=tk.WORD, font=('맑은 고딕', 10))
        other_text.pack(fill=tk.BOTH, expand=True)
        self.other_text = other_text
        
        # 작업 키워드 탭
        self.work_keywords_tab = ttk.Frame(self.parse_notebook)
        self.parse_notebook.add(self.work_keywords_tab, text="작업 키워드")
        
        work_keywords_frame = ttk.Frame(self.work_keywords_tab)
        work_keywords_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        existing_label = ttk.Label(work_keywords_frame, text="기존 작업 키워드:", font=('맑은 고딕', 10, 'bold'))
        existing_label.pack(anchor=tk.W, pady=(0, 5))
        
        existing_keywords_text = scrolledtext.ScrolledText(work_keywords_frame, wrap=tk.WORD, 
                                                          font=('맑은 고딕', 10), height=5)
        existing_keywords_text.pack(fill=tk.X, pady=(0, 10))
        self.existing_keywords_text = existing_keywords_text
        
        groups_label = ttk.Label(work_keywords_frame, text="생성된 키워드 그룹:", font=('맑은 고딕', 10, 'bold'))
        groups_label.pack(anchor=tk.W, pady=(0, 5))
        
        group_notebook = ttk.Notebook(work_keywords_frame)
        group_notebook.pack(fill=tk.BOTH, expand=True)
        
        group1_tab = ttk.Frame(group_notebook)
        group_notebook.add(group1_tab, text="그룹 1: 지역키")
        group1_text = scrolledtext.ScrolledText(group1_tab, wrap=tk.WORD, font=('맑은 고딕', 10))
        group1_text.pack(fill=tk.BOTH, expand=True)
        self.group1_text = group1_text
        
        group2_tab = ttk.Frame(group_notebook)
        group_notebook.add(group2_tab, text="그룹 2: 메뉴키")
        group2_text = scrolledtext.ScrolledText(group2_tab, wrap=tk.WORD, font=('맑은 고딕', 10))
        group2_text.pack(fill=tk.BOTH, expand=True)
        self.group2_text = group2_text
        
        group3_tab = ttk.Frame(group_notebook)
        group_notebook.add(group3_tab, text="그룹 3: 업종키")
        group3_text = scrolledtext.ScrolledText(group3_tab, wrap=tk.WORD, font=('맑은 고딕', 10))
        group3_text.pack(fill=tk.BOTH, expand=True)
        self.group3_text = group3_text
    
    # ========== 탭 3: 파일명 변경 ==========
    def setup_rename_tab(self):
        """파일명 변경 탭 UI 설정"""
        main_container = ttk.Frame(self.rename_tab, padding="10")
        main_container.pack(fill=tk.BOTH, expand=True)
        
        # 상단: 폴더 선택
        folder_frame = ttk.LabelFrame(main_container, text="rawdata 폴더", padding="10")
        folder_frame.pack(fill=tk.X, pady=(0, 10))
        
        self.rename_folder_path_var = tk.StringVar(value=self.rawdata_dir)
        folder_entry = ttk.Entry(folder_frame, textvariable=self.rename_folder_path_var, width=70)
        folder_entry.pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)
        ttk.Button(folder_frame, text="찾아보기", command=self.select_rename_folder).pack(side=tk.LEFT, padx=5)
        
        # 미리보기 영역
        preview_frame = ttk.LabelFrame(main_container, text="변경 미리보기", padding="10")
        preview_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        list_frame = ttk.Frame(preview_frame)
        list_frame.pack(fill=tk.BOTH, expand=True)
        
        columns = ('original', 'new', 'status')
        self.preview_tree = ttk.Treeview(list_frame, columns=columns, show='headings', height=15)
        
        self.preview_tree.heading('original', text='현재 파일명')
        self.preview_tree.heading('new', text='새 파일명 (업체명)')
        self.preview_tree.heading('status', text='상태')
        
        self.preview_tree.column('original', width=350)
        self.preview_tree.column('new', width=350)
        self.preview_tree.column('status', width=150)
        
        scrollbar = ttk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.preview_tree.yview)
        self.preview_tree.configure(yscrollcommand=scrollbar.set)
        
        self.preview_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # 하단: 버튼 및 상태
        bottom_frame = ttk.Frame(main_container)
        bottom_frame.pack(fill=tk.X, pady=(0, 10))
        
        button_frame = ttk.Frame(bottom_frame)
        button_frame.pack(side=tk.LEFT)
        
        ttk.Button(button_frame, text="미리보기", command=self.preview_rename).pack(side=tk.LEFT, padx=5)
        self.rename_button = ttk.Button(button_frame, text="파일명 변경 실행", command=self.start_rename, width=20)
        self.rename_button.pack(side=tk.LEFT, padx=5)
        
        self.rename_status_var = tk.StringVar(value="준비")
        status_label = ttk.Label(bottom_frame, textvariable=self.rename_status_var, font=('맑은 고딕', 10))
        status_label.pack(side=tk.LEFT, padx=20)
        
        # 로그 영역
        log_frame = ttk.LabelFrame(main_container, text="로그", padding="10")
        log_frame.pack(fill=tk.BOTH, expand=True)
        
        log_scroll = scrolledtext.ScrolledText(log_frame, height=8, wrap=tk.WORD, font=('Consolas', 9))
        log_scroll.pack(fill=tk.BOTH, expand=True)
        self.rename_log_text = log_scroll
    
    # ========== 다운로드 탭 메서드 ==========
    def select_excel_files(self):
        """Excel 파일 여러 개 선택"""
        file_paths = filedialog.askopenfilenames(
            title="Excel 파일 선택 (여러 개 선택 가능)",
            filetypes=[("Excel files", "*.xlsx *.xls"), ("All files", "*.*")],
            initialdir=r"C:\Users\lcm35\OneDrive\바탕 화면\플레이스 파서"
        )
        if file_paths:
            self.excel_files = list(file_paths)
            if len(self.excel_files) == 1:
                self.excel_path_var.set(self.excel_files[0])
            else:
                self.excel_path_var.set(f"{len(self.excel_files)}개 파일 선택됨")
            
            self.excel_file_path = self.excel_files[0]
            try:
                import pandas as pd
                excel_file = pd.ExcelFile(self.excel_file_path)
                sheet_names = excel_file.sheet_names
                self.sheet_combo['values'] = sheet_names
                if sheet_names:
                    self.sheet_combo.current(0)
                    self.on_sheet_selected()
            except Exception as e:
                messagebox.showerror("오류", f"Excel 파일 읽기 실패:\n{str(e)}")
            
            self.download_log(f"Excel 파일 {len(self.excel_files)}개 선택됨")
    
    def load_urls_from_excel(self):
        """선택된 Excel 파일들에서 URL 추출하여 UI에 추가"""
        if not self.excel_files:
            messagebox.showwarning("경고", "Excel 파일을 먼저 선택해주세요.")
            return
        
        try:
            import pandas as pd
            all_urls = []
            sheet_name = self.sheet_var.get() or None
            
            self.download_log(f"\nExcel 파일에서 URL 추출 시작...")
            
            for excel_path in self.excel_files:
                try:
                    excel_file = pd.ExcelFile(excel_path)
                    sheet_names = excel_file.sheet_names
                    
                    if sheet_name and sheet_name in sheet_names:
                        sheets_to_process = [sheet_name]
                    else:
                        sheets_to_process = sheet_names
                    
                    for sheet in sheets_to_process:
                        df = pd.read_excel(excel_path, sheet_name=sheet)
                        
                        url_columns = ['플레이스 URL', '플레이스URL', 'URL', 'url', '플레이스 url', '플레이스url']
                        url_col = None
                        
                        for col in df.columns:
                            col_str = str(col).strip()
                            if col_str in url_columns:
                                url_col = col
                                break
                        
                        if url_col:
                            urls = df[url_col].dropna().astype(str).tolist()
                            valid_urls = [url.strip() for url in urls if url.strip().startswith('http')]
                            all_urls.extend(valid_urls)
                            self.download_log(f"  {os.path.basename(excel_path)} ({sheet}): {len(valid_urls)}개 URL")
                        else:
                            self.download_log(f"  [경고] {os.path.basename(excel_path)} ({sheet}): URL 컬럼을 찾을 수 없습니다")
                
                except Exception as e:
                    self.download_log(f"  [오류] {os.path.basename(excel_path)} 처리 실패: {str(e)}")
                    continue
            
            if all_urls:
                unique_urls = list(dict.fromkeys(all_urls))
                self.urls.extend(unique_urls)
                self.update_url_list()
                self.download_log(f"\n총 {len(unique_urls)}개 URL이 추가되었습니다.")
                messagebox.showinfo("완료", f"{len(unique_urls)}개 URL이 추가되었습니다.")
            else:
                self.download_log(f"\n추출된 URL이 없습니다.")
                messagebox.showwarning("경고", "추출된 URL이 없습니다.")
        
        except Exception as e:
            self.download_log(f"\n[오류] URL 추출 실패: {str(e)}")
            import traceback
            self.download_log(traceback.format_exc())
            messagebox.showerror("오류", f"URL 추출 중 오류가 발생했습니다:\n{str(e)}")
    
    def on_sheet_selected(self, event=None):
        """시트 선택 시 Excel 데이터 로드"""
        if not self.excel_file_path:
            return
        
        sheet_name = self.sheet_var.get()
        if not sheet_name:
            return
        
        try:
            import pandas as pd
            df = pd.read_excel(self.excel_file_path, sheet_name=sheet_name)
            self.excel_sheet_name = sheet_name
            self.excel_data = df
            
            self.place_id_map = {}
            
            id_columns = ['플레이스 ID', '플레이스ID', 'MID값', 'MID', 'place_id', 'ID', 'id']
            name_columns = ['플레이스명', '플레이스 이름', 'place_name', '이름', '상점명', 'name']
            url_columns = ['플레이스 URL', '플레이스URL', 'URL', 'url', '플레이스 url', '플레이스url']
            
            id_col = None
            name_col = None
            url_col = None
            
            for col in df.columns:
                col_str = str(col).strip()
                if col_str in id_columns and id_col is None:
                    id_col = col
                if col_str in name_columns and name_col is None:
                    name_col = col
                if col_str in url_columns and url_col is None:
                    url_col = col
            
            if id_col:
                if name_col:
                    for _, row in df.iterrows():
                        place_id = str(row.get(id_col, '')).strip()
                        place_name = str(row.get(name_col, '')).strip()
                        if place_id and place_id != 'nan' and place_id != '':
                            self.place_id_map[place_id] = place_name if place_name and place_name != 'nan' else f"place_{place_id}"
                elif url_col:
                    from download_place_pages import extract_place_id_and_name
                    for _, row in df.iterrows():
                        place_id = str(row.get(id_col, '')).strip()
                        url = str(row.get(url_col, '')).strip()
                        if place_id and place_id != 'nan' and place_id != '':
                            if url and url != 'nan':
                                _, place_name = extract_place_id_and_name(url)
                                self.place_id_map[place_id] = place_name if place_name and place_name != 'unknown' else f"place_{place_id}"
                            else:
                                self.place_id_map[place_id] = f"place_{place_id}"
                else:
                    for _, row in df.iterrows():
                        place_id = str(row.get(id_col, '')).strip()
                        if place_id and place_id != 'nan' and place_id != '':
                            self.place_id_map[place_id] = f"place_{place_id}"
            elif url_col:
                from download_place_pages import extract_place_id_and_name
                for _, row in df.iterrows():
                    url = str(row.get(url_col, '')).strip()
                    if url and url != 'nan' and url.startswith('http'):
                        place_id, place_name = extract_place_id_and_name(url)
                        if place_id:
                            self.place_id_map[place_id] = place_name if place_name and place_name != 'unknown' else f"place_{place_id}"
            
            self.download_log(f"Excel 파일 로드 완료: {sheet_name} 시트 ({len(df)}행)")
            if self.place_id_map:
                self.download_log(f"플레이스 ID 매핑: {len(self.place_id_map)}개")
            else:
                self.download_log(f"⚠ 플레이스 ID 매핑을 찾을 수 없습니다.")
                self.download_log(f"  컬럼 목록: {list(df.columns)}")
        except Exception as e:
            messagebox.showerror("오류", f"시트 읽기 실패:\n{str(e)}")
    
    def select_csv_file(self):
        """CSV 파일 선택"""
        filename = filedialog.askopenfilename(
            title="CSV 파일 선택",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")]
        )
        if filename:
            self.csv_path_var.set(filename)
    
    def load_csv(self):
        """CSV 파일에서 URL 로드"""
        csv_path = self.csv_path_var.get()
        if not csv_path or not os.path.exists(csv_path):
            messagebox.showerror("오류", "CSV 파일을 선택하세요.")
            return
        
        try:
            urls = []
            with open(csv_path, 'r', encoding='utf-8') as f:
                reader = csv.reader(f)
                for row in reader:
                    if row and row[0].strip():
                        url = row[0].strip()
                        if url.startswith('http'):
                            urls.append(url)
            
            if urls:
                self.urls.extend(urls)
                self.update_url_list()
                self.download_log(f"CSV에서 {len(urls)}개 URL 로드 완료")
                messagebox.showinfo("완료", f"{len(urls)}개 URL이 추가되었습니다.")
            else:
                messagebox.showwarning("경고", "CSV 파일에서 URL을 찾을 수 없습니다.")
        except Exception as e:
            messagebox.showerror("오류", f"CSV 파일 읽기 실패: {e}")
    
    def add_urls_from_text(self):
        """텍스트 영역에서 URL 추가"""
        text = self.url_text.get("1.0", tk.END).strip()
        if not text:
            return
        
        lines = [line.strip() for line in text.split('\n') if line.strip()]
        new_urls = []
        
        for line in lines:
            if line.startswith('http'):
                new_urls.append(line)
        
        if new_urls:
            self.urls.extend(new_urls)
            self.update_url_list()
            self.download_log(f"텍스트에서 {len(new_urls)}개 URL 추가 완료")
            self.url_text.delete("1.0", tk.END)
            messagebox.showinfo("완료", f"{len(new_urls)}개 URL이 추가되었습니다.")
        else:
            messagebox.showwarning("경고", "유효한 URL을 찾을 수 없습니다.")
    
    def update_url_list(self):
        """URL 목록 업데이트"""
        self.url_listbox.delete(0, tk.END)
        for i, url in enumerate(self.urls, 1):
            if extract_place_id_and_name:
                _, place_name = extract_place_id_and_name(url)
                display_text = f"{i}. {place_name} - {url[:50]}..."
            else:
                display_text = f"{i}. {url[:50]}..."
            self.url_listbox.insert(tk.END, display_text)
        
        self.count_label.config(text=f"총 {len(self.urls)}개")
    
    def remove_selected(self):
        """선택된 URL 삭제"""
        selected = self.url_listbox.curselection()
        if not selected:
            messagebox.showwarning("경고", "삭제할 항목을 선택하세요.")
            return
        
        for idx in reversed(selected):
            self.urls.pop(idx)
        
        self.update_url_list()
        self.download_log(f"{len(selected)}개 URL 삭제 완료")
    
    def clear_all(self):
        """전체 URL 삭제"""
        if messagebox.askyesno("확인", "모든 URL을 삭제하시겠습니까?"):
            self.urls = []
            self.update_url_list()
            self.download_log("모든 URL 삭제 완료")
    
    def normalize_url(self, url):
        """URL 정규화"""
        if not url.startswith('http'):
            return None
        
        place_types = ['restaurant', 'place', 'accommodation', 'hospital', 'hairshop', 'nailshop']
        sections = ['home', 'review', 'feed', 'menu', 'list', 'information', 'ticket']
        
        has_section = any(url.endswith(f'/{s}') or url.endswith(f'/{s}/') for s in sections)
        
        if not has_section:
            for place_type in place_types:
                if f'/{place_type}/' in url:
                    if url.endswith('/'):
                        url = url + 'home'
                    else:
                        url = url + '/home'
                    break
        
        return url
    
    def open_view_source_section(self, section='home', url=None):
        """선택된 URL의 특정 섹션 페이지 소스 보기 화면 열기"""
        if url is None:
            selected = self.url_listbox.curselection()
            if not selected:
                messagebox.showwarning("경고", "URL을 선택하세요.")
                return
            
            idx = selected[0]
            if idx >= len(self.urls):
                return
            
            url = self.urls[idx]
        
        url = self.normalize_url(url)
        if not url:
            messagebox.showerror("오류", "유효하지 않은 URL입니다.")
            return
        
        place_types = ['restaurant', 'place', 'accommodation', 'hospital', 'hairshop', 'nailshop']
        sections_pattern = r'/(home|review|feed|menu|list|information|ticket)(/)?$'
        
        url = re.sub(sections_pattern, '', url)
        
        has_place_type = any(f'/{pt}/' in url for pt in place_types)
        
        if has_place_type:
            if not url.endswith('/'):
                url = url + '/'
            url = url + section
        
        view_source_url = f"view-source:{url}"
        
        try:
            webbrowser.open(view_source_url)
            self.download_log(f"페이지 소스 보기 열기 [{section}]: {url}")
        except Exception as e:
            messagebox.showerror("오류", f"브라우저 열기 실패: {e}")
    
    def open_view_source_from_text(self, section='home'):
        """텍스트 영역의 첫 번째 URL로 페이지 소스 보기"""
        text = self.url_text.get("1.0", tk.END).strip()
        if not text:
            messagebox.showwarning("경고", "URL을 입력하세요.")
            return
        
        lines = [line.strip() for line in text.split('\n') if line.strip()]
        for line in lines:
            if line.startswith('http'):
                self.open_view_source_section(section, line)
                return
        
        messagebox.showwarning("경고", "유효한 URL을 찾을 수 없습니다.")
    
    def select_download_path(self):
        """다운로드 경로 선택"""
        path = filedialog.askdirectory(
            title="다운로드 경로 선택",
            initialdir=self.download_dir
        )
        if path:
            self.download_dir = path
            self.download_path_var.set(path)
            self.download_log(f"다운로드 경로 변경: {path}")
    
    def select_rawdata_path(self):
        """RAWdata 경로 선택"""
        path = filedialog.askdirectory(
            title="RAWdata 경로 선택",
            initialdir=self.rawdata_dir
        )
        if path:
            self.rawdata_dir = path
            self.rawdata_path_var.set(path)
            self.download_log(f"RAWdata 경로 변경: {path}")
    
    def clear_download_log(self):
        """로그 지우기"""
        self.download_log_text.delete("1.0", tk.END)
        self.download_log("로그가 지워졌습니다.")
    
    def save_download_log(self):
        """로그 저장"""
        filename = filedialog.asksaveasfilename(
            title="로그 저장",
            defaultextension=".txt",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")]
        )
        if filename:
            try:
                with open(filename, 'w', encoding='utf-8') as f:
                    f.write(self.download_log_text.get("1.0", tk.END))
                self.download_log(f"로그 저장 완료: {filename}")
                messagebox.showinfo("완료", "로그가 저장되었습니다.")
            except Exception as e:
                messagebox.showerror("오류", f"로그 저장 실패: {e}")
    
    def download_log(self, message):
        """로그 메시지 추가"""
        self.download_log_text.insert(tk.END, f"{message}\n")
        self.download_log_text.see(tk.END)
        self.root.update()
    
    def start_download(self):
        """다운로드 시작"""
        if not self.urls:
            messagebox.showwarning("경고", "다운로드할 URL이 없습니다.")
            return
        
        if self.downloading:
            messagebox.showwarning("경고", "이미 다운로드 중입니다.")
            return
        
        thread = threading.Thread(target=self.download_all, daemon=True)
        thread.start()
    
    def download_all(self):
        """모든 URL 다운로드 및 취합"""
        self.downloading = True
        self.download_button.config(state='disabled')
        
        total = len(self.urls)
        success_count = 0
        fail_count = 0
        
        self.progress_bar['maximum'] = total
        self.progress_bar['value'] = 0
        
        driver = None
        try:
            from download_place_pages import create_selenium_driver
            self.download_log("\n[초기화] 브라우저 창 생성 중... (모든 업체 공통 사용)")
            driver = create_selenium_driver()
            self.download_log("  [완료] 브라우저 창 생성 완료")
            
            rawdata_dir = self.rawdata_path_var.get() or self.rawdata_dir
            os.makedirs(rawdata_dir, exist_ok=True)
            
            for i, url in enumerate(self.urls, 1):
                if not self.downloading:
                    break
                
                self.progress_var.set(f"진행 중... ({i}/{total})")
                self.download_log(f"\n[{i}/{total}] {url}")
                
                try:
                    place_id, place_name = extract_place_id_and_name(url)
                    
                    if not place_id:
                        self.download_log(f"  [실패] 플레이스 ID를 찾을 수 없습니다.")
                        fail_count += 1
                        continue
                    
                    self.download_log(f"  플레이스: {place_name} (ID: {place_id})")
                    
                    download_mode = self.download_mode.get()
                    
                    if download_mode == "around_only":
                        self.download_log(f"  [모드] 주변 정보만 추가 추출")
                        
                        # 주변 정보 추출 (오류 발생 시 무시하고 계속 진행)
                        try:
                            if not extract_map_markers_from_page:
                                self.download_log(f"  [건너뜀] extract_map_markers_from_page 함수 없음")
                                fail_count += 1
                                continue
                            
                            from urllib.parse import urlparse
                            parsed = urlparse(url)
                            base_path = parsed.path
                            place_types = ['restaurant', 'place', 'accommodation', 'hospital', 'hairshop', 'nailshop']
                            
                            if '/home' in base_path:
                                base_path = base_path.replace('/home', '')
                            
                            for place_type in place_types:
                                pattern = re.compile(rf'/{place_type}/(\d+)/.*')
                                if pattern.search(base_path):
                                    base_path = pattern.sub(rf'/{place_type}/\1', base_path)
                                    break
                            
                            base_domain = f"{parsed.scheme}://{parsed.netloc}"
                            location_url = f"{base_domain}{base_path}/location"
                            
                            markers_file = extract_map_markers_from_page(
                                driver, location_url, place_id, place_name, rawdata_dir
                            )
                            
                            if markers_file:
                                self.download_log(f"  [완료] 주변 정보 추출 완료: {os.path.basename(markers_file)}")
                                success_count += 1
                            else:
                                self.download_log(f"  [실패] 주변 정보 추출 실패")
                                fail_count += 1
                        except Exception as e:
                            self.download_log(f"  [오류] 주변 정보 추출 중 오류: {e}")
                            fail_count += 1
                    
                    else:
                        self.download_log(f"  [모드] 전체 다운로드 (신규 업체)")
                        self.download_log(f"  다운로드 중... (순서: {i}, 경로: {rawdata_dir})")
                        
                        if not download_place_sections:
                            self.download_log(f"  [오류] download_place_sections 함수 없음 (PlacePasser 모듈 확인 필요)")
                            fail_count += 1
                            continue
                        
                        rawdata_file, driver = download_place_sections(
                            base_url=url,
                            place_name=place_name,
                            output_dir=rawdata_dir,
                            use_selenium=True,
                            driver=driver,
                            order=i,
                            place_id=place_id,
                            sections=None,
                            extract_map_markers=True  # 주변 정보 추출 시도 (실패해도 무시)
                        )
                        
                        if rawdata_file:
                            self.download_log(f"  [완료] RAWdata 파일 생성: {os.path.basename(rawdata_file)}")
                            success_count += 1
                            
                            if self.drive_upload_var.get() and HAS_DRIVE_UPLOAD and upload_file_to_drive:
                                try:
                                    self.download_log(f"  구글 드라이브 업로드 중...")
                                    drive_folder_name = self.drive_folder_var.get() or "플레이스_다운로드"
                                    drive_folder_id = find_or_create_folder(drive_folder_name)
                                    
                                    if drive_folder_id:
                                        file_id = upload_file_to_drive(rawdata_file, folder_id=drive_folder_id)
                                        if file_id:
                                            self.download_log(f"  [완료] 구글 드라이브 업로드 성공")
                                        else:
                                            self.download_log(f"  [실패] 구글 드라이브 업로드 실패")
                                    else:
                                        self.download_log(f"  [실패] 구글 드라이브 폴더 생성 실패")
                                except Exception as e:
                                    self.download_log(f"  [오류] 구글 드라이브 업로드 오류: {str(e)}")
                        else:
                            self.download_log(f"  [실패] 다운로드 실패")
                            fail_count += 1
                
                except Exception as e:
                    self.download_log(f"  [오류] {str(e)}")
                    fail_count += 1
                
                self.progress_bar['value'] = i
                self.root.update()
                
                if i < total:
                    self.download_log(f"  [대기] 다음 업체 처리 전 5초 대기...")
                    time.sleep(5)
            
            self.progress_var.set(f"완료! (성공: {success_count}, 실패: {fail_count})")
            self.download_log(f"\n{'='*70}")
            self.download_log(f"전체 완료: 성공 {success_count}개, 실패 {fail_count}개")
            self.download_log(f"{'='*70}")
            
        except Exception as e:
            self.download_log(f"\n[오류] 전체 다운로드 오류: {str(e)}")
        finally:
            if driver:
                self.download_log("\n[종료] 브라우저 창 종료 중...")
                try:
                    driver.quit()
                    self.download_log("  [완료] 브라우저 창 종료 완료")
                except:
                    pass
            
            self.downloading = False
            self.download_button.config(state='normal')
            
            messagebox.showinfo("완료", f"다운로드 및 취합 완료!\n성공: {success_count}개\n실패: {fail_count}개")
    
    def open_result_folder(self):
        """결과 폴더 열기"""
        rawdata_dir = self.rawdata_path_var.get() or self.rawdata_dir
        download_dir = self.download_path_var.get() or self.download_dir
        
        if os.path.exists(rawdata_dir):
            os.startfile(rawdata_dir)
        elif os.path.exists(download_dir):
            os.startfile(download_dir)
        else:
            messagebox.showinfo("정보", "다운로드된 파일이 없습니다.")
    
    def merge_by_place(self):
        """플레이스별로 취합하기"""
        rawdata_dir = self.rawdata_path_var.get() or self.rawdata_dir
        if not rawdata_dir or not os.path.exists(rawdata_dir):
            messagebox.showerror("오류", "RAWdata 폴더를 선택해주세요.")
            return
        
        if self.downloading:
            messagebox.showwarning("경고", "다운로드 중에는 취합할 수 없습니다.")
            return
        
        self.downloading = True
        
        def merge():
            try:
                self.download_log(f"\n{'='*70}")
                self.download_log(f"플레이스별 취합 시작: {rawdata_dir}")
                self.download_log(f"{'='*70}")
                
                place_files = defaultdict(list)
                txt_files = [f for f in os.listdir(rawdata_dir) if f.endswith('.txt')]
                
                for filename in txt_files:
                    place_id_match = re.search(r'place_(\d+)', filename)
                    if place_id_match:
                        place_id = place_id_match.group(1)
                        place_files[place_id].append(filename)
                
                self.download_log(f"\n발견된 플레이스: {len(place_files)}개")
                
                output_dir = rawdata_dir
                merged_count = 0
                
                for place_id, files in place_files.items():
                    if len(files) <= 1:
                        continue
                    
                    place_name = self.place_id_map.get(place_id, f"place_{place_id}")
                    
                    filename_parts = []
                    if self.excel_file_path:
                        excel_name = os.path.splitext(os.path.basename(self.excel_file_path))[0]
                        filename_parts.append(excel_name)
                    if self.excel_sheet_name:
                        filename_parts.append(self.excel_sheet_name)
                    
                    safe_place_name = place_name.replace('/', '_').replace('\\', '_').replace(':', '_').replace('*', '_').replace('?', '_').replace('"', '_').replace('<', '_').replace('>', '_').replace('|', '_')
                    filename_parts.append(safe_place_name)
                    filename_parts.append(place_id)
                    
                    merged_filename = '_'.join(filename_parts) + '_merged.txt'
                    merged_path = os.path.join(output_dir, merged_filename)
                    
                    with open(merged_path, 'w', encoding='utf-8') as f:
                        f.write(f"# 플레이스 취합 데이터\n")
                        f.write(f"# 플레이스명: {place_name}\n")
                        f.write(f"# 플레이스 ID: {place_id}\n")
                        if self.excel_file_path:
                            f.write(f"# Excel 파일: {os.path.basename(self.excel_file_path)}\n")
                        if self.excel_sheet_name:
                            f.write(f"# 시트명: {self.excel_sheet_name}\n")
                        f.write(f"# 섹션 파일: {', '.join(sorted(files))}\n")
                        f.write(f"{'='*70}\n\n")
                        
                        for filename in sorted(files):
                            file_path = os.path.join(rawdata_dir, filename)
                            
                            section_match = re.search(r'_(\w+)\.txt$', filename)
                            section_name = section_match.group(1) if section_match else 'unknown'
                            
                            f.write(f"\n{'='*70}\n")
                            f.write(f"# SECTION: {section_name.upper()}\n")
                            f.write(f"# 파일: {filename}\n")
                            f.write(f"{'='*70}\n\n")
                            
                            try:
                                with open(file_path, 'r', encoding='utf-8') as src:
                                    content = src.read()
                                    f.write(content)
                            except Exception as e:
                                self.download_log(f"  ⚠ 파일 읽기 실패: {filename} - {str(e)}")
                                f.write(f"# 파일 읽기 실패: {str(e)}\n")
                        
                        f.write(f"\n\n{'='*70}\n")
                        f.write(f"# 취합 완료\n")
                        f.write(f"{'='*70}\n")
                    
                    self.download_log(f"  ✓ 취합 완료: {place_name} ({len(files)}개 섹션) -> {merged_filename}")
                    merged_count += 1
                
                self.download_log(f"\n{'='*70}")
                self.download_log(f"취합 완료: {merged_count}개 플레이스")
                self.download_log(f"저장 위치: {output_dir}")
                self.download_log(f"{'='*70}")
                
                messagebox.showinfo("완료", f"플레이스별 취합 완료!\n\n{merged_count}개 플레이스 취합됨\n\n저장 위치: {output_dir}")
                
            except Exception as e:
                self.download_log(f"\n오류 발생: {str(e)}")
                import traceback
                self.download_log(traceback.format_exc())
                messagebox.showerror("오류", f"취합 중 오류가 발생했습니다:\n{str(e)}")
            finally:
                self.downloading = False
        
        threading.Thread(target=merge, daemon=True).start()
    
    def check_missing_places(self):
        """Excel에 있지만 다운로드되지 않은 플레이스 확인"""
        rawdata_dir = self.rawdata_path_var.get() or self.rawdata_dir
        if not rawdata_dir or not os.path.exists(rawdata_dir):
            messagebox.showerror("오류", "RAWdata 폴더를 선택해주세요.")
            return
        
        if not self.excel_file_path or not self.excel_sheet_name:
            messagebox.showwarning("경고", "Excel 파일과 시트를 먼저 선택해주세요.")
            return
        
        if not self.place_id_map:
            messagebox.showwarning("경고", "Excel에서 플레이스 ID를 찾을 수 없습니다.")
            return
        
        try:
            self.download_log(f"\n{'='*70}")
            self.download_log(f"누락 플레이스 확인 시작")
            self.download_log(f"{'='*70}")
            
            excel_place_ids = set(self.place_id_map.keys())
            self.download_log(f"\nExcel 파일의 플레이스 ID: {len(excel_place_ids)}개")
            
            downloaded_place_ids = set()
            txt_files = [f for f in os.listdir(rawdata_dir) if f.endswith('.txt')]
            
            for filename in txt_files:
                place_id_match = re.search(r'place_(\d+)', filename)
                if place_id_match:
                    place_id = place_id_match.group(1)
                    downloaded_place_ids.add(place_id)
            
            self.download_log(f"다운로드된 플레이스 ID: {len(downloaded_place_ids)}개")
            
            missing_place_ids = excel_place_ids - downloaded_place_ids
            
            if missing_place_ids:
                self.download_log(f"\n⚠ 누락된 플레이스: {len(missing_place_ids)}개")
                self.download_log(f"{'='*70}")
                
                missing_list = []
                for place_id in sorted(missing_place_ids):
                    place_name = self.place_id_map.get(place_id, f"place_{place_id}")
                    self.download_log(f"  - {place_name} (ID: {place_id})")
                    missing_list.append({
                        '플레이스ID': place_id,
                        '플레이스명': place_name
                    })
                
                missing_file = os.path.join(rawdata_dir, '_MISSING_PLACES.txt')
                with open(missing_file, 'w', encoding='utf-8') as f:
                    f.write(f"# 누락된 플레이스 목록\n")
                    f.write(f"# Excel 파일: {os.path.basename(self.excel_file_path)}\n")
                    f.write(f"# 시트명: {self.excel_sheet_name}\n")
                    f.write(f"# 확인 일시: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                    f.write(f"# 총 누락: {len(missing_place_ids)}개\n")
                    f.write(f"{'='*70}\n\n")
                    
                    for item in missing_list:
                        f.write(f"플레이스ID: {item['플레이스ID']}\n")
                        f.write(f"플레이스명: {item['플레이스명']}\n")
                        f.write(f"{'-'*70}\n")
                
                self.download_log(f"\n누락 목록 저장: {missing_file}")
                self.download_log(f"{'='*70}")
                
                messagebox.showwarning(
                    "누락 플레이스 발견",
                    f"Excel에는 있지만 다운로드되지 않은 플레이스가 {len(missing_place_ids)}개 있습니다.\n\n"
                    f"상세 목록: {missing_file}"
                )
            else:
                self.download_log(f"\n✓ 모든 플레이스가 다운로드되었습니다!")
                self.download_log(f"{'='*70}")
                messagebox.showinfo("완료", "모든 플레이스가 다운로드되었습니다!")
                
        except Exception as e:
            self.download_log(f"\n오류 발생: {str(e)}")
            import traceback
            self.download_log(traceback.format_exc())
            messagebox.showerror("오류", f"누락 플레이스 확인 중 오류가 발생했습니다:\n{str(e)}")
    
    # ========== 파싱 탭 메서드 ==========
    def select_folder(self):
        """Rawdata 폴더 선택"""
        folder = filedialog.askdirectory(title="Rawdata 폴더 선택", initialdir=self.rawdata_dir)
        if folder:
            self.rawdata_dir = folder
            self.folder_path_var.set(folder)
            self.scan_place_files()
    
    def scan_place_files(self):
        """폴더에서 merged.txt 파일 스캔"""
        if not self.rawdata_dir:
            return
        
        self.status_var.set("파일 스캔 중...")
        self.root.update()
        
        rawdata_path = Path(self.rawdata_dir)
        merged_files = list(rawdata_path.glob("*_merged.txt"))
        
        self.all_place_files = []
        for file in merged_files:
            name = file.stem.replace('_merged', '').replace('place_', '')
            if name.startswith('place_'):
                name = f"업체_{name}"
            
            self.all_place_files.append((str(file), name))
        
        self.all_place_files.sort(key=lambda x: x[1])
        self.filtered_place_files = self.all_place_files.copy()
        
        self.update_place_list()
        self.update_summary_table()
        self.status_var.set(f"파일 {len(self.all_place_files)}개 발견")
    
    def filter_places(self, *args):
        """업체 목록 필터링"""
        search_term = self.search_var.get().lower()
        
        if not search_term:
            self.filtered_place_files = self.all_place_files.copy()
        else:
            self.filtered_place_files = [
                (path, name) for path, name in self.all_place_files
                if search_term in name.lower() or search_term in Path(path).name.lower()
            ]
        
        self.update_place_list()
    
    def update_place_list(self):
        """업체 목록 업데이트"""
        self.place_listbox.delete(0, tk.END)
        
        for file_path, name in self.filtered_place_files:
            status = "✅" if file_path in self.parsed_data else "⏳"
            display_name = f"{status} {name}"
            self.place_listbox.insert(tk.END, display_name)
    
    def on_place_selected(self, event):
        """업체 선택 시 정보 표시"""
        selection = self.place_listbox.curselection()
        if not selection:
            return
        
        idx = selection[0]
        file_path, name = self.filtered_place_files[idx]
        self.current_file = file_path
        
        if file_path not in self.parsed_data:
            self.parse_single_file(file_path)
        else:
            self.display_info(file_path)
    
    def parse_single_file(self, file_path):
        """단일 파일 파싱"""
        self.status_var.set(f"파싱 중: {Path(file_path).name}")
        self.root.update()
        
        try:
            mid = None
            mid_match = re.search(r'place[_\s]*(\d+)', Path(file_path).name)
            if mid_match:
                mid = mid_match.group(1)
            
            around_path = None
            if mid:
                rawdata_dir = Path(file_path).parent
                around_files = list(rawdata_dir.glob(f"*{mid}*around*.txt"))
                if around_files:
                    around_path = str(around_files[0])
            
            if parse_comprehensive_info:
                result = parse_comprehensive_info(file_path, around_path)
                
                if result:
                    self.parsed_data[file_path] = result
                    self.update_place_list()
                    self.update_summary_table()
                    self.display_info(file_path)
                    self.status_var.set(f"파싱 완료: {result.get('name', '알 수 없음')}")
                else:
                    messagebox.showerror("오류", "파싱에 실패했습니다.")
                    self.status_var.set("파싱 실패")
            else:
                messagebox.showerror("오류", "parse_comprehensive_info 모듈을 찾을 수 없습니다.")
                
        except Exception as e:
            messagebox.showerror("오류", f"파싱 중 오류 발생:\n{str(e)}")
            self.status_var.set("오류 발생")
            import traceback
            traceback.print_exc()
    
    def parse_all(self):
        """전체 파일 파싱"""
        if not self.rawdata_dir:
            messagebox.showwarning("경고", "먼저 폴더를 선택하세요.")
            return
        
        if not self.all_place_files:
            messagebox.showinfo("정보", "파싱할 파일이 없습니다.")
            return
        
        def parse_thread():
            total = len(self.all_place_files)
            for idx, (file_path, name) in enumerate(self.all_place_files, 1):
                if file_path in self.parsed_data:
                    continue
                
                self.root.after(0, lambda f=file_path, n=name, i=idx, t=total: 
                               self.status_var.set(f"파싱 중 ({i}/{t}): {n}"))
                
                try:
                    mid = None
                    mid_match = re.search(r'place[_\s]*(\d+)', Path(file_path).name)
                    if mid_match:
                        mid = mid_match.group(1)
                    
                    around_path = None
                    if mid:
                        rawdata_dir = Path(file_path).parent
                        around_files = list(rawdata_dir.glob(f"*{mid}*around*.txt"))
                        if around_files:
                            around_path = str(around_files[0])
                    
                    if parse_comprehensive_info:
                        result = parse_comprehensive_info(file_path, around_path)
                        if result:
                            self.parsed_data[file_path] = result
                            self.root.after(0, self.update_place_list)
                            self.root.after(0, self.update_summary_table)
                except Exception as e:
                    print(f"파싱 오류 ({file_path}): {e}")
            
            self.root.after(0, lambda: self.status_var.set(f"전체 파싱 완료 ({len(self.parsed_data)}/{total}개)"))
            self.root.after(0, lambda: messagebox.showinfo("완료", f"파싱 완료: {len(self.parsed_data)}/{total}개"))
        
        threading.Thread(target=parse_thread, daemon=True).start()
    
    def display_info(self, file_path):
        """정보 표시"""
        if file_path not in self.parsed_data:
            return
        
        data = self.parsed_data[file_path]
        
        # 기본 정보 탭
        basic_info_text = f"""업체명: {data.get('name', '')}
플레이스 URL: {data.get('url', '')}
플레이스 MID: {data.get('mid', '')}
카테고리: {data.get('category', '')}

대표 키워드:
"""
        for kw in data.get('keyword_list', []):
            basic_info_text += f"  • {kw}\n"
        
        self.basic_text.delete(1.0, tk.END)
        self.basic_text.insert(1.0, basic_info_text)
        
        # 주소 탭
        address_text = f"""지번 주소:
{data.get('address', '')}

도로명 주소:
{data.get('road_address', '')}
"""
        self.address_text.delete(1.0, tk.END)
        self.address_text.insert(1.0, address_text)
        
        # 주변 정보 탭
        around_places = data.get('around_places', {})
        around_text = "=== 역 정보 ===\n"
        for station in around_places.get('stations', [])[:20]:
            name = station.get('name', '')
            distance = station.get('distance', '')
            line = station.get('line', '')
            exit_info = station.get('exit', '')
            around_text += f"• {name}"
            if line:
                around_text += f" ({line})"
            if exit_info:
                around_text += f" - {exit_info}"
            if distance:
                around_text += f" - {distance}"
            around_text += "\n"
        
        around_text += "\n=== 아파트 ===\n"
        for apt in around_places.get('apartments', [])[:20]:
            around_text += f"• {apt.get('name', '')}"
            if apt.get('distance'):
                around_text += f" - {apt.get('distance', '')}"
            around_text += "\n"
        
        around_text += "\n=== 랜드마크 ===\n"
        for landmark in around_places.get('landmarks', [])[:20]:
            around_text += f"• {landmark.get('name', '')}"
            if landmark.get('type'):
                around_text += f" ({landmark.get('type', '')})"
            if landmark.get('distance'):
                around_text += f" - {landmark.get('distance', '')}"
            around_text += "\n"
        
        self.around_text.delete(1.0, tk.END)
        self.around_text.insert(1.0, around_text)
        
        # 메뉴 탭
        menus = data.get('menus', [])
        menu_text = f"메뉴 개수: {len(menus)}개\n\n"
        for menu in menus:
            menu_text += f"메뉴명: {menu.get('name', '')}\n"
            if menu.get('price'):
                menu_text += f"가격: {menu.get('price', '')}\n"
            if menu.get('description'):
                menu_text += f"설명: {menu.get('description', '')}\n"
            menu_text += "-" * 50 + "\n"
        
        self.menu_text.delete(1.0, tk.END)
        self.menu_text.insert(1.0, menu_text)
        
        # 소개글 탭
        intro = data.get('introduction', '')
        if not intro:
            intro = "(소개글이 없습니다)"
        self.intro_text.delete(1.0, tk.END)
        self.intro_text.insert(1.0, intro)
        
        # 기타 탭
        other_tabs = data.get('other_tabs', {})
        other_text = "=== 기타 탭 정보 ===\n\n"
        for tab, info in other_tabs.items():
            exists = info.get('exists', False)
            other_text += f"{tab.upper()}: {'있음' if exists else '없음'}\n"
            if exists and 'stats' in info:
                stats = info['stats']
                other_text += f"  - 방문자 리뷰: {stats.get('visitor_review_count', 0)}\n"
                other_text += f"  - 블로그 리뷰: {stats.get('blog_review_count', 0)}\n"
            other_text += "\n"
        
        self.other_text.delete(1.0, tk.END)
        self.other_text.insert(1.0, other_text)
        
        # 작업 키워드 탭 업데이트
        self.update_work_keywords(file_path)
    
    def load_reward_data(self):
        """Reward_data CSV 파일 로드"""
        # exe 빌드 시 경로 처리
        if getattr(sys, 'frozen', False):
            base_dir = Path(sys.executable).parent
        else:
            base_dir = Path(__file__).parent
        csv_path = base_dir / 'Reward_data' / '▶▶▶스마일 내부 통합 (파파인원들만 보는곳) - 트래픽.csv'
        
        if not csv_path.exists():
            return
        
        try:
            with open(csv_path, 'r', encoding='utf-8') as f:
                reader = csv.reader(f)
                rows = list(reader)
            
            # 헤더 찾기 (12번째 줄)
            header_idx = 11  # 0-based index
            if len(rows) > header_idx:
                # 헤더에서 컬럼 인덱스 찾기
                header = rows[header_idx]
                try:
                    url_idx = header.index('플레이스 URL')
                    keyword_idx = header.index('작업키워드')
                    main_keyword_idx = header.index('메인키워드') if '메인키워드' in header else None
                except ValueError:
                    # 기본 인덱스 사용
                    url_idx = 9
                    keyword_idx = 8
                    main_keyword_idx = 12
                
                # 데이터 읽기
                for row in rows[header_idx + 1:]:
                    if len(row) > max(url_idx, keyword_idx):
                        url = row[url_idx].strip()
                        keywords_str = row[keyword_idx].strip()
                        
                        if url:
                            # URL에서 ID 추출
                            url_id_match = re.search(r'/(\d+)', url)
                            
                            # 키워드 분리
                            keywords = []
                            if keywords_str:
                                keywords = [kw.strip() for kw in keywords_str.split(',') if kw.strip()]
                            
                            main_keyword = ''
                            if main_keyword_idx and len(row) > main_keyword_idx:
                                main_keyword = row[main_keyword_idx].strip()
                            
                            # 여러 형식으로 저장 (URL 전체, ID만)
                            self.reward_data[url] = {
                                'keywords': keywords,
                                'main_keyword': main_keyword,
                                'id': url_id_match.group(1) if url_id_match else ''
                            }
                            
                            # ID로도 인덱싱 (빠른 검색을 위해)
                            if url_id_match:
                                place_id = url_id_match.group(1)
                                if place_id not in self.reward_data:
                                    self.reward_data[place_id] = {
                                        'keywords': keywords,
                                        'main_keyword': main_keyword,
                                        'url': url
                                    }
            
            print(f"Reward_data 로드 완료: {len(self.reward_data)}개")
            
        except Exception as e:
            print(f"Reward_data 로드 오류: {e}")
            import traceback
            traceback.print_exc()
    
    def update_work_keywords(self, file_path):
        """작업 키워드 탭 업데이트"""
        if file_path not in self.parsed_data:
            return
        
        data = self.parsed_data[file_path]
        url = data.get('url', '')
        mid = data.get('mid', '')
        
        # Reward_data에서 키워드 찾기
        existing_keywords = []
        main_keyword = ''
        
        # MID를 이용한 매칭 (가장 정확)
        if mid:
            # ID로 직접 조회
            if mid in self.reward_data:
                reward_data = self.reward_data[mid]
                existing_keywords = reward_data.get('keywords', [])
                main_keyword = reward_data.get('main_keyword', '')
            else:
                # URL에서 ID 추출하여 매칭
                for reward_url, reward_data in self.reward_data.items():
                    url_id = reward_data.get('id', '')
                    if url_id == mid:
                        existing_keywords = reward_data.get('keywords', [])
                        main_keyword = reward_data.get('main_keyword', '')
                        break
        
        # URL 직접 매칭 (보조)
        if not existing_keywords and url:
            # 여러 형식으로 정규화
            url_variants = [
                url,
                url.replace('https://m.place.naver.com/', ''),
                url.replace('https://map.naver.com/', ''),
                url.replace('https://m.place.naver.com/', '').replace('/', ''),
            ]
            
            for variant in url_variants:
                if variant in self.reward_data:
                    existing_keywords = self.reward_data[variant].get('keywords', [])
                    main_keyword = self.reward_data[variant].get('main_keyword', '')
                    break
        
        # 기존 작업 키워드 표시
        self.existing_keywords_text.delete(1.0, tk.END)
        if existing_keywords:
            keyword_text = f"메인 키워드: {main_keyword}\n\n" if main_keyword else ""
            keyword_text += f"작업 키워드 ({len(existing_keywords)}개):\n"
            for kw in existing_keywords:
                keyword_text += f"{kw}\n"
        else:
            keyword_text = "작업 키워드 정보가 없습니다."
        
        self.existing_keywords_text.insert(1.0, keyword_text)
        
        # 키워드 그룹 생성
        if data and self.keyword_generator:
            groups = self.keyword_generator.generate_all_groups(data, existing_keywords)
            
            # 그룹 1: 지역키
            self.group1_text.delete(1.0, tk.END)
            if groups['group1']:
                group1_text = f"지역키 ({len(groups['group1'])}개):\n\n"
                for kw in groups['group1']:
                    group1_text += f"{kw}\n"
            else:
                group1_text = "생성된 지역키가 없습니다."
            self.group1_text.insert(1.0, group1_text)
            
            # 그룹 2: 메뉴키
            self.group2_text.delete(1.0, tk.END)
            if groups['group2']:
                group2_text = f"메뉴키 ({len(groups['group2'])}개):\n\n"
                for kw in groups['group2']:
                    group2_text += f"{kw}\n"
            else:
                group2_text = "생성된 메뉴키가 없습니다."
            self.group2_text.insert(1.0, group2_text)
            
            # 그룹 3: 업종키
            self.group3_text.delete(1.0, tk.END)
            if groups['group3']:
                group3_text = f"업종키 ({len(groups['group3'])}개):\n\n"
                for kw in groups['group3']:
                    group3_text += f"{kw}\n"
            else:
                group3_text = "생성된 업종키가 없습니다."
            self.group3_text.insert(1.0, group3_text)
    
    def update_summary_table(self):
        """요약 테이블 업데이트"""
        # 기존 항목 삭제
        for item in self.summary_tree.get_children():
            self.summary_tree.delete(item)
        
        # 파싱된 데이터를 테이블에 추가
        for file_path, data in self.parsed_data.items():
            around = data.get('around_places', {})
            menus = data.get('menus', [])
            
            values = (
                data.get('name', ''),
                data.get('mid', ''),
                len(around.get('stations', [])),
                len(around.get('apartments', [])),
                len(around.get('landmarks', [])),
                len(menus),
                data.get('url', '')[:50] + '...' if len(data.get('url', '')) > 50 else data.get('url', '')
            )
            
            # 파일 경로를 태그로 저장 (더블클릭 시 사용)
            item = self.summary_tree.insert('', tk.END, values=values, tags=(file_path,))
        
        # 파싱된 개수 표시
        if self.parsed_data:
            self.status_var.set(f"파싱 완료: {len(self.parsed_data)}개 | 요약 테이블 업데이트 완료")
    
    def on_summary_double_click(self, event):
        """요약 테이블 더블클릭 시 해당 업체 상세 정보 표시"""
        selection = self.summary_tree.selection()
        if not selection:
            return
        
        item = selection[0]
        tags = self.summary_tree.item(item, 'tags')
        
        if tags:
            file_path = tags[0]
            # 해당 파일을 왼쪽 목록에서 찾아서 선택
            for idx, (fp, name) in enumerate(self.filtered_place_files):
                if fp == file_path:
                    self.place_listbox.selection_clear(0, tk.END)
                    self.place_listbox.selection_set(idx)
                    self.place_listbox.see(idx)
                    self.on_place_selected(None)
                    # 상세 정보 탭으로 전환
                    self.parse_notebook.select(1)  # 기본 정보 탭
                    break
    
    def save_to_excel(self):
        """Excel 파일로 저장"""
        if not self.parsed_data:
            messagebox.showwarning("경고", "저장할 데이터가 없습니다. 먼저 파싱을 실행하세요.")
            return
        
        try:
            import pandas as pd
        except ImportError:
            messagebox.showerror("오류", "pandas와 openpyxl이 필요합니다.\npip install pandas openpyxl")
            return
        
        file_path = filedialog.asksaveasfilename(
            title="Excel 파일로 저장",
            defaultextension=".xlsx",
            filetypes=[("Excel 파일", "*.xlsx"), ("모든 파일", "*.*")]
        )
        
        if not file_path:
            return
        
        try:
            self.status_var.set("Excel 저장 중...")
            self.root.update()
            
            # 데이터를 DataFrame으로 변환
            rows = []
            for file_path_key, data in self.parsed_data.items():
                around = data.get('around_places', {})
                menus = data.get('menus', [])
                
                row = {
                    '업체명': data.get('name', ''),
                    '플레이스URL': data.get('url', ''),
                    '플레이스MID': data.get('mid', ''),
                    '지번주소': data.get('address', ''),
                    '도로명주소': data.get('road_address', ''),
                    '역개수': len(around.get('stations', [])),
                    '역목록': ', '.join([s.get('name', '') for s in around.get('stations', [])[:10]]),
                    '아파트개수': len(around.get('apartments', [])),
                    '아파트목록': ', '.join([a.get('name', '') for a in around.get('apartments', [])[:10]]),
                    '랜드마크개수': len(around.get('landmarks', [])),
                    '랜드마크목록': ', '.join([l.get('name', '') for l in around.get('landmarks', [])[:10]]),
                    '메뉴개수': len(menus),
                    '메뉴목록': ', '.join([m.get('name', '') for m in menus[:10]]),
                    '소개글': data.get('introduction', '')[:500],  # 처음 500자만
                    '카테고리': data.get('category', ''),
                    '대표키워드': ', '.join(data.get('keyword_list', []))
                }
                rows.append(row)
            
            df = pd.DataFrame(rows)
            df.to_excel(file_path, index=False, engine='openpyxl')
            
            self.status_var.set(f"Excel 저장 완료: {Path(file_path).name}")
            messagebox.showinfo("완료", f"저장 완료:\n{file_path}")
            
        except Exception as e:
            messagebox.showerror("오류", f"Excel 저장 중 오류 발생:\n{str(e)}")
            self.status_var.set("저장 실패")
            import traceback
            traceback.print_exc()
    
    def save_to_json(self):
        """JSON 파일로 저장 (전체 통합)"""
        if not self.parsed_data:
            messagebox.showwarning("경고", "저장할 데이터가 없습니다. 먼저 파싱을 실행하세요.")
            return
        
        file_path = filedialog.asksaveasfilename(
            title="JSON 파일로 저장",
            defaultextension=".json",
            filetypes=[("JSON 파일", "*.json"), ("모든 파일", "*.*")]
        )
        
        if not file_path:
            return
        
        try:
            self.status_var.set("JSON 저장 중...")
            self.root.update()
            
            # 데이터 저장 (파일 경로는 키로 사용하지 않고 업체명으로)
            save_data = {}
            for file_path_key, data in self.parsed_data.items():
                name = data.get('name', Path(file_path_key).stem)
                save_data[name] = data
            
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(save_data, f, ensure_ascii=False, indent=2)
            
            self.status_var.set(f"JSON 저장 완료: {Path(file_path).name}")
            messagebox.showinfo("완료", f"저장 완료:\n{file_path}")
            
        except Exception as e:
            messagebox.showerror("오류", f"JSON 저장 중 오류 발생:\n{str(e)}")
            self.status_var.set("저장 실패")
            import traceback
            traceback.print_exc()
    
    def save_search_keywords(self):
        """검색 키워드 저장"""
        search_keyword = self.search_var.get().strip()
        if not search_keyword:
            messagebox.showwarning("경고", "저장할 검색 키워드가 없습니다.")
            return
        
        file_path = filedialog.asksaveasfilename(
            title="검색 키워드 저장",
            defaultextension=".txt",
            filetypes=[("텍스트 파일", "*.txt"), ("모든 파일", "*.*")]
        )
        
        if not file_path:
            return
        
        try:
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(search_keyword)
            
            messagebox.showinfo("완료", f"검색 키워드 저장 완료:\n{file_path}")
            self.status_var.set(f"검색 키워드 저장 완료: {Path(file_path).name}")
            
        except Exception as e:
            messagebox.showerror("오류", f"검색 키워드 저장 중 오류 발생:\n{str(e)}")
    
    def load_search_keywords(self):
        """검색 키워드 로드"""
        file_path = filedialog.askopenfilename(
            title="검색 키워드 파일 선택",
            filetypes=[("텍스트 파일", "*.txt"), ("모든 파일", "*.*")]
        )
        
        if not file_path:
            return
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                keyword = f.read().strip()
            
            if keyword:
                self.search_var.set(keyword)
                # 필터링 자동 실행
                self.filter_places()
                messagebox.showinfo("완료", f"검색 키워드 로드 완료:\n{keyword}")
                self.status_var.set(f"검색 키워드 로드 완료: {Path(file_path).name}")
            else:
                messagebox.showwarning("경고", "로드할 검색 키워드가 없습니다.")
            
        except Exception as e:
            messagebox.showerror("오류", f"검색 키워드 로드 중 오류 발생:\n{str(e)}")
    
    def save_individual_jsons(self):
        """각 업체별로 개별 JSON 파일 저장"""
        if not self.parsed_data:
            messagebox.showwarning("경고", "저장할 데이터가 없습니다. 먼저 파싱을 실행하세요.")
            return
        
        # 저장할 폴더 선택
        save_dir = filedialog.askdirectory(
            title="각 업체 JSON 저장 폴더 선택",
            initialdir=os.path.dirname(__file__)
        )
        
        if not save_dir:
            return
        
        try:
            self.status_var.set("각 업체 JSON 저장 중...")
            self.root.update()
            
            saved_count = 0
            skipped_count = 0  # 건너뛴 파일 개수
            save_dir_path = Path(save_dir)
            
            for file_path_key, data in self.parsed_data.items():
                # 파일명 생성 (업체명 또는 MID 사용)
                name = data.get('name', Path(file_path_key).stem)
                mid = data.get('mid', '')
                
                # 파일명에 특수문자 제거
                safe_name = re.sub(r'[<>:"/\\|?*]', '_', name)
                
                # MID가 있으면 파일명에 포함
                if mid:
                    json_filename = f"{safe_name}_{mid}.json"
                else:
                    json_filename = f"{safe_name}.json"
                
                json_path = save_dir_path / json_filename
                
                # 기존 파일이 있으면 건너뛰기
                if json_path.exists():
                    skipped_count += 1
                    continue
                
                # 데이터에 원본 파일 경로와 저장 시간 추가
                save_data = data.copy()
                save_data['_metadata'] = {
                    'original_file': str(file_path_key),
                    'saved_at': str(Path(file_path_key).stat().st_mtime) if Path(file_path_key).exists() else ''
                }
                
                with open(json_path, 'w', encoding='utf-8') as f:
                    json.dump(save_data, f, ensure_ascii=False, indent=2)
                
                saved_count += 1
            
            self.status_var.set(f"각 업체 JSON 저장 완료: {saved_count}개 저장, {skipped_count}개 건너뜀")
            messagebox.showinfo("완료", f"저장 완료:\n{saved_count}개 파일 저장\n{skipped_count}개 파일 건너뜀\n{save_dir}")
            
        except Exception as e:
            messagebox.showerror("오류", f"각 업체 JSON 저장 중 오류 발생:\n{str(e)}")
            self.status_var.set("저장 실패")
            import traceback
            traceback.print_exc()
    
    def load_from_json(self):
        """기존 JSON 파일들 로드"""
        # 로드할 폴더 선택
        load_dir = filedialog.askdirectory(
            title="JSON 파일들이 있는 폴더 선택",
            initialdir=os.path.dirname(__file__)
        )
        
        if not load_dir:
            return
        
        try:
            self.status_var.set("JSON 로드 중...")
            self.root.update()
            
            load_dir_path = Path(load_dir)
            json_files = list(load_dir_path.glob("*.json"))
            
            if not json_files:
                messagebox.showinfo("정보", "JSON 파일이 없습니다.")
                return
            
            loaded_count = 0
            updated_count = 0
            
            for json_file in json_files:
                try:
                    with open(json_file, 'r', encoding='utf-8') as f:
                        data = json.load(f)
                    
                    # 메타데이터 제거 (로드된 데이터에는 포함하지 않음)
                    if '_metadata' in data:
                        data.pop('_metadata')
                    
                    # 원본 파일 경로 확인
                    original_file = None
                    mid = data.get('mid', '')
                    name = data.get('name', '')
                    
                    # 원본 rawdata 파일 찾기
                    if self.rawdata_dir:
                        rawdata_path = Path(self.rawdata_dir)
                        # MID로 파일 찾기
                        if mid:
                            merged_files = list(rawdata_path.glob(f"*{mid}*merged*.txt"))
                            if merged_files:
                                original_file = str(merged_files[0])
                        else:
                            # 이름으로 파일 찾기
                            merged_files = list(rawdata_path.glob("*_merged.txt"))
                            for mf in merged_files:
                                if name and name in mf.stem:
                                    original_file = str(mf)
                                    break
                    
                    # 원본 파일이 있으면 그것을 키로, 없으면 JSON 파일명을 키로
                    file_key = original_file if original_file else str(json_file)
                    
                    # 기존 데이터와 병합 (JSON 데이터가 우선)
                    if file_key in self.parsed_data:
                        # 기존 데이터에 JSON 데이터로 업데이트
                        self.parsed_data[file_key].update(data)
                        updated_count += 1
                    else:
                        self.parsed_data[file_key] = data
                        loaded_count += 1
                    
                except Exception as e:
                    print(f"JSON 로드 오류 ({json_file}): {e}")
                    continue
            
            # 목록 업데이트
            self.update_place_list()
            self.update_summary_table()
            
            self.status_var.set(f"JSON 로드 완료: 신규 {loaded_count}개, 업데이트 {updated_count}개")
            messagebox.showinfo("완료", f"로드 완료:\n신규: {loaded_count}개\n업데이트: {updated_count}개")
            
        except Exception as e:
            messagebox.showerror("오류", f"JSON 로드 중 오류 발생:\n{str(e)}")
            self.status_var.set("로드 실패")
            import traceback
            traceback.print_exc()
    
    def update_json_files(self):
        """JSON 파일들을 현재 파싱된 데이터로 업데이트"""
        # 업데이트할 JSON 파일들이 있는 폴더 선택
        json_dir = filedialog.askdirectory(
            title="업데이트할 JSON 파일들이 있는 폴더 선택",
            initialdir=os.path.dirname(__file__)
        )
        
        if not json_dir:
            return
        
        if not self.parsed_data:
            messagebox.showwarning("경고", "업데이트할 파싱 데이터가 없습니다.")
            return
        
        try:
            self.status_var.set("JSON 업데이트 중...")
            self.root.update()
            
            json_dir_path = Path(json_dir)
            json_files = list(json_dir_path.glob("*.json"))
            
            if not json_files:
                messagebox.showinfo("정보", "JSON 파일이 없습니다.")
                return
            
            updated_count = 0
            not_found_count = 0
            
            # 파싱된 데이터를 MID 또는 이름으로 인덱싱
            parsed_by_mid = {}
            parsed_by_name = {}
            
            for file_key, data in self.parsed_data.items():
                mid = data.get('mid', '')
                name = data.get('name', '')
                
                if mid:
                    parsed_by_mid[mid] = data
                if name:
                    safe_name = re.sub(r'[<>:"/\\|?*]', '_', name)
                    parsed_by_name[safe_name] = data
            
            for json_file in json_files:
                try:
                    # JSON 파일에서 기존 데이터 읽기
                    with open(json_file, 'r', encoding='utf-8') as f:
                        existing_data = json.load(f)
                    
                    # MID 또는 이름으로 매칭
                    mid = existing_data.get('mid', '')
                    name = existing_data.get('name', '')
                    safe_name = re.sub(r'[<>:"/\\|?*]', '_', name) if name else ''
                    
                    # 업데이트할 데이터 찾기
                    update_data = None
                    
                    if mid and mid in parsed_by_mid:
                        update_data = parsed_by_mid[mid]
                    elif safe_name and safe_name in parsed_by_name:
                        update_data = parsed_by_name[safe_name]
                    else:
                        # 파일명에서 MID 추출 시도
                        mid_match = re.search(r'(\d+)\.json$', json_file.name)
                        if mid_match and mid_match.group(1) in parsed_by_mid:
                            update_data = parsed_by_mid[mid_match.group(1)]
                    
                    if update_data:
                        # 메타데이터 보존
                        metadata = existing_data.get('_metadata', {})
                        
                        # 데이터 업데이트
                        updated_data = update_data.copy()
                        updated_data['_metadata'] = metadata
                        updated_data['_metadata']['updated_at'] = str(Path(json_file).stat().st_mtime) if Path(json_file).exists() else ''
                        
                        # JSON 파일 저장
                        with open(json_file, 'w', encoding='utf-8') as f:
                            json.dump(updated_data, f, ensure_ascii=False, indent=2)
                        
                        updated_count += 1
                    else:
                        not_found_count += 1
                    
                except Exception as e:
                    print(f"JSON 업데이트 오류 ({json_file}): {e}")
                    continue
            
            self.status_var.set(f"JSON 업데이트 완료: {updated_count}개, 매칭 실패 {not_found_count}개")
            messagebox.showinfo("완료", f"업데이트 완료:\n성공: {updated_count}개\n매칭 실패: {not_found_count}개")
            
        except Exception as e:
            messagebox.showerror("오류", f"JSON 업데이트 중 오류 발생:\n{str(e)}")
            self.status_var.set("업데이트 실패")
            import traceback
            traceback.print_exc()
    
    # ========== 파일명 변경 탭 메서드 ==========
    def select_rename_folder(self):
        """파일명 변경용 폴더 선택"""
        folder = filedialog.askdirectory(title="rawdata 폴더 선택", initialdir=self.rawdata_dir)
        if folder:
            self.rawdata_dir = folder
            self.rename_folder_path_var.set(folder)
    
    def rename_log(self, message):
        """파일명 변경 로그 메시지 추가"""
        self.rename_log_text.insert(tk.END, f"{message}\n")
        self.rename_log_text.see(tk.END)
        self.root.update()
    
    def sanitize_filename(self, name):
        """파일명으로 사용할 수 없는 문자 제거"""
        invalid_chars = r'[<>:"/\\|?*]'
        name = re.sub(invalid_chars, '_', name)
        name = name.strip('. ')
        name = re.sub(r'[_\s]+', '_', name)
        if len(name) > 200:
            name = name[:200]
        return name
    
    def preview_rename(self):
        """변경 미리보기"""
        rawdata_dir = Path(self.rename_folder_path_var.get().strip())
        
        if not rawdata_dir.exists():
            messagebox.showerror("오류", f"폴더를 찾을 수 없습니다:\n{rawdata_dir}")
            return
        
        # 기존 항목 지우기
        for item in self.preview_tree.get_children():
            self.preview_tree.delete(item)
        
        self.rename_log_text.delete(1.0, tk.END)
        self.rename_log("🔍 파일 스캔 중...")
        self.root.update()
        
        merged_files = list(rawdata_dir.glob("*_merged.txt"))
        
        if not merged_files:
            messagebox.showwarning("경고", "merged.txt 파일을 찾을 수 없습니다.")
            return
        
        self.rename_log(f"📁 총 {len(merged_files)}개의 파일을 찾았습니다.")
        self.rename_status_var.set(f"파일 스캔 완료: {len(merged_files)}개")
        
        preview_data = []
        
        for idx, file_path in enumerate(merged_files, 1):
            if idx % 10 == 0:
                self.rename_log(f"  파싱 중... ({idx}/{len(merged_files)})")
                self.root.update()
            
            # MID 추출
            mid_match = re.search(r'place[_\s]*(\d+)', file_path.name)
            if not mid_match:
                preview_data.append({
                    'file_path': file_path,
                    'original': file_path.name,
                    'new': '(MID 없음)',
                    'status': '실패'
                })
                continue
            
            mid = mid_match.group(1)
            
            # 업체명 추출
            try:
                if parse_comprehensive_info:
                    result = parse_comprehensive_info(str(file_path))
                    if result and result.get('name'):
                        place_name = result.get('name')
                        safe_name = self.sanitize_filename(place_name)
                        new_filename = f"{safe_name}_place_{mid}_{mid}_merged.txt"
                        
                        # 이미 같은 이름인지 확인
                        if file_path.name == new_filename:
                            status = '변경 불필요'
                        else:
                            status = '변경 예정'
                        
                        preview_data.append({
                            'file_path': file_path,
                            'original': file_path.name,
                            'new': new_filename,
                            'status': status
                        })
                    else:
                        preview_data.append({
                            'file_path': file_path,
                            'original': file_path.name,
                            'new': '(업체명 추출 실패)',
                            'status': '실패'
                        })
                else:
                    preview_data.append({
                        'file_path': file_path,
                        'original': file_path.name,
                        'new': '(파싱 모듈 없음)',
                        'status': '실패'
                    })
            except Exception as e:
                preview_data.append({
                    'file_path': file_path,
                    'original': file_path.name,
                    'new': f'(오류: {str(e)[:30]})',
                    'status': '실패'
                })
        
        # 미리보기 표시
        for data in preview_data:
            self.preview_tree.insert('', tk.END, values=(
                data['original'][:80] + '...' if len(data['original']) > 80 else data['original'],
                data['new'][:80] + '...' if len(data['new']) > 80 else data['new'],
                data['status']
            ), tags=(data['status'],))
        
        # 태그별 색상 설정
        self.preview_tree.tag_configure('변경 예정', background='#e8f5e9')
        self.preview_tree.tag_configure('변경 불필요', background='#fff3e0')
        self.preview_tree.tag_configure('실패', background='#ffebee')
        
        # 미리보기 데이터 저장
        self.preview_data = preview_data
        
        change_count = sum(1 for d in preview_data if d['status'] == '변경 예정')
        skip_count = sum(1 for d in preview_data if d['status'] == '변경 불필요')
        fail_count = sum(1 for d in preview_data if d['status'] == '실패')
        
        self.rename_log(f"\n📊 미리보기 완료:")
        self.rename_log(f"  ✅ 변경 예정: {change_count}개")
        self.rename_log(f"  ⏭️  변경 불필요: {skip_count}개")
        self.rename_log(f"  ❌ 실패: {fail_count}개")
        self.rename_status_var.set(f"미리보기 완료 (변경: {change_count}개)")
    
    def start_rename(self):
        """파일명 변경 실행"""
        if self.is_renaming:
            messagebox.showwarning("경고", "이미 변경 작업이 진행 중입니다.")
            return
        
        if not hasattr(self, 'preview_data'):
            messagebox.showwarning("경고", "먼저 '미리보기'를 실행하세요.")
            return
        
        change_count = sum(1 for d in self.preview_data if d['status'] == '변경 예정')
        
        if change_count == 0:
            messagebox.showinfo("정보", "변경할 파일이 없습니다.")
            return
        
        response = messagebox.askyesno(
            "확인",
            f"{change_count}개의 파일명을 변경하시겠습니까?\n\n이 작업은 되돌릴 수 없습니다."
        )
        
        if not response:
            return
        
        # 스레드로 실행
        self.is_renaming = True
        self.rename_button.config(state='disabled', text="변경 중...")
        self.rename_log_text.delete(1.0, tk.END)
        
        thread = threading.Thread(target=self.rename_thread, daemon=True)
        thread.start()
    
    def rename_thread(self):
        """파일명 변경 스레드"""
        renamed_count = 0
        failed_count = 0
        skipped_count = 0
        
        self.root.after(0, lambda: self.rename_log("🔄 파일명 변경 시작...\n"))
        
        for idx, data in enumerate(self.preview_data, 1):
            if data['status'] != '변경 예정':
                if data['status'] == '변경 불필요':
                    skipped_count += 1
                else:
                    failed_count += 1
                continue
            
            file_path = data['file_path']
            new_filename = data['new']
            new_file_path = file_path.parent / new_filename
            
            self.root.after(0, lambda f=file_path.name, n=new_filename, i=idx: 
                           self.rename_log(f"[{i}/{len(self.preview_data)}] {f}"))
            
            # 중복 파일 확인
            if new_file_path.exists() and new_file_path != file_path:
                counter = 1
                name_base = new_filename.replace('_merged.txt', '')
                while new_file_path.exists():
                    new_filename = f"{name_base}_{counter}_merged.txt"
                    new_file_path = file_path.parent / new_filename
                    counter += 1
                
                self.root.after(0, lambda n=new_filename: 
                               self.rename_log(f"  ⚠️ 중복 방지: {n}"))
            
            try:
                file_path.rename(new_file_path)
                self.root.after(0, lambda: self.rename_log(f"  ✅ 성공"))
                renamed_count += 1
            except Exception as e:
                self.root.after(0, lambda e=str(e): self.rename_log(f"  ❌ 실패: {e}"))
                failed_count += 1
        
        # 완료 메시지
        self.root.after(0, lambda: self.rename_log(f"\n{'='*60}"))
        self.root.after(0, lambda: self.rename_log(f"📊 변경 완료:"))
        self.root.after(0, lambda: self.rename_log(f"  ✅ 성공: {renamed_count}개"))
        self.root.after(0, lambda: self.rename_log(f"  ⏭️  건너뜀: {skipped_count}개"))
        self.root.after(0, lambda: self.rename_log(f"  ❌ 실패: {failed_count}개"))
        self.root.after(0, lambda: self.rename_status_var.set(f"완료 (성공: {renamed_count})"))
        self.root.after(0, lambda: self.rename_button.config(state='normal', text="파일명 변경 실행"))
        
        self.is_renaming = False
        
        self.root.after(0, lambda: messagebox.showinfo("완료", 
            f"파일명 변경이 완료되었습니다!\n\n✅ 성공: {renamed_count}개\n⏭️ 건너뜀: {skipped_count}개\n❌ 실패: {failed_count}개"))


if __name__ == '__main__':
    root = tk.Tk()
    app = IntegratedPlaceManager(root)
    root.mainloop()