"use client";

/**
 * 장소 카드 컴포넌트 (Sprint 3)
 *
 * 장소 목록 페이지에서 사용하는 개별 카드.
 * 키워드별 최신 순위 칩, 순위 변동 아이콘 포함.
 */
import Link from "next/link";
import { ExternalLink, Trash2, ChevronRight, Flame } from "lucide-react";
import type { PlaceListItem, KeywordSummary } from "@/hooks/usePlaces";

// ============================
// 서브 컴포넌트: 순위 칩
// ============================

interface RankChipProps {
  summary: KeywordSummary;
}

function RankChip({ summary }: RankChipProps) {
  const { keyword, latest_rank, case_type, rank_change } = summary;

  // 케이스 타입별 배지 아이콘
  const popularIcon =
    case_type === "popular" ? (
      <Flame size={10} className="inline mr-0.5" />
    ) : null;

  // 순위 변동 표시
  let changeEl: React.ReactNode = null;
  if (rank_change !== null && rank_change !== undefined) {
    if (rank_change > 0) {
      // 순위 상승 (숫자 낮아짐)
      changeEl = (
        <span className="text-[10px] text-green-400 ml-0.5">
          ▲{rank_change}
        </span>
      );
    } else if (rank_change < 0) {
      // 순위 하락
      changeEl = (
        <span className="text-[10px] text-red-400 ml-0.5">
          ▼{Math.abs(rank_change)}
        </span>
      );
    } else {
      changeEl = (
        <span className="text-[10px] text-gray-500 ml-0.5">–</span>
      );
    }
  }

  // 미진입
  if (case_type === "not_ranked" || latest_rank === null || latest_rank === undefined) {
    return (
      <span
        className="inline-flex items-center gap-0.5 px-2 py-0.5 rounded-full text-xs font-medium"
        style={{
          background: "rgba(239,68,68,0.15)",
          color: "#f87171",
          border: "1px solid rgba(239,68,68,0.2)",
        }}
      >
        {keyword} <span className="opacity-60">미진입</span>
      </span>
    );
  }

  // 1~3위: 메달 아이콘 + 초록
  if (latest_rank <= 3) {
    const medal = latest_rank === 1 ? "🥇" : latest_rank === 2 ? "🥈" : "🥉";
    return (
      <span
        className="inline-flex items-center gap-0.5 px-2 py-0.5 rounded-full text-xs font-medium"
        style={{
          background: "rgba(34,197,94,0.15)",
          color: "#4ade80",
          border: "1px solid rgba(34,197,94,0.2)",
        }}
      >
        {popularIcon}
        {medal} {keyword} <span className="font-bold">#{latest_rank}</span>
        {changeEl}
      </span>
    );
  }

  // 4~10위: 파란색
  if (latest_rank <= 10) {
    return (
      <span
        className="inline-flex items-center gap-0.5 px-2 py-0.5 rounded-full text-xs font-medium"
        style={{
          background: "rgba(59,130,246,0.15)",
          color: "#60a5fa",
          border: "1px solid rgba(59,130,246,0.2)",
        }}
      >
        {popularIcon}
        {keyword} <span className="font-bold">#{latest_rank}</span>
        {changeEl}
      </span>
    );
  }

  // 11~20위: 회색
  if (latest_rank <= 20) {
    return (
      <span
        className="inline-flex items-center gap-0.5 px-2 py-0.5 rounded-full text-xs font-medium"
        style={{
          background: "rgba(107,114,128,0.15)",
          color: "#9ca3af",
          border: "1px solid rgba(107,114,128,0.2)",
        }}
      >
        {popularIcon}
        {keyword} <span className="font-bold">#{latest_rank}</span>
        {changeEl}
      </span>
    );
  }

  // 21위 이상: 더 어두운 회색
  return (
    <span
      className="inline-flex items-center gap-0.5 px-2 py-0.5 rounded-full text-xs font-medium"
      style={{
        background: "rgba(75,85,99,0.15)",
        color: "#6b7280",
        border: "1px solid rgba(75,85,99,0.2)",
      }}
    >
      {keyword} <span className="font-bold">#{latest_rank}</span>
      {changeEl}
    </span>
  );
}

// ============================
// 날짜 포맷 헬퍼
// ============================

function formatRelativeTime(isoString: string): string {
  const now = Date.now();
  const diff = now - new Date(isoString).getTime();
  const minutes = Math.floor(diff / 60000);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);

  if (minutes < 1) return "방금 전";
  if (minutes < 60) return `${minutes}분 전`;
  if (hours < 24) return `${hours}시간 전`;
  if (days < 7) return `${days}일 전`;
  return new Date(isoString).toLocaleDateString("ko-KR");
}

// ============================
// PlaceCard 메인 컴포넌트
// ============================

interface PlaceCardProps {
  place: PlaceListItem;
  onDelete: (place: PlaceListItem) => void;
}

export default function PlaceCard({ place, onDelete }: PlaceCardProps) {
  const displayName = place.alias || place.name;
  const naverUrl = `https://map.naver.com/v5/entry/place/${place.naver_place_id}`;

  // 활성 키워드만 표시 (최대 5개)
  const visibleKeywords = place.latest_rankings.slice(0, 5);
  const hiddenCount = Math.max(0, place.latest_rankings.length - 5);

  return (
    <div
      className="rounded-xl p-5 flex flex-col gap-4 transition-all duration-200 group"
      style={{
        background: "rgba(255,255,255,0.04)",
        border: "1px solid rgba(255,255,255,0.08)",
      }}
      onMouseEnter={(e) => {
        (e.currentTarget as HTMLDivElement).style.borderColor =
          "rgba(0,212,255,0.3)";
      }}
      onMouseLeave={(e) => {
        (e.currentTarget as HTMLDivElement).style.borderColor =
          "rgba(255,255,255,0.08)";
      }}
    >
      {/* 카드 헤더 */}
      <div className="flex items-start justify-between gap-2">
        <div className="flex items-center gap-2 min-w-0">
          <span className="text-xl flex-shrink-0">🏪</span>
          <div className="min-w-0">
            <h3 className="font-semibold text-slate-100 truncate text-sm">
              {displayName}
            </h3>
            {place.category && (
              <p className="text-xs text-slate-500 mt-0.5">{place.category}</p>
            )}
          </div>
        </div>

        {/* 활성 상태 배지 */}
        <span
          className="flex-shrink-0 text-xs px-2 py-0.5 rounded-full font-medium"
          style={
            place.is_active
              ? {
                  background: "rgba(34,197,94,0.15)",
                  color: "#4ade80",
                  border: "1px solid rgba(34,197,94,0.2)",
                }
              : {
                  background: "rgba(107,114,128,0.15)",
                  color: "#9ca3af",
                  border: "1px solid rgba(107,114,128,0.2)",
                }
          }
        >
          {place.is_active ? "활성" : "비활성"}
        </span>
      </div>

      {/* 네이버 플레이스 링크 */}
      <a
        href={naverUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="flex items-center gap-1.5 text-xs transition-colors"
        style={{ color: "#00d4ff" }}
        onMouseEnter={(e) => {
          (e.currentTarget as HTMLAnchorElement).style.opacity = "0.7";
        }}
        onMouseLeave={(e) => {
          (e.currentTarget as HTMLAnchorElement).style.opacity = "1";
        }}
      >
        <ExternalLink size={12} />
        네이버 플레이스 바로가기
      </a>

      {/* 구분선 */}
      <div
        className="h-px"
        style={{ background: "rgba(255,255,255,0.06)" }}
      />

      {/* 키워드 순위 칩 */}
      <div>
        <p className="text-xs text-slate-500 mb-2">
          키워드 {place.keyword_count}개
        </p>
        {visibleKeywords.length > 0 ? (
          <div className="flex flex-wrap gap-1.5">
            {visibleKeywords.map((kw) => (
              <RankChip key={kw.id} summary={kw} />
            ))}
            {hiddenCount > 0 && (
              <span className="text-xs text-slate-500 self-center">
                +{hiddenCount}개 더
              </span>
            )}
          </div>
        ) : (
          <p className="text-xs text-slate-600">등록된 키워드가 없습니다</p>
        )}
      </div>

      {/* 구분선 */}
      <div
        className="h-px"
        style={{ background: "rgba(255,255,255,0.06)" }}
      />

      {/* 카드 푸터 */}
      <div className="flex items-center justify-between">
        {/* 마지막 등록일 */}
        <p className="text-xs text-slate-600">
          등록: {formatRelativeTime(place.created_at)}
        </p>

        {/* 액션 버튼 */}
        <div className="flex items-center gap-2">
          <Link
            href={`/places/${place.id}`}
            className="flex items-center gap-1 text-xs px-3 py-1.5 rounded-lg font-medium transition-all"
            style={{
              background: "rgba(0,212,255,0.1)",
              color: "#00d4ff",
              border: "1px solid rgba(0,212,255,0.2)",
            }}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLAnchorElement).style.background =
                "rgba(0,212,255,0.2)";
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLAnchorElement).style.background =
                "rgba(0,212,255,0.1)";
            }}
          >
            상세보기
            <ChevronRight size={12} />
          </Link>

          <button
            type="button"
            onClick={() => onDelete(place)}
            className="flex items-center gap-1 text-xs px-3 py-1.5 rounded-lg font-medium transition-all"
            style={{
              background: "rgba(239,68,68,0.1)",
              color: "#f87171",
              border: "1px solid rgba(239,68,68,0.2)",
            }}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLButtonElement).style.background =
                "rgba(239,68,68,0.2)";
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLButtonElement).style.background =
                "rgba(239,68,68,0.1)";
            }}
          >
            <Trash2 size={12} />
            삭제
          </button>
        </div>
      </div>
    </div>
  );
}
