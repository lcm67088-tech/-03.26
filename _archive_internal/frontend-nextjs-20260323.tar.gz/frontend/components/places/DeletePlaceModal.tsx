"use client";

/**
 * 장소 삭제 확인 모달 (Sprint 3)
 *
 * shadcn/ui Dialog 기반.
 * 키워드 수 함께 안내, 로딩 상태, 삭제 성공/실패 처리.
 */
import { useState, useEffect } from "react";
import { toast } from "sonner";
import { AlertTriangle, X, Loader2 } from "lucide-react";
import { useDeletePlace } from "@/hooks/usePlaces";
import type { PlaceListItem } from "@/hooks/usePlaces";

// ============================
// Props
// ============================

interface DeletePlaceModalProps {
  place: PlaceListItem | null;        // null이면 모달 닫힘
  workspaceId: string;
  onClose: () => void;
  onDeleted?: () => void;            // 삭제 성공 콜백 (목록으로 이동 등)
}

// ============================
// 컴포넌트
// ============================

export default function DeletePlaceModal({
  place,
  workspaceId,
  onClose,
  onDeleted,
}: DeletePlaceModalProps) {
  const [isVisible, setIsVisible] = useState(false);
  const deleteMutation = useDeletePlace();

  // 모달 열림/닫힘 애니메이션 제어
  useEffect(() => {
    if (place) {
      // 약간의 딜레이 후 표시 (transition을 위해)
      requestAnimationFrame(() => setIsVisible(true));
    } else {
      setIsVisible(false);
    }
  }, [place]);

  if (!place) return null;

  const displayName = place.alias || place.name;
  const keywordCount = place.keyword_count;

  // ============================
  // 삭제 실행
  // ============================

  const handleConfirm = async () => {
    try {
      await deleteMutation.mutateAsync({
        placeId: place.id,
        workspaceId,
      });
      toast.success(`"${displayName}" 장소가 삭제되었습니다`);
      onClose();
      onDeleted?.();
    } catch (error) {
      const msg =
        error instanceof Error ? error.message : "삭제 중 오류가 발생했습니다";
      toast.error(msg);
    }
  };

  const handleClose = () => {
    if (deleteMutation.isPending) return; // 삭제 중 닫기 방지
    onClose();
  };

  const isDeleting = deleteMutation.isPending;

  // ============================
  // 렌더
  // ============================

  return (
    <>
      {/* 배경 오버레이 */}
      <div
        className="fixed inset-0 z-50 transition-opacity duration-200"
        style={{
          background: "rgba(0,0,0,0.7)",
          backdropFilter: "blur(4px)",
          opacity: isVisible ? 1 : 0,
        }}
        onClick={handleClose}
      />

      {/* 모달 */}
      <div
        className="fixed inset-0 z-50 flex items-center justify-center p-4"
        role="dialog"
        aria-modal="true"
        aria-labelledby="delete-modal-title"
      >
        <div
          className="relative w-full max-w-md rounded-2xl p-6 transition-all duration-200"
          style={{
            background: "linear-gradient(135deg, #1a1a2e 0%, #16213e 100%)",
            border: "1px solid rgba(255,255,255,0.1)",
            boxShadow: "0 25px 50px rgba(0,0,0,0.5)",
            transform: isVisible ? "scale(1) translateY(0)" : "scale(0.95) translateY(-8px)",
            opacity: isVisible ? 1 : 0,
          }}
          onClick={(e) => e.stopPropagation()} // 모달 내부 클릭 시 닫힘 방지
        >
          {/* 닫기 버튼 */}
          {!isDeleting && (
            <button
              type="button"
              onClick={handleClose}
              className="absolute top-4 right-4 text-slate-500 hover:text-slate-300 transition-colors"
              aria-label="모달 닫기"
            >
              <X size={18} />
            </button>
          )}

          {/* 아이콘 */}
          <div className="flex justify-center mb-4">
            <div
              className="w-14 h-14 rounded-full flex items-center justify-center"
              style={{ background: "rgba(239,68,68,0.15)" }}
            >
              <AlertTriangle size={28} style={{ color: "#f87171" }} />
            </div>
          </div>

          {/* 제목 */}
          <h2
            id="delete-modal-title"
            className="text-lg font-bold text-slate-100 text-center mb-2"
          >
            장소를 삭제하시겠습니까?
          </h2>

          {/* 설명 */}
          <div className="text-center space-y-2 mb-6">
            <p className="text-sm text-slate-300">
              <span
                className="font-semibold"
                style={{ color: "#00d4ff" }}
              >
                &ldquo;{displayName}&rdquo;
              </span>
              을(를) 삭제합니다.
            </p>

            {keywordCount > 0 && (
              <p
                className="text-xs px-4 py-2 rounded-xl"
                style={{
                  background: "rgba(245,158,11,0.12)",
                  border: "1px solid rgba(245,158,11,0.2)",
                  color: "#fcd34d",
                }}
              >
                ⚠️ 연결된 키워드 {keywordCount}개도 함께 비활성화됩니다.
              </p>
            )}

            <p className="text-xs text-slate-500 mt-2">
              삭제된 장소는 복구할 수 없습니다.
            </p>
          </div>

          {/* 버튼 그룹 */}
          <div className="flex gap-3">
            {/* 취소 버튼 */}
            <button
              type="button"
              onClick={handleClose}
              disabled={isDeleting}
              className="flex-1 py-2.5 rounded-xl text-sm font-medium transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              style={{
                background: "rgba(255,255,255,0.06)",
                border: "1px solid rgba(255,255,255,0.1)",
                color: "#94a3b8",
              }}
              onMouseEnter={(e) => {
                if (!isDeleting)
                  (e.currentTarget as HTMLButtonElement).style.background =
                    "rgba(255,255,255,0.1)";
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLButtonElement).style.background =
                  "rgba(255,255,255,0.06)";
              }}
            >
              취소
            </button>

            {/* 삭제 버튼 */}
            <button
              type="button"
              onClick={handleConfirm}
              disabled={isDeleting}
              className="flex-1 py-2.5 rounded-xl text-sm font-semibold transition-all disabled:opacity-60 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              style={{
                background: isDeleting
                  ? "rgba(239,68,68,0.5)"
                  : "rgba(239,68,68,0.8)",
                color: "white",
                border: "1px solid rgba(239,68,68,0.3)",
              }}
              onMouseEnter={(e) => {
                if (!isDeleting)
                  (e.currentTarget as HTMLButtonElement).style.background =
                    "rgba(239,68,68,1)";
              }}
              onMouseLeave={(e) => {
                if (!isDeleting)
                  (e.currentTarget as HTMLButtonElement).style.background =
                    "rgba(239,68,68,0.8)";
              }}
            >
              {isDeleting ? (
                <>
                  <Loader2 size={16} className="animate-spin" />
                  삭제 중...
                </>
              ) : (
                "삭제"
              )}
            </button>
          </div>
        </div>
      </div>
    </>
  );
}
