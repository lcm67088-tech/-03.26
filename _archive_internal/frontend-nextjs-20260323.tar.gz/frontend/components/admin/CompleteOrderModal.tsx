"use client";

/**
 * 주문 완료 처리 모달 (Sprint 6)
 *
 * - 증빙 URL 입력 (Zod url 검증)
 * - 선택적 메모 입력
 * - 성공 시 sonner toast + 쿼리 무효화
 */
import { useState } from "react";
import { z } from "zod";
import { toast } from "sonner";
import { useCompleteOrderAdmin } from "@/hooks/useAdmin";
import type { AdminOrderDetail } from "@/hooks/useAdmin";
import { getApiErrorMessage } from "@/lib/api";

// ============================
// Zod 스키마
// ============================
const schema = z.object({
  proof_url: z
    .string()
    .min(1, "증빙 URL을 입력해주세요")
    .url("유효한 URL 형식이어야 합니다 (https://...)"),
  memo: z.string().max(300, "메모는 300자 이내로 입력해주세요").optional(),
});

interface CompleteOrderModalProps {
  /** 완료 처리할 주문 */
  order: AdminOrderDetail;
  /** 닫기 콜백 */
  onClose: () => void;
  /** 성공 콜백 (선택) */
  onSuccess?: () => void;
}

export default function CompleteOrderModal({
  order,
  onClose,
  onSuccess,
}: CompleteOrderModalProps) {
  const [proofUrl, setProofUrl] = useState("");
  const [memo, setMemo] = useState("");
  const [errors, setErrors] = useState<{ proof_url?: string; memo?: string }>({});

  const completeMutation = useCompleteOrderAdmin(order.id);

  // ============================
  // 유효성 검사 + 제출
  // ============================
  const handleSubmit = async () => {
    const parsed = schema.safeParse({ proof_url: proofUrl, memo });
    if (!parsed.success) {
      const fieldErrors: typeof errors = {};
      for (const issue of parsed.error.issues) {
        const key = issue.path[0] as keyof typeof errors;
        fieldErrors[key] = issue.message;
      }
      setErrors(fieldErrors);
      return;
    }
    setErrors({});

    try {
      await completeMutation.mutateAsync({ proof_url: proofUrl });
      toast.success("주문이 완료 처리되었습니다");
      onSuccess?.();
      onClose();
    } catch (err) {
      toast.error(getApiErrorMessage(err));
    }
  };

  // ============================
  // 상태 확인 (in_progress / confirmed만 완료 가능)
  // ============================
  const canComplete =
    order.status === "in_progress" || order.status === "confirmed";

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm"
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <div className="bg-slate-900 border border-slate-700 rounded-xl shadow-2xl w-full max-w-md mx-4">
        {/* 헤더 */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-700">
          <h2 className="text-lg font-semibold text-slate-100">
            주문 완료 처리
          </h2>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-200 transition-colors"
            aria-label="닫기"
          >
            ✕
          </button>
        </div>

        {/* 본문 */}
        <div className="px-6 py-5 space-y-4">
          {/* 주문 요약 */}
          <div className="bg-slate-800 rounded-lg p-3 text-sm space-y-1">
            <div className="flex justify-between">
              <span className="text-slate-400">주문</span>
              <span className="text-slate-200">{order.product_name}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">수량</span>
              <span className="text-slate-200">{order.quantity}개</span>
            </div>
            {order.media_company && (
              <div className="flex justify-between">
                <span className="text-slate-400">미디어사</span>
                <span className="text-cyan-400">{order.media_company.name}</span>
              </div>
            )}
          </div>

          {/* 완료 처리 불가 안내 */}
          {!canComplete && (
            <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-3 text-sm text-red-300">
              ⚠️ 현재 상태({order.status})에서는 완료 처리할 수 없습니다.
            </div>
          )}

          {/* 증빙 URL 입력 */}
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-1.5">
              증빙 URL <span className="text-red-400">*</span>
            </label>
            <input
              type="url"
              value={proofUrl}
              onChange={(e) => setProofUrl(e.target.value)}
              placeholder="https://drive.google.com/..."
              disabled={!canComplete}
              className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2.5 text-slate-200 text-sm placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500/50 focus:border-cyan-500 disabled:opacity-50"
            />
            {errors.proof_url && (
              <p className="text-red-400 text-xs mt-1">{errors.proof_url}</p>
            )}
            <p className="text-slate-500 text-xs mt-1">
              구글 드라이브, 스크린샷 공유 링크 등 증빙 자료 URL
            </p>
          </div>

          {/* 메모 입력 (선택) */}
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-1.5">
              처리 메모 <span className="text-slate-500">(선택)</span>
            </label>
            <textarea
              value={memo}
              onChange={(e) => setMemo(e.target.value)}
              placeholder="완료 처리 관련 메모 (어드민 내부 기록)"
              disabled={!canComplete}
              rows={3}
              className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2.5 text-slate-200 text-sm placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500/50 focus:border-cyan-500 resize-none disabled:opacity-50"
            />
            {errors.memo && (
              <p className="text-red-400 text-xs mt-1">{errors.memo}</p>
            )}
          </div>
        </div>

        {/* 버튼 영역 */}
        <div className="flex justify-end gap-3 px-6 py-4 border-t border-slate-700">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-lg text-sm text-slate-300 hover:text-slate-100 hover:bg-slate-700 transition-colors"
          >
            취소
          </button>
          <button
            onClick={handleSubmit}
            disabled={!canComplete || completeMutation.isPending || !proofUrl}
            className="px-5 py-2 rounded-lg text-sm font-medium bg-emerald-600 hover:bg-emerald-500 text-white disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
          >
            {completeMutation.isPending ? "처리 중…" : "완료 처리"}
          </button>
        </div>
      </div>
    </div>
  );
}
