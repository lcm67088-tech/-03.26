"use client";

/**
 * ForceChangePlanModal — 어드민 워크스페이스 플랜 강제 변경 모달 (Sprint 9)
 *
 * Props:
 *   workspaceId    — 대상 워크스페이스 UUID
 *   workspaceName  — 표시용 이름
 *   currentPlan    — 현재 플랜 (free/starter/pro/enterprise)
 *   onClose        — 모달 닫기 콜백
 *   onSuccess      — 변경 성공 후 콜백 (newPlan: string)
 *
 * 사용하는 컴포넌트:
 *   - Shadcn Dialog 스타일 (직접 구현, 다크 테마)
 *   - 플랜 선택 셀렉트
 *   - 사유 textarea (2자 이상 필수)
 *   - BillingHistory 생성 여부 체크박스
 */

import { useState } from "react";
import { usePatchWorkspacePlan } from "@/hooks/useAdminAdvanced";
import { getApiErrorMessage } from "@/lib/api";

// ── 플랜 옵션 ────────────────────────────────────────────────
const PLANS = [
  { value: "free", label: "Free", price: "무료" },
  { value: "starter", label: "Starter", price: "49,000원/월" },
  { value: "pro", label: "Pro", price: "149,000원/월" },
  { value: "enterprise", label: "Enterprise", price: "499,000원/월" },
] as const;

// ── 플랜 뱃지 색상 ────────────────────────────────────────────
const PLAN_COLOR: Record<string, string> = {
  free: "text-slate-400",
  starter: "text-blue-400",
  pro: "text-cyan-400",
  enterprise: "text-purple-400",
};

interface ForceChangePlanModalProps {
  workspaceId: string;
  workspaceName: string;
  currentPlan: string;
  onClose: () => void;
  onSuccess: (newPlan: string) => void;
}

export default function ForceChangePlanModal({
  workspaceId,
  workspaceName,
  currentPlan,
  onClose,
  onSuccess,
}: ForceChangePlanModalProps) {
  // 선택된 플랜 (기본: 현재 플랜)
  const [selectedPlan, setSelectedPlan] = useState(currentPlan);
  // 변경 사유 (2자 이상 필수)
  const [reason, setReason] = useState("");
  // BillingHistory 생성 여부
  const [createBilling, setCreateBilling] = useState(true);
  // 에러 메시지
  const [error, setError] = useState("");

  const patchPlan = usePatchWorkspacePlan(workspaceId);

  // ── 유효성 검사 ──────────────────────────────────────────────
  const isValid =
    selectedPlan !== currentPlan &&
    reason.trim().length >= 2;

  // ── 제출 ────────────────────────────────────────────────────
  const handleSubmit = async () => {
    if (!isValid) {
      if (selectedPlan === currentPlan) {
        setError("현재 플랜과 동일합니다. 다른 플랜을 선택해주세요.");
      } else if (reason.trim().length < 2) {
        setError("변경 사유를 2자 이상 입력해주세요.");
      }
      return;
    }
    setError("");

    try {
      await patchPlan.mutateAsync({
        plan: selectedPlan,
        reason: reason.trim(),
        create_billing_record: createBilling,
      });
      onSuccess(selectedPlan);
    } catch (e) {
      setError(getApiErrorMessage(e));
    }
  };

  return (
    // 오버레이
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60"
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
    >
      {/* 모달 바디 */}
      <div className="bg-[#12121a] border border-slate-700 rounded-2xl p-6 w-[480px] space-y-5 shadow-2xl">
        {/* 헤더 */}
        <div className="flex items-start justify-between">
          <div>
            <h3 className="text-white font-bold text-lg">플랜 강제 변경</h3>
            <p className="text-slate-400 text-sm mt-0.5">{workspaceName}</p>
          </div>
          <button
            onClick={onClose}
            className="text-slate-500 hover:text-white transition text-xl leading-none"
          >
            ✕
          </button>
        </div>

        {/* 현재 플랜 표시 */}
        <div className="bg-slate-800/50 rounded-lg px-4 py-3">
          <p className="text-slate-400 text-xs">현재 플랜</p>
          <p className={`text-base font-semibold mt-0.5 ${PLAN_COLOR[currentPlan] ?? "text-white"}`}>
            {PLANS.find((p) => p.value === currentPlan)?.label ?? currentPlan}
          </p>
        </div>

        {/* 새 플랜 선택 */}
        <div className="space-y-2">
          <label className="text-sm text-slate-400 block">변경할 플랜 선택</label>
          <div className="grid grid-cols-2 gap-2">
            {PLANS.map((plan) => (
              <button
                key={plan.value}
                onClick={() => setSelectedPlan(plan.value)}
                className={`px-3 py-3 rounded-lg text-left text-sm border transition ${
                  selectedPlan === plan.value
                    ? "border-cyan-500 bg-cyan-500/10"
                    : "border-slate-700 bg-slate-800/30 hover:border-slate-600"
                } ${plan.value === currentPlan ? "opacity-50 cursor-not-allowed" : ""}`}
                disabled={plan.value === currentPlan}
              >
                <p className={`font-medium ${PLAN_COLOR[plan.value]}`}>{plan.label}</p>
                <p className="text-slate-500 text-xs mt-0.5">{plan.price}</p>
              </button>
            ))}
          </div>
        </div>

        {/* 변경 사유 */}
        <div className="space-y-2">
          <label className="text-sm text-slate-400 block">
            변경 사유 <span className="text-red-400">*</span>
          </label>
          <textarea
            placeholder="변경 사유를 2자 이상 입력해주세요 (감사 로그에 기록됩니다)"
            value={reason}
            onChange={(e) => { setReason(e.target.value); setError(""); }}
            rows={3}
            maxLength={500}
            className="w-full bg-slate-800 text-white placeholder-slate-500 px-3 py-2 rounded-lg text-sm resize-none focus:outline-none focus:ring-1 focus:ring-cyan-500"
          />
          <p className="text-xs text-slate-500 text-right">{reason.length}/500</p>
        </div>

        {/* BillingHistory 생성 옵션 */}
        <label className="flex items-center gap-3 cursor-pointer group">
          <input
            type="checkbox"
            checked={createBilling}
            onChange={(e) => setCreateBilling(e.target.checked)}
            className="w-4 h-4 accent-cyan-500"
          />
          <div>
            <p className="text-sm text-slate-300 group-hover:text-white transition">
              BillingHistory 레코드 생성
            </p>
            <p className="text-xs text-slate-500">
              변경 내역을 청구 이력으로 기록합니다
            </p>
          </div>
        </label>

        {/* 에러 메시지 */}
        {error && (
          <p className="text-red-400 text-sm bg-red-400/10 rounded-lg px-3 py-2">{error}</p>
        )}

        {/* 버튼 */}
        <div className="flex gap-3 justify-end pt-1">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-lg bg-slate-700 hover:bg-slate-600 text-slate-300 text-sm transition"
          >
            취소
          </button>
          <button
            onClick={handleSubmit}
            disabled={!isValid || patchPlan.isPending}
            className="px-5 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-sm font-medium disabled:opacity-50 disabled:cursor-not-allowed transition"
          >
            {patchPlan.isPending ? "처리 중..." : "플랜 변경"}
          </button>
        </div>
      </div>
    </div>
  );
}
