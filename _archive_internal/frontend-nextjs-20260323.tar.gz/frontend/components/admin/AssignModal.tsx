"use client";

/**
 * 미디어사 배정 모달 (Sprint 6)
 *
 * - 미디어사 목록 드롭다운 (useMediaCompanies)
 * - 현재 배정된 미디어사 표시
 * - 배정 시 confirmed → in_progress 자동 전환 안내
 * - 성공 시 sonner toast + 쿼리 무효화 (useAssignMediaCompany가 처리)
 */
import { useState } from "react";
import { toast } from "sonner";
import {
  useAssignMediaCompany,
  useMediaCompanies,
} from "@/hooks/useAdmin";
import type { AdminOrderDetail } from "@/hooks/useAdmin";
import { getApiErrorMessage } from "@/lib/api";

interface AssignModalProps {
  /** 배정 대상 주문 */
  order: AdminOrderDetail;
  /** 닫기 콜백 */
  onClose: () => void;
  /** 성공 콜백 (선택) */
  onSuccess?: () => void;
}

export default function AssignModal({
  order,
  onClose,
  onSuccess,
}: AssignModalProps) {
  // 현재 선택된 미디어사 ID
  const [selectedId, setSelectedId] = useState<string>(
    order.media_company?.id ?? ""
  );

  const { data: companies = [], isLoading: loadingCompanies } =
    useMediaCompanies(false); // 활성 미디어사만

  const assignMutation = useAssignMediaCompany(order.id);

  // ============================
  // 배정 제출
  // ============================
  const handleSubmit = async () => {
    if (!selectedId) {
      toast.error("미디어사를 선택해주세요");
      return;
    }

    try {
      const result = await assignMutation.mutateAsync({
        media_company_id: selectedId,
      });

      const autoMsg =
        result.status === "in_progress"
          ? " (확정→진행중으로 자동 전환)"
          : "";

      toast.success(`${result.media_company_name}에 배정되었습니다${autoMsg}`);
      onSuccess?.();
      onClose();
    } catch (err) {
      toast.error(getApiErrorMessage(err));
    }
  };

  // ============================
  // 상태 전환 안내 메시지
  // ============================
  const showAutoTransitionNote = order.status === "confirmed";

  return (
    /* 배경 오버레이 */
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm"
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <div className="bg-slate-900 border border-slate-700 rounded-xl shadow-2xl w-full max-w-md mx-4">
        {/* 헤더 */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-700">
          <h2 className="text-lg font-semibold text-slate-100">
            미디어사 배정
          </h2>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-200 transition-colors"
            aria-label="닫기"
          >
            ✕
          </button>
        </div>

        {/* 본문 */}
        <div className="px-6 py-5 space-y-4">
          {/* 주문 요약 */}
          <div className="bg-slate-800 rounded-lg p-3 text-sm space-y-1">
            <div className="flex justify-between">
              <span className="text-slate-400">주문 ID</span>
              <span className="text-slate-200 font-mono">
                {order.id.slice(0, 8)}…
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">상품</span>
              <span className="text-slate-200">{order.product_name}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">현재 배정</span>
              <span
                className={
                  order.media_company
                    ? "text-cyan-400"
                    : "text-slate-500"
                }
              >
                {order.media_company?.name ?? "미배정"}
              </span>
            </div>
          </div>

          {/* confirmed → in_progress 전환 안내 */}
          {showAutoTransitionNote && (
            <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-3 text-sm text-blue-300">
              ℹ️ 현재 주문 상태가 <strong>확정(confirmed)</strong>입니다.
              배정 시 자동으로 <strong>진행중(in_progress)</strong>으로 전환됩니다.
            </div>
          )}

          {/* 미디어사 선택 */}
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-1.5">
              배정할 미디어사 <span className="text-red-400">*</span>
            </label>
            {loadingCompanies ? (
              <div className="h-10 bg-slate-800 rounded-lg animate-pulse" />
            ) : (
              <select
                value={selectedId}
                onChange={(e) => setSelectedId(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2.5 text-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500/50 focus:border-cyan-500"
              >
                <option value="">— 선택하세요 —</option>
                {companies.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                    {c.order_count > 0
                      ? ` (진행 ${c.order_count}건 / 완료 ${c.completed_count}건)`
                      : " (신규)"}
                  </option>
                ))}
              </select>
            )}
            {companies.length === 0 && !loadingCompanies && (
              <p className="text-sm text-slate-500 mt-1">
                등록된 활성 미디어사가 없습니다.
              </p>
            )}
          </div>
        </div>

        {/* 버튼 영역 */}
        <div className="flex justify-end gap-3 px-6 py-4 border-t border-slate-700">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-lg text-sm text-slate-300 hover:text-slate-100 hover:bg-slate-700 transition-colors"
          >
            취소
          </button>
          <button
            onClick={handleSubmit}
            disabled={!selectedId || assignMutation.isPending}
            className="px-5 py-2 rounded-lg text-sm font-medium bg-cyan-600 hover:bg-cyan-500 text-white disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
          >
            {assignMutation.isPending ? "배정 중…" : "배정 완료"}
          </button>
        </div>
      </div>
    </div>
  );
}
