"use client";

/**
 * 환불 결정 모달 (Sprint 6)
 *
 * - 유저가 요청한 환불 사유 표시
 * - 처리 메모 필수 입력 (10자 이상)
 * - 승인(빨강) / 거부(회색) 버튼
 * - 승인 → order.status=refunded, payment.status=refunded
 * - 거부 → order.status=confirmed (원상복구)
 */
import { useState } from "react";
import { toast } from "sonner";
import { useRefundDecision } from "@/hooks/useAdmin";
import type { AdminOrderDetail } from "@/hooks/useAdmin";
import { getApiErrorMessage } from "@/lib/api";

interface RefundDecisionModalProps {
  /** 환불 결정 대상 주문 */
  order: AdminOrderDetail;
  /** 닫기 콜백 */
  onClose: () => void;
  /** 성공 콜백 (선택) */
  onSuccess?: () => void;
}

export default function RefundDecisionModal({
  order,
  onClose,
  onSuccess,
}: RefundDecisionModalProps) {
  const [note, setNote] = useState("");
  const [noteError, setNoteError] = useState("");

  const refundMutation = useRefundDecision(order.id);

  // ============================
  // 환불 결정 제출
  // ============================
  const handleDecision = async (approve: boolean) => {
    // 메모 최소 길이 검증
    if (note.trim().length < 10) {
      setNoteError("처리 메모는 최소 10자 이상 입력해주세요");
      return;
    }
    setNoteError("");

    const actionLabel = approve ? "승인" : "거부";

    try {
      const result = await refundMutation.mutateAsync({ approve, note });

      if (approve) {
        toast.success("환불이 승인되었습니다. 결제가 환불 처리됩니다.");
      } else {
        toast.success("환불 요청이 거부되었습니다. 주문이 확정 상태로 복구됩니다.");
      }

      onSuccess?.();
      onClose();
    } catch (err) {
      toast.error(getApiErrorMessage(err));
    }
  };

  // ============================
  // 환불 사유 추출 (order.extra_data에서 가져올 수 없으므로
  // admin_notes에서 refund 관련 노트 탐색)
  // ============================
  const refundNote = order.admin_notes
    .slice()
    .reverse()
    .find((n) => n.note.includes("환불") || n.note.includes("disputed"));

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm"
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <div className="bg-slate-900 border border-slate-700 rounded-xl shadow-2xl w-full max-w-lg mx-4">
        {/* 헤더 */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-700">
          <div className="flex items-center gap-2">
            <span className="text-lg">⚠️</span>
            <h2 className="text-lg font-semibold text-slate-100">
              환불 결정
            </h2>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-200 transition-colors"
            aria-label="닫기"
          >
            ✕
          </button>
        </div>

        {/* 본문 */}
        <div className="px-6 py-5 space-y-4">
          {/* 주문 요약 */}
          <div className="bg-slate-800 rounded-lg p-3 text-sm space-y-1">
            <div className="flex justify-between">
              <span className="text-slate-400">주문</span>
              <span className="text-slate-200">{order.product_name}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">금액</span>
              <span className="text-slate-200">
                ₩{order.total_amount.toLocaleString()}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">워크스페이스</span>
              <span className="text-slate-200">
                {order.workspace?.name ?? "-"}
              </span>
            </div>
          </div>

          {/* 환불 요청 사유 */}
          <div>
            <p className="text-sm font-medium text-slate-300 mb-1.5">
              환불 요청 내역
            </p>
            <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-3 text-sm text-amber-200">
              {refundNote ? (
                <div>
                  <p className="font-mono text-xs text-amber-400 mb-1">
                    {new Date(refundNote.timestamp).toLocaleString("ko-KR")}
                  </p>
                  <p>{refundNote.note}</p>
                </div>
              ) : (
                <p className="text-slate-400">유저 요청 사유가 기록되지 않았습니다.</p>
              )}
            </div>
          </div>

          {/* 환불 정책 요약 */}
          <div className="bg-slate-800/50 rounded-lg p-3 text-xs text-slate-400 space-y-1">
            <p className="font-medium text-slate-300 mb-1">📋 처리 결과</p>
            <p>• <strong className="text-green-400">승인</strong>: 주문 상태 → refunded, 결제 상태 → refunded</p>
            <p>• <strong className="text-slate-300">거부</strong>: 주문 상태 → confirmed (원상복구)</p>
          </div>

          {/* 처리 메모 */}
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-1.5">
              처리 메모 <span className="text-red-400">*</span>
              <span className="text-slate-500 font-normal ml-1">(최소 10자)</span>
            </label>
            <textarea
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="환불 결정 사유 및 처리 내용을 입력해주세요. 이 메모는 어드민 노트에 기록됩니다."
              rows={4}
              className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2.5 text-slate-200 text-sm placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500/50 focus:border-cyan-500 resize-none"
            />
            <div className="flex justify-between mt-1">
              {noteError ? (
                <p className="text-red-400 text-xs">{noteError}</p>
              ) : (
                <span />
              )}
              <span className="text-slate-500 text-xs">
                {note.length}자
              </span>
            </div>
          </div>
        </div>

        {/* 버튼 영역 */}
        <div className="flex justify-end gap-3 px-6 py-4 border-t border-slate-700">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-lg text-sm text-slate-300 hover:text-slate-100 hover:bg-slate-700 transition-colors"
          >
            취소
          </button>

          {/* 거부 버튼 */}
          <button
            onClick={() => handleDecision(false)}
            disabled={refundMutation.isPending}
            className="px-4 py-2 rounded-lg text-sm font-medium bg-slate-700 hover:bg-slate-600 text-slate-200 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
          >
            {refundMutation.isPending ? "처리 중…" : "환불 거부"}
          </button>

          {/* 승인 버튼 */}
          <button
            onClick={() => handleDecision(true)}
            disabled={refundMutation.isPending}
            className="px-5 py-2 rounded-lg text-sm font-medium bg-red-600 hover:bg-red-500 text-white disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
          >
            {refundMutation.isPending ? "처리 중…" : "환불 승인"}
          </button>
        </div>
      </div>
    </div>
  );
}
