"use client";

/**
 * PaymentMethodModal 컴포넌트 (Sprint 8)
 *
 * 결제 수단 등록/변경 모달
 * - 카드 번호 끝 4자리, 카드 브랜드, 유효기간 입력
 * - useUpdatePaymentMethod 훅으로 API 호출
 * - 성공 시 toast + 모달 닫기
 *
 * Props:
 *   isOpen     모달 표시 여부
 *   onClose    닫기 핸들러
 */

import { useState, useEffect } from "react";
import { X, CreditCard, ShieldCheck } from "lucide-react";
import { toast } from "sonner";
import { useUpdatePaymentMethod, PaymentMethodRequest } from "@/hooks/useBilling";

// ─────────────────────────────────────────────────────────────
// 카드 브랜드 목록
// ─────────────────────────────────────────────────────────────
const CARD_BRANDS = [
  { value: "Visa", label: "Visa" },
  { value: "Mastercard", label: "Mastercard" },
  { value: "Amex", label: "American Express" },
  { value: "KakaoBank", label: "카카오뱅크" },
  { value: "TossBank", label: "토스뱅크" },
  { value: "Shinhan", label: "신한카드" },
  { value: "KB", label: "KB국민카드" },
  { value: "Hyundai", label: "현대카드" },
  { value: "Lotte", label: "롯데카드" },
  { value: "Hana", label: "하나카드" },
  { value: "Samsung", label: "삼성카드" },
];

// ─────────────────────────────────────────────────────────────
// Props 타입
// ─────────────────────────────────────────────────────────────
interface PaymentMethodModalProps {
  isOpen: boolean;
  onClose: () => void;
}

// ─────────────────────────────────────────────────────────────
// 유효성 검사
// ─────────────────────────────────────────────────────────────
function validateForm(form: PaymentMethodRequest): string | null {
  if (!form.card_number_last4 || form.card_number_last4.length !== 4) {
    return "카드 번호 끝 4자리를 정확히 입력하세요.";
  }
  if (!/^\d{4}$/.test(form.card_number_last4)) {
    return "카드 번호는 숫자 4자리만 입력 가능합니다.";
  }
  if (!form.card_brand) {
    return "카드 브랜드를 선택하세요.";
  }
  const monthNum = parseInt(form.exp_month, 10);
  if (!form.exp_month || monthNum < 1 || monthNum > 12) {
    return "유효한 만료 월(01~12)을 입력하세요.";
  }
  if (!form.exp_year || form.exp_year.length !== 2) {
    return "유효 연도를 2자리로 입력하세요 (예: 27).";
  }
  return null;
}

// ─────────────────────────────────────────────────────────────
// 컴포넌트
// ─────────────────────────────────────────────────────────────
export default function PaymentMethodModal({ isOpen, onClose }: PaymentMethodModalProps) {
  const updatePaymentMethod = useUpdatePaymentMethod();

  // 폼 상태
  const [form, setForm] = useState<PaymentMethodRequest>({
    card_number_last4: "",
    card_brand: "",
    exp_month: "",
    exp_year: "",
    pg_customer_id: undefined,
  });
  const [error, setError] = useState<string>("");

  // 모달 열릴 때 폼 초기화
  useEffect(() => {
    if (isOpen) {
      setForm({ card_number_last4: "", card_brand: "", exp_month: "", exp_year: "" });
      setError("");
    }
  }, [isOpen]);

  // 필드 변경 핸들러
  function handleChange(
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
    setError("");
  }

  // 제출 핸들러
  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const validationError = validateForm(form);
    if (validationError) {
      setError(validationError);
      return;
    }

    // 월 두 자리 패딩
    const normalizedForm: PaymentMethodRequest = {
      ...form,
      exp_month: form.exp_month.padStart(2, "0"),
    };

    updatePaymentMethod.mutate(normalizedForm, {
      onSuccess: () => {
        toast.success("결제 수단이 등록되었습니다.");
        onClose();
      },
      onError: (err: any) => {
        const msg = err?.response?.data?.detail || "결제 수단 등록에 실패했습니다.";
        setError(msg);
        toast.error(msg);
      },
    });
  }

  // 모달 닫기 (배경 클릭)
  function handleBackdropClick(e: React.MouseEvent<HTMLDivElement>) {
    if (e.target === e.currentTarget) onClose();
  }

  if (!isOpen) return null;

  // ─────────────────────────────────────────────────────────────
  // 스타일 상수
  // ─────────────────────────────────────────────────────────────
  const inputStyle: React.CSSProperties = {
    width: "100%",
    padding: "10px 12px",
    background: "rgba(255,255,255,0.05)",
    border: "1px solid rgba(255,255,255,0.12)",
    borderRadius: "8px",
    color: "#fff",
    fontSize: "14px",
    outline: "none",
    boxSizing: "border-box",
    transition: "border-color 0.2s",
  };

  const labelStyle: React.CSSProperties = {
    display: "block",
    fontSize: "13px",
    color: "rgba(255,255,255,0.6)",
    marginBottom: "6px",
    fontWeight: 500,
  };

  return (
    /* 배경 오버레이 */
    <div
      onClick={handleBackdropClick}
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(0,0,0,0.7)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        zIndex: 1000,
        padding: "20px",
      }}
    >
      {/* 모달 카드 */}
      <div
        style={{
          background: "#13131a",
          border: "1px solid rgba(255,255,255,0.1)",
          borderRadius: "16px",
          padding: "28px",
          width: "100%",
          maxWidth: "440px",
          position: "relative",
        }}
      >
        {/* 닫기 버튼 */}
        <button
          onClick={onClose}
          style={{
            position: "absolute",
            top: "16px",
            right: "16px",
            background: "transparent",
            border: "none",
            color: "rgba(255,255,255,0.4)",
            cursor: "pointer",
            padding: "4px",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <X size={18} />
        </button>

        {/* 타이틀 */}
        <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "24px" }}>
          <div
            style={{
              width: "40px",
              height: "40px",
              background: "rgba(0,212,255,0.1)",
              border: "1px solid rgba(0,212,255,0.2)",
              borderRadius: "10px",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <CreditCard size={20} style={{ color: "#00d4ff" }} />
          </div>
          <div>
            <h2 style={{ fontSize: "16px", fontWeight: 600, color: "#fff", margin: 0 }}>
              결제 수단 등록
            </h2>
            <p style={{ fontSize: "12px", color: "rgba(255,255,255,0.4)", margin: "2px 0 0" }}>
              카드 정보를 입력해 주세요
            </p>
          </div>
        </div>

        {/* 폼 */}
        <form onSubmit={handleSubmit}>
          {/* 카드 브랜드 */}
          <div style={{ marginBottom: "16px" }}>
            <label style={labelStyle}>카드 브랜드</label>
            <select
              name="card_brand"
              value={form.card_brand}
              onChange={handleChange}
              style={{ ...inputStyle, cursor: "pointer" }}
              required
            >
              <option value="" style={{ background: "#13131a" }}>선택하세요</option>
              {CARD_BRANDS.map((b) => (
                <option key={b.value} value={b.value} style={{ background: "#13131a" }}>
                  {b.label}
                </option>
              ))}
            </select>
          </div>

          {/* 카드 번호 끝 4자리 */}
          <div style={{ marginBottom: "16px" }}>
            <label style={labelStyle}>카드 번호 끝 4자리</label>
            <input
              name="card_number_last4"
              type="text"
              inputMode="numeric"
              maxLength={4}
              placeholder="1234"
              value={form.card_number_last4}
              onChange={handleChange}
              style={inputStyle}
              required
            />
            <p style={{ fontSize: "11px", color: "rgba(255,255,255,0.3)", marginTop: "4px" }}>
              보안을 위해 카드 번호 끝 4자리만 저장됩니다
            </p>
          </div>

          {/* 유효기간 */}
          <div style={{ marginBottom: "20px" }}>
            <label style={labelStyle}>유효기간</label>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "10px" }}>
              <div>
                <input
                  name="exp_month"
                  type="text"
                  inputMode="numeric"
                  maxLength={2}
                  placeholder="MM (예: 09)"
                  value={form.exp_month}
                  onChange={handleChange}
                  style={inputStyle}
                  required
                />
              </div>
              <div>
                <input
                  name="exp_year"
                  type="text"
                  inputMode="numeric"
                  maxLength={2}
                  placeholder="YY (예: 27)"
                  value={form.exp_year}
                  onChange={handleChange}
                  style={inputStyle}
                  required
                />
              </div>
            </div>
          </div>

          {/* 에러 메시지 */}
          {error && (
            <div
              style={{
                background: "rgba(248,113,113,0.1)",
                border: "1px solid rgba(248,113,113,0.2)",
                borderRadius: "8px",
                padding: "10px 12px",
                color: "#f87171",
                fontSize: "13px",
                marginBottom: "16px",
              }}
            >
              {error}
            </div>
          )}

          {/* 보안 안내 */}
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: "8px",
              padding: "10px 12px",
              background: "rgba(255,255,255,0.03)",
              border: "1px solid rgba(255,255,255,0.06)",
              borderRadius: "8px",
              marginBottom: "20px",
            }}
          >
            <ShieldCheck size={14} style={{ color: "#22c55e", flexShrink: 0 }} />
            <span style={{ fontSize: "12px", color: "rgba(255,255,255,0.4)" }}>
              결제 정보는 안전하게 암호화되어 저장됩니다
            </span>
          </div>

          {/* 버튼 그룹 */}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "10px" }}>
            <button
              type="button"
              onClick={onClose}
              style={{
                padding: "11px 0",
                background: "rgba(255,255,255,0.05)",
                border: "1px solid rgba(255,255,255,0.1)",
                borderRadius: "8px",
                color: "rgba(255,255,255,0.6)",
                fontSize: "14px",
                cursor: "pointer",
                fontWeight: 500,
              }}
            >
              취소
            </button>
            <button
              type="submit"
              disabled={updatePaymentMethod.isPending}
              style={{
                padding: "11px 0",
                background: updatePaymentMethod.isPending
                  ? "rgba(0,212,255,0.3)"
                  : "linear-gradient(135deg, #00d4ff, #7c3aed)",
                border: "none",
                borderRadius: "8px",
                color: "#fff",
                fontSize: "14px",
                cursor: updatePaymentMethod.isPending ? "not-allowed" : "pointer",
                fontWeight: 600,
              }}
            >
              {updatePaymentMethod.isPending ? "저장 중..." : "결제 수단 등록"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
