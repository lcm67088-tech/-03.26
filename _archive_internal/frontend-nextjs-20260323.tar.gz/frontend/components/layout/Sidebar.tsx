"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  LayoutDashboard,
  MapPin,
  ShoppingCart,
  Bell,
  User,
  Settings,
  ChevronLeft,
  ChevronRight,
  Users,
  Building2,
  CreditCard,
  BarChart3,
  TrendingUp,
  Shield,
  Zap,
} from "lucide-react";

// 유저 사이드 메뉴
const userMenuItems = [
  {
    group: "메인",
    items: [
      { href: "/dashboard", label: "대시보드", icon: LayoutDashboard },
      { href: "/places", label: "장소 관리", icon: MapPin },
      { href: "/orders", label: "주문", icon: ShoppingCart },
    ],
  },
  {
    group: "분석",
    items: [
      { href: "/insights", label: "인사이트", icon: BarChart3 },
      { href: "/notifications", label: "알림", icon: Bell },
    ],
  },
  {
    group: "설정",
    items: [
      { href: "/billing", label: "구독·결제", icon: CreditCard },
      { href: "/workspace/members", label: "팀원 관리", icon: Users },
      { href: "/account", label: "계정", icon: User },
    ],
  },
];

// 어드민 사이드 메뉴
const adminMenuItems = [
  {
    group: "관리",
    items: [
      { href: "/admin", label: "대시보드", icon: LayoutDashboard },
      { href: "/admin/orders", label: "주문 관리", icon: ShoppingCart },
      { href: "/admin/media-companies", label: "매체사", icon: Building2 },
      { href: "/admin/settlements", label: "정산", icon: CreditCard },
    ],
  },
  {
    group: "운영",
    items: [
      { href: "/admin/users", label: "유저 관리", icon: Users },
      { href: "/admin/workspaces", label: "워크스페이스", icon: Zap },
      { href: "/admin/crawling", label: "크롤링", icon: BarChart3 },
      { href: "/admin/stats", label: "통계·KPI", icon: TrendingUp },
    ],
  },
  {
    group: "시스템",
    items: [
      { href: "/admin/support", label: "CS 관리", icon: Bell },
      { href: "/admin/security", label: "보안", icon: Shield },
    ],
  },
];

// 플랜 뱃지 컬러
const planColors: Record<string, string> = {
  free: "bg-slate-500/20 text-slate-400",
  starter: "bg-blue-500/20 text-blue-400",
  pro: "bg-purple-500/20 text-purple-400",
  enterprise: "bg-yellow-500/20 text-yellow-400",
};

interface SidebarProps {
  isAdmin?: boolean;
  currentPlan?: string;
  workspaceName?: string;
}

/**
 * 사이드바 컴포넌트
 * - 유저/어드민 메뉴 분기
 * - 현재 경로 하이라이트
 * - 접기/펼치기 토글
 */
export function Sidebar({
  isAdmin = false,
  currentPlan = "free",
  workspaceName = "내 워크스페이스",
}: SidebarProps) {
  const [collapsed, setCollapsed] = useState(false);
  const pathname = usePathname();

  const menuItems = isAdmin ? adminMenuItems : userMenuItems;

  const isActive = (href: string) => {
    if (href === "/dashboard" || href === "/admin") {
      return pathname === href;
    }
    return pathname.startsWith(href);
  };

  return (
    <aside
      className={`
        relative flex flex-col border-r transition-all duration-300 ease-in-out
        ${collapsed ? "w-16" : "w-60"}
      `}
      style={{
        background: "rgba(10,10,20,0.95)",
        borderColor: "rgba(0,212,255,0.1)",
      }}
    >
      {/* 로고 */}
      <div
        className="flex items-center h-16 px-4 border-b"
        style={{ borderColor: "rgba(0,212,255,0.1)" }}
      >
        {!collapsed ? (
          <Link href={isAdmin ? "/admin" : "/dashboard"} className="flex items-center gap-2">
            <div
              className="w-8 h-8 rounded-lg flex items-center justify-center text-sm font-bold"
              style={{
                background: "linear-gradient(135deg, #00d4ff 0%, #7c3aed 100%)",
                color: "#0a0a0f",
              }}
            >
              N
            </div>
            <span className="font-bold text-slate-100">
              nplace.io
              {isAdmin && (
                <span className="ml-1 text-xs text-red-400">ADMIN</span>
              )}
            </span>
          </Link>
        ) : (
          <Link href={isAdmin ? "/admin" : "/dashboard"}>
            <div
              className="w-8 h-8 rounded-lg flex items-center justify-center text-sm font-bold mx-auto"
              style={{
                background: "linear-gradient(135deg, #00d4ff 0%, #7c3aed 100%)",
                color: "#0a0a0f",
              }}
            >
              N
            </div>
          </Link>
        )}
      </div>

      {/* 메뉴 */}
      <nav className="flex-1 overflow-y-auto py-4 px-2">
        {menuItems.map((group) => (
          <div key={group.group} className="mb-4">
            {!collapsed && (
              <p className="text-[10px] font-semibold text-slate-600 uppercase tracking-widest px-3 mb-1.5">
                {group.group}
              </p>
            )}
            <ul className="space-y-0.5">
              {group.items.map((item) => {
                const Icon = item.icon;
                const active = isActive(item.href);

                return (
                  <li key={item.href}>
                    <Link
                      href={item.href}
                      className={`
                        flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium
                        transition-all duration-150
                        ${active
                          ? "bg-brand-primary/10 text-brand-primary"
                          : "text-slate-400 hover:text-slate-100 hover:bg-white/5"
                        }
                      `}
                      style={active ? { borderLeft: "2px solid #00d4ff", paddingLeft: "10px" } : {}}
                      title={collapsed ? item.label : undefined}
                    >
                      <Icon
                        size={18}
                        className={active ? "text-brand-primary" : "text-slate-500"}
                      />
                      {!collapsed && <span>{item.label}</span>}
                    </Link>
                  </li>
                );
              })}
            </ul>
          </div>
        ))}
      </nav>

      {/* 하단: 워크스페이스 정보 */}
      {!isAdmin && !collapsed && (
        <div
          className="p-3 border-t mx-2 mb-2 rounded-lg"
          style={{
            borderColor: "rgba(0,212,255,0.1)",
            background: "rgba(255,255,255,0.02)",
          }}
        >
          <div className="flex items-center justify-between">
            <div className="min-w-0">
              <p className="text-xs font-medium text-slate-300 truncate">{workspaceName}</p>
              <span
                className={`text-[10px] px-1.5 py-0.5 rounded font-medium uppercase ${planColors[currentPlan] || planColors.free}`}
              >
                {currentPlan}
              </span>
            </div>
            <Link href="/billing/upgrade" className="ml-2 flex-shrink-0">
              <Zap size={14} className="text-brand-primary" />
            </Link>
          </div>
        </div>
      )}

      {/* 접기/펼치기 버튼 */}
      <button
        onClick={() => setCollapsed(!collapsed)}
        className="absolute -right-3 top-20 w-6 h-6 rounded-full flex items-center justify-center
          text-slate-400 hover:text-slate-100 transition-colors z-10"
        style={{
          background: "rgba(15,15,25,0.95)",
          border: "1px solid rgba(0,212,255,0.2)",
        }}
      >
        {collapsed ? <ChevronRight size={12} /> : <ChevronLeft size={12} />}
      </button>
    </aside>
  );
}
