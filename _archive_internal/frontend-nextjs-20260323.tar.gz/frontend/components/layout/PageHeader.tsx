/**
 * PageHeader 컴포넌트
 * 페이지 상단 제목 + 부제목 + 액션 버튼 영역
 */

interface PageHeaderProps {
  title: string;
  description?: string;
  actions?: React.ReactNode;
  breadcrumbs?: { label: string; href?: string }[];
}

/**
 * 페이지 헤더 컴포넌트
 */
export function PageHeader({ title, description, actions, breadcrumbs }: PageHeaderProps) {
  return (
    <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4 mb-6">
      <div>
        {/* 브레드크럼 */}
        {breadcrumbs && breadcrumbs.length > 0 && (
          <nav className="flex items-center gap-1.5 text-xs text-slate-500 mb-2">
            {breadcrumbs.map((crumb, idx) => (
              <span key={idx} className="flex items-center gap-1.5">
                {crumb.href ? (
                  <a href={crumb.href} className="hover:text-slate-300 transition-colors">
                    {crumb.label}
                  </a>
                ) : (
                  <span className="text-slate-400">{crumb.label}</span>
                )}
                {idx < breadcrumbs.length - 1 && <span>/</span>}
              </span>
            ))}
          </nav>
        )}

        {/* 제목 */}
        <h1 className="text-2xl font-bold text-slate-100">{title}</h1>

        {/* 부제목 */}
        {description && (
          <p className="text-slate-400 text-sm mt-1">{description}</p>
        )}
      </div>

      {/* 액션 버튼 영역 */}
      {actions && (
        <div className="flex items-center gap-2 flex-shrink-0">
          {actions}
        </div>
      )}
    </div>
  );
}
