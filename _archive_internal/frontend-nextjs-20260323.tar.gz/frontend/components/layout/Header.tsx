"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { ChevronDown, Settings, LogOut, User } from "lucide-react";
import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import NotificationBell from "@/components/notifications/NotificationBell";

interface HeaderProps {
  isAdmin?: boolean;
}

/**
 * 상단 헤더 컴포넌트 (Sprint 7 업데이트)
 * - 페이지 제목
 * - NotificationBell 컴포넌트 (알림 드롭다운 포함)
 * - 유저 아바타 드롭다운 (useAuth 연동)
 */
export function Header({ isAdmin = false }: HeaderProps) {
  const pathname = usePathname();
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const { user, workspace, logout, currentPlan } = useAuth();

  // 경로에 따른 페이지 제목 매핑
  const pageTitle = getPageTitle(pathname);

  const userName = user?.name ?? "사용자";
  const userEmail = user?.email ?? "user@example.com";

  // 로그아웃 처리
  async function handleLogout() {
    setDropdownOpen(false);
    await logout();
    window.location.href = "/login";
  }

  return (
    <header
      className="h-16 flex items-center justify-between px-6 border-b flex-shrink-0"
      style={{
        background: "rgba(10,10,20,0.8)",
        borderColor: "rgba(0,212,255,0.1)",
        backdropFilter: "blur(10px)",
      }}
    >
      {/* 좌측: 페이지 제목 */}
      <div>
        <h2 className="text-lg font-semibold text-slate-100">{pageTitle}</h2>
        {/* 워크스페이스 이름 서브텍스트 (일반 유저만) */}
        {!isAdmin && workspace?.name && (
          <p className="text-xs text-slate-500 -mt-0.5">{workspace.name}</p>
        )}
      </div>

      {/* 우측: 알림 + 유저 */}
      <div className="flex items-center gap-3">
        {/* 알림 벨 (NotificationBell 컴포넌트) */}
        <NotificationBell />

        {/* 유저 드롭다운 */}
        <div className="relative">
          <button
            onClick={() => setDropdownOpen(!dropdownOpen)}
            className="flex items-center gap-2 p-1.5 rounded-lg hover:bg-white/5 transition-all"
          >
            {/* 아바타 */}
            <div
              className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold"
              style={{
                background: "linear-gradient(135deg, #00d4ff 0%, #7c3aed 100%)",
                color: "#0a0a0f",
              }}
            >
              {userName.charAt(0).toUpperCase()}
            </div>
            <span className="text-sm text-slate-300 hidden sm:block">{userName}</span>
            <ChevronDown
              size={14}
              className={`text-slate-500 transition-transform ${dropdownOpen ? "rotate-180" : ""}`}
            />
          </button>

          {/* 드롭다운 메뉴 */}
          {dropdownOpen && (
            <>
              {/* 오버레이 */}
              <div
                className="fixed inset-0 z-10"
                onClick={() => setDropdownOpen(false)}
              />
              <div
                className="absolute right-0 top-full mt-2 w-52 rounded-xl py-1 z-20"
                style={{
                  background: "rgba(15,15,25,0.98)",
                  border: "1px solid rgba(0,212,255,0.15)",
                  boxShadow: "0 8px 32px rgba(0,0,0,0.5)",
                }}
              >
                {/* 유저 정보 */}
                <div className="px-3 py-2 border-b" style={{ borderColor: "rgba(255,255,255,0.05)" }}>
                  <p className="text-sm font-medium text-slate-200">{userName}</p>
                  <p className="text-xs text-slate-500 truncate">{userEmail}</p>
                  {!isAdmin && currentPlan && (
                    <span
                      className="inline-block mt-1 text-[10px] px-1.5 py-0.5 rounded font-semibold uppercase"
                      style={{
                        background:
                          currentPlan === "enterprise"
                            ? "rgba(234,179,8,0.15)"
                            : currentPlan === "pro"
                            ? "rgba(124,58,237,0.15)"
                            : currentPlan === "starter"
                            ? "rgba(59,130,246,0.15)"
                            : "rgba(100,116,139,0.15)",
                        color:
                          currentPlan === "enterprise"
                            ? "#eab308"
                            : currentPlan === "pro"
                            ? "#a78bfa"
                            : currentPlan === "starter"
                            ? "#60a5fa"
                            : "#94a3b8",
                      }}
                    >
                      {currentPlan}
                    </span>
                  )}
                </div>

                {/* 메뉴 아이템 */}
                <Link
                  href="/account"
                  className="flex items-center gap-2 px-3 py-2 text-sm text-slate-400 hover:text-slate-100 hover:bg-white/5 transition-all"
                  onClick={() => setDropdownOpen(false)}
                >
                  <User size={14} />
                  내 계정
                </Link>
                {!isAdmin && (
                  <Link
                    href={`/workspaces/${workspace?.id ?? ""}/members`}
                    className="flex items-center gap-2 px-3 py-2 text-sm text-slate-400 hover:text-slate-100 hover:bg-white/5 transition-all"
                    onClick={() => setDropdownOpen(false)}
                  >
                    <Settings size={14} />
                    워크스페이스 설정
                  </Link>
                )}
                <Link
                  href="/notifications/settings"
                  className="flex items-center gap-2 px-3 py-2 text-sm text-slate-400 hover:text-slate-100 hover:bg-white/5 transition-all"
                  onClick={() => setDropdownOpen(false)}
                >
                  <Settings size={14} />
                  알림 설정
                </Link>
                <hr style={{ borderColor: "rgba(255,255,255,0.05)" }} className="my-1" />
                <button
                  className="w-full flex items-center gap-2 px-3 py-2 text-sm text-red-400 hover:text-red-300 hover:bg-red-500/5 transition-all"
                  onClick={handleLogout}
                >
                  <LogOut size={14} />
                  로그아웃
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </header>
  );
}

// 경로에 따른 페이지 제목 반환
function getPageTitle(pathname: string): string {
  // 동적 경로 처리
  if (pathname.match(/^\/workspaces\/[^/]+\/members/)) return "팀원 관리";
  if (pathname.match(/^\/orders\/[^/]+/)) return "주문 상세";
  if (pathname.match(/^\/places\/[^/]+/)) return "장소 상세";

  const titleMap: Record<string, string> = {
    "/dashboard": "대시보드",
    "/places": "장소 관리",
    "/places/new": "장소 등록",
    "/orders": "주문 목록",
    "/orders/new": "주문 생성",
    "/insights": "인사이트",
    "/notifications": "알림 센터",
    "/notifications/settings": "알림 설정",
    "/billing": "구독·결제",
    "/billing/upgrade": "플랜 업그레이드",
    "/workspace/members": "팀원 관리",
    "/workspace/settings": "워크스페이스 설정",
    "/account": "내 계정",
    "/admin": "어드민 대시보드",
    "/admin/orders": "주문 관리",
    "/admin/media-companies": "매체사 관리",
    "/admin/settlements": "정산 관리",
    "/admin/users": "유저 관리",
    "/admin/workspaces": "워크스페이스 관리",
    "/admin/crawling": "크롤링 관리",
    "/admin/support": "CS 관리",
    "/admin/stats/dashboard": "통계·KPI",
  };

  return titleMap[pathname] || pathname.split("/").pop() || "페이지";
}
