/**
 * LoadingSpinner 컴포넌트
 * 로딩 상태를 표시하는 스피너 및 스켈레톤
 */

interface LoadingSpinnerProps {
  size?: "sm" | "md" | "lg";
  className?: string;
}

const sizeClasses = {
  sm: "w-4 h-4 border-2",
  md: "w-8 h-8 border-2",
  lg: "w-12 h-12 border-3",
};

/**
 * 스피너 컴포넌트
 */
export function LoadingSpinner({ size = "md", className = "" }: LoadingSpinnerProps) {
  return (
    <div
      className={`rounded-full animate-spin ${sizeClasses[size]} ${className}`}
      style={{
        borderColor: "rgba(0,212,255,0.2)",
        borderTopColor: "#00d4ff",
      }}
    />
  );
}

/**
 * 전체 페이지 로딩
 */
export function PageLoading() {
  return (
    <div className="flex items-center justify-center h-full min-h-64">
      <div className="text-center space-y-3">
        <LoadingSpinner size="lg" className="mx-auto" />
        <p className="text-slate-400 text-sm">불러오는 중...</p>
      </div>
    </div>
  );
}

/**
 * 카드 스켈레톤
 */
export function CardSkeleton() {
  return (
    <div className="card p-5 animate-pulse">
      <div className="h-4 bg-white/5 rounded w-3/4 mb-3" />
      <div className="h-8 bg-white/5 rounded w-1/2 mb-2" />
      <div className="h-3 bg-white/5 rounded w-1/4" />
    </div>
  );
}

/**
 * 테이블 로우 스켈레톤
 */
export function TableRowSkeleton({ cols = 5 }: { cols?: number }) {
  return (
    <tr className="animate-pulse">
      {Array.from({ length: cols }).map((_, i) => (
        <td key={i} className="px-4 py-3">
          <div className="h-4 bg-white/5 rounded" />
        </td>
      ))}
    </tr>
  );
}

/**
 * 페이지 스켈레톤 (대시보드용)
 */
export function DashboardSkeleton() {
  return (
    <div className="space-y-6">
      {/* 헤더 */}
      <div className="animate-pulse">
        <div className="h-7 bg-white/5 rounded w-48 mb-2" />
        <div className="h-4 bg-white/5 rounded w-64" />
      </div>

      {/* KPI 카드 */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {[1, 2, 3, 4].map((i) => (
          <CardSkeleton key={i} />
        ))}
      </div>

      {/* 차트 영역 */}
      <div className="card p-5 animate-pulse">
        <div className="h-64 bg-white/5 rounded" />
      </div>
    </div>
  );
}
