/**
 * EmptyState 컴포넌트
 * 데이터가 없을 때 표시하는 빈 상태 컴포넌트
 */

interface EmptyStateProps {
  icon?: string;
  title: string;
  description?: string;
  actionLabel?: string;
  actionHref?: string;
  onAction?: () => void;
}

/**
 * 빈 상태 컴포넌트
 * 목록이 비어있거나 검색 결과가 없을 때 사용
 */
export function EmptyState({
  icon = "📭",
  title,
  description,
  actionLabel,
  actionHref,
  onAction,
}: EmptyStateProps) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-center">
      {/* 아이콘 */}
      <div className="text-5xl mb-4">{icon}</div>

      {/* 텍스트 */}
      <h3 className="text-lg font-semibold text-slate-200 mb-2">{title}</h3>
      {description && (
        <p className="text-slate-400 text-sm max-w-sm">{description}</p>
      )}

      {/* 액션 버튼 */}
      {actionLabel && (
        <div className="mt-6">
          {actionHref ? (
            <a
              href={actionHref}
              className="btn-primary"
            >
              {actionLabel}
            </a>
          ) : (
            <button onClick={onAction} className="btn-primary">
              {actionLabel}
            </button>
          )}
        </div>
      )}
    </div>
  );
}

/**
 * 장소 없음 상태 (편의 컴포넌트)
 */
export function NoPlacesEmpty() {
  return (
    <EmptyState
      icon="🏪"
      title="등록된 장소가 없습니다"
      description="네이버 플레이스 URL을 입력해 첫 번째 장소를 등록하고 순위 모니터링을 시작하세요."
      actionLabel="장소 등록하기"
      actionHref="/places/new"
    />
  );
}

/**
 * 주문 없음 상태 (편의 컴포넌트)
 */
export function NoOrdersEmpty() {
  return (
    <EmptyState
      icon="📦"
      title="주문 내역이 없습니다"
      description="마케팅 서비스를 주문하면 여기에 표시됩니다."
      actionLabel="주문하기"
      actionHref="/orders/new"
    />
  );
}

/**
 * 검색 결과 없음 (편의 컴포넌트)
 */
export function NoSearchResults({ query }: { query: string }) {
  return (
    <EmptyState
      icon="🔍"
      title={`"${query}" 검색 결과가 없습니다`}
      description="다른 검색어로 다시 시도해 보세요."
    />
  );
}
