/**
 * StatusBadge 컴포넌트
 * 주문 상태, 플랜, 순위 케이스 등 뱃지 표시
 */

interface StatusBadgeProps {
  status: string;
  type?: "order" | "plan" | "rank" | "payment" | "custom";
  className?: string;
}

// 주문 상태 설정
const orderStatusConfig: Record<string, { label: string; className: string }> = {
  pending: { label: "결제완료·대기", className: "bg-yellow-500/15 text-yellow-400 border-yellow-500/20" },
  confirmed: { label: "배정완료", className: "bg-blue-500/15 text-blue-400 border-blue-500/20" },
  in_progress: { label: "진행중", className: "bg-purple-500/15 text-purple-400 border-purple-500/20" },
  completed: { label: "완료", className: "bg-green-500/15 text-green-400 border-green-500/20" },
  cancelled: { label: "취소", className: "bg-gray-500/15 text-gray-400 border-gray-500/20" },
  refunded: { label: "환불", className: "bg-red-500/15 text-red-400 border-red-500/20" },
  disputed: { label: "분쟁", className: "bg-orange-500/15 text-orange-400 border-orange-500/20" },
};

// 플랜 설정
const planConfig: Record<string, { label: string; className: string }> = {
  free: { label: "Free", className: "bg-gray-500/15 text-gray-400 border-gray-500/20" },
  starter: { label: "Starter", className: "bg-blue-500/15 text-blue-400 border-blue-500/20" },
  pro: { label: "Pro", className: "bg-purple-500/15 text-purple-400 border-purple-500/20" },
  enterprise: { label: "Enterprise", className: "bg-yellow-500/15 text-yellow-400 border-yellow-500/20" },
};

// 순위 케이스 설정
const rankCaseConfig: Record<string, { label: string; className: string }> = {
  normal: { label: "일반", className: "bg-slate-500/15 text-slate-400 border-slate-500/20" },
  popular: { label: "인기", className: "bg-cyan-500/15 text-cyan-400 border-cyan-500/20" },
  not_ranked: { label: "미진입", className: "bg-red-500/15 text-red-400 border-red-500/20" },
};

// 결제 상태 설정
const paymentStatusConfig: Record<string, { label: string; className: string }> = {
  pending: { label: "처리중", className: "bg-yellow-500/15 text-yellow-400 border-yellow-500/20" },
  completed: { label: "완료", className: "bg-green-500/15 text-green-400 border-green-500/20" },
  failed: { label: "실패", className: "bg-red-500/15 text-red-400 border-red-500/20" },
  refunded: { label: "환불", className: "bg-orange-500/15 text-orange-400 border-orange-500/20" },
};

/**
 * 상태 뱃지 컴포넌트
 */
export function StatusBadge({ status, type = "order", className = "" }: StatusBadgeProps) {
  const configMap = {
    order: orderStatusConfig,
    plan: planConfig,
    rank: rankCaseConfig,
    payment: paymentStatusConfig,
    custom: {},
  };

  const config = configMap[type][status];

  if (!config) {
    return (
      <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium border ${className}`}>
        {status}
      </span>
    );
  }

  return (
    <span
      className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium border ${config.className} ${className}`}
    >
      {config.label}
    </span>
  );
}

/**
 * 플랜 뱃지 (편의 컴포넌트)
 */
export function PlanBadge({ plan }: { plan: string }) {
  return <StatusBadge status={plan} type="plan" />;
}
