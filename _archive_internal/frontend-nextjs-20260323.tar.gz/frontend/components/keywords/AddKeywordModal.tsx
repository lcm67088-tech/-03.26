"use client";

/**
 * 키워드 추가 모달 (Sprint 4)
 *
 * - shadcn Dialog 기반
 * - React Hook Form + Zod 검증
 * - 기존 그룹 Select + "직접 입력" 옵션
 * - 주요 키워드 토글
 * - 로딩 상태 + 에러 처리
 * - 성공 시 onClose() + toast.success
 */
import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Loader2, X } from "lucide-react";
import { toast } from "sonner";
import { useCreateKeyword } from "@/hooks/useKeywords";

// ============================
// Zod 스키마
// ============================

const KeywordSchema = z.object({
  keyword: z
    .string()
    .min(1, "키워드를 입력해주세요")
    .max(50, "키워드는 최대 50자입니다")
    .transform((v) => v.trim()),
  is_primary: z.boolean().default(false),
  group_name: z.string().optional(),
  custom_group: z.string().max(50, "그룹명은 50자 이하").optional(),
});

type KeywordFormData = z.infer<typeof KeywordSchema>;

// ============================
// Props
// ============================

interface AddKeywordModalProps {
  placeId: string;
  existingGroups: string[];   // 이미 사용 중인 그룹명 목록
  isOpen: boolean;
  onClose: () => void;
}

// ============================
// 메인 컴포넌트
// ============================

export default function AddKeywordModal({
  placeId,
  existingGroups,
  isOpen,
  onClose,
}: AddKeywordModalProps) {
  const createMutation = useCreateKeyword(placeId);

  // "직접 입력" 선택 여부
  const [isCustomGroup, setIsCustomGroup] = useState(false);

  const {
    register,
    handleSubmit,
    watch,
    setValue,
    reset,
    formState: { errors },
  } = useForm<KeywordFormData>({
    resolver: zodResolver(KeywordSchema),
    defaultValues: {
      keyword: "",
      is_primary: false,
      group_name: "",
      custom_group: "",
    },
  });

  const isPrimary = watch("is_primary");
  const selectedGroup = watch("group_name");

  // 모달 열릴 때마다 초기화
  useEffect(() => {
    if (isOpen) {
      reset();
      setIsCustomGroup(false);
    }
  }, [isOpen, reset]);

  // group_name Select 변경 핸들러
  const handleGroupChange = (value: string) => {
    if (value === "__custom__") {
      setIsCustomGroup(true);
      setValue("group_name", "");
    } else {
      setIsCustomGroup(false);
      setValue("group_name", value);
    }
  };

  // ============================
  // 폼 제출
  // ============================
  const onSubmit = async (data: KeywordFormData) => {
    // 그룹명 결정 (직접 입력 vs 선택)
    const finalGroup = isCustomGroup
      ? (data.custom_group?.trim() || undefined)
      : (data.group_name?.trim() || undefined);

    try {
      await createMutation.mutateAsync({
        keyword: data.keyword,
        is_primary: data.is_primary,
        group_name: finalGroup,
      });

      toast.success("키워드가 등록되었습니다 🔑", {
        description: `'${data.keyword}' 순위 모니터링을 시작합니다`,
      });
      onClose();
    } catch (error) {
      const msg =
        error instanceof Error ? error.message : "등록 중 오류가 발생했습니다";
      toast.error(msg);
    }
  };

  if (!isOpen) return null;

  const isLoading = createMutation.isPending;

  // ============================
  // 렌더
  // ============================
  return (
    <>
      {/* 오버레이 */}
      <div
        className="fixed inset-0 z-50"
        style={{ background: "rgba(0,0,0,0.65)", backdropFilter: "blur(4px)" }}
        onClick={onClose}
      />

      {/* 모달 */}
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        <div
          className="w-full max-w-md rounded-2xl p-6 shadow-2xl"
          style={{
            background: "linear-gradient(135deg, #1a1a2e 0%, #16213e 100%)",
            border: "1px solid rgba(255,255,255,0.1)",
          }}
          onClick={(e) => e.stopPropagation()}
        >
          {/* 헤더 */}
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-lg font-bold text-slate-100">
                키워드 추가
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                키워드를 등록하면 매일 자동으로 순위를 추적합니다
              </p>
            </div>
            <button
              type="button"
              onClick={onClose}
              disabled={isLoading}
              className="p-1.5 rounded-lg transition-all"
              style={{ color: "#64748b" }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLButtonElement).style.color = "#e2e8f0";
                (e.currentTarget as HTMLButtonElement).style.background =
                  "rgba(255,255,255,0.06)";
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLButtonElement).style.color = "#64748b";
                (e.currentTarget as HTMLButtonElement).style.background =
                  "transparent";
              }}
            >
              <X size={18} />
            </button>
          </div>

          <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
            {/* ① 키워드 입력 */}
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1.5">
                키워드
                <span className="text-red-400 ml-0.5">*</span>
              </label>
              <input
                {...register("keyword")}
                type="text"
                maxLength={50}
                placeholder="예: 강남 맛집, 서울 카페"
                disabled={isLoading}
                className="w-full rounded-xl px-4 py-2.5 text-sm text-slate-100 placeholder:text-slate-600 outline-none transition-all"
                style={{
                  background: "rgba(255,255,255,0.06)",
                  border: `1px solid ${
                    errors.keyword
                      ? "rgba(239,68,68,0.5)"
                      : "rgba(255,255,255,0.1)"
                  }`,
                }}
                onFocus={(e) => {
                  e.currentTarget.style.borderColor = "#00d4ff";
                  e.currentTarget.style.boxShadow =
                    "0 0 0 3px rgba(0,212,255,0.1)";
                }}
                onBlur={(e) => {
                  e.currentTarget.style.borderColor = errors.keyword
                    ? "rgba(239,68,68,0.5)"
                    : "rgba(255,255,255,0.1)";
                  e.currentTarget.style.boxShadow = "none";
                }}
              />
              {errors.keyword && (
                <p className="text-xs text-red-400 mt-1">
                  {errors.keyword.message}
                </p>
              )}
            </div>

            {/* ② 주요 키워드 토글 */}
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-300">
                  주요 키워드로 설정
                </p>
                <p className="text-xs text-slate-500 mt-0.5">
                  대시보드 최상단에 표시됩니다
                </p>
              </div>
              <button
                type="button"
                onClick={() => setValue("is_primary", !isPrimary)}
                disabled={isLoading}
                className="relative w-11 h-6 rounded-full transition-all focus:outline-none flex-shrink-0"
                style={{
                  background: isPrimary
                    ? "#00d4ff"
                    : "rgba(255,255,255,0.12)",
                }}
              >
                <span
                  className="absolute top-0.5 w-5 h-5 rounded-full transition-all"
                  style={{
                    left: isPrimary ? "calc(100% - 22px)" : "2px",
                    background: "#fff",
                    boxShadow: "0 1px 3px rgba(0,0,0,0.3)",
                  }}
                />
              </button>
            </div>

            {/* ③ 그룹 지정 */}
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1.5">
                그룹 지정{" "}
                <span className="text-slate-500 font-normal">(선택)</span>
              </label>

              {existingGroups.length > 0 && !isCustomGroup ? (
                <>
                  <select
                    value={selectedGroup || ""}
                    onChange={(e) => handleGroupChange(e.target.value)}
                    disabled={isLoading}
                    className="w-full rounded-xl px-4 py-2.5 text-sm text-slate-100 outline-none transition-all appearance-none"
                    style={{
                      background: "rgba(255,255,255,0.06)",
                      border: "1px solid rgba(255,255,255,0.1)",
                    }}
                    onFocus={(e) => {
                      e.currentTarget.style.borderColor = "#00d4ff";
                    }}
                    onBlur={(e) => {
                      e.currentTarget.style.borderColor =
                        "rgba(255,255,255,0.1)";
                    }}
                  >
                    <option value="">그룹 없음</option>
                    {existingGroups.map((g) => (
                      <option key={g} value={g}>
                        {g}
                      </option>
                    ))}
                    <option value="__custom__">+ 새 그룹 만들기</option>
                  </select>
                </>
              ) : (
                <>
                  <input
                    {...register("custom_group")}
                    type="text"
                    maxLength={50}
                    placeholder="새 그룹명 입력 (예: 브랜드, 지역)"
                    disabled={isLoading}
                    className="w-full rounded-xl px-4 py-2.5 text-sm text-slate-100 placeholder:text-slate-600 outline-none transition-all"
                    style={{
                      background: "rgba(255,255,255,0.06)",
                      border: `1px solid ${
                        errors.custom_group
                          ? "rgba(239,68,68,0.5)"
                          : "rgba(255,255,255,0.1)"
                      }`,
                    }}
                    onFocus={(e) => {
                      e.currentTarget.style.borderColor = "#00d4ff";
                      e.currentTarget.style.boxShadow =
                        "0 0 0 3px rgba(0,212,255,0.1)";
                    }}
                    onBlur={(e) => {
                      e.currentTarget.style.borderColor = errors.custom_group
                        ? "rgba(239,68,68,0.5)"
                        : "rgba(255,255,255,0.1)";
                      e.currentTarget.style.boxShadow = "none";
                    }}
                  />
                  {existingGroups.length > 0 && (
                    <button
                      type="button"
                      onClick={() => setIsCustomGroup(false)}
                      className="mt-1.5 text-xs"
                      style={{ color: "#00d4ff" }}
                    >
                      ← 기존 그룹 선택
                    </button>
                  )}
                  {errors.custom_group && (
                    <p className="text-xs text-red-400 mt-1">
                      {errors.custom_group.message}
                    </p>
                  )}
                </>
              )}
            </div>

            {/* 버튼 그룹 */}
            <div className="flex gap-3 pt-2">
              <button
                type="button"
                onClick={onClose}
                disabled={isLoading}
                className="flex-1 py-2.5 rounded-xl text-sm font-medium transition-all disabled:opacity-50"
                style={{
                  background: "rgba(255,255,255,0.06)",
                  border: "1px solid rgba(255,255,255,0.1)",
                  color: "#94a3b8",
                }}
              >
                취소
              </button>
              <button
                type="submit"
                disabled={isLoading}
                className="flex-1 py-2.5 rounded-xl text-sm font-semibold transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                style={{ background: "#00d4ff", color: "#0a0a0f" }}
              >
                {isLoading ? (
                  <>
                    <Loader2 size={14} className="animate-spin" />
                    등록 중...
                  </>
                ) : (
                  "키워드 등록"
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    </>
  );
}
