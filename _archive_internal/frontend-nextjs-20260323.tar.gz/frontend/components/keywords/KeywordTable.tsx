"use client";

/**
 * 키워드 테이블 컴포넌트 (Sprint 4)
 *
 * - 키워드명 | 주요여부 | 최신순위 | 7일평균 | 순위변동 | 최종크롤링 | 액션
 * - 로딩 시 스켈레톤 (5행)
 * - is_primary 먼저, 이후 rank 오름차순 (API에서 정렬 후 전달)
 * - 그룹 필터 탭 (그룹 없으면 숨김)
 *
 * SubComponents:
 *   RankDisplay     순위 배지 (메달 이모지 + 색상)
 *   RankChange      순위 변동 (▲▼ 표시)
 */
import { useState } from "react";
import { Edit3, Trash2, Star } from "lucide-react";
import { formatRelativeTime, formatRankChange } from "@/lib/utils";
import type { KeywordWithRank } from "@/hooks/useKeywords";

// ============================
// 순위 표시 컴포넌트
// ============================

export function RankDisplay({
  rank,
  caseType,
}: {
  rank?: number | null;
  caseType?: string | null;
}) {
  // 크롤링 전 (데이터 없음)
  if (caseType === undefined || caseType === null) {
    return <span className="text-slate-600 text-sm">-</span>;
  }
  // 미진입
  if (caseType === "not_ranked" || rank === null || rank === undefined) {
    return (
      <span
        className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium"
        style={{
          background: "rgba(239,68,68,0.12)",
          color: "#f87171",
          border: "1px solid rgba(239,68,68,0.2)",
        }}
      >
        미진입
      </span>
    );
  }
  // 메달 이모지 (1~3위)
  if (rank === 1) return <span className="text-sm font-bold">🥇 1위</span>;
  if (rank === 2) return <span className="text-sm font-bold">🥈 2위</span>;
  if (rank === 3) return <span className="text-sm font-bold">🥉 3위</span>;

  // 4~10위: 파랑
  if (rank <= 10) {
    return (
      <span
        className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium"
        style={{
          background: "rgba(59,130,246,0.12)",
          color: "#60a5fa",
          border: "1px solid rgba(59,130,246,0.2)",
        }}
      >
        {rank}위
      </span>
    );
  }

  // 11~20위: 회색
  if (rank <= 20) {
    return (
      <span
        className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium"
        style={{
          background: "rgba(107,114,128,0.12)",
          color: "#9ca3af",
          border: "1px solid rgba(107,114,128,0.2)",
        }}
      >
        {rank}위
      </span>
    );
  }

  // 21위 이상: 더 흐린 회색
  return (
    <span
      className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium"
      style={{
        background: "rgba(75,85,99,0.1)",
        color: "#6b7280",
        border: "1px solid rgba(75,85,99,0.15)",
      }}
    >
      {rank}위
    </span>
  );
}

// ============================
// 순위 변동 컴포넌트
// ============================

export function RankChange({ change }: { change?: number | null }) {
  const { text, color } = formatRankChange(change);
  return <span className={`text-xs font-medium ${color}`}>{text}</span>;
}

// ============================
// 스켈레톤
// ============================

function TableSkeleton() {
  return (
    <>
      {Array.from({ length: 5 }).map((_, i) => (
        <tr key={i}>
          {Array.from({ length: 7 }).map((_, j) => (
            <td key={j} className="px-4 py-3">
              <div
                className="h-4 rounded animate-pulse"
                style={{
                  background: "rgba(255,255,255,0.06)",
                  width: j === 0 ? "120px" : j === 5 ? "80px" : "60px",
                }}
              />
            </td>
          ))}
        </tr>
      ))}
    </>
  );
}

// ============================
// KeywordTable Props
// ============================

interface KeywordTableProps {
  keywords: KeywordWithRank[];
  onEdit: (keyword: KeywordWithRank) => void;
  onDelete: (keywordId: string) => void;
  isLoading?: boolean;
}

// ============================
// 메인 컴포넌트
// ============================

export default function KeywordTable({
  keywords,
  onEdit,
  onDelete,
  isLoading = false,
}: KeywordTableProps) {
  // 그룹 필터 상태
  const [activeGroup, setActiveGroup] = useState<string>("all");

  // 기존 그룹명 추출 (중복 제거, null/undefined 제외)
  const groups = Array.from(
    new Set(
      keywords
        .map((kw) => kw.group_name)
        .filter((g): g is string => !!g)
    )
  );
  const hasGroups = groups.length > 0;

  // 그룹 필터 적용
  const filteredKeywords =
    activeGroup === "all"
      ? keywords
      : keywords.filter((kw) => kw.group_name === activeGroup);

  return (
    <div>
      {/* 그룹 필터 탭 — 그룹 있을 때만 표시 */}
      {hasGroups && (
        <div className="flex gap-2 mb-4 flex-wrap">
          <button
            type="button"
            onClick={() => setActiveGroup("all")}
            className="px-3 py-1 rounded-lg text-xs font-medium transition-all"
            style={
              activeGroup === "all"
                ? { background: "#00d4ff", color: "#0a0a0f" }
                : {
                    background: "rgba(255,255,255,0.06)",
                    color: "#94a3b8",
                    border: "1px solid rgba(255,255,255,0.1)",
                  }
            }
          >
            전체 ({keywords.length})
          </button>
          {groups.map((g) => {
            const count = keywords.filter((kw) => kw.group_name === g).length;
            return (
              <button
                key={g}
                type="button"
                onClick={() => setActiveGroup(g)}
                className="px-3 py-1 rounded-lg text-xs font-medium transition-all"
                style={
                  activeGroup === g
                    ? { background: "#00d4ff", color: "#0a0a0f" }
                    : {
                        background: "rgba(255,255,255,0.06)",
                        color: "#94a3b8",
                        border: "1px solid rgba(255,255,255,0.1)",
                      }
                }
              >
                {g} ({count})
              </button>
            );
          })}
        </div>
      )}

      {/* 테이블 */}
      <div
        className="rounded-xl overflow-hidden"
        style={{ border: "1px solid rgba(255,255,255,0.08)" }}
      >
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            {/* 헤더 */}
            <thead>
              <tr style={{ borderBottom: "1px solid rgba(255,255,255,0.08)" }}>
                <th
                  className="px-4 py-3 text-left text-xs font-medium text-slate-400"
                  style={{ background: "rgba(255,255,255,0.03)" }}
                >
                  키워드
                </th>
                <th
                  className="px-4 py-3 text-left text-xs font-medium text-slate-400"
                  style={{ background: "rgba(255,255,255,0.03)" }}
                >
                  주요
                </th>
                <th
                  className="px-4 py-3 text-left text-xs font-medium text-slate-400"
                  style={{ background: "rgba(255,255,255,0.03)" }}
                >
                  최신순위
                </th>
                <th
                  className="px-4 py-3 text-left text-xs font-medium text-slate-400"
                  style={{ background: "rgba(255,255,255,0.03)" }}
                >
                  7일평균
                </th>
                <th
                  className="px-4 py-3 text-left text-xs font-medium text-slate-400"
                  style={{ background: "rgba(255,255,255,0.03)" }}
                >
                  순위변동
                </th>
                <th
                  className="px-4 py-3 text-left text-xs font-medium text-slate-400"
                  style={{ background: "rgba(255,255,255,0.03)" }}
                >
                  최종크롤링
                </th>
                <th
                  className="px-4 py-3 text-right text-xs font-medium text-slate-400"
                  style={{ background: "rgba(255,255,255,0.03)" }}
                >
                  액션
                </th>
              </tr>
            </thead>

            {/* 바디 */}
            <tbody>
              {isLoading ? (
                <TableSkeleton />
              ) : filteredKeywords.length === 0 ? (
                <tr>
                  <td
                    colSpan={7}
                    className="px-4 py-8 text-center text-slate-500 text-sm"
                  >
                    {activeGroup === "all"
                      ? "등록된 키워드가 없습니다"
                      : `'${activeGroup}' 그룹에 키워드가 없습니다`}
                  </td>
                </tr>
              ) : (
                filteredKeywords.map((kw, idx) => (
                  <tr
                    key={kw.id}
                    style={{
                      borderBottom:
                        idx < filteredKeywords.length - 1
                          ? "1px solid rgba(255,255,255,0.05)"
                          : "none",
                      background: "transparent",
                      transition: "background 0.15s",
                    }}
                    onMouseEnter={(e) => {
                      (e.currentTarget as HTMLTableRowElement).style.background =
                        "rgba(255,255,255,0.02)";
                    }}
                    onMouseLeave={(e) => {
                      (e.currentTarget as HTMLTableRowElement).style.background =
                        "transparent";
                    }}
                  >
                    {/* 키워드명 */}
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <span className="text-slate-100 font-medium">
                          {kw.keyword}
                        </span>
                        {kw.group_name && (
                          <span
                            className="text-[10px] px-1.5 py-0.5 rounded font-medium"
                            style={{
                              background: "rgba(124,58,237,0.15)",
                              color: "#a78bfa",
                              border: "1px solid rgba(124,58,237,0.2)",
                            }}
                          >
                            {kw.group_name}
                          </span>
                        )}
                      </div>
                    </td>

                    {/* 주요 키워드 */}
                    <td className="px-4 py-3">
                      {kw.is_primary ? (
                        <Star
                          size={14}
                          style={{ color: "#fbbf24" }}
                          fill="#fbbf24"
                        />
                      ) : (
                        <span className="text-slate-700">—</span>
                      )}
                    </td>

                    {/* 최신 순위 */}
                    <td className="px-4 py-3">
                      <RankDisplay
                        rank={kw.latest_rank}
                        caseType={kw.case_type}
                      />
                    </td>

                    {/* 7일 평균 */}
                    <td className="px-4 py-3">
                      <span className="text-slate-300 text-xs">
                        {kw.rank_7d_avg != null
                          ? `${kw.rank_7d_avg.toFixed(1)}위`
                          : "-"}
                      </span>
                    </td>

                    {/* 순위 변동 */}
                    <td className="px-4 py-3">
                      <RankChange change={kw.rank_change} />
                    </td>

                    {/* 최종 크롤링 */}
                    <td className="px-4 py-3">
                      <span className="text-slate-500 text-xs">
                        {kw.crawled_at
                          ? formatRelativeTime(kw.crawled_at)
                          : "미실행"}
                      </span>
                    </td>

                    {/* 액션 버튼 */}
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-end gap-1.5">
                        {/* 수정 */}
                        <button
                          type="button"
                          onClick={() => onEdit(kw)}
                          className="p-1.5 rounded-lg transition-all"
                          style={{ color: "#64748b" }}
                          onMouseEnter={(e) => {
                            (e.currentTarget as HTMLButtonElement).style.color =
                              "#00d4ff";
                            (
                              e.currentTarget as HTMLButtonElement
                            ).style.background = "rgba(0,212,255,0.08)";
                          }}
                          onMouseLeave={(e) => {
                            (e.currentTarget as HTMLButtonElement).style.color =
                              "#64748b";
                            (
                              e.currentTarget as HTMLButtonElement
                            ).style.background = "transparent";
                          }}
                          title="수정"
                        >
                          <Edit3 size={13} />
                        </button>

                        {/* 삭제 */}
                        <button
                          type="button"
                          onClick={() => onDelete(kw.id)}
                          className="p-1.5 rounded-lg transition-all"
                          style={{ color: "#64748b" }}
                          onMouseEnter={(e) => {
                            (e.currentTarget as HTMLButtonElement).style.color =
                              "#f87171";
                            (
                              e.currentTarget as HTMLButtonElement
                            ).style.background = "rgba(239,68,68,0.08)";
                          }}
                          onMouseLeave={(e) => {
                            (e.currentTarget as HTMLButtonElement).style.color =
                              "#64748b";
                            (
                              e.currentTarget as HTMLButtonElement
                            ).style.background = "transparent";
                          }}
                          title="삭제"
                        >
                          <Trash2 size={13} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
