"use client";

/**
 * 키워드 순위 트렌드 차트 컴포넌트 (Sprint 4)
 *
 * - Recharts LineChart 사용
 * - Y축 역전 (1위가 위에 오도록)
 * - 기간 선택 버튼 (7일 / 30일 / 90일)
 * - 키워드별 색상 라인
 * - 미진입 → null (라인 끊김)
 * - 커스텀 툴팁 (날짜 + 키워드별 순위)
 * - 범례 (키워드명, 주요 키워드 ⭐)
 * - 크롤링 데이터 없을 때 EmptyState
 * - 하단: 키워드별 요약 카드
 */
import { useState, useMemo } from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import { format } from "date-fns";
import { ko } from "date-fns/locale";
import { useKeywordRankings } from "@/hooks/useKeywords";
import LoadingSpinner from "@/components/common/LoadingSpinner";
import type { PlaceRankingSummaryKeyword } from "@/hooks/useKeywords";
import type { RankingPeriod } from "@/hooks/useKeywords";

// ============================
// 키워드별 색상 팔레트 (최대 10개)
// ============================

const CHART_COLORS = [
  "#00d4ff", // cyan (포인트 컬러)
  "#7c3aed", // violet
  "#10b981", // emerald
  "#f59e0b", // amber
  "#ef4444", // red
  "#8b5cf6", // purple
  "#06b6d4", // teal
  "#84cc16", // lime
  "#f97316", // orange
  "#ec4899", // pink
];

// ============================
// 기간 선택 버튼
// ============================

interface PeriodTabsProps {
  period: RankingPeriod;
  onChange: (p: RankingPeriod) => void;
}

function PeriodTabs({ period, onChange }: PeriodTabsProps) {
  const options: { value: RankingPeriod; label: string }[] = [
    { value: "7d", label: "7일" },
    { value: "30d", label: "30일" },
    { value: "90d", label: "90일" },
  ];

  return (
    <div className="flex gap-1.5">
      {options.map((opt) => (
        <button
          key={opt.value}
          type="button"
          onClick={() => onChange(opt.value)}
          className="px-3 py-1.5 rounded-lg text-xs font-medium transition-all"
          style={
            period === opt.value
              ? { background: "#00d4ff", color: "#0a0a0f" }
              : {
                  background: "rgba(255,255,255,0.06)",
                  color: "#94a3b8",
                  border: "1px solid rgba(255,255,255,0.1)",
                }
          }
        >
          {opt.label}
        </button>
      ))}
    </div>
  );
}

// ============================
// 커스텀 툴팁
// ============================

interface CustomTooltipProps {
  active?: boolean;
  payload?: Array<{
    name: string;
    value: number | null;
    color: string;
  }>;
  label?: string;
}

function CustomTooltip({ active, payload, label }: CustomTooltipProps) {
  if (!active || !payload || payload.length === 0) return null;

  return (
    <div
      className="rounded-xl p-3 text-xs shadow-xl"
      style={{
        background: "rgba(15,15,30,0.95)",
        border: "1px solid rgba(255,255,255,0.1)",
        backdropFilter: "blur(8px)",
        minWidth: 140,
      }}
    >
      {/* 날짜 */}
      <p className="text-slate-400 mb-2 font-medium">{label}</p>
      {payload.map((entry, idx) => (
        <div key={idx} className="flex items-center justify-between gap-4 mb-1">
          <div className="flex items-center gap-1.5">
            <span
              className="w-2 h-2 rounded-full flex-shrink-0"
              style={{ background: entry.color }}
            />
            <span className="text-slate-300">{entry.name}</span>
          </div>
          <span className="font-semibold text-slate-100">
            {entry.value != null ? `${entry.value}위` : "미진입"}
          </span>
        </div>
      ))}
    </div>
  );
}

// ============================
// 키워드별 요약 카드 (차트 하단)
// ============================

function KeywordSummaryCard({
  keyword,
  color,
}: {
  keyword: PlaceRankingSummaryKeyword;
  color: string;
}) {
  const rank = keyword.latest_rank;
  const change = keyword.rank_change;

  const changeEl =
    change !== null && change !== undefined ? (
      change > 0 ? (
        <span className="text-[10px] text-green-400">▲{change}</span>
      ) : change < 0 ? (
        <span className="text-[10px] text-red-400">▼{Math.abs(change)}</span>
      ) : (
        <span className="text-[10px] text-slate-500">-</span>
      )
    ) : null;

  return (
    <div
      className="rounded-xl p-3 flex-1 min-w-[120px]"
      style={{
        background: "rgba(255,255,255,0.03)",
        border: "1px solid rgba(255,255,255,0.07)",
        borderTop: `2px solid ${color}`,
      }}
    >
      {/* 키워드명 */}
      <div className="flex items-center gap-1 mb-2">
        {keyword.is_primary && (
          <span className="text-[10px]" title="주요 키워드">
            ⭐
          </span>
        )}
        <p className="text-xs text-slate-300 font-medium truncate">
          {keyword.keyword}
        </p>
      </div>

      {/* 최신 순위 + 변동 */}
      <div className="flex items-center gap-1.5 mb-1">
        <span className="text-xl font-bold" style={{ color }}>
          {rank != null ? `${rank}` : "-"}
        </span>
        {rank != null && <span className="text-xs text-slate-500">위</span>}
        {changeEl}
      </div>

      {/* 7일 평균 / 역대 최고 */}
      <div className="space-y-0.5">
        <p className="text-[10px] text-slate-600">
          7일평균{" "}
          <span className="text-slate-400">
            {keyword.rank_7d_avg != null
              ? `${keyword.rank_7d_avg.toFixed(1)}위`
              : "-"}
          </span>
        </p>
        <p className="text-[10px] text-slate-600">
          역대최고{" "}
          <span className="text-slate-400">
            {keyword.best_rank != null ? `${keyword.best_rank}위` : "-"}
          </span>
        </p>
      </div>
    </div>
  );
}

// ============================
// 단일 키워드 순위 이력 로더
// ============================

interface SingleKeywordLineProps {
  placeId: string;
  keywordId: string;
  period: RankingPeriod;
  onDataReady: (keywordId: string, data: { date: string; rank: number | null }[]) => void;
}

function SingleKeywordLoader({
  placeId,
  keywordId,
  period,
  onDataReady,
}: SingleKeywordLineProps) {
  const { data } = useKeywordRankings(placeId, keywordId, period);

  // 데이터 준비되면 콜백
  if (data && data.rankings) {
    const points = data.rankings.map((r) => ({
      date: format(new Date(r.crawled_at), "MM/dd", { locale: ko }),
      rank: r.rank ?? null,
    }));
    onDataReady(keywordId, points);
  }

  return null; // 렌더 없음 (데이터만 수집)
}

// ============================
// RankingChart Props
// ============================

interface RankingChartProps {
  keywords: PlaceRankingSummaryKeyword[];
  placeId: string;
}

// ============================
// 메인 차트 컴포넌트
// ============================

export default function RankingChart({ keywords, placeId }: RankingChartProps) {
  const [period, setPeriod] = useState<RankingPeriod>("30d");

  // 키워드별 순위 이력 데이터 수집
  // key: keywordId, value: [{date, rank}]
  const [rankingData, setRankingData] = useState<
    Record<string, { date: string; rank: number | null }[]>
  >({});

  const handleDataReady = (
    keywordId: string,
    data: { date: string; rank: number | null }[]
  ) => {
    setRankingData((prev) => {
      // 동일 데이터면 state 업데이트 스킵 (불필요한 리렌더 방지)
      if (JSON.stringify(prev[keywordId]) === JSON.stringify(data)) return prev;
      return { ...prev, [keywordId]: data };
    });
  };

  // 모든 날짜 집합 (union)
  const allDates = useMemo(() => {
    const dateSet = new Set<string>();
    Object.values(rankingData).forEach((points) => {
      points.forEach((p) => dateSet.add(p.date));
    });
    return Array.from(dateSet).sort();
  }, [rankingData]);

  // Recharts용 데이터 배열 구성
  // [{ date: "01/01", "키워드A": 5, "키워드B": null, ... }]
  const chartData = useMemo(() => {
    return allDates.map((date) => {
      const entry: Record<string, string | number | null> = { date };
      keywords.forEach((kw, idx) => {
        const points = rankingData[kw.id] ?? [];
        const found = points.find((p) => p.date === date);
        // 해당 날짜 데이터 없으면 null (라인 끊김)
        entry[kw.keyword] = found ? found.rank : null;
      });
      return entry;
    });
  }, [allDates, rankingData, keywords]);

  // 크롤링 데이터가 하나도 없는 경우
  const hasAnyData = Object.values(rankingData).some(
    (points) => points.length > 0
  );

  // 최대 순위 값 계산 (Y축 domain 용)
  const maxRank = useMemo(() => {
    let max = 10;
    Object.values(rankingData).forEach((points) => {
      points.forEach((p) => {
        if (p.rank != null && p.rank > max) max = p.rank;
      });
    });
    return max;
  }, [rankingData]);

  return (
    <div>
      {/* 기간 선택 + 로딩 중인 SingleKeywordLoader들 (렌더 없음) */}
      {keywords.map((kw) => (
        <SingleKeywordLoader
          key={`${kw.id}-${period}`}
          placeId={placeId}
          keywordId={kw.id}
          period={period}
          onDataReady={handleDataReady}
        />
      ))}

      {/* 상단 헤더: 기간 탭 */}
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-sm font-medium text-slate-300">순위 트렌드</h3>
        <PeriodTabs period={period} onChange={setPeriod} />
      </div>

      {/* 크롤링 데이터 없을 때 */}
      {!hasAnyData ? (
        <div
          className="rounded-xl p-10 text-center"
          style={{
            background: "rgba(255,255,255,0.02)",
            border: "1px solid rgba(255,255,255,0.06)",
          }}
        >
          <p className="text-3xl mb-3">📊</p>
          <p className="text-slate-300 font-medium mb-1">
            아직 크롤링 데이터가 없습니다
          </p>
          <p className="text-xs text-slate-500">
            크롤링이 실행되면 순위 추이를 확인할 수 있습니다
          </p>
        </div>
      ) : (
        <>
          {/* 차트 */}
          <div style={{ height: 300 }}>
            <ResponsiveContainer width="100%" height="100%">
              <LineChart
                data={chartData}
                margin={{ top: 5, right: 20, left: -20, bottom: 5 }}
              >
                <CartesianGrid
                  strokeDasharray="3 3"
                  stroke="rgba(255,255,255,0.06)"
                />
                <XAxis
                  dataKey="date"
                  tick={{ fill: "#64748b", fontSize: 11 }}
                  axisLine={{ stroke: "rgba(255,255,255,0.08)" }}
                  tickLine={false}
                />
                {/* Y축 역전: 1위가 맨 위 */}
                <YAxis
                  reversed
                  domain={[1, maxRank + 5]}
                  tick={{ fill: "#64748b", fontSize: 11 }}
                  axisLine={{ stroke: "rgba(255,255,255,0.08)" }}
                  tickLine={false}
                  tickFormatter={(v) => `${v}위`}
                />
                <Tooltip content={<CustomTooltip />} />
                <Legend
                  formatter={(value) => {
                    const kw = keywords.find((k) => k.keyword === value);
                    return (
                      <span
                        style={{ color: "#94a3b8", fontSize: 11 }}
                      >
                        {kw?.is_primary ? "⭐ " : ""}
                        {value}
                      </span>
                    );
                  }}
                />
                {keywords.map((kw, idx) => (
                  <Line
                    key={kw.id}
                    type="monotone"
                    dataKey={kw.keyword}
                    stroke={CHART_COLORS[idx % CHART_COLORS.length]}
                    strokeWidth={2}
                    dot={false}
                    activeDot={{ r: 4, strokeWidth: 0 }}
                    connectNulls={false}   // 미진입 구간은 라인 끊김
                  />
                ))}
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* 키워드별 요약 카드 */}
          <div className="flex flex-wrap gap-3 mt-6">
            {keywords.map((kw, idx) => (
              <KeywordSummaryCard
                key={kw.id}
                keyword={kw}
                color={CHART_COLORS[idx % CHART_COLORS.length]}
              />
            ))}
          </div>
        </>
      )}
    </div>
  );
}
