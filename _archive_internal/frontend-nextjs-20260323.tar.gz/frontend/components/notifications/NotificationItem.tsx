/**
 * NotificationItem 컴포넌트
 * Sprint 7: 단일 알림 항목 렌더링
 * - 알림 타입별 아이콘 색상 적용
 * - 읽음/미읽음 상태 표시
 * - 읽음 처리 / 삭제 액션 버튼
 */

"use client";

import { useState } from "react";
import { formatDistanceToNow } from "date-fns";
import { ko } from "date-fns/locale";
import { Bell, Package, TrendingUp, TrendingDown, Settings, Users, CreditCard, X, Check } from "lucide-react";
import {
  NotificationItem as NotificationItemType,
  NotificationType,
  NOTIFICATION_TYPE_LABELS,
  NOTIFICATION_TYPE_COLOR,
} from "@/hooks/useNotifications";

// ─────────────────────────────────────────────────────────────
// 알림 타입별 아이콘 컴포넌트
// ─────────────────────────────────────────────────────────────
function NotificationIcon({ type }: { type: NotificationType }) {
  const color = NOTIFICATION_TYPE_COLOR[type] ?? "#a3a3a3";
  const size = 16;

  // 주문 관련
  if (type.startsWith("ORDER_")) {
    return <Package size={size} style={{ color }} />;
  }
  // 랭킹 상승
  if (type === "RANK_IMPROVED" || type === "RANK_TOP10" || type === "RANK_TOP3") {
    return <TrendingUp size={size} style={{ color }} />;
  }
  // 랭킹 하락/급변동
  if (type === "RANK_DROPPED" || type === "RANK_FLUCTUATION") {
    return <TrendingDown size={size} style={{ color }} />;
  }
  // 시스템/플랜
  if (type.startsWith("PLAN_") || type.startsWith("CRAWL_")) {
    return <Settings size={size} style={{ color }} />;
  }
  // 워크스페이스 멤버
  if (type.startsWith("MEMBER_")) {
    return <Users size={size} style={{ color }} />;
  }
  // 결제
  if (type.startsWith("PAYMENT_")) {
    return <CreditCard size={size} style={{ color }} />;
  }
  return <Bell size={size} style={{ color }} />;
}

// ─────────────────────────────────────────────────────────────
// Props 정의
// ─────────────────────────────────────────────────────────────
interface NotificationItemProps {
  notification: NotificationItemType;
  onMarkRead: (id: string) => void;
  onDelete: (id: string) => void;
  isMarkingRead?: boolean;
  isDeleting?: boolean;
}

// ─────────────────────────────────────────────────────────────
// NotificationItem 컴포넌트
// ─────────────────────────────────────────────────────────────
export default function NotificationItem({
  notification,
  onMarkRead,
  onDelete,
  isMarkingRead = false,
  isDeleting = false,
}: NotificationItemProps) {
  const [isHovered, setIsHovered] = useState(false);

  // 상대 시간 표시 (예: "3분 전")
  const timeAgo = formatDistanceToNow(new Date(notification.created_at), {
    addSuffix: true,
    locale: ko,
  });

  const accentColor = NOTIFICATION_TYPE_COLOR[notification.type] ?? "#a3a3a3";

  return (
    <div
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      style={{
        display: "flex",
        gap: "12px",
        padding: "14px 16px",
        background: notification.is_read
          ? "transparent"
          : "rgba(0, 212, 255, 0.04)",
        borderBottom: "1px solid rgba(255,255,255,0.06)",
        transition: "background 0.15s",
        position: "relative",
        cursor: "default",
      }}
    >
      {/* 읽지 않은 알림 표시 점 */}
      {!notification.is_read && (
        <div
          style={{
            position: "absolute",
            left: "6px",
            top: "50%",
            transform: "translateY(-50%)",
            width: "6px",
            height: "6px",
            borderRadius: "50%",
            background: accentColor,
            flexShrink: 0,
          }}
        />
      )}

      {/* 아이콘 영역 */}
      <div
        style={{
          width: "36px",
          height: "36px",
          borderRadius: "8px",
          background: `${accentColor}18`,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          flexShrink: 0,
        }}
      >
        <NotificationIcon type={notification.type} />
      </div>

      {/* 본문 영역 */}
      <div style={{ flex: 1, minWidth: 0 }}>
        {/* 타입 레이블 + 시간 */}
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            marginBottom: "2px",
          }}
        >
          <span
            style={{
              fontSize: "11px",
              color: accentColor,
              fontWeight: 600,
              letterSpacing: "0.02em",
            }}
          >
            {NOTIFICATION_TYPE_LABELS[notification.type]}
          </span>
          <span
            style={{
              fontSize: "11px",
              color: "rgba(255,255,255,0.35)",
              whiteSpace: "nowrap",
              marginLeft: "8px",
            }}
          >
            {timeAgo}
          </span>
        </div>

        {/* 제목 */}
        <p
          style={{
            fontSize: "13px",
            fontWeight: notification.is_read ? 400 : 600,
            color: notification.is_read
              ? "rgba(255,255,255,0.6)"
              : "rgba(255,255,255,0.9)",
            margin: 0,
            marginBottom: "2px",
            overflow: "hidden",
            textOverflow: "ellipsis",
            whiteSpace: "nowrap",
          }}
        >
          {notification.title}
        </p>

        {/* 메시지 */}
        <p
          style={{
            fontSize: "12px",
            color: "rgba(255,255,255,0.45)",
            margin: 0,
            overflow: "hidden",
            textOverflow: "ellipsis",
            whiteSpace: "nowrap",
          }}
        >
          {notification.message}
        </p>
      </div>

      {/* 액션 버튼 (호버 시 표시) */}
      {isHovered && (
        <div
          style={{
            display: "flex",
            gap: "4px",
            alignItems: "center",
            flexShrink: 0,
          }}
        >
          {/* 읽음 처리 버튼 */}
          {!notification.is_read && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                onMarkRead(notification.id);
              }}
              disabled={isMarkingRead}
              title="읽음 처리"
              style={{
                width: "28px",
                height: "28px",
                borderRadius: "6px",
                border: "1px solid rgba(0, 212, 255, 0.3)",
                background: "rgba(0, 212, 255, 0.08)",
                color: "#00d4ff",
                cursor: "pointer",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                opacity: isMarkingRead ? 0.5 : 1,
              }}
            >
              <Check size={13} />
            </button>
          )}

          {/* 삭제 버튼 */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              onDelete(notification.id);
            }}
            disabled={isDeleting}
            title="삭제"
            style={{
              width: "28px",
              height: "28px",
              borderRadius: "6px",
              border: "1px solid rgba(248, 113, 113, 0.3)",
              background: "rgba(248, 113, 113, 0.08)",
              color: "#f87171",
              cursor: "pointer",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              opacity: isDeleting ? 0.5 : 1,
            }}
          >
            <X size={13} />
          </button>
        </div>
      )}
    </div>
  );
}
