/**
 * NotificationBell 컴포넌트
 * Sprint 7: 헤더에 표시되는 알림 벨 아이콘 + 드롭다운 패널
 * - 읽지 않은 알림 수 뱃지
 * - 드롭다운: 최근 알림 10개 표시
 * - "전체 읽음" / "알림 센터로" 버튼
 */

"use client";

import { useState, useRef, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Bell, CheckCheck } from "lucide-react";
import { toast } from "sonner";
import {
  useUnreadCount,
  useNotifications,
  useMarkAllRead,
  useMarkNotificationRead,
  useDeleteNotification,
} from "@/hooks/useNotifications";
import NotificationItem from "./NotificationItem";

// ─────────────────────────────────────────────────────────────
// NotificationBell 컴포넌트
// ─────────────────────────────────────────────────────────────
export default function NotificationBell() {
  const router = useRouter();
  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  // 읽지 않은 알림 수 조회 (30초마다 갱신)
  const { data: unreadData } = useUnreadCount();
  // 최근 알림 10개 조회
  const { data: notificationList } = useNotifications({ page: 1, limit: 10 });

  const { mutate: markAllRead, isPending: isMarkingAll } = useMarkAllRead();
  const { mutate: markRead, isPending: isMarkingRead } = useMarkNotificationRead();
  const { mutate: deleteNotification, isPending: isDeleting } = useDeleteNotification();

  // 읽지 않은 알림 수
  const unreadCount = unreadData?.total ?? 0;

  // 외부 클릭 시 드롭다운 닫기
  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (
        containerRef.current &&
        !containerRef.current.contains(e.target as Node)
      ) {
        setIsOpen(false);
      }
    }
    if (isOpen) {
      document.addEventListener("mousedown", handleClickOutside);
    }
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [isOpen]);

  // 전체 읽음 처리
  function handleMarkAllRead() {
    markAllRead(undefined, {
      onSuccess: ({ count }) => {
        toast.success(`${count}개의 알림을 읽음 처리했습니다.`);
      },
      onError: () => toast.error("읽음 처리에 실패했습니다."),
    });
  }

  return (
    <div ref={containerRef} style={{ position: "relative" }}>
      {/* 벨 아이콘 버튼 */}
      <button
        onClick={() => setIsOpen((prev) => !prev)}
        style={{
          position: "relative",
          width: "36px",
          height: "36px",
          borderRadius: "8px",
          border: isOpen
            ? "1px solid rgba(0, 212, 255, 0.4)"
            : "1px solid rgba(255,255,255,0.08)",
          background: isOpen
            ? "rgba(0, 212, 255, 0.08)"
            : "rgba(255,255,255,0.04)",
          color: isOpen ? "#00d4ff" : "rgba(255,255,255,0.6)",
          cursor: "pointer",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          transition: "all 0.15s",
        }}
      >
        <Bell size={18} />

        {/* 읽지 않은 알림 뱃지 */}
        {unreadCount > 0 && (
          <div
            style={{
              position: "absolute",
              top: "-4px",
              right: "-4px",
              minWidth: "18px",
              height: "18px",
              borderRadius: "9px",
              background: "#f87171",
              color: "#fff",
              fontSize: "10px",
              fontWeight: 700,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              padding: "0 4px",
              border: "2px solid #0a0a0f",
            }}
          >
            {unreadCount > 99 ? "99+" : unreadCount}
          </div>
        )}
      </button>

      {/* 드롭다운 패널 */}
      {isOpen && (
        <div
          style={{
            position: "absolute",
            top: "calc(100% + 8px)",
            right: 0,
            width: "380px",
            maxHeight: "520px",
            background: "#111118",
            border: "1px solid rgba(255,255,255,0.1)",
            borderRadius: "12px",
            boxShadow: "0 8px 32px rgba(0,0,0,0.5)",
            zIndex: 1000,
            display: "flex",
            flexDirection: "column",
            overflow: "hidden",
          }}
        >
          {/* 드롭다운 헤더 */}
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              padding: "14px 16px",
              borderBottom: "1px solid rgba(255,255,255,0.08)",
            }}
          >
            <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
              <span
                style={{
                  fontSize: "14px",
                  fontWeight: 600,
                  color: "rgba(255,255,255,0.9)",
                }}
              >
                알림
              </span>
              {unreadCount > 0 && (
                <span
                  style={{
                    padding: "2px 8px",
                    borderRadius: "10px",
                    background: "rgba(0, 212, 255, 0.15)",
                    color: "#00d4ff",
                    fontSize: "11px",
                    fontWeight: 600,
                  }}
                >
                  {unreadCount}개 미읽음
                </span>
              )}
            </div>

            {/* 전체 읽음 버튼 */}
            {unreadCount > 0 && (
              <button
                onClick={handleMarkAllRead}
                disabled={isMarkingAll}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "4px",
                  padding: "4px 10px",
                  borderRadius: "6px",
                  border: "1px solid rgba(255,255,255,0.1)",
                  background: "transparent",
                  color: "rgba(255,255,255,0.5)",
                  fontSize: "11px",
                  cursor: "pointer",
                  opacity: isMarkingAll ? 0.5 : 1,
                }}
              >
                <CheckCheck size={12} />
                전체 읽음
              </button>
            )}
          </div>

          {/* 알림 목록 */}
          <div style={{ overflowY: "auto", flex: 1 }}>
            {!notificationList || notificationList.items.length === 0 ? (
              <div
                style={{
                  padding: "40px 16px",
                  textAlign: "center",
                  color: "rgba(255,255,255,0.3)",
                  fontSize: "13px",
                }}
              >
                <Bell
                  size={28}
                  style={{ marginBottom: "8px", opacity: 0.3 }}
                />
                <p style={{ margin: 0 }}>새 알림이 없습니다</p>
              </div>
            ) : (
              notificationList.items.map((n) => (
                <NotificationItem
                  key={n.id}
                  notification={n}
                  onMarkRead={(id) =>
                    markRead(id, {
                      onError: () => toast.error("읽음 처리에 실패했습니다."),
                    })
                  }
                  onDelete={(id) =>
                    deleteNotification(id, {
                      onError: () => toast.error("삭제에 실패했습니다."),
                    })
                  }
                  isMarkingRead={isMarkingRead}
                  isDeleting={isDeleting}
                />
              ))
            )}
          </div>

          {/* 드롭다운 푸터 */}
          <div
            style={{
              padding: "10px 16px",
              borderTop: "1px solid rgba(255,255,255,0.08)",
            }}
          >
            <button
              onClick={() => {
                setIsOpen(false);
                router.push("/notifications");
              }}
              style={{
                width: "100%",
                padding: "8px",
                borderRadius: "8px",
                border: "1px solid rgba(0, 212, 255, 0.2)",
                background: "rgba(0, 212, 255, 0.06)",
                color: "#00d4ff",
                fontSize: "12px",
                fontWeight: 500,
                cursor: "pointer",
                transition: "all 0.15s",
              }}
            >
              알림 센터에서 모두 보기
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
