"use client";

/**
 * 주문 상태 타임라인 컴포넌트 (Sprint 5)
 *
 * 주문 상태 흐름을 수직 타임라인으로 시각화한다.
 *
 * Props:
 *   currentStatus  현재 주문 상태 (OrderStatus 문자열)
 *   orderedAt      결제 완료 시각 (ISO string)
 *   completedAt    작업 완료 시각 (ISO string)
 *
 * 상태 흐름:
 *   pending → confirmed → in_progress → completed
 *                      ↘ cancelled
 *                                   ↘ disputed / refunded
 */
import { CheckCircle, Circle, Clock, XCircle, AlertTriangle } from "lucide-react";
import { cn } from "@/lib/utils";
import { formatDate } from "@/lib/utils";

// ============================
// 상태 정의
// ============================

/** 주문 상태 문자열 */
export type OrderStatusValue =
  | "pending"
  | "confirmed"
  | "in_progress"
  | "completed"
  | "cancelled"
  | "refunded"
  | "disputed";

/** 타임라인 단계 정의 */
interface TimelineStep {
  status: OrderStatusValue;
  label: string;
  description: string;
}

/** 정상 진행 타임라인 단계 */
const NORMAL_STEPS: TimelineStep[] = [
  {
    status: "pending",
    label: "결제 완료",
    description: "주문이 접수되어 담당자 확인을 기다리고 있습니다.",
  },
  {
    status: "confirmed",
    label: "주문 확정",
    description: "담당자가 확인하여 매체사를 배정했습니다.",
  },
  {
    status: "in_progress",
    label: "작업 진행 중",
    description: "매체사에서 마케팅 작업을 진행하고 있습니다.",
  },
  {
    status: "completed",
    label: "작업 완료",
    description: "모든 작업이 완료되었습니다.",
  },
];

/** 비정상 종료 단계 레이블 */
const TERMINAL_LABELS: Record<string, { label: string; description: string }> = {
  cancelled: { label: "주문 취소", description: "주문이 취소되었습니다." },
  refunded:  { label: "환불 완료", description: "결제가 환불 처리되었습니다." },
  disputed:  { label: "분쟁 처리 중", description: "환불 요청이 접수되어 검토 중입니다." },
};

// ============================
// 단계 아이콘 + 색상 계산
// ============================

/** 정상 타임라인 단계의 표시 상태 */
type StepState = "done" | "current" | "upcoming";

/** 정상 진행 시 각 단계의 상태를 계산 */
function getStepState(stepStatus: OrderStatusValue, currentStatus: OrderStatusValue): StepState {
  const ORDER: OrderStatusValue[] = ["pending", "confirmed", "in_progress", "completed"];
  const stepIndex = ORDER.indexOf(stepStatus);
  const currentIndex = ORDER.indexOf(currentStatus);
  if (stepIndex < currentIndex) return "done";
  if (stepIndex === currentIndex) return "current";
  return "upcoming";
}

// ============================
// Props
// ============================

interface OrderStatusTimelineProps {
  currentStatus: OrderStatusValue;
  orderedAt?: string | null;
  completedAt?: string | null;
  /** 타임라인 너비 (기본값: 전체) */
  className?: string;
}

// ============================
// 컴포넌트
// ============================

export default function OrderStatusTimeline({
  currentStatus,
  orderedAt,
  completedAt,
  className,
}: OrderStatusTimelineProps) {
  // ── 비정상 종료 상태 판별 ─────────────────────────────────
  const isTerminal =
    currentStatus === "cancelled" ||
    currentStatus === "refunded" ||
    currentStatus === "disputed";

  // ── 비정상 상태: 축약 타임라인 표시 ─────────────────────────
  if (isTerminal) {
    const terminal = TERMINAL_LABELS[currentStatus];
    return (
      <div className={cn("space-y-0", className)}>
        {/* pending 단계 (항상 완료) */}
        <NormalStep
          label="결제 완료"
          description="주문이 접수되었습니다."
          state="done"
          isLast={false}
        />
        {/* 비정상 종료 단계 */}
        <TerminalStep
          status={currentStatus}
          label={terminal.label}
          description={terminal.description}
        />
      </div>
    );
  }

  // ── 정상 타임라인 표시 ───────────────────────────────────
  return (
    <div className={cn("space-y-0", className)}>
      {NORMAL_STEPS.map((step, idx) => {
        const state = getStepState(step.status, currentStatus);
        const isLast = idx === NORMAL_STEPS.length - 1;

        // completed 단계에 completedAt 시각 부여
        const extraDescription =
          step.status === "completed" && completedAt
            ? `완료 시각: ${formatDate(completedAt)}`
            : step.status === "pending" && orderedAt
            ? `결제 시각: ${formatDate(orderedAt)}`
            : undefined;

        return (
          <NormalStep
            key={step.status}
            label={step.label}
            description={extraDescription ?? step.description}
            state={state}
            isLast={isLast}
          />
        );
      })}
    </div>
  );
}

// ============================
// 내부 — 정상 단계 아이템
// ============================

interface NormalStepProps {
  label: string;
  description: string;
  state: StepState;
  isLast: boolean;
}

function NormalStep({ label, description, state, isLast }: NormalStepProps) {
  return (
    <div className="flex gap-4">
      {/* 왼쪽: 아이콘 + 선 */}
      <div className="flex flex-col items-center">
        {/* 아이콘 */}
        <div
          className={cn(
            "flex items-center justify-center w-8 h-8 rounded-full border-2 shrink-0 z-10",
            state === "done" && "border-green-500 bg-green-500/10",
            state === "current" && "border-blue-400 bg-blue-400/10",
            state === "upcoming" && "border-slate-600 bg-transparent",
          )}
        >
          {state === "done" && (
            <CheckCircle className="w-4 h-4 text-green-400" />
          )}
          {state === "current" && (
            <Clock className="w-4 h-4 text-blue-400 animate-pulse" />
          )}
          {state === "upcoming" && (
            <Circle className="w-4 h-4 text-slate-600" />
          )}
        </div>

        {/* 수직선 (마지막 단계 제외) */}
        {!isLast && (
          <div
            className={cn(
              "w-0.5 flex-1 my-1 min-h-[24px]",
              state === "done" ? "bg-green-500/40" : "bg-slate-700",
            )}
          />
        )}
      </div>

      {/* 오른쪽: 텍스트 */}
      <div className={cn("pb-6", isLast && "pb-0")}>
        <p
          className={cn(
            "text-sm font-semibold mb-0.5",
            state === "done" && "text-green-400",
            state === "current" && "text-blue-300",
            state === "upcoming" && "text-slate-500",
          )}
        >
          {label}
        </p>
        <p className="text-xs text-slate-500 leading-relaxed">{description}</p>
      </div>
    </div>
  );
}

// ============================
// 내부 — 비정상 종료 단계 아이템
// ============================

interface TerminalStepProps {
  status: "cancelled" | "refunded" | "disputed";
  label: string;
  description: string;
}

function TerminalStep({ status, label, description }: TerminalStepProps) {
  const iconColor =
    status === "cancelled"
      ? "text-slate-400"
      : status === "refunded"
      ? "text-yellow-400"
      : "text-orange-400";

  const borderColor =
    status === "cancelled"
      ? "border-slate-500 bg-slate-500/10"
      : status === "refunded"
      ? "border-yellow-500 bg-yellow-500/10"
      : "border-orange-500 bg-orange-500/10";

  const textColor =
    status === "cancelled"
      ? "text-slate-400"
      : status === "refunded"
      ? "text-yellow-400"
      : "text-orange-400";

  return (
    <div className="flex gap-4">
      {/* 아이콘 */}
      <div className="flex flex-col items-center">
        <div
          className={cn(
            "flex items-center justify-center w-8 h-8 rounded-full border-2 shrink-0 z-10",
            borderColor
          )}
        >
          {status === "cancelled" ? (
            <XCircle className={cn("w-4 h-4", iconColor)} />
          ) : (
            <AlertTriangle className={cn("w-4 h-4", iconColor)} />
          )}
        </div>
      </div>
      {/* 텍스트 */}
      <div>
        <p className={cn("text-sm font-semibold mb-0.5", textColor)}>{label}</p>
        <p className="text-xs text-slate-500 leading-relaxed">{description}</p>
      </div>
    </div>
  );
}
