"use client";

/**
 * 환불 요청 모달 컴포넌트 (Sprint 5)
 *
 * shadcn/ui Dialog 기반.
 * - textarea에 환불 사유 입력 (최소 10자 검증)
 * - 정책 안내문 표시
 * - 제출 시 useRefundRequest 뮤테이션 호출
 *
 * Props:
 *   orderId     환불 요청할 주문 ID
 *   open        모달 열림 여부
 *   onClose     모달 닫기 콜백
 *   onSuccess   환불 요청 성공 콜백 (선택)
 */
import { useState } from "react";
import { AlertTriangle, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { useRefundRequest } from "@/hooks/useOrders";
import { getApiErrorMessage } from "@/lib/api";

// ============================
// Props
// ============================

interface RefundModalProps {
  orderId: string;
  open: boolean;
  onClose: () => void;
  onSuccess?: () => void;
}

// ============================
// 컴포넌트
// ============================

export default function RefundModal({
  orderId,
  open,
  onClose,
  onSuccess,
}: RefundModalProps) {
  // 환불 사유 상태
  const [reason, setReason] = useState("");
  // 유효성 에러 메시지
  const [error, setError] = useState<string | null>(null);

  // 환불 요청 뮤테이션
  const refundMutation = useRefundRequest(orderId);

  // 모달 닫기 + 상태 초기화
  function handleClose() {
    setReason("");
    setError(null);
    onClose();
  }

  // 제출 핸들러
  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();

    // 유효성 검사: 최소 10자
    if (reason.trim().length < 10) {
      setError("환불 사유는 최소 10자 이상 입력해주세요.");
      return;
    }
    setError(null);

    try {
      await refundMutation.mutateAsync({ reason: reason.trim() });
      toast.success("환불 요청이 접수되었습니다. 영업일 기준 1~3일 내 처리됩니다.");
      onSuccess?.();
      handleClose();
    } catch (err) {
      toast.error(getApiErrorMessage(err));
    }
  }

  // 모달이 닫혀 있으면 렌더링하지 않음
  if (!open) return null;

  return (
    /* ── 오버레이 ────────────────────────────────────────── */
    <div
      className="fixed inset-0 z-50 flex items-center justify-center"
      style={{ backgroundColor: "rgba(0,0,0,0.7)" }}
      onClick={handleClose}
    >
      {/* ── 다이얼로그 ─────────────────────────────────────── */}
      <div
        className="w-full max-w-md mx-4 rounded-2xl p-6 flex flex-col gap-5"
        style={{
          background: "rgba(30, 35, 50, 0.98)",
          border: "1px solid rgba(255,255,255,0.1)",
          boxShadow: "0 24px 60px rgba(0,0,0,0.7)",
        }}
        onClick={(e) => e.stopPropagation()}   // 버블링 차단
      >
        {/* ── 헤더 ─────────────────────────────────────────── */}
        <div className="flex items-start gap-3">
          <div
            className="flex items-center justify-center w-10 h-10 rounded-xl shrink-0"
            style={{ background: "rgba(251, 146, 60, 0.15)" }}
          >
            <AlertTriangle className="w-5 h-5 text-orange-400" />
          </div>
          <div>
            <h2 className="text-white font-semibold text-base">환불 요청</h2>
            <p className="text-slate-400 text-sm mt-0.5">
              담당자가 검토 후 처리합니다.
            </p>
          </div>
        </div>

        {/* ── 정책 안내문 ──────────────────────────────────── */}
        <div
          className="rounded-xl p-4 text-xs text-slate-400 leading-relaxed space-y-1"
          style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.07)" }}
        >
          <p className="font-medium text-slate-300 mb-2">환불 정책 안내</p>
          <p>• 작업 진행 중 또는 완료 후 7일 이내 신청 가능합니다.</p>
          <p>• 환불 요청 접수 후 영업일 기준 1~3일 이내 처리됩니다.</p>
          <p>• 작업이 50% 이상 진행된 경우 부분 환불이 적용될 수 있습니다.</p>
          <p>• 환불 처리 결과는 가입 이메일로 안내됩니다.</p>
        </div>

        {/* ── 폼 ───────────────────────────────────────────── */}
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* 사유 입력 */}
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">
              환불 사유 <span className="text-red-400">*</span>
            </label>
            <textarea
              value={reason}
              onChange={(e) => {
                setReason(e.target.value);
                if (error) setError(null);
              }}
              placeholder="환불을 요청하는 구체적인 사유를 입력해주세요. (최소 10자)"
              rows={4}
              maxLength={500}
              className={`
                w-full rounded-xl px-4 py-3 text-sm text-white
                bg-white/5 border resize-none outline-none transition
                placeholder:text-slate-600
                focus:ring-1 focus:ring-blue-500
                ${error ? "border-red-500/70" : "border-white/10 focus:border-blue-500/50"}
              `}
            />
            {/* 글자 수 + 에러 */}
            <div className="flex justify-between items-center mt-1.5">
              {error ? (
                <p className="text-xs text-red-400">{error}</p>
              ) : (
                <span />
              )}
              <p className="text-xs text-slate-600 ml-auto">
                {reason.length} / 500
              </p>
            </div>
          </div>

          {/* 버튼 행 */}
          <div className="flex gap-3 pt-1">
            {/* 취소 버튼 */}
            <button
              type="button"
              onClick={handleClose}
              disabled={refundMutation.isPending}
              className="flex-1 py-2.5 rounded-xl text-sm font-medium text-slate-400 transition"
              style={{
                background: "rgba(255,255,255,0.06)",
                border: "1px solid rgba(255,255,255,0.1)",
              }}
            >
              취소
            </button>

            {/* 제출 버튼 */}
            <button
              type="submit"
              disabled={refundMutation.isPending || reason.trim().length < 10}
              className="flex-1 py-2.5 rounded-xl text-sm font-semibold flex items-center justify-center gap-2 transition disabled:opacity-50"
              style={{ background: "rgba(249, 115, 22, 0.85)" }}
            >
              {refundMutation.isPending ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  처리 중...
                </>
              ) : (
                "환불 요청하기"
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
