/**
 * Next.js Edge Middleware — 인증 및 권한 라우팅 (Sprint 2 완성)
 *
 * 동작 규칙:
 * 1. 보호된 라우트(/dashboard/*, /places/*, /orders/*, /account/*, /admin/*)에
 *    미인증 상태로 접근 → /login?redirect=<원래경로> 로 리다이렉트
 * 2. /admin/* 접근 시 role이 admin | superadmin 이 아니면 → /dashboard 리다이렉트
 * 3. 로그인 상태에서 /login, /signup, /forgot-password, /reset-password 접근 → /dashboard 리다이렉트
 *
 * Edge Runtime 호환:
 * - jose 라이브러리로 JWT 검증 (Node.js crypto 미사용)
 * - cookie에서 access_token 읽기 (tokenStorage.setTokens에서 쿠키 동기화)
 */

import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";
import { jwtVerify } from "jose";

// ============================
// 라우트 분류
// ============================

/** 로그인 없이 접근 불가한 보호된 경로 */
const PROTECTED_PATHS = [
  "/dashboard",
  "/places",
  "/orders",
  "/account",
  "/admin",
];

/** 어드민(admin | superadmin)만 접근 가능한 경로 */
const ADMIN_PATHS = ["/admin"];

/** 로그인된 상태에서 접근하면 /dashboard로 보낼 경로 */
const AUTH_ONLY_PATHS = [
  "/login",
  "/signup",
  "/forgot-password",
  "/reset-password",
];

// ============================
// JWT 검증 헬퍼 (Edge Runtime)
// ============================

interface JwtPayload {
  sub?: string;
  role?: string;
  type?: string;
  exp?: number;
}

/**
 * JWT access_token 검증 후 페이로드 반환
 * 검증 실패 시 null 반환 (예외 throw 안 함)
 */
async function verifyToken(token: string): Promise<JwtPayload | null> {
  const secretKey = process.env.SECRET_KEY;

  if (!secretKey) {
    // SECRET_KEY 환경변수 없으면 쿠키만 확인 (개발 환경 fallback)
    // 실제 운영에서는 반드시 설정해야 함
    return decodePayloadUnsafe(token);
  }

  try {
    const key = new TextEncoder().encode(secretKey);
    const { payload } = await jwtVerify(token, key, {
      algorithms: ["HS256"],
    });

    // access 토큰 타입 검증
    if (payload["type"] !== "access") return null;

    return payload as JwtPayload;
  } catch {
    // 만료 / 서명 불일치 / 형식 오류
    return null;
  }
}

/**
 * JWT 서명 검증 없이 페이로드만 디코딩 (개발 환경 fallback)
 * ⚠️ 프로덕션에서는 사용하지 말 것
 */
function decodePayloadUnsafe(token: string): JwtPayload | null {
  try {
    const parts = token.split(".");
    if (parts.length !== 3) return null;

    const base64Url = parts[1];
    const base64 = base64Url.replace(/-/g, "+").replace(/_/g, "/");
    // Edge Runtime에서는 atob 사용 가능
    const jsonString = atob(base64);
    return JSON.parse(jsonString) as JwtPayload;
  } catch {
    return null;
  }
}

// ============================
// 경로 일치 헬퍼
// ============================

function matchesPath(pathname: string, patterns: string[]): boolean {
  return patterns.some(
    (pattern) => pathname === pattern || pathname.startsWith(pattern + "/")
  );
}

// ============================
// 미들웨어 메인 함수
// ============================

export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;

  // 쿠키에서 access_token 읽기 (lib/auth.ts tokenStorage.setTokens에서 동기화)
  const accessToken = request.cookies.get("access_token")?.value ?? null;

  // JWT 검증
  const payload = accessToken ? await verifyToken(accessToken) : null;
  const isAuthenticated = !!payload;
  const userRole = payload?.role ?? null;

  // ============================================================
  // 규칙 1: 로그인 상태에서 인증 전용 페이지 접근 → /dashboard
  // ============================================================
  if (isAuthenticated && matchesPath(pathname, AUTH_ONLY_PATHS)) {
    return NextResponse.redirect(new URL("/dashboard", request.url));
  }

  // ============================================================
  // 규칙 2: 보호된 라우트 미인증 접근 → /login?redirect=<경로>
  // ============================================================
  if (!isAuthenticated && matchesPath(pathname, PROTECTED_PATHS)) {
    const loginUrl = new URL("/login", request.url);
    loginUrl.searchParams.set("redirect", pathname);
    return NextResponse.redirect(loginUrl);
  }

  // ============================================================
  // 규칙 3: /admin/* 어드민 권한 체크 → /dashboard
  // ============================================================
  if (
    isAuthenticated &&
    matchesPath(pathname, ADMIN_PATHS) &&
    userRole !== "admin" &&
    userRole !== "superadmin"
  ) {
    return NextResponse.redirect(new URL("/dashboard", request.url));
  }

  // 통과
  return NextResponse.next();
}

// ============================
// 미들웨어 실행 경로 설정
// ============================
export const config = {
  matcher: [
    /*
     * 아래 경로를 제외한 모든 요청에 미들웨어 적용:
     * - _next/static  (정적 파일)
     * - _next/image   (이미지 최적화)
     * - favicon.ico
     * - /api/*        (Next.js API 라우트 / FastAPI 프록시)
     * - *.{png,jpg,svg,...} (이미지 파일)
     */
    "/((?!_next/static|_next/image|favicon.ico|api/|.*\\.(?:png|jpg|jpeg|gif|svg|ico|webp|woff2?|ttf|eot)).*)",
  ],
};
