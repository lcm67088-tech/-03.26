"use client";

/**
 * 빌링(구독·결제) 관련 TanStack Query 훅 모음 (Sprint 8)
 *
 * useSubscription          현재 구독 조회 (플랜 한도 + 사용량 포함)
 * useBillingHistory        결제 내역 목록 (페이지네이션)
 * useUpgradePlan           플랜 업그레이드 뮤테이션
 * useDowngradePlan         플랜 다운그레이드 뮤테이션
 * useCancelSubscription    구독 취소 뮤테이션
 * usePaymentMethod         결제 수단 조회
 * useUpdatePaymentMethod   결제 수단 등록/변경 뮤테이션
 */

import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import api from "@/lib/api";
import { useAuthStore } from "@/store/authStore";

// ─────────────────────────────────────────────────────────────
// 타입 정의
// ─────────────────────────────────────────────────────────────

/** 구독 정보 */
export interface SubscriptionResponse {
  id: string;
  workspace_id: string;
  plan: string;
  billing_cycle: "monthly" | "yearly";
  status: "active" | "cancelled" | "past_due" | "expired";
  amount: number;
  started_at: string;
  next_billing_at: string | null;
  cancelled_at: string | null;
  created_at: string;
  updated_at: string;
}

/** 플랜 한도 */
export interface PlanLimits {
  max_places: number;
  max_keywords: number;
  crawl_per_day: number;
}

/** 플랜 한도 + 사용량 포함 구독 정보 */
export interface SubscriptionWithLimits extends SubscriptionResponse {
  plan_limits: PlanLimits;
  plan_price_monthly: number;
  plan_price_yearly: number;
  current_places: number;
  current_keywords: number;
}

/** 결제 내역 단건 */
export interface BillingHistoryItem {
  id: string;
  workspace_id: string;
  subscription_id: string | null;
  type: "subscription" | "upgrade" | "downgrade" | "refund";
  plan: string;
  billing_cycle: "monthly" | "yearly";
  amount: number;
  status: "paid" | "failed" | "refunded";
  pg_transaction_id: string | null;
  description: string;
  created_at: string;
}

/** 결제 내역 목록 */
export interface BillingHistoryList {
  items: BillingHistoryItem[];
  total: number;
  page: number;
  limit: number;
}

/** 플랜 변경 요청 */
export interface PlanChangeRequest {
  plan: string;
  billing_cycle: "monthly" | "yearly";
}

/** 플랜 변경 결과 */
export interface PlanChangeResponse {
  subscription: SubscriptionResponse;
  billing_history: BillingHistoryItem;
  message: string;
  deactivated_places: number;
  deactivated_keywords: number;
}

/** 구독 취소 요청 */
export interface CancelSubscriptionRequest {
  reason?: string;
}

/** 구독 취소 결과 */
export interface CancelSubscriptionResponse {
  message: string;
  cancelled_at: string;
  expires_at: string | null;
}

/** 결제 수단 요청 */
export interface PaymentMethodRequest {
  card_number_last4: string;
  card_brand: string;
  exp_month: string;
  exp_year: string;
  pg_customer_id?: string;
}

/** 결제 수단 */
export interface PaymentMethod {
  card_number_last4: string;
  card_brand: string;
  exp_month: string;
  exp_year: string;
  pg_customer_id: string | null;
  display: string;    // 예: "Visa **** 1234 (12/27)"
}

// ─────────────────────────────────────────────────────────────
// Query Keys
// ─────────────────────────────────────────────────────────────

export const billingKeys = {
  all: ["billing"] as const,
  subscription: () => [...billingKeys.all, "subscription"] as const,
  history: (page: number) => [...billingKeys.all, "history", page] as const,
  paymentMethod: () => [...billingKeys.all, "payment-method"] as const,
};

// ─────────────────────────────────────────────────────────────
// useSubscription
// ─────────────────────────────────────────────────────────────

/**
 * 현재 구독 조회 (플랜 한도 + 현재 사용량 포함)
 * staleTime: 5분 (구독 정보는 자주 변경되지 않음)
 */
export function useSubscription() {
  return useQuery<SubscriptionWithLimits>({
    queryKey: billingKeys.subscription(),
    queryFn: async () => {
      const res = await api.get("/billing/subscription");
      return res.data;
    },
    staleTime: 5 * 60 * 1000,   // 5분
    retry: 1,
  });
}

// ─────────────────────────────────────────────────────────────
// useBillingHistory
// ─────────────────────────────────────────────────────────────

/**
 * 결제 내역 목록 조회 (페이지네이션)
 */
export function useBillingHistory(page: number = 1, limit: number = 20) {
  return useQuery<BillingHistoryList>({
    queryKey: billingKeys.history(page),
    queryFn: async () => {
      const res = await api.get("/billing/history", {
        params: { page, limit },
      });
      return res.data;
    },
    staleTime: 2 * 60 * 1000,   // 2분
  });
}

// ─────────────────────────────────────────────────────────────
// useUpgradePlan
// ─────────────────────────────────────────────────────────────

/**
 * 플랜 업그레이드 뮤테이션
 * onSuccess: subscription + history 쿼리 무효화, authStore workspace.plan 업데이트
 */
export function useUpgradePlan() {
  const queryClient = useQueryClient();
  const updateWorkspace = useAuthStore((s) => s.updateWorkspace);
  const workspace = useAuthStore((s) => s.workspace);

  return useMutation<PlanChangeResponse, Error, PlanChangeRequest>({
    mutationFn: async (data) => {
      const res = await api.post("/billing/upgrade", data);
      return res.data;
    },
    onSuccess: (data) => {
      // 구독 + 내역 쿼리 무효화
      queryClient.invalidateQueries({ queryKey: billingKeys.all });
      // authStore workspace.plan 업데이트
      if (workspace) {
        updateWorkspace({ ...workspace, plan: data.subscription.plan as any });
      }
    },
  });
}

// ─────────────────────────────────────────────────────────────
// useDowngradePlan
// ─────────────────────────────────────────────────────────────

/**
 * 플랜 다운그레이드 뮤테이션
 * onSuccess: subscription + history 쿼리 무효화, authStore workspace.plan 업데이트
 */
export function useDowngradePlan() {
  const queryClient = useQueryClient();
  const updateWorkspace = useAuthStore((s) => s.updateWorkspace);
  const workspace = useAuthStore((s) => s.workspace);

  return useMutation<PlanChangeResponse, Error, PlanChangeRequest>({
    mutationFn: async (data) => {
      const res = await api.post("/billing/downgrade", data);
      return res.data;
    },
    onSuccess: (data) => {
      // 구독 + 내역 + 장소/키워드 쿼리 모두 무효화 (다운그레이드로 비활성화 가능)
      queryClient.invalidateQueries({ queryKey: billingKeys.all });
      queryClient.invalidateQueries({ queryKey: ["places"] });
      queryClient.invalidateQueries({ queryKey: ["keywords"] });
      // authStore workspace.plan 업데이트
      if (workspace) {
        updateWorkspace({ ...workspace, plan: data.subscription.plan as any });
      }
    },
  });
}

// ─────────────────────────────────────────────────────────────
// useCancelSubscription
// ─────────────────────────────────────────────────────────────

/**
 * 구독 취소 뮤테이션
 */
export function useCancelSubscription() {
  const queryClient = useQueryClient();

  return useMutation<CancelSubscriptionResponse, Error, CancelSubscriptionRequest>({
    mutationFn: async (data) => {
      const res = await api.post("/billing/cancel", data);
      return res.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: billingKeys.subscription() });
      queryClient.invalidateQueries({ queryKey: billingKeys.history(1) });
    },
  });
}

// ─────────────────────────────────────────────────────────────
// usePaymentMethod
// ─────────────────────────────────────────────────────────────

/**
 * 결제 수단 조회
 */
export function usePaymentMethod() {
  return useQuery<{ payment_method: PaymentMethod | null }>({
    queryKey: billingKeys.paymentMethod(),
    queryFn: async () => {
      const res = await api.get("/billing/payment-method");
      return res.data;
    },
    staleTime: 5 * 60 * 1000,
  });
}

// ─────────────────────────────────────────────────────────────
// useUpdatePaymentMethod
// ─────────────────────────────────────────────────────────────

/**
 * 결제 수단 등록/변경 뮤테이션
 */
export function useUpdatePaymentMethod() {
  const queryClient = useQueryClient();

  return useMutation<
    { message: string; payment_method: PaymentMethod },
    Error,
    PaymentMethodRequest
  >({
    mutationFn: async (data) => {
      const res = await api.post("/billing/payment-method", data);
      return res.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: billingKeys.paymentMethod() });
    },
  });
}

// ─────────────────────────────────────────────────────────────
// 플랜 정보 상수 (프론트엔드용)
// ─────────────────────────────────────────────────────────────

/** 플랜별 가격 (원 단위) */
export const PLAN_PRICES: Record<string, { monthly: number; yearly: number }> = {
  free:       { monthly: 0,      yearly: 0 },
  starter:    { monthly: 29000,  yearly: 23200 },
  pro:        { monthly: 79000,  yearly: 63200 },
  enterprise: { monthly: 199000, yearly: 159200 },
};

/** 플랜 순서 (인덱스 높을수록 상위) */
export const PLAN_ORDER = ["free", "starter", "pro", "enterprise"] as const;

/** 플랜 표시명 */
export const PLAN_LABELS: Record<string, string> = {
  free:       "Free",
  starter:    "Starter",
  pro:        "Pro",
  enterprise: "Enterprise",
};

/** 플랜별 특징 목록 */
export const PLAN_FEATURES: Record<string, string[]> = {
  free:       ["장소 1개", "키워드 5개", "일 1회 크롤링", "기본 대시보드"],
  starter:    ["장소 5개", "키워드 30개", "일 2회 크롤링", "순위 트렌드 차트", "이메일 알림"],
  pro:        ["장소 20개", "키워드 100개", "일 4회 크롤링", "고급 인사이트", "우선 지원", "API 접근"],
  enterprise: ["장소 무제한", "키워드 무제한", "일 4회 크롤링", "전용 매니저", "SLA 보장", "커스텀 연동"],
};

/** 플랜 rank 반환 (높을수록 상위) */
export function getPlanRank(plan: string): number {
  return PLAN_ORDER.indexOf(plan as any);
}

/** 구독 상태 한국어 레이블 */
export const SUBSCRIPTION_STATUS_LABELS: Record<string, string> = {
  active:    "이용 중",
  cancelled: "취소됨",
  past_due:  "연체",
  expired:   "만료",
};

/** 구독 상태 색상 */
export const SUBSCRIPTION_STATUS_COLORS: Record<string, string> = {
  active:    "#22c55e",    // green-500
  cancelled: "#fcd34d",   // yellow-300
  past_due:  "#f87171",   // red-400
  expired:   "#94a3b8",   // slate-400
};

/** 결제 내역 상태 색상 */
export const BILLING_STATUS_COLORS: Record<string, string> = {
  paid:     "#22c55e",
  failed:   "#f87171",
  refunded: "#94a3b8",
};

/** 결제 내역 타입 한국어 */
export const BILLING_TYPE_LABELS: Record<string, string> = {
  subscription: "신규 구독",
  upgrade:      "업그레이드",
  downgrade:    "다운그레이드",
  refund:       "환불",
};
