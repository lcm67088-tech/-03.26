"use client";

/**
 * 어드민 심화 전용 TanStack Query 훅 모음 (Sprint 9)
 *
 * ── 유저 관리 ──────────────────────────────────────────────
 * useAdminUsers            유저 목록 (필터·페이지네이션)
 * useAdminUser             유저 상세
 * usePatchUserRole         유저 역할 변경 (superadmin 전용)
 * usePatchUserStatus       유저 활성/비활성 변경
 * useForceLogout           유저 강제 로그아웃
 *
 * ── 워크스페이스 관리 ─────────────────────────────────────
 * useAdminWorkspaces       워크스페이스 목록
 * useAdminWorkspace        워크스페이스 상세
 * usePatchWorkspacePlan    플랜 강제 변경
 * useDeactivateWorkspace   워크스페이스 비활성화
 *
 * ── 정산 관리 ─────────────────────────────────────────────
 * useAdminSettlements      정산 목록
 * useAdminSettlement       정산 상세
 * useGenerateSettlement    정산 생성
 * useApproveSettlement     정산 승인
 * usePaySettlement         정산 지급 처리
 *
 * ── 통계 ──────────────────────────────────────────────────
 * useStatsOverview         KPI 통계 (5분 자동 갱신)
 * useMonthlyRevenue        월별 매출 통계
 */

import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import api from "@/lib/api";

// ============================================================
// 타입 정의
// ============================================================

// ── 유저 관련 타입 ───────────────────────────────────────────

/** 유저 목록 아이템 */
export interface AdminUserListItem {
  id: string;
  email: string;
  name: string;
  phone?: string | null;
  /** user / admin / superadmin */
  role: string;
  is_active: boolean;
  email_verified: boolean;
  workspace_count: number;
  order_count: number;
  created_at: string;
  updated_at: string;
}

/** 유저 목록 페이지네이션 응답 */
export interface AdminUserListResponse {
  total: number;
  items: AdminUserListItem[];
}

/** 유저 소유 워크스페이스 요약 */
export interface AdminUserWorkspaceSummary {
  id: string;
  name: string;
  plan: string;
  is_active: boolean;
  member_count: number;
  place_count: number;
  created_at: string;
}

/** 유저 최근 주문 요약 */
export interface AdminUserOrderSummary {
  id: string;
  product_name: string;
  status: string;
  total_amount: number;
  workspace_name: string;
  ordered_at?: string | null;
  created_at: string;
}

/** 유저 상세 */
export interface AdminUserDetail {
  id: string;
  email: string;
  name: string;
  phone?: string | null;
  role: string;
  is_active: boolean;
  email_verified: boolean;
  workspaces: AdminUserWorkspaceSummary[];
  recent_orders: AdminUserOrderSummary[];
  workspace_count: number;
  order_count: number;
  created_at: string;
  updated_at: string;
}

/** 역할 변경 요청 */
export interface UserRolePatchBody {
  /** user / admin / superadmin */
  role: string;
  reason?: string;
}

/** 상태 변경 요청 */
export interface UserStatusPatchBody {
  is_active: boolean;
  reason?: string;
}

// ── 워크스페이스 관련 타입 ────────────────────────────────────

/** 워크스페이스 목록 아이템 */
export interface AdminWorkspaceListItem {
  id: string;
  name: string;
  slug: string;
  /** free / starter / pro / enterprise */
  plan: string;
  is_active: boolean;
  owner_id: string;
  owner_email: string;
  owner_name: string;
  member_count: number;
  place_count: number;
  order_count: number;
  monthly_spend: number;
  created_at: string;
  updated_at: string;
}

/** 워크스페이스 목록 페이지네이션 응답 */
export interface AdminWorkspaceListResponse {
  total: number;
  items: AdminWorkspaceListItem[];
}

/** 워크스페이스 멤버 요약 */
export interface AdminWorkspaceMemberSummary {
  id: string;
  user_id: string;
  user_email: string;
  user_name: string;
  role: string;
  joined_at: string;
}

/** 워크스페이스 플레이스 요약 */
export interface AdminWorkspacePlaceSummary {
  id: string;
  name: string;
  alias?: string | null;
  naver_place_id: string;
  category?: string | null;
  is_active: boolean;
  keyword_count: number;
  created_at: string;
}

/** 워크스페이스 빌링 아이템 */
export interface AdminWorkspaceBillingItem {
  id: string;
  type: string;
  plan: string;
  amount: number;
  status: string;
  description?: string | null;
  created_at: string;
}

/** 워크스페이스 상세 */
export interface AdminWorkspaceDetail extends AdminWorkspaceListItem {
  members: AdminWorkspaceMemberSummary[];
  places: AdminWorkspacePlaceSummary[];
  recent_billing: AdminWorkspaceBillingItem[];
}

/** 플랜 변경 요청 */
export interface WorkspacePlanPatchBody {
  /** free / starter / pro / enterprise */
  plan: string;
  reason: string;
  create_billing_record?: boolean;
}

/** 워크스페이스 비활성화 요청 */
export interface WorkspaceDeactivateBody {
  reason: string;
}

// ── 정산 관련 타입 ────────────────────────────────────────────

/** 정산 항목 */
export interface SettlementItem {
  id: string;
  order_id: string;
  amount: number;
  commission_amount: number;
  product_name?: string | null;
  workspace_name?: string | null;
  ordered_at?: string | null;
  created_at: string;
}

/** 정산 목록 아이템 */
export interface SettlementListItem {
  id: string;
  media_company_id: string;
  media_company_name: string;
  /** YYYY-MM */
  month: string;
  /** pending / approved / paid */
  status: string;
  total_orders: number;
  total_amount: number;
  commission_rate: number;
  commission_amount: number;
  approved_at?: string | null;
  paid_at?: string | null;
  created_at: string;
  updated_at: string;
}

/** 정산 목록 페이지네이션 응답 */
export interface SettlementListResponse {
  total: number;
  items: SettlementListItem[];
}

/** 정산 상세 */
export interface SettlementDetail extends SettlementListItem {
  items: SettlementItem[];
}

/** 정산 생성 요청 */
export interface SettlementGenerateBody {
  media_company_id: string;
  /** YYYY-MM */
  month: string;
  commission_rate?: number;
}

/** 정산 승인 요청 */
export interface SettlementApproveBody {
  note?: string;
}

// ── 통계 관련 타입 ────────────────────────────────────────────

/** 플랜별 분포 */
export interface PlanDistributionStat {
  free: number;
  starter: number;
  pro: number;
  enterprise: number;
}

/** KPI 통계 개요 */
export interface StatsOverview {
  today_orders: number;
  today_revenue: number;
  month_new_users: number;
  month_new_workspaces: number;
  mrr: number;
  arr: number;
  total_users: number;
  total_workspaces: number;
  active_workspaces: number;
  total_orders: number;
  pending_orders: number;
  plan_distribution: PlanDistributionStat;
}

/** 월별 매출 통계 아이템 */
export interface MonthlyRevenueStat {
  /** YYYY-MM */
  month: string;
  revenue: number;
  order_count: number;
  new_users: number;
}

/** 월별 매출 통계 응답 */
export interface MonthlyRevenueResponse {
  items: MonthlyRevenueStat[];
}

// ============================================================
// Query Keys
// ============================================================

export const adminAdvancedKeys = {
  // 유저
  users: (filters?: Record<string, unknown>) =>
    ["admin-adv", "users", filters] as const,
  user: (userId: string) =>
    ["admin-adv", "users", userId] as const,
  // 워크스페이스
  workspaces: (filters?: Record<string, unknown>) =>
    ["admin-adv", "workspaces", filters] as const,
  workspace: (workspaceId: string) =>
    ["admin-adv", "workspaces", workspaceId] as const,
  // 정산
  settlements: (filters?: Record<string, unknown>) =>
    ["admin-adv", "settlements", filters] as const,
  settlement: (settlementId: string) =>
    ["admin-adv", "settlements", settlementId] as const,
  // 통계
  statsOverview: () =>
    ["admin-adv", "stats", "overview"] as const,
  monthlyRevenue: (months?: number) =>
    ["admin-adv", "stats", "revenue", months] as const,
};

// ============================================================
// 유저 관리 훅
// ============================================================

/**
 * 어드민 유저 목록 조회
 * @param search 검색어 (이메일/이름)
 * @param role 역할 필터
 * @param isActive 활성화 여부 필터
 * @param skip 오프셋
 * @param limit 페이지 크기
 */
export function useAdminUsers(
  search?: string,
  role?: string,
  isActive?: boolean,
  skip = 0,
  limit = 20,
) {
  const filters = { search, role, isActive, skip, limit };
  return useQuery<AdminUserListResponse>({
    queryKey: adminAdvancedKeys.users(filters),
    queryFn: async () => {
      // 쿼리 파라미터 조합
      const params = new URLSearchParams({
        skip: String(skip),
        limit: String(limit),
      });
      if (search) params.append("search", search);
      if (role) params.append("role", role);
      if (isActive !== undefined) params.append("is_active", String(isActive));

      const { data } = await api.get<AdminUserListResponse>(
        `/admin/users?${params.toString()}`
      );
      return data;
    },
    staleTime: 60 * 1000, // 1분
  });
}

/**
 * 어드민 유저 상세 조회
 */
export function useAdminUser(userId: string) {
  return useQuery<AdminUserDetail>({
    queryKey: adminAdvancedKeys.user(userId),
    queryFn: async () => {
      const { data } = await api.get<AdminUserDetail>(`/admin/users/${userId}`);
      return data;
    },
    enabled: !!userId,
    staleTime: 60 * 1000,
  });
}

/**
 * 유저 역할 변경 (superadmin 전용)
 * 자기 자신 변경 불가 / 서버에서 403 처리
 */
export function usePatchUserRole(userId: string) {
  const queryClient = useQueryClient();
  return useMutation<unknown, Error, UserRolePatchBody>({
    mutationFn: async (body) => {
      const { data } = await api.patch(`/admin/users/${userId}/role`, body);
      return data;
    },
    onSuccess: () => {
      // 해당 유저 상세 + 목록 캐시 무효화
      queryClient.invalidateQueries({ queryKey: adminAdvancedKeys.user(userId) });
      queryClient.invalidateQueries({ queryKey: ["admin-adv", "users"] });
    },
  });
}

/**
 * 유저 활성/비활성 변경
 */
export function usePatchUserStatus(userId: string) {
  const queryClient = useQueryClient();
  return useMutation<unknown, Error, UserStatusPatchBody>({
    mutationFn: async (body) => {
      const { data } = await api.patch(`/admin/users/${userId}/status`, body);
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: adminAdvancedKeys.user(userId) });
      queryClient.invalidateQueries({ queryKey: ["admin-adv", "users"] });
    },
  });
}

/**
 * 유저 강제 로그아웃
 */
export function useForceLogout(userId: string) {
  const queryClient = useQueryClient();
  return useMutation<unknown, Error, void>({
    mutationFn: async () => {
      const { data } = await api.post(`/admin/users/${userId}/force-logout`);
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: adminAdvancedKeys.user(userId) });
    },
  });
}

// ============================================================
// 워크스페이스 관리 훅
// ============================================================

/**
 * 어드민 워크스페이스 목록 조회
 */
export function useAdminWorkspaces(
  search?: string,
  plan?: string,
  isActive?: boolean,
  skip = 0,
  limit = 20,
) {
  const filters = { search, plan, isActive, skip, limit };
  return useQuery<AdminWorkspaceListResponse>({
    queryKey: adminAdvancedKeys.workspaces(filters),
    queryFn: async () => {
      const params = new URLSearchParams({
        skip: String(skip),
        limit: String(limit),
      });
      if (search) params.append("search", search);
      if (plan) params.append("plan", plan);
      if (isActive !== undefined) params.append("is_active", String(isActive));

      const { data } = await api.get<AdminWorkspaceListResponse>(
        `/admin/workspaces?${params.toString()}`
      );
      return data;
    },
    staleTime: 60 * 1000,
  });
}

/**
 * 어드민 워크스페이스 상세 조회
 */
export function useAdminWorkspace(workspaceId: string) {
  return useQuery<AdminWorkspaceDetail>({
    queryKey: adminAdvancedKeys.workspace(workspaceId),
    queryFn: async () => {
      const { data } = await api.get<AdminWorkspaceDetail>(
        `/admin/workspaces/${workspaceId}`
      );
      return data;
    },
    enabled: !!workspaceId,
    staleTime: 60 * 1000,
  });
}

/**
 * 워크스페이스 플랜 강제 변경
 */
export function usePatchWorkspacePlan(workspaceId: string) {
  const queryClient = useQueryClient();
  return useMutation<unknown, Error, WorkspacePlanPatchBody>({
    mutationFn: async (body) => {
      const { data } = await api.patch(
        `/admin/workspaces/${workspaceId}/plan`,
        body
      );
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: adminAdvancedKeys.workspace(workspaceId),
      });
      queryClient.invalidateQueries({ queryKey: ["admin-adv", "workspaces"] });
      // 통계도 갱신
      queryClient.invalidateQueries({ queryKey: adminAdvancedKeys.statsOverview() });
    },
  });
}

/**
 * 워크스페이스 비활성화 (소프트 삭제)
 */
export function useDeactivateWorkspace(workspaceId: string) {
  const queryClient = useQueryClient();
  return useMutation<unknown, Error, WorkspaceDeactivateBody>({
    mutationFn: async (body) => {
      const { data } = await api.post(
        `/admin/workspaces/${workspaceId}/deactivate`,
        body
      );
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: adminAdvancedKeys.workspace(workspaceId),
      });
      queryClient.invalidateQueries({ queryKey: ["admin-adv", "workspaces"] });
      queryClient.invalidateQueries({ queryKey: adminAdvancedKeys.statsOverview() });
    },
  });
}

// ============================================================
// 정산 관리 훅
// ============================================================

/**
 * 정산 목록 조회
 */
export function useAdminSettlements(
  month?: string,
  mediaCompanyId?: string,
  settlementStatus?: string,
  skip = 0,
  limit = 20,
) {
  const filters = { month, mediaCompanyId, settlementStatus, skip, limit };
  return useQuery<SettlementListResponse>({
    queryKey: adminAdvancedKeys.settlements(filters),
    queryFn: async () => {
      const params = new URLSearchParams({
        skip: String(skip),
        limit: String(limit),
      });
      if (month) params.append("month", month);
      if (mediaCompanyId) params.append("media_company_id", mediaCompanyId);
      if (settlementStatus) params.append("status", settlementStatus);

      const { data } = await api.get<SettlementListResponse>(
        `/admin/settlements?${params.toString()}`
      );
      return data;
    },
    staleTime: 60 * 1000,
  });
}

/**
 * 정산 상세 조회
 */
export function useAdminSettlement(settlementId: string) {
  return useQuery<SettlementDetail>({
    queryKey: adminAdvancedKeys.settlement(settlementId),
    queryFn: async () => {
      const { data } = await api.get<SettlementDetail>(
        `/admin/settlements/${settlementId}`
      );
      return data;
    },
    enabled: !!settlementId,
    staleTime: 60 * 1000,
  });
}

/**
 * 정산 생성 (미디어사 + 월 기준 완료 주문 집계)
 */
export function useGenerateSettlement() {
  const queryClient = useQueryClient();
  return useMutation<SettlementDetail, Error, SettlementGenerateBody>({
    mutationFn: async (body) => {
      const { data } = await api.post<SettlementDetail>(
        "/admin/settlements/generate",
        body
      );
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-adv", "settlements"] });
    },
  });
}

/**
 * 정산 승인 (pending → approved)
 */
export function useApproveSettlement(settlementId: string) {
  const queryClient = useQueryClient();
  return useMutation<unknown, Error, SettlementApproveBody>({
    mutationFn: async (body) => {
      const { data } = await api.post(
        `/admin/settlements/${settlementId}/approve`,
        body
      );
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: adminAdvancedKeys.settlement(settlementId),
      });
      queryClient.invalidateQueries({ queryKey: ["admin-adv", "settlements"] });
    },
  });
}

/**
 * 정산 지급 처리 (approved → paid)
 */
export function usePaySettlement(settlementId: string) {
  const queryClient = useQueryClient();
  return useMutation<unknown, Error, void>({
    mutationFn: async () => {
      const { data } = await api.post(
        `/admin/settlements/${settlementId}/pay`
      );
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: adminAdvancedKeys.settlement(settlementId),
      });
      queryClient.invalidateQueries({ queryKey: ["admin-adv", "settlements"] });
    },
  });
}

// ============================================================
// 통계 훅
// ============================================================

/**
 * KPI 통계 개요 조회
 * 5분 자동 갱신
 */
export function useStatsOverview() {
  return useQuery<StatsOverview>({
    queryKey: adminAdvancedKeys.statsOverview(),
    queryFn: async () => {
      const { data } = await api.get<StatsOverview>("/admin/stats/overview");
      return data;
    },
    staleTime: 5 * 60 * 1000,      // 5분 캐시
    refetchInterval: 5 * 60 * 1000, // 5분 자동 갱신
  });
}

/**
 * 월별 매출 통계 조회
 * @param months 조회할 개월 수 (기본 6)
 */
export function useMonthlyRevenue(months = 6) {
  return useQuery<MonthlyRevenueResponse>({
    queryKey: adminAdvancedKeys.monthlyRevenue(months),
    queryFn: async () => {
      const { data } = await api.get<MonthlyRevenueResponse>(
        `/admin/stats/revenue?months=${months}`
      );
      return data;
    },
    staleTime: 5 * 60 * 1000,
  });
}
