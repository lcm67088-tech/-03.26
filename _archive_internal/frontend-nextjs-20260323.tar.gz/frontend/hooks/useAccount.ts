/**
 * 계정 관련 React Query 훅 모음
 * Sprint 7: 계정 프로필, 비밀번호, 워크스페이스 관리
 *
 * API 엔드포인트:
 *   GET  /api/v1/account/profile     - 프로필 조회
 *   PUT  /api/v1/account/profile     - 프로필 수정
 *   PUT  /api/v1/account/password    - 비밀번호 변경
 *   GET  /api/v1/account/workspaces  - 소속 워크스페이스 목록
 *   POST /api/v1/account/workspaces  - 새 워크스페이스 생성
 *
 * 워크스페이스 멤버 API:
 *   GET    /api/v1/workspaces/{id}/members                   - 멤버 목록
 *   POST   /api/v1/workspaces/{id}/members/invite            - 멤버 초대
 *   PUT    /api/v1/workspaces/{id}/members/{user_id}         - 역할 변경
 *   DELETE /api/v1/workspaces/{id}/members/{user_id}         - 멤버 제거
 *   POST   /api/v1/workspaces/{id}/members/transfer-ownership - 소유권 이전
 */

import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import api from "@/lib/api";

// ─────────────────────────────────────────────────────────────
// 타입 정의
// ─────────────────────────────────────────────────────────────

/** 계정 프로필 응답 타입 */
export interface ProfileResponse {
  id: string;
  email: string;
  name: string;
  phone: string | null;
  profile_image_url: string | null;
  role: string;
  created_at: string;
  current_workspace_id: string | null;
}

/** 프로필 수정 요청 타입 */
export interface ProfileUpdateRequest {
  name?: string;
  phone?: string;
  profile_image_url?: string;
}

/** 비밀번호 변경 요청 타입 */
export interface PasswordChangeRequest {
  current_password: string;
  new_password: string;
  confirm_password: string;
}

/** 워크스페이스 목록 항목 타입 */
export interface WorkspaceListItem {
  id: string;
  name: string;
  plan: string;
  role: string;
  member_count: number;
  place_count: number;
}

/** 워크스페이스 생성 요청 타입 */
export interface WorkspaceCreateRequest {
  name: string;
}

/** 워크스페이스 멤버 타입 */
export interface WorkspaceMember {
  id: string;
  name: string;
  email: string;
  role: string;
  joined_at: string;
  is_current_user: boolean;
}

/** 멤버 초대 요청 타입 */
export interface InviteMemberRequest {
  email: string;
  role: string;
}

/** 역할 변경 요청 타입 */
export interface UpdateMemberRoleRequest {
  role: string;
}

// ─────────────────────────────────────────────────────────────
// 쿼리 키 정의
// ─────────────────────────────────────────────────────────────
export const accountKeys = {
  all: ["account"] as const,
  profile: () => [...accountKeys.all, "profile"] as const,
  workspaces: () => [...accountKeys.all, "workspaces"] as const,
  members: (workspaceId: string) =>
    ["workspace-members", workspaceId] as const,
};

// ─────────────────────────────────────────────────────────────
// 훅: 프로필 조회
// ─────────────────────────────────────────────────────────────

/**
 * 현재 로그인 사용자의 프로필을 조회합니다.
 */
export function useProfile() {
  return useQuery<ProfileResponse>({
    queryKey: accountKeys.profile(),
    queryFn: async () => {
      const { data } = await api.get("/api/v1/account/profile");
      return data;
    },
    staleTime: 5 * 60 * 1000, // 5분 캐시
  });
}

// ─────────────────────────────────────────────────────────────
// 훅: 프로필 수정
// ─────────────────────────────────────────────────────────────

/**
 * 프로필(이름/전화번호/이미지)을 수정합니다.
 * 이메일은 수정 불가.
 */
export function useUpdateProfile() {
  const queryClient = useQueryClient();

  return useMutation<ProfileResponse, Error, ProfileUpdateRequest>({
    mutationFn: async (body) => {
      const { data } = await api.put("/api/v1/account/profile", body);
      return data;
    },
    onSuccess: () => {
      // 프로필 캐시 무효화
      queryClient.invalidateQueries({ queryKey: accountKeys.profile() });
    },
  });
}

// ─────────────────────────────────────────────────────────────
// 훅: 비밀번호 변경
// ─────────────────────────────────────────────────────────────

/**
 * 비밀번호를 변경합니다.
 * 현재 비밀번호 검증 후 bcrypt 해싱으로 저장.
 */
export function useChangePassword() {
  return useMutation<{ message: string }, Error, PasswordChangeRequest>({
    mutationFn: async (body) => {
      const { data } = await api.put("/api/v1/account/password", body);
      return data;
    },
  });
}

// ─────────────────────────────────────────────────────────────
// 훅: 소속 워크스페이스 목록
// ─────────────────────────────────────────────────────────────

/**
 * 현재 사용자가 속한 모든 워크스페이스 목록을 조회합니다.
 * role, member_count, place_count 포함.
 */
export function useMyWorkspaces() {
  return useQuery<WorkspaceListItem[]>({
    queryKey: accountKeys.workspaces(),
    queryFn: async () => {
      const { data } = await api.get("/api/v1/account/workspaces");
      return data;
    },
    staleTime: 2 * 60 * 1000, // 2분 캐시
  });
}

// ─────────────────────────────────────────────────────────────
// 훅: 새 워크스페이스 생성
// ─────────────────────────────────────────────────────────────

/**
 * 새 워크스페이스를 생성합니다.
 * 최대 5개 초과 시 403 에러.
 */
export function useCreateWorkspace() {
  const queryClient = useQueryClient();

  return useMutation<WorkspaceListItem, Error, WorkspaceCreateRequest>({
    mutationFn: async (body) => {
      const { data } = await api.post("/api/v1/account/workspaces", body);
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: accountKeys.workspaces() });
    },
  });
}

// ─────────────────────────────────────────────────────────────
// 훅: 워크스페이스 멤버 목록
// ─────────────────────────────────────────────────────────────

/**
 * 워크스페이스 멤버 목록을 조회합니다.
 * 해당 워크스페이스 멤버가 아니면 403.
 */
export function useWorkspaceMembers(workspaceId: string) {
  return useQuery<WorkspaceMember[]>({
    queryKey: accountKeys.members(workspaceId),
    queryFn: async () => {
      const { data } = await api.get(
        `/api/v1/workspaces/${workspaceId}/members`
      );
      return data;
    },
    enabled: !!workspaceId,
    staleTime: 2 * 60 * 1000,
  });
}

// ─────────────────────────────────────────────────────────────
// 훅: 멤버 초대
// ─────────────────────────────────────────────────────────────

/**
 * 워크스페이스에 새 멤버를 초대합니다.
 * owner/manager만 가능. 미가입 이메일은 Mock 처리.
 */
export function useInviteMember(workspaceId: string) {
  const queryClient = useQueryClient();

  return useMutation<
    { message: string; status: string },
    Error,
    InviteMemberRequest
  >({
    mutationFn: async (body) => {
      const { data } = await api.post(
        `/api/v1/workspaces/${workspaceId}/members/invite`,
        body
      );
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: accountKeys.members(workspaceId),
      });
    },
  });
}

// ─────────────────────────────────────────────────────────────
// 훅: 멤버 역할 변경
// ─────────────────────────────────────────────────────────────

/**
 * 워크스페이스 멤버의 역할을 변경합니다.
 * owner만 가능. owner 역할로는 변경 불가.
 */
export function useUpdateMemberRole(workspaceId: string) {
  const queryClient = useQueryClient();

  return useMutation<
    WorkspaceMember,
    Error,
    { userId: string; role: string }
  >({
    mutationFn: async ({ userId, role }) => {
      const { data } = await api.put(
        `/api/v1/workspaces/${workspaceId}/members/${userId}`,
        { role }
      );
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: accountKeys.members(workspaceId),
      });
    },
  });
}

// ─────────────────────────────────────────────────────────────
// 훅: 멤버 제거
// ─────────────────────────────────────────────────────────────

/**
 * 워크스페이스에서 멤버를 제거합니다.
 * owner만 가능. 본인/마지막 멤버 제거 불가.
 */
export function useRemoveMember(workspaceId: string) {
  const queryClient = useQueryClient();

  return useMutation<void, Error, string>({
    mutationFn: async (userId: string) => {
      await api.delete(
        `/api/v1/workspaces/${workspaceId}/members/${userId}`
      );
    },
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: accountKeys.members(workspaceId),
      });
    },
  });
}

// ─────────────────────────────────────────────────────────────
// 훅: 소유권 이전
// ─────────────────────────────────────────────────────────────

/**
 * 워크스페이스 소유권을 다른 멤버에게 이전합니다.
 * 현재 owner만 가능.
 */
export function useTransferOwnership(workspaceId: string) {
  const queryClient = useQueryClient();

  return useMutation<
    { message: string; new_owner_id: string },
    Error,
    { new_owner_id: string }
  >({
    mutationFn: async (body) => {
      const { data } = await api.post(
        `/api/v1/workspaces/${workspaceId}/members/transfer-ownership`,
        body
      );
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: accountKeys.members(workspaceId),
      });
    },
  });
}

// ─────────────────────────────────────────────────────────────
// 유틸: role 한국어 레이블
// ─────────────────────────────────────────────────────────────

export const ROLE_LABELS: Record<string, string> = {
  owner: "소유자",
  manager: "관리자",
  member: "멤버",
  viewer: "뷰어",
};

/** role별 색상 */
export const ROLE_COLORS: Record<string, string> = {
  owner: "#fcd34d",
  manager: "#00d4ff",
  member: "#a3a3a3",
  viewer: "#737373",
};
