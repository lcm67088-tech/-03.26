"use client";

/**
 * 장소 관련 TanStack Query 훅 모음 (Sprint 3)
 *
 * usePlaces          장소 목록 조회
 * usePlace           장소 상세 조회
 * useDashboardSummary 대시보드 요약 데이터
 * useCreatePlace     장소 등록 뮤테이션
 * useUpdatePlace     장소 수정 뮤테이션
 * useDeletePlace     장소 삭제 뮤테이션
 */
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import api from "@/lib/api";

// ============================
// 타입 정의
// ============================

export interface KeywordSummary {
  id: string;
  keyword: string;
  is_primary: boolean;
  is_active: boolean;
  group_name?: string | null;
  latest_rank?: number | null;
  case_type?: string | null;       // normal | popular | not_ranked
  rank_change?: number | null;     // 어제 대비 변화 (양수=상승, 음수=하락)
}

export interface PlaceListItem {
  id: string;
  naver_place_id: string;
  naver_place_url: string;
  name: string;
  alias?: string | null;
  category?: string | null;
  is_active: boolean;
  keyword_count: number;
  latest_rankings: KeywordSummary[];
  created_at: string;
}

export interface PlaceDetail extends PlaceListItem {
  address?: string | null;
  keywords: KeywordSummary[];
  recent_orders: {
    id: string;
    product_name: string;
    status: string;
    total_amount: number;
    ordered_at?: string | null;
  }[];
  updated_at: string;
}

export interface PlaceListResponse {
  total: number;
  items: PlaceListItem[];
}

export interface PlaceCreate {
  workspace_id: string;
  naver_place_url: string;
  alias?: string;
}

export interface PlaceUpdate {
  alias?: string;
  is_active?: boolean;
}

// 대시보드 요약 타입
export interface RankSummaryKeyword {
  keyword: string;
  rank?: number | null;
  case_type?: string | null;
  rank_change?: number | null;
}

export interface PlaceRankSummary {
  place_id: string;
  place_name: string;
  alias?: string | null;
  keywords: RankSummaryKeyword[];
}

export interface RecentOrderItem {
  id: string;
  product_name: string;
  status: string;
  total_amount: number;
  ordered_at?: string | null;
}

export interface DashboardSummary {
  total_places: number;
  total_keywords: number;
  this_month_orders: number;
  this_month_revenue: number;
  avg_rank?: number | null;
  rank_summary: PlaceRankSummary[];
  recent_orders: RecentOrderItem[];
}

// ============================
// Query Keys
// ============================

export const placeKeys = {
  all: ["places"] as const,
  list: (workspaceId: string) => ["places", "list", workspaceId] as const,
  detail: (placeId: string) => ["places", "detail", placeId] as const,
  dashboard: (workspaceId: string) => ["places", "dashboard", workspaceId] as const,
};

// ============================
// 장소 목록 조회
// ============================

export function usePlaces(workspaceId: string) {
  return useQuery<PlaceListResponse>({
    queryKey: placeKeys.list(workspaceId),
    queryFn: async () => {
      const { data } = await api.get<PlaceListResponse>(
        `/places?workspace_id=${workspaceId}`
      );
      return data;
    },
    enabled: !!workspaceId,
    staleTime: 5 * 60 * 1000, // 5분
  });
}

// ============================
// 장소 상세 조회
// ============================

export function usePlace(placeId: string) {
  return useQuery<PlaceDetail>({
    queryKey: placeKeys.detail(placeId),
    queryFn: async () => {
      const { data } = await api.get<PlaceDetail>(`/places/${placeId}`);
      return data;
    },
    enabled: !!placeId,
    staleTime: 3 * 60 * 1000, // 3분
  });
}

// ============================
// 대시보드 요약 조회
// ============================

export function useDashboardSummary(workspaceId: string) {
  return useQuery<DashboardSummary>({
    queryKey: placeKeys.dashboard(workspaceId),
    queryFn: async () => {
      const { data } = await api.get<DashboardSummary>(
        `/places/dashboard-summary?workspace_id=${workspaceId}`
      );
      return data;
    },
    enabled: !!workspaceId,
    staleTime: 5 * 60 * 1000,        // 5분
    refetchInterval: 10 * 60 * 1000, // 10분마다 자동 갱신
  });
}

// ============================
// 장소 등록 뮤테이션
// ============================

export function useCreatePlace() {
  const queryClient = useQueryClient();

  return useMutation<PlaceDetail, Error, PlaceCreate>({
    mutationFn: async (body) => {
      const { data } = await api.post<PlaceDetail>("/places", body);
      return data;
    },
    onSuccess: (_, variables) => {
      // 장소 목록 쿼리 무효화 → 자동 재조회
      queryClient.invalidateQueries({
        queryKey: placeKeys.list(variables.workspace_id),
      });
      // 대시보드도 갱신
      queryClient.invalidateQueries({
        queryKey: placeKeys.dashboard(variables.workspace_id),
      });
    },
  });
}

// ============================
// 장소 수정 뮤테이션
// ============================

export function useUpdatePlace(placeId: string) {
  const queryClient = useQueryClient();

  return useMutation<PlaceDetail, Error, PlaceUpdate>({
    mutationFn: async (body) => {
      const { data } = await api.put<PlaceDetail>(`/places/${placeId}`, body);
      return data;
    },
    onSuccess: (updatedPlace) => {
      // 상세 캐시 갱신
      queryClient.setQueryData(placeKeys.detail(placeId), updatedPlace);
      // 목록 쿼리 무효화
      queryClient.invalidateQueries({ queryKey: placeKeys.all });
    },
  });
}

// ============================
// 장소 삭제 뮤테이션
// ============================

export function useDeletePlace() {
  const queryClient = useQueryClient();

  return useMutation<void, Error, { placeId: string; workspaceId: string }>({
    mutationFn: async ({ placeId }) => {
      await api.delete(`/places/${placeId}`);
    },
    onSuccess: (_, { workspaceId }) => {
      // 전체 장소 캐시 무효화
      queryClient.invalidateQueries({ queryKey: placeKeys.all });
      // 대시보드도 갱신
      queryClient.invalidateQueries({
        queryKey: placeKeys.dashboard(workspaceId),
      });
    },
  });
}
