"use client";

/**
 * 어드민 전용 TanStack Query 훅 모음 (Sprint 6)
 *
 * useAdminDashboard        어드민 대시보드 데이터 (5분 자동 갱신)
 * useAdminOrders           전체 주문 목록 (필터·페이지네이션)
 * useAdminOrder            주문 상세 (어드민 뷰)
 * useUpdateOrderStatus     주문 상태 변경
 * useAssignMediaCompany    미디어사 배정
 * useCompleteOrderAdmin    주문 완료 처리 (증빙 URL)
 * useRefundDecision        환불 결정 (승인/거부)
 * useMediaCompanies        미디어사 목록 (통계 포함)
 * useMediaCompany          미디어사 상세 (최근 주문 포함)
 * useCreateMediaCompany    미디어사 등록
 * useUpdateMediaCompany    미디어사 수정
 * useDeleteMediaCompany    미디어사 소프트 삭제
 */
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import api from "@/lib/api";

// ============================
// 타입 정의
// ============================

/** 플랜별 워크스페이스 분포 */
export interface PlanDistribution {
  free: number;
  starter: number;
  pro: number;
  enterprise: number;
}

/** 대시보드 응답 */
export interface AdminDashboardData {
  today_orders: number;
  today_revenue: number;
  pending_orders: number;
  this_month_revenue: number;
  total_workspaces: number;
  active_workspaces: number;
  plan_distribution: PlanDistribution;
  recent_orders: {
    id: string;
    product_name: string;
    status: string;
    total_amount: number;
    ordered_at: string | null;
    workspace_id: string;
    workspace_name: string;
  }[];
}

/** 어드민 주문 목록 아이템 */
export interface AdminOrderListItem {
  id: string;
  product_name: string;
  status: string;
  total_amount: number;
  quantity: number;
  workspace_id: string;
  workspace_name: string;
  workspace_plan: string;
  place_name?: string | null;
  media_company_id?: string | null;
  media_company_name?: string | null;
  ordered_at?: string | null;
  updated_at: string;
  created_at: string;
}

/** 어드민 주문 목록 응답 */
export interface AdminOrderListResponse {
  total: number;
  items: AdminOrderListItem[];
}

/** 결제 정보 (어드민용) */
export interface AdminPaymentInfo {
  id: string;
  amount: number;
  method?: string | null;
  status: string;
  pg_transaction_id?: string | null;
  paid_at?: string | null;
  created_at: string;
}

/** 어드민 주문 상세 */
export interface AdminOrderDetail {
  id: string;
  product_id?: string | null;
  product_name: string;
  description?: string | null;
  status: string;
  quantity: number;
  unit_price: number;
  total_amount: number;
  special_requests?: string | null;
  proof_url?: string | null;
  workspace?: { id: string; name: string; plan: string } | null;
  place?: { id: string; name: string; alias?: string | null; naver_place_id: string } | null;
  keywords: { id: string; keyword: string }[];
  payment?: AdminPaymentInfo | null;
  media_company?: { id: string; name: string } | null;
  admin_notes: { timestamp: string; note: string; admin_id: string }[];
  ordered_at?: string | null;
  completed_at?: string | null;
  created_at: string;
  updated_at: string;
}

/** 미디어사 목록 아이템 */
export interface MediaCompanyResponse {
  id: string;
  name: string;
  contact_email?: string | null;
  contact_phone?: string | null;
  bank_account?: string | null;
  is_active: boolean;
  order_count: number;
  completed_count: number;
  avg_completion_days?: number | null;
}

/** 미디어사 최근 주문 */
export interface RecentOrderForMedia {
  id: string;
  product_name: string;
  status: string;
  total_amount: number;
  workspace_name: string;
  ordered_at?: string | null;
  completed_at?: string | null;
}

/** 미디어사 상세 */
export interface MediaCompanyDetail extends MediaCompanyResponse {
  recent_orders: RecentOrderForMedia[];
}

// ============================
// 요청 Body 타입
// ============================

export interface OrderStatusUpdateBody {
  status: string;
  note?: string;
}

export interface AssignMediaCompanyBody {
  media_company_id: string;
}

export interface CompleteOrderBody {
  proof_url: string;
}

export interface RefundDecisionBody {
  approve: boolean;
  note: string;
}

export interface MediaCompanyCreateBody {
  name: string;
  contact_email?: string;
  contact_phone?: string;
  bank_account?: string;
}

export interface MediaCompanyUpdateBody {
  name?: string;
  contact_email?: string | null;
  contact_phone?: string | null;
  bank_account?: string | null;
  is_active?: boolean;
}

// ============================
// Query Keys
// ============================

export const adminKeys = {
  all: ["admin"] as const,
  /** 대시보드 */
  dashboard: () => ["admin", "dashboard"] as const,
  /** 주문 목록 (필터 포함) */
  orders: (filters?: Record<string, unknown>) =>
    ["admin", "orders", filters] as const,
  /** 주문 상세 */
  order: (orderId: string) => ["admin", "orders", orderId] as const,
  /** 미디어사 목록 */
  mediaCompanies: (includeInactive?: boolean) =>
    ["admin", "media-companies", { includeInactive }] as const,
  /** 미디어사 상세 */
  mediaCompany: (id: string) => ["admin", "media-companies", id] as const,
};

// ============================
// 어드민 대시보드
// ============================

/**
 * 어드민 대시보드 데이터 조회
 * 5분 간격으로 자동 재조회
 */
export function useAdminDashboard() {
  return useQuery<AdminDashboardData>({
    queryKey: adminKeys.dashboard(),
    queryFn: async () => {
      const { data } = await api.get<AdminDashboardData>("/admin/dashboard");
      return data;
    },
    staleTime: 5 * 60 * 1000,      // 5분 캐시
    refetchInterval: 5 * 60 * 1000, // 5분 자동 갱신
  });
}

// ============================
// 주문 목록 (어드민)
// ============================

/**
 * 어드민 전체 주문 목록
 * @param statusFilter    상태 필터 (null=전체)
 * @param workspaceId     워크스페이스 필터
 * @param mediaCompanyId  미디어사 필터
 * @param skip            오프셋
 * @param limit           페이지 크기
 */
export function useAdminOrders(
  statusFilter: string | null = null,
  workspaceId: string | null = null,
  mediaCompanyId: string | null = null,
  skip = 0,
  limit = 20,
) {
  const filters = { statusFilter, workspaceId, mediaCompanyId, skip, limit };

  return useQuery<AdminOrderListResponse>({
    queryKey: adminKeys.orders(filters),
    queryFn: async () => {
      const params = new URLSearchParams({
        skip: String(skip),
        limit: String(limit),
      });
      if (statusFilter) params.append("status", statusFilter);
      if (workspaceId) params.append("workspace_id", workspaceId);
      if (mediaCompanyId) params.append("media_company_id", mediaCompanyId);

      const { data } = await api.get<AdminOrderListResponse>(
        `/admin/orders?${params.toString()}`
      );
      return data;
    },
    staleTime: 60 * 1000, // 1분
  });
}

// ============================
// 주문 상세 (어드민)
// ============================

/**
 * 어드민 주문 상세 조회
 */
export function useAdminOrder(orderId: string) {
  return useQuery<AdminOrderDetail>({
    queryKey: adminKeys.order(orderId),
    queryFn: async () => {
      const { data } = await api.get<AdminOrderDetail>(
        `/admin/orders/${orderId}`
      );
      return data;
    },
    enabled: !!orderId,
    staleTime: 60 * 1000,
  });
}

// ============================
// 주문 상태 변경
// ============================

/**
 * 주문 상태 변경 뮤테이션
 * 허용 전이: confirmed→in_progress, in_progress→completed, 등
 */
export function useUpdateOrderStatus(orderId: string) {
  const queryClient = useQueryClient();

  return useMutation<
    { order_id: string; status: string; message: string },
    Error,
    OrderStatusUpdateBody
  >({
    mutationFn: async (body) => {
      const { data } = await api.patch(
        `/admin/orders/${orderId}/status`,
        body
      );
      return data;
    },
    onSuccess: () => {
      // 해당 주문 상세 캐시 무효화
      queryClient.invalidateQueries({ queryKey: adminKeys.order(orderId) });
      // 주문 목록 전체 무효화
      queryClient.invalidateQueries({ queryKey: ["admin", "orders"] });
    },
  });
}

// ============================
// 미디어사 배정
// ============================

/**
 * 미디어사 배정 뮤테이션
 * confirmed 상태이면 in_progress로 자동 전환
 */
export function useAssignMediaCompany(orderId: string) {
  const queryClient = useQueryClient();

  return useMutation<
    { order_id: string; media_company_id: string; media_company_name: string; status: string },
    Error,
    AssignMediaCompanyBody
  >({
    mutationFn: async (body) => {
      const { data } = await api.post(
        `/admin/orders/${orderId}/assign`,
        body
      );
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: adminKeys.order(orderId) });
      queryClient.invalidateQueries({ queryKey: ["admin", "orders"] });
    },
  });
}

// ============================
// 주문 완료 처리 (어드민)
// ============================

/**
 * 주문 완료 처리 뮤테이션 (증빙 URL 저장)
 */
export function useCompleteOrderAdmin(orderId: string) {
  const queryClient = useQueryClient();

  return useMutation<
    { order_id: string; status: string; proof_url: string; completed_at: string },
    Error,
    CompleteOrderBody
  >({
    mutationFn: async (body) => {
      const { data } = await api.post(
        `/admin/orders/${orderId}/complete`,
        body
      );
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: adminKeys.order(orderId) });
      queryClient.invalidateQueries({ queryKey: ["admin", "orders"] });
      queryClient.invalidateQueries({ queryKey: adminKeys.dashboard() });
    },
  });
}

// ============================
// 환불 결정
// ============================

/**
 * 환불 결정 뮤테이션 (승인/거부)
 * approve=true: refunded, approve=false: confirmed으로 복구
 */
export function useRefundDecision(orderId: string) {
  const queryClient = useQueryClient();

  return useMutation<
    { order_id: string; status: string; approved: boolean; message: string },
    Error,
    RefundDecisionBody
  >({
    mutationFn: async (body) => {
      const { data } = await api.post(
        `/admin/orders/${orderId}/refund`,
        body
      );
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: adminKeys.order(orderId) });
      queryClient.invalidateQueries({ queryKey: ["admin", "orders"] });
    },
  });
}

// ============================
// 미디어사 목록
// ============================

/**
 * 미디어사 목록 조회 (통계 포함)
 * @param includeInactive 비활성 포함 여부 (기본 false)
 */
export function useMediaCompanies(includeInactive = false) {
  return useQuery<MediaCompanyResponse[]>({
    queryKey: adminKeys.mediaCompanies(includeInactive),
    queryFn: async () => {
      const params = includeInactive
        ? "?include_inactive=true"
        : "";
      const { data } = await api.get<MediaCompanyResponse[]>(
        `/admin/media-companies${params}`
      );
      return data;
    },
    staleTime: 2 * 60 * 1000,
  });
}

// ============================
// 미디어사 상세
// ============================

/**
 * 미디어사 상세 조회 (최근 주문 10개 포함)
 */
export function useMediaCompany(id: string) {
  return useQuery<MediaCompanyDetail>({
    queryKey: adminKeys.mediaCompany(id),
    queryFn: async () => {
      const { data } = await api.get<MediaCompanyDetail>(
        `/admin/media-companies/${id}`
      );
      return data;
    },
    enabled: !!id,
    staleTime: 2 * 60 * 1000,
  });
}

// ============================
// 미디어사 등록
// ============================

/**
 * 미디어사 등록 뮤테이션 (이름 중복 체크 포함)
 */
export function useCreateMediaCompany() {
  const queryClient = useQueryClient();

  return useMutation<MediaCompanyResponse, Error, MediaCompanyCreateBody>({
    mutationFn: async (body) => {
      const { data } = await api.post<MediaCompanyResponse>(
        "/admin/media-companies",
        body
      );
      return data;
    },
    onSuccess: () => {
      // 미디어사 목록 캐시 무효화 (활성/비활성 모두)
      queryClient.invalidateQueries({ queryKey: ["admin", "media-companies"] });
    },
  });
}

// ============================
// 미디어사 수정
// ============================

/**
 * 미디어사 수정 뮤테이션
 */
export function useUpdateMediaCompany(id: string) {
  const queryClient = useQueryClient();

  return useMutation<MediaCompanyResponse, Error, MediaCompanyUpdateBody>({
    mutationFn: async (body) => {
      const { data } = await api.put<MediaCompanyResponse>(
        `/admin/media-companies/${id}`,
        body
      );
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: adminKeys.mediaCompany(id) });
      queryClient.invalidateQueries({ queryKey: ["admin", "media-companies"] });
    },
  });
}

// ============================
// 미디어사 소프트 삭제
// ============================

/**
 * 미디어사 소프트 삭제 (is_active=false)
 * 진행 중인 주문이 있으면 400 에러
 */
export function useDeleteMediaCompany() {
  const queryClient = useQueryClient();

  return useMutation<void, Error, string>({
    mutationFn: async (id) => {
      await api.delete(`/admin/media-companies/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin", "media-companies"] });
    },
  });
}
