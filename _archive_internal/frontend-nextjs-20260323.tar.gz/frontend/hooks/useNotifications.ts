/**
 * 알림 관련 React Query 훅 모음
 * Sprint 7: 알림 시스템 프론트엔드 데이터 레이어
 *
 * API 엔드포인트:
 *   GET    /api/v1/notifications              - 알림 목록 (페이지네이션)
 *   GET    /api/v1/notifications/unread-count - 읽지 않은 수
 *   PUT    /api/v1/notifications/read-all     - 전체 읽음 처리
 *   PUT    /api/v1/notifications/{id}/read    - 단건 읽음 처리
 *   DELETE /api/v1/notifications/{id}         - 알림 삭제
 *   GET    /api/v1/notifications/settings     - 알림 설정 조회
 *   PUT    /api/v1/notifications/settings     - 알림 설정 업데이트
 */

import {
  useQuery,
  useMutation,
  useQueryClient,
  useInfiniteQuery,
} from "@tanstack/react-query";
import api from "@/lib/api";

// ─────────────────────────────────────────────────────────────
// 타입 정의
// ─────────────────────────────────────────────────────────────

/** 알림 타입 enum (백엔드 NotificationType과 동일) */
export type NotificationType =
  // 주문 관련 (8가지)
  | "ORDER_CREATED"
  | "ORDER_CONFIRMED"
  | "ORDER_ASSIGNED"
  | "ORDER_IN_PROGRESS"
  | "ORDER_COMPLETED"
  | "ORDER_CANCELLED"
  | "ORDER_REFUND_REQUESTED"
  | "ORDER_REFUND_DECIDED"
  // 랭킹 관련 (5가지)
  | "RANK_IMPROVED"
  | "RANK_DROPPED"
  | "RANK_TOP10"
  | "RANK_TOP3"
  | "RANK_FLUCTUATION"
  // 시스템 관련 (5가지)
  | "PLAN_UPGRADED"
  | "PLAN_DOWNGRADED"
  | "PLAN_EXPIRED"
  | "CRAWL_COMPLETED"
  | "CRAWL_FAILED"
  // 워크스페이스 관련 (4가지)
  | "MEMBER_INVITED"
  | "MEMBER_JOINED"
  | "MEMBER_LEFT"
  | "MEMBER_ROLE_CHANGED"
  // 결제 관련 (3가지)
  | "PAYMENT_COMPLETED"
  | "PAYMENT_FAILED"
  | "PAYMENT_REFUNDED";

/** 단일 알림 아이템 */
export interface NotificationItem {
  id: string;
  type: NotificationType;
  title: string;
  message: string;
  data: Record<string, unknown>;
  is_read: boolean;
  created_at: string;
  read_at: string | null;
  workspace_id: string | null;
}

/** 알림 목록 응답 */
export interface NotificationListResponse {
  items: NotificationItem[];
  total: number;
  unread_count: number;
  page: number;
  limit: number;
}

/** 읽지 않은 알림 수 응답 */
export interface UnreadCountResponse {
  total: number;
  by_type: Record<string, number>;
}

/** 단일 알림 설정 항목 */
export interface NotificationSettingItem {
  notification_type: NotificationType;
  in_app_enabled: boolean;
  email_enabled: boolean;
  kakao_enabled: boolean;
  sms_enabled: boolean;
}

/** 알림 설정 응답 */
export interface NotificationSettingResponse {
  settings: NotificationSettingItem[];
}

// ─────────────────────────────────────────────────────────────
// 쿼리 키 정의
// ─────────────────────────────────────────────────────────────
export const notificationKeys = {
  all: ["notifications"] as const,
  lists: () => [...notificationKeys.all, "list"] as const,
  list: (filters: Record<string, unknown>) =>
    [...notificationKeys.lists(), filters] as const,
  unreadCount: () => [...notificationKeys.all, "unread-count"] as const,
  settings: () => [...notificationKeys.all, "settings"] as const,
};

// ─────────────────────────────────────────────────────────────
// 훅: 알림 목록 조회 (페이지네이션)
// ─────────────────────────────────────────────────────────────

interface UseNotificationsParams {
  page?: number;
  limit?: number;
  is_read?: boolean | null;
  type?: NotificationType | null;
}

/**
 * 알림 목록을 페이지네이션으로 조회합니다.
 * 20개씩 페이지네이션 (기본값).
 */
export function useNotifications({
  page = 1,
  limit = 20,
  is_read = null,
  type = null,
}: UseNotificationsParams = {}) {
  const params: Record<string, unknown> = { page, limit };
  if (is_read !== null) params.is_read = is_read;
  if (type) params.type = type;

  return useQuery<NotificationListResponse>({
    queryKey: notificationKeys.list({ page, limit, is_read, type }),
    queryFn: async () => {
      const { data } = await api.get("/api/v1/notifications", { params });
      return data;
    },
    // 30초마다 자동 갱신 (알림 실시간성)
    refetchInterval: 30_000,
  });
}

// ─────────────────────────────────────────────────────────────
// 훅: 읽지 않은 알림 수 조회
// ─────────────────────────────────────────────────────────────

/**
 * 읽지 않은 알림 수를 타입별로 조회합니다.
 * Header의 NotificationBell 뱃지 표시에 사용.
 * 30초마다 자동 갱신.
 */
export function useUnreadCount() {
  return useQuery<UnreadCountResponse>({
    queryKey: notificationKeys.unreadCount(),
    queryFn: async () => {
      const { data } = await api.get("/api/v1/notifications/unread-count");
      return data;
    },
    refetchInterval: 30_000,
  });
}

// ─────────────────────────────────────────────────────────────
// 훅: 단건 읽음 처리
// ─────────────────────────────────────────────────────────────

/**
 * 특정 알림을 읽음 처리합니다.
 * 성공 시 목록 및 unread-count 캐시를 무효화합니다.
 */
export function useMarkNotificationRead() {
  const queryClient = useQueryClient();

  return useMutation<NotificationItem, Error, string>({
    mutationFn: async (notificationId: string) => {
      const { data } = await api.put(
        `/api/v1/notifications/${notificationId}/read`
      );
      return data;
    },
    onSuccess: () => {
      // 알림 목록 및 읽지 않은 수 캐시 무효화
      queryClient.invalidateQueries({ queryKey: notificationKeys.lists() });
      queryClient.invalidateQueries({ queryKey: notificationKeys.unreadCount() });
    },
  });
}

// ─────────────────────────────────────────────────────────────
// 훅: 전체 읽음 처리
// ─────────────────────────────────────────────────────────────

/**
 * 모든 알림을 읽음 처리합니다.
 */
export function useMarkAllRead() {
  const queryClient = useQueryClient();

  return useMutation<{ message: string; count: number }, Error, void>({
    mutationFn: async () => {
      const { data } = await api.put("/api/v1/notifications/read-all");
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: notificationKeys.lists() });
      queryClient.invalidateQueries({ queryKey: notificationKeys.unreadCount() });
    },
  });
}

// ─────────────────────────────────────────────────────────────
// 훅: 알림 삭제
// ─────────────────────────────────────────────────────────────

/**
 * 특정 알림을 삭제합니다.
 */
export function useDeleteNotification() {
  const queryClient = useQueryClient();

  return useMutation<void, Error, string>({
    mutationFn: async (notificationId: string) => {
      await api.delete(`/api/v1/notifications/${notificationId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: notificationKeys.lists() });
      queryClient.invalidateQueries({ queryKey: notificationKeys.unreadCount() });
    },
  });
}

// ─────────────────────────────────────────────────────────────
// 훅: 알림 설정 조회
// ─────────────────────────────────────────────────────────────

/**
 * 사용자의 알림 설정을 25가지 타입 전체에 대해 조회합니다.
 */
export function useNotificationSettings() {
  return useQuery<NotificationSettingResponse>({
    queryKey: notificationKeys.settings(),
    queryFn: async () => {
      const { data } = await api.get("/api/v1/notifications/settings");
      return data;
    },
    staleTime: 5 * 60 * 1000, // 5분 캐시
  });
}

// ─────────────────────────────────────────────────────────────
// 훅: 알림 설정 업데이트
// ─────────────────────────────────────────────────────────────

/**
 * 알림 설정을 업데이트합니다. (upsert)
 * 변경된 설정만 전달해도 됩니다.
 */
export function useUpdateNotificationSettings() {
  const queryClient = useQueryClient();

  return useMutation<
    NotificationSettingResponse,
    Error,
    { settings: NotificationSettingItem[] }
  >({
    mutationFn: async (body) => {
      const { data } = await api.put("/api/v1/notifications/settings", body);
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: notificationKeys.settings() });
    },
  });
}

// ─────────────────────────────────────────────────────────────
// 유틸: 알림 타입 한국어 레이블
// ─────────────────────────────────────────────────────────────

/** 알림 타입 → 한국어 레이블 매핑 */
export const NOTIFICATION_TYPE_LABELS: Record<NotificationType, string> = {
  // 주문
  ORDER_CREATED: "주문 접수",
  ORDER_CONFIRMED: "주문 확인",
  ORDER_ASSIGNED: "매체사 배정",
  ORDER_IN_PROGRESS: "작업 시작",
  ORDER_COMPLETED: "주문 완료",
  ORDER_CANCELLED: "주문 취소",
  ORDER_REFUND_REQUESTED: "환불 요청",
  ORDER_REFUND_DECIDED: "환불 결정",
  // 랭킹
  RANK_IMPROVED: "순위 상승",
  RANK_DROPPED: "순위 하락",
  RANK_TOP10: "TOP 10 진입",
  RANK_TOP3: "TOP 3 진입",
  RANK_FLUCTUATION: "순위 급변동",
  // 시스템
  PLAN_UPGRADED: "플랜 업그레이드",
  PLAN_DOWNGRADED: "플랜 다운그레이드",
  PLAN_EXPIRED: "플랜 만료",
  CRAWL_COMPLETED: "순위 조회 완료",
  CRAWL_FAILED: "순위 조회 실패",
  // 워크스페이스
  MEMBER_INVITED: "멤버 초대",
  MEMBER_JOINED: "멤버 합류",
  MEMBER_LEFT: "멤버 탈퇴",
  MEMBER_ROLE_CHANGED: "역할 변경",
  // 결제
  PAYMENT_COMPLETED: "결제 완료",
  PAYMENT_FAILED: "결제 실패",
  PAYMENT_REFUNDED: "환불 처리",
};

/** 알림 타입 → 카테고리 그룹 */
export const NOTIFICATION_CATEGORIES: Record<string, NotificationType[]> = {
  주문: [
    "ORDER_CREATED",
    "ORDER_CONFIRMED",
    "ORDER_ASSIGNED",
    "ORDER_IN_PROGRESS",
    "ORDER_COMPLETED",
    "ORDER_CANCELLED",
    "ORDER_REFUND_REQUESTED",
    "ORDER_REFUND_DECIDED",
  ],
  랭킹: [
    "RANK_IMPROVED",
    "RANK_DROPPED",
    "RANK_TOP10",
    "RANK_TOP3",
    "RANK_FLUCTUATION",
  ],
  시스템: [
    "PLAN_UPGRADED",
    "PLAN_DOWNGRADED",
    "PLAN_EXPIRED",
    "CRAWL_COMPLETED",
    "CRAWL_FAILED",
  ],
  워크스페이스: [
    "MEMBER_INVITED",
    "MEMBER_JOINED",
    "MEMBER_LEFT",
    "MEMBER_ROLE_CHANGED",
  ],
  결제: ["PAYMENT_COMPLETED", "PAYMENT_FAILED", "PAYMENT_REFUNDED"],
};

/** 알림 타입별 아이콘 색상 */
export const NOTIFICATION_TYPE_COLOR: Record<string, string> = {
  ORDER_CREATED: "#00d4ff",
  ORDER_CONFIRMED: "#00d4ff",
  ORDER_ASSIGNED: "#7c3aed",
  ORDER_IN_PROGRESS: "#7c3aed",
  ORDER_COMPLETED: "#10b981",
  ORDER_CANCELLED: "#f87171",
  ORDER_REFUND_REQUESTED: "#fcd34d",
  ORDER_REFUND_DECIDED: "#fcd34d",
  RANK_IMPROVED: "#10b981",
  RANK_DROPPED: "#f87171",
  RANK_TOP10: "#00d4ff",
  RANK_TOP3: "#fcd34d",
  RANK_FLUCTUATION: "#fcd34d",
  PLAN_UPGRADED: "#10b981",
  PLAN_DOWNGRADED: "#f87171",
  PLAN_EXPIRED: "#f87171",
  CRAWL_COMPLETED: "#10b981",
  CRAWL_FAILED: "#f87171",
  MEMBER_INVITED: "#00d4ff",
  MEMBER_JOINED: "#10b981",
  MEMBER_LEFT: "#f87171",
  MEMBER_ROLE_CHANGED: "#fcd34d",
  PAYMENT_COMPLETED: "#10b981",
  PAYMENT_FAILED: "#f87171",
  PAYMENT_REFUNDED: "#fcd34d",
};
