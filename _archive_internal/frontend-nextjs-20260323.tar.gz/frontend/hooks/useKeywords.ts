"use client";

/**
 * 키워드 관련 TanStack Query 훅 모음 (Sprint 4)
 *
 * useKeywords              키워드 목록 (순위 포함)
 * useCreateKeyword         키워드 등록 뮤테이션
 * useUpdateKeyword         키워드 수정 뮤테이션
 * useDeleteKeyword         키워드 소프트 삭제 뮤테이션
 * useKeywordRankings       특정 키워드 순위 이력
 * usePlaceRankingSummary   장소 전체 순위 요약
 * useCrawlNow              수동 크롤링 실행 뮤테이션
 */
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import api from "@/lib/api";

// ============================
// 타입 정의
// ============================

export interface KeywordWithRank {
  id: string;
  keyword: string;
  is_primary: boolean;
  group_name?: string | null;
  is_active: boolean;
  latest_rank?: number | null;
  case_type?: string | null;       // normal | popular | not_ranked
  rank_change?: number | null;     // 양수=상승, 음수=하락
  rank_7d_avg?: number | null;     // 7일 평균
  best_rank?: number | null;       // 역대 최고 순위
  worst_rank?: number | null;      // 역대 최저 순위
  crawled_at?: string | null;      // 최신 크롤링 시각 (ISO string)
}

export interface KeywordListResponse {
  total: number;
  items: KeywordWithRank[];
}

export interface KeywordCreate {
  keyword: string;
  is_primary?: boolean;
  group_name?: string;
}

export interface KeywordUpdate {
  is_primary?: boolean;
  group_name?: string;
  is_active?: boolean;
}

export interface RankingPoint {
  rank?: number | null;
  case_type: string;
  crawled_at: string;
}

export interface RankingHistoryResponse {
  keyword_id: string;
  keyword: string;
  period: string;
  rankings: RankingPoint[];
}

export interface PlaceRankingSummaryKeyword {
  id: string;
  keyword: string;
  is_primary: boolean;
  group_name?: string | null;
  latest_rank?: number | null;
  case_type?: string | null;
  crawled_at?: string | null;
  rank_change?: number | null;
  rank_7d_avg?: number | null;
  best_rank?: number | null;
  worst_rank?: number | null;
}

export interface PlaceRankingSummaryResponse {
  place_id: string;
  place_name: string;
  keywords: PlaceRankingSummaryKeyword[];
}

export type RankingPeriod = "7d" | "30d" | "90d";

// ============================
// Query Keys
// ============================

export const keywordKeys = {
  all: ["keywords"] as const,
  list: (placeId: string) => ["keywords", "list", placeId] as const,
  detail: (keywordId: string) => ["keywords", "detail", keywordId] as const,
  rankings: (placeId: string, keywordId: string, period: RankingPeriod) =>
    ["keywords", "rankings", placeId, keywordId, period] as const,
  summary: (placeId: string) => ["keywords", "summary", placeId] as const,
};

// ============================
// 키워드 목록 조회
// ============================

export function useKeywords(placeId: string, includeInactive = false) {
  return useQuery<KeywordListResponse>({
    queryKey: keywordKeys.list(placeId),
    queryFn: async () => {
      const { data } = await api.get<KeywordListResponse>(
        `/places/${placeId}/keywords${includeInactive ? "?include_inactive=true" : ""}`
      );
      return data;
    },
    enabled: !!placeId,
    staleTime: 3 * 60 * 1000, // 3분
  });
}

// ============================
// 키워드 등록 뮤테이션
// ============================

export function useCreateKeyword(placeId: string) {
  const queryClient = useQueryClient();

  return useMutation<KeywordWithRank, Error, KeywordCreate>({
    mutationFn: async (body) => {
      const { data } = await api.post<KeywordWithRank>(
        `/places/${placeId}/keywords`,
        body
      );
      return data;
    },
    onSuccess: () => {
      // 키워드 목록 무효화 → 자동 재조회
      queryClient.invalidateQueries({ queryKey: keywordKeys.list(placeId) });
      // 순위 요약도 갱신
      queryClient.invalidateQueries({ queryKey: keywordKeys.summary(placeId) });
    },
  });
}

// ============================
// 키워드 수정 뮤테이션
// ============================

export function useUpdateKeyword(placeId: string, keywordId: string) {
  const queryClient = useQueryClient();

  return useMutation<KeywordWithRank, Error, KeywordUpdate>({
    mutationFn: async (body) => {
      const { data } = await api.put<KeywordWithRank>(
        `/places/${placeId}/keywords/${keywordId}`,
        body
      );
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: keywordKeys.list(placeId) });
      queryClient.invalidateQueries({ queryKey: keywordKeys.summary(placeId) });
    },
  });
}

// ============================
// 키워드 삭제 뮤테이션
// ============================

export function useDeleteKeyword(placeId: string) {
  const queryClient = useQueryClient();

  return useMutation<void, Error, string>({
    mutationFn: async (keywordId: string) => {
      await api.delete(`/places/${placeId}/keywords/${keywordId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: keywordKeys.list(placeId) });
      queryClient.invalidateQueries({ queryKey: keywordKeys.summary(placeId) });
    },
  });
}

// ============================
// 키워드 순위 이력
// ============================

export function useKeywordRankings(
  placeId: string,
  keywordId: string,
  period: RankingPeriod = "30d"
) {
  return useQuery<RankingHistoryResponse>({
    queryKey: keywordKeys.rankings(placeId, keywordId, period),
    queryFn: async () => {
      const { data } = await api.get<RankingHistoryResponse>(
        `/places/${placeId}/keywords/${keywordId}/rankings?period=${period}`
      );
      return data;
    },
    enabled: !!placeId && !!keywordId,
    staleTime: 5 * 60 * 1000, // 5분
  });
}

// ============================
// 장소 전체 순위 요약
// ============================

export function usePlaceRankingSummary(placeId: string) {
  return useQuery<PlaceRankingSummaryResponse>({
    queryKey: keywordKeys.summary(placeId),
    queryFn: async () => {
      const { data } = await api.get<PlaceRankingSummaryResponse>(
        `/places/${placeId}/rankings/summary`
      );
      return data;
    },
    enabled: !!placeId,
    staleTime: 5 * 60 * 1000,        // 5분
    refetchInterval: 10 * 60 * 1000, // 10분마다 자동 갱신
  });
}

// ============================
// 수동 크롤링 실행 뮤테이션
// ============================

export function useCrawlNow(placeId: string) {
  const queryClient = useQueryClient();

  return useMutation<{ message: string; job_count: number }, Error, void>({
    mutationFn: async () => {
      const { data } = await api.post<{ message: string; job_count: number }>(
        `/places/${placeId}/crawl-now`
      );
      return data;
    },
    onSuccess: () => {
      // 크롤링 시작 후 순위 요약 갱신 (약간의 딜레이를 두고)
      setTimeout(() => {
        queryClient.invalidateQueries({ queryKey: keywordKeys.list(placeId) });
        queryClient.invalidateQueries({ queryKey: keywordKeys.summary(placeId) });
      }, 3000); // 3초 후 갱신 시도
    },
  });
}
