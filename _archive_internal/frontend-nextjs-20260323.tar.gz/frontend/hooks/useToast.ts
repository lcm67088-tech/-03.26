"use client";

/**
 * Toast 알림 훅
 * sonner 라이브러리 래퍼
 */
import { toast } from "sonner";

/**
 * 토스트 훅
 * 성공/에러/경고/정보 토스트 제공
 */
export function useToast() {
  return {
    /**
     * 성공 토스트
     */
    success: (message: string, description?: string) => {
      toast.success(message, {
        description,
        duration: 3000,
      });
    },

    /**
     * 에러 토스트
     */
    error: (message: string, description?: string) => {
      toast.error(message, {
        description,
        duration: 5000,
      });
    },

    /**
     * 경고 토스트
     */
    warning: (message: string, description?: string) => {
      toast.warning(message, {
        description,
        duration: 4000,
      });
    },

    /**
     * 정보 토스트
     */
    info: (message: string, description?: string) => {
      toast.info(message, {
        description,
        duration: 3000,
      });
    },

    /**
     * 로딩 토스트 (Promise 기반)
     */
    promise: <T>(
      promise: Promise<T>,
      messages: {
        loading: string;
        success: string;
        error: string;
      }
    ) => {
      return toast.promise(promise, {
        loading: messages.loading,
        success: messages.success,
        error: messages.error,
      });
    },

    /**
     * 토스트 닫기
     */
    dismiss: (toastId?: string | number) => {
      toast.dismiss(toastId);
    },
  };
}
