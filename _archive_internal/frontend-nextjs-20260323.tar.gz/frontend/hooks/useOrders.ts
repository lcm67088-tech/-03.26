"use client";

/**
 * 주문(Order) 관련 TanStack Query 훅 모음 (Sprint 5)
 *
 * useProducts          상품 목록 조회 (공개 API, 유형별 그룹)
 * useOrders            주문 목록 조회 (workspace_id + 상태 필터)
 * useOrder             주문 상세 조회
 * useCreateOrder       주문 생성 뮤테이션
 * useCompletePayment   Mock PG 결제 완료 뮤테이션
 * useCancelOrder       주문 취소 뮤테이션
 * useRefundRequest     환불 요청 뮤테이션
 */
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import api from "@/lib/api";

// ============================
// 타입 정의
// ============================

/** 단일 상품 */
export interface ProductResponse {
  id: string;
  name: string;
  description?: string | null;
  base_price: number;
  unit: string;
  min_quantity: number;
  max_quantity?: number | null;
  badge?: string | null;          // extra_data.badge (예: "인기", "추천")
  features: string[];             // extra_data.features
}

/** 상품 유형 + 소속 상품 목록 */
export interface ProductTypeWithProducts {
  id: string;
  name: string;
  description?: string | null;
  products: ProductResponse[];
}

/** 상품 목록 응답 */
export interface ProductListResponse {
  product_types: ProductTypeWithProducts[];
}

/** 결제 정보 */
export interface PaymentInfo {
  id: string;
  amount: number;
  method?: string | null;
  status: string;
  pg_transaction_id?: string | null;
  paid_at?: string | null;
  created_at: string;
}

/** 주문 목록 아이템 */
export interface OrderListItem {
  id: string;
  product_name: string;
  status: string;
  total_amount: number;
  quantity: number;
  unit_price: number;
  place_name?: string | null;
  ordered_at?: string | null;
  created_at: string;
}

/** 주문 목록 응답 */
export interface OrderListResponse {
  total: number;
  items: OrderListItem[];
}

/** 주문 상세 응답 */
export interface OrderDetail {
  id: string;
  product_id?: string | null;
  product_name: string;
  description?: string | null;
  status: string;
  quantity: number;
  unit_price: number;
  total_amount: number;
  special_requests?: string | null;
  place?: {
    id: string;
    name: string;
    alias?: string | null;
    naver_place_id: string;
  } | null;
  keywords: { id: string; keyword: string }[];
  payment?: PaymentInfo | null;
  media_company_id?: string | null;
  media_company_name?: string | null;
  proof_url?: string | null;
  ordered_at?: string | null;
  completed_at?: string | null;
  created_at: string;
  updated_at: string;
}

/** 주문 생성 응답 */
export interface CreateOrderResponse {
  order: OrderDetail;
  payment: PaymentInfo;
}

/** 주문 생성 요청 Body */
export interface OrderCreateRequest {
  workspace_id: string;
  product_id: string;
  place_id?: string | null;
  keyword_ids?: string[];
  quantity: number;
  payment_method: "kakaopay" | "naverpay" | "card";
  special_requests?: string | null;
}

/** Mock PG 결제 완료 요청 Body */
export interface PaymentCompleteRequest {
  pg_transaction_id: string;
  method: "kakaopay" | "naverpay" | "card";
}

/** 환불 요청 Body */
export interface RefundRequestBody {
  reason: string;
}

// ============================
// Query Keys
// ============================

export const orderKeys = {
  all: ["orders"] as const,
  /** 상품 목록 (공개, 캐시 오래 유지) */
  products: () => ["orders", "products"] as const,
  /** 주문 목록 (워크스페이스 + 상태 필터) */
  list: (workspaceId: string, statusFilter?: string | null) =>
    ["orders", "list", workspaceId, statusFilter ?? "all"] as const,
  /** 주문 상세 */
  detail: (orderId: string) => ["orders", "detail", orderId] as const,
};

// ============================
// 상품 목록 조회 (공개 API)
// ============================

/**
 * 활성 상품 목록 조회 (유형별 그룹)
 * 인증 불필요 — 주문 위저드 1단계에서 사용
 */
export function useProducts() {
  return useQuery<ProductListResponse>({
    queryKey: orderKeys.products(),
    queryFn: async () => {
      const { data } = await api.get<ProductListResponse>("/products");
      return data;
    },
    staleTime: 10 * 60 * 1000,  // 10분 (상품 목록은 자주 변하지 않음)
    gcTime: 30 * 60 * 1000,     // 30분 캐시 유지
  });
}

// ============================
// 주문 목록 조회
// ============================

/**
 * 워크스페이스 주문 목록 조회
 * @param workspaceId  워크스페이스 ID
 * @param statusFilter 상태 필터 (null이면 전체)
 * @param page         현재 페이지 (1-based)
 * @param pageSize     페이지 당 건수 (기본 20)
 */
export function useOrders(
  workspaceId: string,
  statusFilter: string | null = null,
  page = 1,
  pageSize = 20,
) {
  const skip = (page - 1) * pageSize;

  return useQuery<OrderListResponse>({
    queryKey: orderKeys.list(workspaceId, statusFilter),
    queryFn: async () => {
      const params = new URLSearchParams({
        workspace_id: workspaceId,
        skip: String(skip),
        limit: String(pageSize),
      });
      if (statusFilter) params.append("status", statusFilter);

      const { data } = await api.get<OrderListResponse>(
        `/orders?${params.toString()}`
      );
      return data;
    },
    enabled: !!workspaceId,
    staleTime: 2 * 60 * 1000, // 2분
  });
}

// ============================
// 주문 상세 조회
// ============================

/**
 * 주문 상세 조회
 * @param orderId 주문 ID
 */
export function useOrder(orderId: string) {
  return useQuery<OrderDetail>({
    queryKey: orderKeys.detail(orderId),
    queryFn: async () => {
      const { data } = await api.get<OrderDetail>(`/orders/${orderId}`);
      return data;
    },
    enabled: !!orderId,
    staleTime: 2 * 60 * 1000,
  });
}

// ============================
// 주문 생성 뮤테이션
// ============================

/**
 * 주문 생성
 * 성공 시: 주문 목록 캐시 무효화
 */
export function useCreateOrder() {
  const queryClient = useQueryClient();

  return useMutation<CreateOrderResponse, Error, OrderCreateRequest>({
    mutationFn: async (body) => {
      const { data } = await api.post<CreateOrderResponse>("/orders", body);
      return data;
    },
    onSuccess: (_, variables) => {
      // 주문 목록 캐시 무효화 (모든 상태 필터 포함)
      queryClient.invalidateQueries({
        queryKey: ["orders", "list", variables.workspace_id],
      });
    },
  });
}

// ============================
// Mock PG 결제 완료 뮤테이션
// ============================

/**
 * Mock PG 결제 완료 처리
 * 성공 시: 해당 주문 상세 캐시 무효화
 */
export function useCompletePayment(orderId: string) {
  const queryClient = useQueryClient();

  return useMutation<
    { order_id: string; payment_id: string; status: string; message: string },
    Error,
    { paymentId: string; body: PaymentCompleteRequest }
  >({
    mutationFn: async ({ paymentId, body }) => {
      const { data } = await api.post(
        `/payments/${paymentId}/complete`,
        body
      );
      return data;
    },
    onSuccess: () => {
      // 주문 상세 캐시 갱신
      queryClient.invalidateQueries({ queryKey: orderKeys.detail(orderId) });
      // 전체 주문 목록도 갱신
      queryClient.invalidateQueries({ queryKey: ["orders", "list"] });
    },
  });
}

// ============================
// 주문 취소 뮤테이션
// ============================

/**
 * 주문 취소 (pending 상태만 가능)
 * 성공 시: 주문 상세 + 목록 캐시 무효화
 */
export function useCancelOrder(orderId: string) {
  const queryClient = useQueryClient();

  return useMutation<{ message: string; order_id: string }, Error, void>({
    mutationFn: async () => {
      const { data } = await api.post(`/orders/${orderId}/cancel`);
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: orderKeys.detail(orderId) });
      queryClient.invalidateQueries({ queryKey: ["orders", "list"] });
    },
  });
}

// ============================
// 환불 요청 뮤테이션
// ============================

/**
 * 환불 요청 (completed / in_progress 상태에서 가능)
 * 성공 시: 주문 상세 + 목록 캐시 무효화
 */
export function useRefundRequest(orderId: string) {
  const queryClient = useQueryClient();

  return useMutation<
    { message: string; order_id: string; status: string },
    Error,
    RefundRequestBody
  >({
    mutationFn: async (body) => {
      const { data } = await api.post(
        `/orders/${orderId}/refund-request`,
        body
      );
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: orderKeys.detail(orderId) });
      queryClient.invalidateQueries({ queryKey: ["orders", "list"] });
    },
  });
}
