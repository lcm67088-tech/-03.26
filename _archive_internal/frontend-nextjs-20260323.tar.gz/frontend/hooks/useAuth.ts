"use client";

/**
 * 인증 훅 (Sprint 2 완성)
 * 로그인 상태, 현재 유저, 플랜/권한 헬퍼 포함
 */
import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { useAuthStore } from "@/store/authStore";
import { tokenStorage } from "@/lib/auth";
import type { MemberRole } from "@/types";

/**
 * 메인 인증 훅
 *
 * @param redirectIfUnauthenticated - 인증 안 된 경우 /login으로 리다이렉트 (기본 false)
 */
export function useAuth(redirectIfUnauthenticated = false) {
  const router = useRouter();
  const {
    user,
    workspace,
    isAuthenticated,
    isLoading,
    login,
    logout,
    refreshAccessToken,
    updateUser,
    updateWorkspace,
  } = useAuthStore();

  // 마운트 시 토큰 유효성 체크
  useEffect(() => {
    if (redirectIfUnauthenticated) {
      const authenticated = tokenStorage.isAuthenticated();
      if (!authenticated && !isLoading) {
        router.replace("/login");
      }
    }
  }, [isAuthenticated, isLoading, redirectIfUnauthenticated, router]);

  return {
    // 상태
    user,
    workspace,
    isAuthenticated,
    isLoading,

    // 액션
    login,
    logout,
    refreshAccessToken,
    updateUser,
    updateWorkspace,

    // 편의 헬퍼
    /** 어드민 여부 (admin 또는 superadmin) */
    isAdmin: user?.role === "admin" || user?.role === "superadmin",

    /** 슈퍼어드민 여부 */
    isSuperAdmin: user?.role === "superadmin",

    /** Pro 이상 플랜 여부 */
    isPro: ["pro", "enterprise"].includes(workspace?.plan ?? ""),

    /** Enterprise 플랜 여부 */
    isEnterprise: workspace?.plan === "enterprise",

    /** 현재 플랜 */
    currentPlan: workspace?.plan ?? "free",

    /** 유저 이름 이니셜 */
    userInitial: user?.name?.charAt(0)?.toUpperCase() ?? "?",
  };
}

/**
 * 어드민 전용 훅
 * 어드민이 아니면 /dashboard로 리다이렉트
 */
export function useRequireAdmin() {
  const router = useRouter();
  const { user, isAuthenticated } = useAuthStore();

  useEffect(() => {
    if (isAuthenticated && user) {
      if (user.role !== "admin" && user.role !== "superadmin") {
        router.replace("/dashboard");
      }
    }
    if (!isAuthenticated && !tokenStorage.isAuthenticated()) {
      router.replace("/login");
    }
  }, [user, isAuthenticated, router]);

  return {
    isAdmin: user?.role === "admin" || user?.role === "superadmin",
    isSuperAdmin: user?.role === "superadmin",
  };
}

/**
 * 워크스페이스 멤버 역할 체크 훅
 * 현재 워크스페이스에서의 역할 확인
 *
 * @param memberRole - 현재 유저의 멤버 역할 (서버에서 가져온 값)
 */
export function useWorkspaceRole(memberRole?: MemberRole) {
  return {
    isOwner: memberRole === "owner",
    isManager: memberRole === "owner" || memberRole === "manager",
    canView: !!memberRole,
    /** 멤버를 초대/관리할 수 있는지 */
    canManageMembers: memberRole === "owner" || memberRole === "manager",
  };
}
