/**
 * 공통 TypeScript 타입 정의
 * PRD 기반 완전한 도메인 타입
 */

// =====================
// 기본 타입
// =====================
export type UUID = string;
export type ISODateString = string;

// =====================
// 유저
// =====================
export type UserRole = "user" | "admin" | "superadmin";

export interface User {
  id: UUID;
  email: string;
  name: string;
  phone?: string;
  role: UserRole;
  is_active: boolean;
  email_verified: boolean;
  created_at: ISODateString;
  updated_at: ISODateString;
}

// =====================
// 워크스페이스
// =====================
export type WorkspacePlan = "free" | "starter" | "pro" | "enterprise";
export type MemberRole = "owner" | "manager" | "viewer";

export interface Workspace {
  id: UUID;
  owner_id: UUID;
  name: string;
  plan: WorkspacePlan;
  is_active: boolean;
  extra_data?: Record<string, unknown>;
  created_at: ISODateString;
  updated_at: ISODateString;
}

export interface WorkspaceMember {
  id: UUID;
  workspace_id: UUID;
  user_id: UUID;
  role: MemberRole;
  user?: User;
  created_at: ISODateString;
}

// =====================
// 플랜 한도 (PRD 기준)
// =====================
export const PLAN_LIMITS: Record<WorkspacePlan, {
  places: number;
  keywords: number;
  crawlsPerDay: number;
  historyDays: number;
  teamMembers: number;
}> = {
  free: { places: 1, keywords: 5, crawlsPerDay: 1, historyDays: 7, teamMembers: 1 },
  starter: { places: 5, keywords: 20, crawlsPerDay: 2, historyDays: 30, teamMembers: 3 },
  pro: { places: 30, keywords: 100, crawlsPerDay: 4, historyDays: 180, teamMembers: 10 },
  enterprise: { places: -1, keywords: -1, crawlsPerDay: -1, historyDays: 365, teamMembers: -1 },
};

// =====================
// 장소 (Place)
// =====================
export interface Place {
  id: UUID;
  workspace_id: UUID;
  naver_place_id: string;
  naver_place_url: string;
  name: string;
  alias?: string;
  category?: string;
  address?: string;
  is_active: boolean;
  extra_data?: Record<string, unknown>;
  created_at: ISODateString;
  updated_at: ISODateString;
  // 조인 필드
  keyword_count?: number;
  latest_rank?: number | null;
}

// =====================
// 키워드 & 순위
// =====================
export type RankCaseType = "normal" | "popular" | "not_ranked";

export interface PlaceKeyword {
  id: UUID;
  place_id: UUID;
  keyword: string;
  is_primary: boolean;
  is_active: boolean;
  group_name?: string;
  created_at: ISODateString;
  updated_at: ISODateString;
  // 조인 필드
  latest_rank?: number | null;
  latest_case_type?: RankCaseType;
}

export interface KeywordRanking {
  id: UUID;
  keyword_id: UUID;
  rank: number | null;
  case_type: RankCaseType;
  crawled_at: ISODateString;
  extra_data?: Record<string, unknown>;
  created_at: ISODateString;
}

// =====================
// 매체사
// =====================
export interface MediaCompany {
  id: UUID;
  name: string;
  contact_email?: string;
  contact_phone?: string;
  bank_account?: string;
  is_active: boolean;
  extra_data?: Record<string, unknown>;
  created_at: ISODateString;
  updated_at: ISODateString;
}

// =====================
// 주문
// =====================
export type OrderStatus =
  | "pending"
  | "confirmed"
  | "in_progress"
  | "completed"
  | "cancelled"
  | "refunded"
  | "disputed";

export type PaymentMethod = "kakaopay" | "naverpay" | "card";
export type PaymentStatus = "pending" | "completed" | "failed" | "refunded";

export interface Order {
  id: UUID;
  workspace_id: UUID;
  place_id?: UUID;
  product_name: string;
  description?: string;
  total_amount: number;
  status: OrderStatus;
  media_company_id?: UUID;
  proof_url?: string;
  ordered_at?: ISODateString;
  completed_at?: ISODateString;
  extra_data?: Record<string, unknown>;
  created_at: ISODateString;
  updated_at: ISODateString;
  // 조인 필드
  place?: Pick<Place, "id" | "name" | "alias">;
  media_company?: Pick<MediaCompany, "id" | "name">;
  payment?: Payment;
}

export interface Payment {
  id: UUID;
  order_id: UUID;
  amount: number;
  method: PaymentMethod;
  status: PaymentStatus;
  pg_transaction_id?: string;
  paid_at?: ISODateString;
  created_at: ISODateString;
}

// =====================
// API 응답 타입
// =====================
export interface PaginatedResponse<T> {
  items: T[];
  total: number;
  page: number;
  size: number;
  pages: number;
}

export interface MessageResponse {
  message: string;
  success: boolean;
}

export interface ApiError {
  detail: string;
  status_code?: number;
}

// =====================
// 인증
// =====================
export interface AuthTokens {
  access_token: string;
  refresh_token: string;
  token_type: string;
}

export interface AuthState {
  user: User | null;
  workspace: Workspace | null;
  tokens: AuthTokens | null;
  isAuthenticated: boolean;
}
