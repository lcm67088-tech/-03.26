/**
 * 워크스페이스 멤버 관리 페이지
 * Sprint 7: /workspaces/[id]/members
 * - 멤버 목록 (역할별 색상)
 * - 멤버 초대 (이메일 입력)
 * - 역할 변경 (owner → manager/member/viewer)
 * - 멤버 제거
 * - 소유권 이전
 */

"use client";

import { useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { Users, UserPlus, ArrowLeft, Crown, Shield, User, Eye, Trash2, ArrowRightLeft } from "lucide-react";
import { toast } from "sonner";
import {
  useWorkspaceMembers,
  useInviteMember,
  useUpdateMemberRole,
  useRemoveMember,
  useTransferOwnership,
  WorkspaceMember,
  ROLE_LABELS,
  ROLE_COLORS,
} from "@/hooks/useAccount";

// ─────────────────────────────────────────────────────────────
// 역할 아이콘
// ─────────────────────────────────────────────────────────────
function RoleIcon({ role }: { role: string }) {
  const color = ROLE_COLORS[role] ?? "#a3a3a3";
  const size = 14;
  if (role === "owner") return <Crown size={size} style={{ color }} />;
  if (role === "manager") return <Shield size={size} style={{ color }} />;
  if (role === "viewer") return <Eye size={size} style={{ color }} />;
  return <User size={size} style={{ color }} />;
}

// ─────────────────────────────────────────────────────────────
// 역할 선택 드롭다운
// ─────────────────────────────────────────────────────────────
const SELECTABLE_ROLES = ["member", "manager", "viewer"] as const;

export default function WorkspaceMembersPage() {
  const params = useParams();
  const router = useRouter();
  const workspaceId = params?.id as string;

  // 훅
  const { data: members, isLoading } = useWorkspaceMembers(workspaceId);
  const { mutate: invite, isPending: isInviting } = useInviteMember(workspaceId);
  const { mutate: updateRole, isPending: isUpdatingRole } = useUpdateMemberRole(workspaceId);
  const { mutate: removeMember, isPending: isRemoving } = useRemoveMember(workspaceId);
  const { mutate: transferOwnership, isPending: isTransferring } = useTransferOwnership(workspaceId);

  // 초대 폼 상태
  const [inviteEmail, setInviteEmail] = useState("");
  const [inviteRole, setInviteRole] = useState("member");
  const [showInviteForm, setShowInviteForm] = useState(false);

  // 소유권 이전 모달 상태
  const [showTransferModal, setShowTransferModal] = useState(false);
  const [transferTargetId, setTransferTargetId] = useState("");

  // 현재 사용자 (is_current_user=true인 멤버)
  const currentMember = members?.find((m) => m.is_current_user);
  const isOwner = currentMember?.role === "owner";

  // 멤버 초대 핸들러
  function handleInvite() {
    if (!inviteEmail.trim()) { toast.error("이메일을 입력해주세요."); return; }
    invite({ email: inviteEmail.trim(), role: inviteRole }, {
      onSuccess: (res) => {
        toast.success(res.message);
        setInviteEmail("");
        setShowInviteForm(false);
      },
      onError: (err: any) => toast.error(err?.response?.data?.detail ?? "초대에 실패했습니다."),
    });
  }

  // 역할 변경 핸들러
  function handleRoleChange(userId: string, role: string) {
    updateRole({ userId, role }, {
      onSuccess: () => toast.success("역할이 변경되었습니다."),
      onError: (err: any) => toast.error(err?.response?.data?.detail ?? "역할 변경에 실패했습니다."),
    });
  }

  // 멤버 제거 핸들러
  function handleRemove(userId: string, name: string) {
    if (!confirm(`'${name}' 님을 워크스페이스에서 제거하시겠습니까?`)) return;
    removeMember(userId, {
      onSuccess: () => toast.success(`${name} 님이 제거되었습니다.`),
      onError: (err: any) => toast.error(err?.response?.data?.detail ?? "제거에 실패했습니다."),
    });
  }

  // 소유권 이전 핸들러
  function handleTransfer() {
    if (!transferTargetId) { toast.error("이전 대상을 선택해주세요."); return; }
    if (!confirm("소유권을 이전하면 현재 사용자는 manager로 변경됩니다. 계속하시겠습니까?")) return;
    transferOwnership({ new_owner_id: transferTargetId }, {
      onSuccess: () => {
        toast.success("소유권이 이전되었습니다.");
        setShowTransferModal(false);
        setTransferTargetId("");
      },
      onError: (err: any) => toast.error(err?.response?.data?.detail ?? "소유권 이전에 실패했습니다."),
    });
  }

  return (
    <div style={{ minHeight: "100vh", background: "#0a0a0f", color: "#fff", padding: "32px", fontFamily: "'Pretendard', sans-serif" }}>
      {/* 헤더 */}
      <div style={{ marginBottom: "28px" }}>
        <button onClick={() => router.back()} style={{ display: "flex", alignItems: "center", gap: "6px", background: "none", border: "none", color: "rgba(255,255,255,0.4)", fontSize: "13px", cursor: "pointer", marginBottom: "10px", padding: 0 }}>
          <ArrowLeft size={14} />뒤로 가기
        </button>
        <h1 style={{ fontSize: "24px", fontWeight: 700, margin: "0 0 6px", display: "flex", alignItems: "center", gap: "10px" }}>
          <Users size={22} style={{ color: "#00d4ff" }} />멤버 관리
        </h1>
        <p style={{ color: "rgba(255,255,255,0.4)", margin: 0, fontSize: "14px" }}>워크스페이스 멤버를 초대하고 관리합니다.</p>
      </div>

      {/* 액션 버튼 그룹 */}
      <div style={{ display: "flex", gap: "8px", marginBottom: "20px" }}>
        {(isOwner || currentMember?.role === "manager") && (
          <button onClick={() => setShowInviteForm((v) => !v)} style={{ display: "flex", alignItems: "center", gap: "6px", padding: "8px 16px", borderRadius: "8px", border: "1px solid rgba(0,212,255,0.3)", background: "rgba(0,212,255,0.07)", color: "#00d4ff", fontSize: "13px", cursor: "pointer" }}>
            <UserPlus size={14} />멤버 초대
          </button>
        )}
        {isOwner && (
          <button onClick={() => setShowTransferModal(true)} style={{ display: "flex", alignItems: "center", gap: "6px", padding: "8px 16px", borderRadius: "8px", border: "1px solid rgba(252,211,77,0.3)", background: "rgba(252,211,77,0.07)", color: "#fcd34d", fontSize: "13px", cursor: "pointer" }}>
            <ArrowRightLeft size={14} />소유권 이전
          </button>
        )}
      </div>

      {/* 초대 폼 */}
      {showInviteForm && (
        <div style={{ background: "rgba(0,212,255,0.04)", border: "1px solid rgba(0,212,255,0.12)", borderRadius: "10px", padding: "16px", marginBottom: "20px" }}>
          <p style={{ margin: "0 0 12px", fontSize: "13px", color: "rgba(255,255,255,0.6)", fontWeight: 600 }}>멤버 초대</p>
          <div style={{ display: "flex", gap: "10px", flexWrap: "wrap" }}>
            <input type="email" value={inviteEmail} onChange={(e) => setInviteEmail(e.target.value)} onKeyDown={(e) => e.key === "Enter" && handleInvite()} placeholder="초대할 이메일 주소" style={{ flex: 2, minWidth: "200px", padding: "9px 14px", borderRadius: "8px", border: "1px solid rgba(255,255,255,0.1)", background: "rgba(255,255,255,0.04)", color: "#fff", fontSize: "13px", outline: "none" }} autoFocus />
            <select value={inviteRole} onChange={(e) => setInviteRole(e.target.value)} style={{ flex: 1, minWidth: "120px", padding: "9px 14px", borderRadius: "8px", border: "1px solid rgba(255,255,255,0.1)", background: "#111118", color: "#fff", fontSize: "13px", outline: "none" }}>
              {SELECTABLE_ROLES.map((r) => (
                <option key={r} value={r}>{ROLE_LABELS[r]}</option>
              ))}
            </select>
            <button onClick={handleInvite} disabled={isInviting} style={{ padding: "9px 18px", borderRadius: "8px", border: "1px solid rgba(0,212,255,0.4)", background: "rgba(0,212,255,0.12)", color: "#00d4ff", fontSize: "13px", fontWeight: 600, cursor: isInviting ? "not-allowed" : "pointer", opacity: isInviting ? 0.6 : 1, whiteSpace: "nowrap" }}>
              {isInviting ? "초대 중..." : "초대"}
            </button>
          </div>
          <p style={{ margin: "8px 0 0", fontSize: "12px", color: "rgba(255,255,255,0.3)" }}>미가입 이메일은 초대 메일이 발송됩니다. (현재 Mock 처리)</p>
        </div>
      )}

      {/* 멤버 목록 */}
      <div style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: "12px", overflow: "hidden" }}>
        {/* 테이블 헤더 */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 220px 140px 80px", padding: "10px 16px", background: "rgba(255,255,255,0.03)", borderBottom: "1px solid rgba(255,255,255,0.06)" }}>
          {["멤버", "이메일", "역할", "액션"].map((col) => (
            <span key={col} style={{ fontSize: "11px", color: "rgba(255,255,255,0.3)", fontWeight: 600, letterSpacing: "0.04em", textAlign: col === "액션" ? "center" : "left" }}>{col}</span>
          ))}
        </div>

        {isLoading ? (
          <div style={{ padding: "40px", textAlign: "center", color: "rgba(255,255,255,0.3)", fontSize: "13px" }}>멤버 목록을 불러오는 중...</div>
        ) : !members || members.length === 0 ? (
          <div style={{ padding: "40px", textAlign: "center", color: "rgba(255,255,255,0.3)", fontSize: "13px" }}>멤버가 없습니다.</div>
        ) : (
          members.map((member, idx) => (
            <div key={member.id} style={{ display: "grid", gridTemplateColumns: "1fr 220px 140px 80px", padding: "12px 16px", borderBottom: idx < members.length - 1 ? "1px solid rgba(255,255,255,0.05)" : "none", alignItems: "center", background: member.is_current_user ? "rgba(0,212,255,0.03)" : "transparent" }}>
              {/* 이름 */}
              <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                <div style={{ width: "34px", height: "34px", borderRadius: "50%", background: `${ROLE_COLORS[member.role] ?? "#a3a3a3"}20`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "13px", fontWeight: 700, color: ROLE_COLORS[member.role] ?? "#a3a3a3", flexShrink: 0 }}>
                  {member.name?.[0]?.toUpperCase() ?? "?"}
                </div>
                <div>
                  <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
                    <span style={{ fontSize: "13px", fontWeight: 600, color: "rgba(255,255,255,0.85)" }}>{member.name}</span>
                    {member.is_current_user && <span style={{ padding: "1px 6px", borderRadius: "4px", fontSize: "10px", background: "rgba(0,212,255,0.1)", color: "#00d4ff" }}>나</span>}
                  </div>
                  <span style={{ fontSize: "11px", color: "rgba(255,255,255,0.3)" }}>{new Date(member.joined_at).toLocaleDateString("ko-KR")} 합류</span>
                </div>
              </div>

              {/* 이메일 */}
              <span style={{ fontSize: "12px", color: "rgba(255,255,255,0.4)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{member.email}</span>

              {/* 역할 */}
              <div>
                {isOwner && !member.is_current_user && member.role !== "owner" ? (
                  <select value={member.role} onChange={(e) => handleRoleChange(member.id, e.target.value)} disabled={isUpdatingRole} style={{ padding: "5px 10px", borderRadius: "6px", border: `1px solid ${ROLE_COLORS[member.role] ?? "#a3a3a3"}40`, background: `${ROLE_COLORS[member.role] ?? "#a3a3a3"}10`, color: ROLE_COLORS[member.role] ?? "#a3a3a3", fontSize: "12px", fontWeight: 600, outline: "none", cursor: "pointer" }}>
                    {SELECTABLE_ROLES.map((r) => (
                      <option key={r} value={r}>{ROLE_LABELS[r]}</option>
                    ))}
                  </select>
                ) : (
                  <div style={{ display: "flex", alignItems: "center", gap: "5px" }}>
                    <RoleIcon role={member.role} />
                    <span style={{ fontSize: "12px", fontWeight: 600, color: ROLE_COLORS[member.role] ?? "#a3a3a3" }}>{ROLE_LABELS[member.role] ?? member.role}</span>
                  </div>
                )}
              </div>

              {/* 액션 */}
              <div style={{ display: "flex", justifyContent: "center" }}>
                {isOwner && !member.is_current_user && (
                  <button onClick={() => handleRemove(member.id, member.name)} disabled={isRemoving} title="멤버 제거" style={{ width: "30px", height: "30px", borderRadius: "6px", border: "1px solid rgba(248,113,113,0.2)", background: "rgba(248,113,113,0.06)", color: "#f87171", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", opacity: isRemoving ? 0.5 : 1 }}>
                    <Trash2 size={13} />
                  </button>
                )}
              </div>
            </div>
          ))
        )}
      </div>

      {/* 소유권 이전 모달 */}
      {showTransferModal && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.7)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 1000 }}>
          <div style={{ background: "#111118", border: "1px solid rgba(255,255,255,0.1)", borderRadius: "14px", padding: "28px", width: "420px", maxWidth: "90vw" }}>
            <h3 style={{ fontSize: "17px", fontWeight: 700, margin: "0 0 8px", display: "flex", alignItems: "center", gap: "8px" }}>
              <ArrowRightLeft size={17} style={{ color: "#fcd34d" }} />소유권 이전
            </h3>
            <p style={{ fontSize: "13px", color: "rgba(255,255,255,0.4)", margin: "0 0 20px" }}>소유권 이전 후 현재 계정은 manager로 변경됩니다.</p>
            <label style={{ fontSize: "13px", color: "rgba(255,255,255,0.55)", marginBottom: "8px", display: "block" }}>새 소유자 선택</label>
            <select value={transferTargetId} onChange={(e) => setTransferTargetId(e.target.value)} style={{ width: "100%", padding: "10px 14px", borderRadius: "8px", border: "1px solid rgba(255,255,255,0.1)", background: "#0a0a0f", color: "#fff", fontSize: "13px", outline: "none", marginBottom: "20px" }}>
              <option value="">-- 선택하세요 --</option>
              {members?.filter((m) => !m.is_current_user).map((m) => (
                <option key={m.id} value={m.id}>{m.name} ({m.email})</option>
              ))}
            </select>
            <div style={{ display: "flex", gap: "10px" }}>
              <button onClick={() => { setShowTransferModal(false); setTransferTargetId(""); }} style={{ flex: 1, padding: "10px", borderRadius: "8px", border: "1px solid rgba(255,255,255,0.1)", background: "transparent", color: "rgba(255,255,255,0.5)", fontSize: "13px", cursor: "pointer" }}>취소</button>
              <button onClick={handleTransfer} disabled={isTransferring || !transferTargetId} style={{ flex: 1, padding: "10px", borderRadius: "8px", border: "1px solid rgba(252,211,77,0.4)", background: "rgba(252,211,77,0.1)", color: "#fcd34d", fontSize: "13px", fontWeight: 600, cursor: isTransferring || !transferTargetId ? "not-allowed" : "pointer", opacity: isTransferring || !transferTargetId ? 0.5 : 1 }}>
                {isTransferring ? "이전 중..." : "소유권 이전"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
