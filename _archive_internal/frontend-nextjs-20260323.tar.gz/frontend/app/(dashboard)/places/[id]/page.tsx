"use client";

/**
 * 장소 상세 페이지 (Sprint 4 완성)
 *
 * 탭 3개:
 *   - 키워드 탭: 목록 테이블 + 추가/수정/삭제 모달 + 지금 크롤링 버튼
 *   - 순위 현황 탭: Recharts LineChart (기간 선택)
 *   - 주문 이력 탭: 최근 주문 목록
 */
import { useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import { toast } from "sonner";
import {
  ArrowLeft,
  ExternalLink,
  Edit3,
  Trash2,
  Plus,
  Loader2,
  Clock,
  RefreshCw,
} from "lucide-react";
import { usePlace, useUpdatePlace, useDeletePlace } from "@/hooks/usePlaces";
import {
  useKeywords,
  useDeleteKeyword,
  useUpdateKeyword,
  usePlaceRankingSummary,
  useCrawlNow,
} from "@/hooks/useKeywords";
import { useAuthStore } from "@/store/authStore";
import { StatusBadge } from "@/components/common/StatusBadge";
import EmptyState from "@/components/common/EmptyState";
import LoadingSpinner from "@/components/common/LoadingSpinner";
import DeletePlaceModal from "@/components/places/DeletePlaceModal";
import KeywordTable from "@/components/keywords/KeywordTable";
import AddKeywordModal from "@/components/keywords/AddKeywordModal";
import RankingChart from "@/components/rankings/RankingChart";
import type { PlaceDetail } from "@/hooks/usePlaces";
import type { KeywordWithRank } from "@/hooks/useKeywords";
import { useAuthStore as useStore } from "@/store/authStore";

// ============================
// 탭 타입
// ============================

type TabKey = "keywords" | "rankings" | "orders";

// ============================
// 별칭 수정 모달
// ============================

interface EditAliasModalProps {
  currentAlias: string;
  onSave: (alias: string) => Promise<void>;
  onClose: () => void;
  isSaving: boolean;
}

function EditAliasModal({
  currentAlias,
  onSave,
  onClose,
  isSaving,
}: EditAliasModalProps) {
  const [value, setValue] = useState(currentAlias);

  return (
    <>
      <div
        className="fixed inset-0 z-50"
        style={{ background: "rgba(0,0,0,0.6)", backdropFilter: "blur(4px)" }}
        onClick={onClose}
      />
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        <div
          className="w-full max-w-sm rounded-2xl p-6"
          style={{
            background: "linear-gradient(135deg, #1a1a2e 0%, #16213e 100%)",
            border: "1px solid rgba(255,255,255,0.1)",
          }}
          onClick={(e) => e.stopPropagation()}
        >
          <h3 className="text-base font-semibold text-slate-100 mb-4">
            별칭 수정
          </h3>
          <input
            type="text"
            value={value}
            onChange={(e) => setValue(e.target.value)}
            maxLength={50}
            className="w-full rounded-xl px-4 py-2.5 text-sm text-slate-100 placeholder:text-slate-600 outline-none mb-4"
            style={{
              background: "rgba(255,255,255,0.06)",
              border: "1px solid rgba(255,255,255,0.1)",
            }}
            onFocus={(e) => {
              e.currentTarget.style.borderColor = "#00d4ff";
              e.currentTarget.style.boxShadow =
                "0 0 0 3px rgba(0,212,255,0.1)";
            }}
            onBlur={(e) => {
              e.currentTarget.style.borderColor = "rgba(255,255,255,0.1)";
              e.currentTarget.style.boxShadow = "none";
            }}
            placeholder="별칭 입력 (예: 강남점, 본점)"
            autoFocus
            disabled={isSaving}
          />
          <div className="flex gap-3">
            <button
              type="button"
              onClick={onClose}
              disabled={isSaving}
              className="flex-1 py-2 rounded-xl text-sm font-medium transition-all disabled:opacity-50"
              style={{
                background: "rgba(255,255,255,0.06)",
                border: "1px solid rgba(255,255,255,0.1)",
                color: "#94a3b8",
              }}
            >
              취소
            </button>
            <button
              type="button"
              onClick={() => onSave(value.trim())}
              disabled={isSaving}
              className="flex-1 py-2 rounded-xl text-sm font-semibold transition-all disabled:opacity-50 flex items-center justify-center gap-2"
              style={{ background: "#00d4ff", color: "#0a0a0f" }}
            >
              {isSaving ? (
                <Loader2 size={14} className="animate-spin" />
              ) : (
                "저장"
              )}
            </button>
          </div>
        </div>
      </div>
    </>
  );
}

// ============================
// 키워드 수정 모달 (간단 인라인)
// ============================

interface EditKeywordModalProps {
  keyword: KeywordWithRank;
  placeId: string;
  onClose: () => void;
}

function EditKeywordModal({
  keyword,
  placeId,
  onClose,
}: EditKeywordModalProps) {
  const [isPrimary, setIsPrimary] = useState(keyword.is_primary);
  const [groupName, setGroupName] = useState(keyword.group_name ?? "");
  const updateMutation = useUpdateKeyword(placeId, keyword.id);

  const handleSave = async () => {
    try {
      await updateMutation.mutateAsync({
        is_primary: isPrimary,
        group_name: groupName.trim() || undefined,
      });
      toast.success("키워드가 수정되었습니다");
      onClose();
    } catch (error) {
      const msg =
        error instanceof Error ? error.message : "수정 중 오류가 발생했습니다";
      toast.error(msg);
    }
  };

  return (
    <>
      <div
        className="fixed inset-0 z-50"
        style={{ background: "rgba(0,0,0,0.6)", backdropFilter: "blur(4px)" }}
        onClick={onClose}
      />
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        <div
          className="w-full max-w-sm rounded-2xl p-6"
          style={{
            background: "linear-gradient(135deg, #1a1a2e 0%, #16213e 100%)",
            border: "1px solid rgba(255,255,255,0.1)",
          }}
          onClick={(e) => e.stopPropagation()}
        >
          <h3 className="text-base font-semibold text-slate-100 mb-1">
            키워드 수정
          </h3>
          <p className="text-xs text-slate-500 mb-5">
            &ldquo;{keyword.keyword}&rdquo;
          </p>

          {/* 주요 키워드 토글 */}
          <div className="flex items-center justify-between mb-4">
            <p className="text-sm text-slate-300">주요 키워드</p>
            <button
              type="button"
              onClick={() => setIsPrimary(!isPrimary)}
              className="relative w-11 h-6 rounded-full transition-all"
              style={{
                background: isPrimary
                  ? "#00d4ff"
                  : "rgba(255,255,255,0.12)",
              }}
            >
              <span
                className="absolute top-0.5 w-5 h-5 rounded-full transition-all"
                style={{
                  left: isPrimary ? "calc(100% - 22px)" : "2px",
                  background: "#fff",
                  boxShadow: "0 1px 3px rgba(0,0,0,0.3)",
                }}
              />
            </button>
          </div>

          {/* 그룹명 */}
          <div className="mb-5">
            <label className="block text-sm text-slate-300 mb-1.5">
              그룹명{" "}
              <span className="text-slate-500 text-xs">(선택)</span>
            </label>
            <input
              type="text"
              value={groupName}
              onChange={(e) => setGroupName(e.target.value)}
              maxLength={50}
              className="w-full rounded-xl px-4 py-2.5 text-sm text-slate-100 placeholder:text-slate-600 outline-none"
              style={{
                background: "rgba(255,255,255,0.06)",
                border: "1px solid rgba(255,255,255,0.1)",
              }}
              onFocus={(e) => {
                e.currentTarget.style.borderColor = "#00d4ff";
              }}
              onBlur={(e) => {
                e.currentTarget.style.borderColor = "rgba(255,255,255,0.1)";
              }}
              placeholder="예: 브랜드, 지역"
            />
          </div>

          {/* 버튼 */}
          <div className="flex gap-3">
            <button
              type="button"
              onClick={onClose}
              disabled={updateMutation.isPending}
              className="flex-1 py-2 rounded-xl text-sm font-medium disabled:opacity-50"
              style={{
                background: "rgba(255,255,255,0.06)",
                border: "1px solid rgba(255,255,255,0.1)",
                color: "#94a3b8",
              }}
            >
              취소
            </button>
            <button
              type="button"
              onClick={handleSave}
              disabled={updateMutation.isPending}
              className="flex-1 py-2 rounded-xl text-sm font-semibold disabled:opacity-50 flex items-center justify-center gap-2"
              style={{ background: "#00d4ff", color: "#0a0a0f" }}
            >
              {updateMutation.isPending ? (
                <Loader2 size={14} className="animate-spin" />
              ) : (
                "저장"
              )}
            </button>
          </div>
        </div>
      </div>
    </>
  );
}

// ============================
// 메인 컴포넌트
// ============================

export default function PlaceDetailPage() {
  const params = useParams();
  const router = useRouter();
  const placeId = (params?.id as string) ?? "";
  const { workspace } = useAuthStore();
  const workspaceId = workspace?.id ?? "";
  const plan = workspace?.plan ?? "free";

  // 탭 + 모달 상태
  const [activeTab, setActiveTab] = useState<TabKey>("keywords");
  const [showEditAlias, setShowEditAlias] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [showAddKeyword, setShowAddKeyword] = useState(false);
  const [editingKeyword, setEditingKeyword] = useState<KeywordWithRank | null>(null);

  // 데이터 조회
  const { data: place, isLoading, isError, error } = usePlace(placeId);
  const { data: keywordData, isLoading: keywordsLoading } = useKeywords(placeId);
  const { data: rankingSummary } = usePlaceRankingSummary(placeId);

  const updateMutation = useUpdatePlace(placeId);
  const deleteKeywordMutation = useDeleteKeyword(placeId);
  const crawlNowMutation = useCrawlNow(placeId);

  // ── 플랜 키워드 한도 ──────────────────────────────────────
  const KEYWORD_LIMITS: Record<string, number> = {
    free: 5,
    starter: 30,
    pro: 100,
    enterprise: 999,
  };
  const maxKeywords = KEYWORD_LIMITS[plan] ?? 5;
  const currentKeywordCount = keywordData?.total ?? 0;
  const isKeywordAtLimit = currentKeywordCount >= maxKeywords;
  const isKeywordNearLimit =
    !isKeywordAtLimit && currentKeywordCount >= maxKeywords * 0.8;

  // 기존 그룹명 목록
  const existingGroups = Array.from(
    new Set(
      (keywordData?.items ?? [])
        .map((kw) => kw.group_name)
        .filter((g): g is string => !!g)
    )
  );

  // ── 별칭 저장 ─────────────────────────────────────────────
  const handleSaveAlias = async (alias: string) => {
    try {
      await updateMutation.mutateAsync({ alias });
      toast.success("별칭이 수정되었습니다");
      setShowEditAlias(false);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "수정 중 오류");
    }
  };

  // ── 키워드 삭제 ──────────────────────────────────────────
  const handleDeleteKeyword = async (keywordId: string) => {
    if (!window.confirm("이 키워드를 삭제하시겠습니까?")) return;
    try {
      await deleteKeywordMutation.mutateAsync(keywordId);
      toast.success("키워드가 삭제되었습니다");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "삭제 중 오류");
    }
  };

  // ── 수동 크롤링 ──────────────────────────────────────────
  const handleCrawlNow = async () => {
    try {
      const result = await crawlNowMutation.mutateAsync();
      toast.success(result.message);
    } catch (err) {
      const msg = err instanceof Error ? err.message : "크롤링 중 오류";
      toast.error(msg);
    }
  };

  // ── 삭제 후 리다이렉트 ────────────────────────────────────
  const handleDeleted = () => {
    router.push("/places");
  };

  // ── 로딩 ─────────────────────────────────────────────────
  if (isLoading) {
    return (
      <div className="p-6 max-w-4xl mx-auto flex justify-center py-20">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  // ── 에러 ─────────────────────────────────────────────────
  if (isError || !place) {
    return (
      <div className="p-6 max-w-4xl mx-auto">
        <div
          className="rounded-xl p-6 text-center"
          style={{
            background: "rgba(239,68,68,0.08)",
            border: "1px solid rgba(239,68,68,0.2)",
          }}
        >
          <p className="text-red-400 font-medium mb-1">
            장소를 불러오지 못했습니다
          </p>
          <p className="text-xs text-slate-500">
            {error instanceof Error
              ? error.message
              : "잠시 후 다시 시도해주세요"}
          </p>
        </div>
      </div>
    );
  }

  const displayName = place.alias || place.name;
  const naverUrl = `https://map.naver.com/v5/entry/place/${place.naver_place_id}`;

  // ============================
  // 정상 렌더
  // ============================
  return (
    <div className="p-6 max-w-4xl mx-auto">
      {/* 뒤로가기 */}
      <Link
        href="/places"
        className="inline-flex items-center gap-1.5 text-sm mb-6 transition-colors"
        style={{ color: "#00d4ff" }}
      >
        <ArrowLeft size={15} />
        장소 목록
      </Link>

      {/* 헤더 */}
      <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 mb-6">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-2xl">🏪</span>
            <h1 className="text-xl font-bold text-slate-100">{displayName}</h1>
          </div>
          {place.category && (
            <p className="text-sm text-slate-400">{place.category}</p>
          )}
        </div>

        {/* 액션 버튼 그룹 */}
        <div className="flex items-center gap-2 flex-shrink-0 flex-wrap">
          <a
            href={naverUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium transition-all"
            style={{
              background: "rgba(255,255,255,0.06)",
              border: "1px solid rgba(255,255,255,0.1)",
              color: "#94a3b8",
            }}
          >
            <ExternalLink size={13} />
            네이버 플레이스
          </a>

          <button
            type="button"
            onClick={() => setShowEditAlias(true)}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium transition-all"
            style={{
              background: "rgba(255,255,255,0.06)",
              border: "1px solid rgba(255,255,255,0.1)",
              color: "#94a3b8",
            }}
          >
            <Edit3 size={13} />
            수정
          </button>

          <button
            type="button"
            onClick={() => setShowDeleteModal(true)}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium transition-all"
            style={{
              background: "rgba(239,68,68,0.1)",
              border: "1px solid rgba(239,68,68,0.2)",
              color: "#f87171",
            }}
          >
            <Trash2 size={13} />
            삭제
          </button>
        </div>
      </div>

      {/* 장소 정보 카드 */}
      <div
        className="rounded-xl p-4 mb-6 grid grid-cols-2 sm:grid-cols-4 gap-4"
        style={{
          background: "rgba(255,255,255,0.03)",
          border: "1px solid rgba(255,255,255,0.07)",
        }}
      >
        <div>
          <p className="text-xs text-slate-500 mb-1">Place ID</p>
          <p className="text-sm text-slate-200 font-mono">
            {place.naver_place_id}
          </p>
        </div>
        <div>
          <p className="text-xs text-slate-500 mb-1">카테고리</p>
          <p className="text-sm text-slate-200">{place.category || "–"}</p>
        </div>
        <div>
          <p className="text-xs text-slate-500 mb-1">등록일</p>
          <p className="text-sm text-slate-200">
            {new Date(place.created_at).toLocaleDateString("ko-KR")}
          </p>
        </div>
        <div>
          <p className="text-xs text-slate-500 mb-1">상태</p>
          <span
            className="inline-block text-xs px-2 py-0.5 rounded-full font-medium"
            style={
              place.is_active
                ? {
                    background: "rgba(34,197,94,0.12)",
                    color: "#4ade80",
                    border: "1px solid rgba(34,197,94,0.2)",
                  }
                : {
                    background: "rgba(107,114,128,0.12)",
                    color: "#9ca3af",
                    border: "1px solid rgba(107,114,128,0.2)",
                  }
            }
          >
            {place.is_active ? "활성" : "비활성"}
          </span>
        </div>
      </div>

      {/* 탭 네비게이션 */}
      <div
        className="flex border-b mb-6"
        style={{ borderColor: "rgba(255,255,255,0.08)" }}
      >
        {(
          [
            {
              key: "keywords",
              label: `키워드 (${currentKeywordCount})`,
            },
            { key: "rankings", label: "순위 현황" },
            {
              key: "orders",
              label: `주문 이력 (${place.recent_orders.length})`,
            },
          ] as { key: TabKey; label: string }[]
        ).map((tab) => (
          <button
            key={tab.key}
            type="button"
            onClick={() => setActiveTab(tab.key)}
            className="px-4 py-2.5 text-sm font-medium transition-all relative"
            style={{
              color: activeTab === tab.key ? "#00d4ff" : "#64748b",
              borderBottom:
                activeTab === tab.key
                  ? "2px solid #00d4ff"
                  : "2px solid transparent",
              marginBottom: -1,
            }}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* ── 키워드 탭 ──────────────────────────────────────── */}
      {activeTab === "keywords" && (
        <div>
          {/* 탭 헤더 */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5">
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-medium text-slate-300">
                등록된 키워드
              </h3>
              {/* 한도 사용량 */}
              <span
                className="text-xs px-2 py-0.5 rounded-full font-medium"
                style={
                  isKeywordAtLimit
                    ? {
                        background: "rgba(239,68,68,0.12)",
                        color: "#f87171",
                        border: "1px solid rgba(239,68,68,0.2)",
                      }
                    : isKeywordNearLimit
                    ? {
                        background: "rgba(245,158,11,0.12)",
                        color: "#fcd34d",
                        border: "1px solid rgba(245,158,11,0.2)",
                      }
                    : {
                        background: "rgba(255,255,255,0.06)",
                        color: "#94a3b8",
                        border: "1px solid rgba(255,255,255,0.1)",
                      }
                }
              >
                {currentKeywordCount} /{" "}
                {maxKeywords === 999 ? "무제한" : `${maxKeywords}개`}
              </span>
              {isKeywordAtLimit && (
                <Link
                  href="/billing/upgrade"
                  className="text-xs font-medium"
                  style={{ color: "#f87171" }}
                >
                  업그레이드 →
                </Link>
              )}
            </div>

            <div className="flex items-center gap-2">
              {/* 지금 크롤링 버튼 */}
              <button
                type="button"
                onClick={handleCrawlNow}
                disabled={
                  crawlNowMutation.isPending || currentKeywordCount === 0
                }
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium transition-all disabled:opacity-50"
                style={{
                  background: "rgba(255,255,255,0.06)",
                  border: "1px solid rgba(255,255,255,0.1)",
                  color: "#94a3b8",
                }}
              >
                {crawlNowMutation.isPending ? (
                  <Loader2 size={12} className="animate-spin" />
                ) : (
                  <RefreshCw size={12} />
                )}
                지금 크롤링
              </button>

              {/* 키워드 추가 버튼 */}
              <button
                type="button"
                onClick={() => setShowAddKeyword(true)}
                disabled={isKeywordAtLimit}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all disabled:opacity-40 disabled:cursor-not-allowed"
                style={
                  isKeywordAtLimit
                    ? {
                        background: "rgba(107,114,128,0.2)",
                        color: "#6b7280",
                      }
                    : {
                        background: "rgba(0,212,255,0.1)",
                        color: "#00d4ff",
                        border: "1px solid rgba(0,212,255,0.2)",
                      }
                }
              >
                <Plus size={12} />
                키워드 추가
              </button>
            </div>
          </div>

          {/* 키워드 테이블 or EmptyState */}
          {keywordData?.items && keywordData.items.length > 0 ? (
            <KeywordTable
              keywords={keywordData.items}
              onEdit={(kw) => setEditingKeyword(kw)}
              onDelete={handleDeleteKeyword}
              isLoading={keywordsLoading}
            />
          ) : keywordsLoading ? (
            <div className="py-10 flex justify-center">
              <LoadingSpinner size="md" />
            </div>
          ) : (
            <EmptyState
              icon="🔑"
              title="등록된 키워드가 없습니다"
              description="키워드를 등록하면 매일 자동으로 네이버 순위를 추적합니다"
              action={
                <button
                  type="button"
                  onClick={() => setShowAddKeyword(true)}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold"
                  style={{ background: "#00d4ff", color: "#0a0a0f" }}
                >
                  <Plus size={14} />
                  첫 키워드 등록하기
                </button>
              }
            />
          )}
        </div>
      )}

      {/* ── 순위 현황 탭 ──────────────────────────────────── */}
      {activeTab === "rankings" && (
        <div>
          {rankingSummary && rankingSummary.keywords.length > 0 ? (
            <RankingChart
              keywords={rankingSummary.keywords}
              placeId={placeId}
            />
          ) : (
            <div
              className="rounded-xl p-10 text-center"
              style={{
                background: "rgba(255,255,255,0.02)",
                border: "1px solid rgba(255,255,255,0.06)",
              }}
            >
              <p className="text-3xl mb-3">📊</p>
              <p className="text-slate-300 font-medium mb-1">
                등록된 키워드가 없습니다
              </p>
              <p className="text-xs text-slate-500 mb-4">
                키워드를 등록하고 크롤링을 실행하면 순위 추이를 확인할 수
                있습니다
              </p>
              <button
                type="button"
                onClick={() => setActiveTab("keywords")}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold"
                style={{ background: "#00d4ff", color: "#0a0a0f" }}
              >
                키워드 탭으로 이동
              </button>
            </div>
          )}
        </div>
      )}

      {/* ── 주문 이력 탭 ──────────────────────────────────── */}
      {activeTab === "orders" && (
        <div>
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-sm font-medium text-slate-300">최근 주문</h3>
            <Link
              href={`/orders/new?place_id=${placeId}`}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all"
              style={{
                background: "rgba(0,212,255,0.1)",
                color: "#00d4ff",
                border: "1px solid rgba(0,212,255,0.2)",
              }}
            >
              <Plus size={12} />
              주문하기
            </Link>
          </div>

          {place.recent_orders.length === 0 ? (
            <EmptyState
              icon="📦"
              title="주문 내역이 없습니다"
              description="이 장소에 대한 마케팅 서비스를 주문해 보세요"
              action={
                <Link
                  href={`/orders/new?place_id=${placeId}`}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold"
                  style={{ background: "#00d4ff", color: "#0a0a0f" }}
                >
                  <Plus size={14} />
                  주문하기
                </Link>
              }
            />
          ) : (
            <div
              className="rounded-xl overflow-hidden"
              style={{
                background: "rgba(255,255,255,0.03)",
                border: "1px solid rgba(255,255,255,0.07)",
              }}
            >
              {place.recent_orders.map((order, idx) => (
                <Link
                  key={order.id}
                  href={`/orders/${order.id}`}
                  className="flex items-center justify-between px-5 py-3.5 transition-colors"
                  style={{
                    borderBottom:
                      idx < place.recent_orders.length - 1
                        ? "1px solid rgba(255,255,255,0.05)"
                        : "none",
                  }}
                  onMouseEnter={(e) => {
                    (e.currentTarget as HTMLAnchorElement).style.background =
                      "rgba(255,255,255,0.03)";
                  }}
                  onMouseLeave={(e) => {
                    (e.currentTarget as HTMLAnchorElement).style.background =
                      "transparent";
                  }}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <StatusBadge status={order.status as any} />
                    <span className="text-sm text-slate-200 truncate">
                      {order.product_name}
                    </span>
                  </div>
                  <div className="flex items-center gap-3 flex-shrink-0">
                    <span className="text-sm font-semibold text-slate-300">
                      {order.total_amount.toLocaleString("ko-KR")}원
                    </span>
                    {order.ordered_at && (
                      <span className="text-xs text-slate-500 hidden sm:flex items-center gap-1">
                        <Clock size={11} />
                        {new Date(order.ordered_at).toLocaleDateString("ko-KR")}
                      </span>
                    )}
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ── 모달들 ─────────────────────────────────────────── */}

      {/* 별칭 수정 */}
      {showEditAlias && (
        <EditAliasModal
          currentAlias={place.alias ?? ""}
          onSave={handleSaveAlias}
          onClose={() => setShowEditAlias(false)}
          isSaving={updateMutation.isPending}
        />
      )}

      {/* 키워드 추가 */}
      {showAddKeyword && (
        <AddKeywordModal
          placeId={placeId}
          existingGroups={existingGroups}
          isOpen={showAddKeyword}
          onClose={() => setShowAddKeyword(false)}
        />
      )}

      {/* 키워드 수정 */}
      {editingKeyword && (
        <EditKeywordModal
          keyword={editingKeyword}
          placeId={placeId}
          onClose={() => setEditingKeyword(null)}
        />
      )}

      {/* 장소 삭제 */}
      {showDeleteModal && (
        <DeletePlaceModal
          place={{
            ...place,
            latest_rankings: place.keywords,
          }}
          workspaceId={workspaceId}
          onClose={() => setShowDeleteModal(false)}
          onDeleted={handleDeleted}
        />
      )}
    </div>
  );
}
