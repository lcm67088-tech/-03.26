"use client";

/**
 * 장소 관리 목록 페이지 (Sprint 3 완성)
 *
 * - 플랜별 사용량 배지
 * - 한도 초과 배너
 * - 카드 그리드 (1→2→3 반응형)
 * - 삭제 모달 (DeletePlaceModal)
 * - 스켈레톤 로딩, 에러 처리
 */
import Link from "next/link";
import { useState } from "react";
import { Plus, AlertTriangle, Loader2 } from "lucide-react";
import { useAuthStore } from "@/store/authStore";
import { usePlaces } from "@/hooks/usePlaces";
import PlaceCard from "@/components/places/PlaceCard";
import DeletePlaceModal from "@/components/places/DeletePlaceModal";
import EmptyState from "@/components/common/EmptyState";
import type { PlaceListItem } from "@/hooks/usePlaces";

// ============================
// 플랜별 한도 (FE 로컬 상수)
// ============================

const PLAN_LIMITS: Record<string, { max_places: number }> = {
  free: { max_places: 1 },
  starter: { max_places: 5 },
  pro: { max_places: 20 },
  enterprise: { max_places: 999 },
};

// ============================
// 스켈레톤
// ============================

function PlaceCardSkeleton() {
  return (
    <div
      className="rounded-xl p-5 animate-pulse flex flex-col gap-4"
      style={{
        background: "rgba(255,255,255,0.04)",
        border: "1px solid rgba(255,255,255,0.08)",
        minHeight: 200,
      }}
    >
      <div className="flex justify-between">
        <div className="flex items-center gap-2">
          <div
            className="w-7 h-7 rounded"
            style={{ background: "rgba(255,255,255,0.08)" }}
          />
          <div
            className="h-4 w-32 rounded"
            style={{ background: "rgba(255,255,255,0.08)" }}
          />
        </div>
        <div
          className="h-5 w-12 rounded-full"
          style={{ background: "rgba(255,255,255,0.06)" }}
        />
      </div>
      <div
        className="h-3 w-40 rounded"
        style={{ background: "rgba(255,255,255,0.06)" }}
      />
      <div className="flex flex-wrap gap-2">
        {[1, 2, 3].map((i) => (
          <div
            key={i}
            className="h-6 w-20 rounded-full"
            style={{ background: "rgba(255,255,255,0.06)" }}
          />
        ))}
      </div>
      <div className="flex justify-end gap-2 mt-auto">
        <div
          className="h-7 w-20 rounded-lg"
          style={{ background: "rgba(255,255,255,0.06)" }}
        />
        <div
          className="h-7 w-14 rounded-lg"
          style={{ background: "rgba(255,255,255,0.06)" }}
        />
      </div>
    </div>
  );
}

// ============================
// 메인 컴포넌트
// ============================

export default function PlacesPage() {
  const { workspace } = useAuthStore();
  const workspaceId = workspace?.id ?? "";
  const plan = workspace?.plan ?? "free";
  const limits = PLAN_LIMITS[plan] ?? PLAN_LIMITS.free;
  const isEnterprise = plan === "enterprise";

  // 삭제 모달 상태
  const [deleteTarget, setDeleteTarget] = useState<PlaceListItem | null>(null);

  const { data, isLoading, isError, error } = usePlaces(workspaceId);

  const totalPlaces = data?.total ?? 0;
  const isAtLimit = !isEnterprise && (data?.total ?? 0) >= limits.max_places;
  const isNearLimit =
    !isEnterprise &&
    !isAtLimit &&
    (data?.total ?? 0) >= limits.max_places * 0.8;

  // ============================
  // 로딩
  // ============================
  if (isLoading) {
    return (
      <div className="p-6 max-w-7xl mx-auto">
        {/* 헤더 스켈레톤 */}
        <div className="flex justify-between items-center mb-6">
          <div
            className="h-7 w-24 rounded animate-pulse"
            style={{ background: "rgba(255,255,255,0.08)" }}
          />
          <div className="flex items-center gap-3">
            <div
              className="h-6 w-16 rounded-full animate-pulse"
              style={{ background: "rgba(255,255,255,0.06)" }}
            />
            <div
              className="h-9 w-28 rounded-xl animate-pulse"
              style={{ background: "rgba(255,255,255,0.08)" }}
            />
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1, 2, 3].map((i) => (
            <PlaceCardSkeleton key={i} />
          ))}
        </div>
      </div>
    );
  }

  // ============================
  // 에러
  // ============================
  if (isError) {
    return (
      <div className="p-6 max-w-7xl mx-auto">
        <div
          className="rounded-xl p-6 text-center"
          style={{
            background: "rgba(239,68,68,0.08)",
            border: "1px solid rgba(239,68,68,0.2)",
          }}
        >
          <p className="text-red-400 font-medium mb-1">
            장소 목록을 불러오지 못했습니다
          </p>
          <p className="text-xs text-slate-500">
            {error instanceof Error ? error.message : "잠시 후 다시 시도해주세요"}
          </p>
        </div>
      </div>
    );
  }

  // ============================
  // 정상 렌더
  // ============================
  return (
    <div className="p-6 max-w-7xl mx-auto">
      {/* 페이지 헤더 */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <h1 className="text-xl font-bold text-slate-100">장소 관리</h1>

        <div className="flex items-center gap-3">
          {/* 사용량 배지 */}
          <span
            className="text-xs px-3 py-1.5 rounded-full font-medium"
            style={
              isAtLimit
                ? {
                    background: "rgba(239,68,68,0.15)",
                    color: "#f87171",
                    border: "1px solid rgba(239,68,68,0.2)",
                  }
                : isNearLimit
                ? {
                    background: "rgba(245,158,11,0.15)",
                    color: "#fcd34d",
                    border: "1px solid rgba(245,158,11,0.2)",
                  }
                : {
                    background: "rgba(255,255,255,0.08)",
                    color: "#94a3b8",
                    border: "1px solid rgba(255,255,255,0.1)",
                  }
            }
          >
            {data?.total ?? 0} / {isEnterprise ? "무제한" : `${limits.max_places}개`}
          </span>

          {/* 장소 등록 버튼 */}
          <Link
            href="/places/new"
            className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold transition-all"
            style={
              isAtLimit
                ? {
                    background: "rgba(107,114,128,0.3)",
                    color: "#6b7280",
                    cursor: "not-allowed",
                    pointerEvents: "none",
                  }
                : { background: "#00d4ff", color: "#0a0a0f" }
            }
          >
            <Plus size={15} />
            장소 등록
          </Link>
        </div>
      </div>

      {/* 한도 초과 배너 */}
      {isAtLimit && (
        <div
          className="flex items-center justify-between gap-4 p-4 rounded-xl mb-6"
          style={{
            background: "rgba(245,158,11,0.08)",
            border: "1px solid rgba(245,158,11,0.2)",
          }}
        >
          <div className="flex items-center gap-2 text-sm">
            <AlertTriangle size={16} style={{ color: "#fcd34d", flexShrink: 0 }} />
            <span style={{ color: "#fcd34d" }}>
              🔒 {plan.charAt(0).toUpperCase() + plan.slice(1)} 플랜 장소 한도(
              {limits.max_places}개)에 도달했습니다. 업그레이드하면 더 많은 장소를
              등록할 수 있어요.
            </span>
          </div>
          <Link
            href="/billing/upgrade"
            className="flex-shrink-0 text-xs px-3 py-1.5 rounded-lg font-semibold transition-all"
            style={{
              background: "rgba(245,158,11,0.2)",
              color: "#fcd34d",
              border: "1px solid rgba(245,158,11,0.3)",
              whiteSpace: "nowrap",
            }}
          >
            플랜 업그레이드
          </Link>
        </div>
      )}

      {/* 장소 없음 → EmptyState */}
      {(!data?.items || data.items.length === 0) ? (
        <EmptyState
          icon="🏪"
          title="등록된 장소가 없습니다"
          description="네이버 플레이스 URL을 등록하고 순위 모니터링을 시작해보세요"
          action={
            <Link
              href="/places/new"
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold transition-all"
              style={{ background: "#00d4ff", color: "#0a0a0f" }}
            >
              <Plus size={14} />
              첫 장소 등록하기
            </Link>
          }
        />
      ) : (
        /* 장소 카드 그리드 */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {data.items.map((place) => (
            <PlaceCard
              key={place.id}
              place={place}
              onDelete={(p) => setDeleteTarget(p)}
            />
          ))}
        </div>
      )}

      {/* 삭제 확인 모달 */}
      <DeletePlaceModal
        place={deleteTarget}
        workspaceId={workspaceId}
        onClose={() => setDeleteTarget(null)}
      />
    </div>
  );
}
