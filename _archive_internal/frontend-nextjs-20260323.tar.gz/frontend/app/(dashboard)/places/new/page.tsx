"use client";

/**
 * 새 장소 등록 페이지 (Sprint 3 완성)
 *
 * - 네이버 플레이스 URL 입력 + 실시간 place_id 파싱 미리보기
 * - 별칭 입력 (선택)
 * - React Hook Form + Zod 검증
 * - 에러 처리 (한도 초과, 중복, 잘못된 URL)
 */
import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import Link from "next/link";
import { ArrowLeft, CheckCircle2, XCircle, Loader2, ExternalLink } from "lucide-react";
import { toast } from "sonner";
import { useAuthStore } from "@/store/authStore";
import { useCreatePlace } from "@/hooks/usePlaces";

// ============================
// 네이버 place_id 파싱 (클라이언트용)
// ============================

function extractNaverPlaceId(url: string): string | null {
  const patterns = [
    /map\.naver\.com\/v5\/entry\/place\/(\d+)/,
    /map\.naver\.com\/p\/entry\/place\/(\d+)/,
    /place\.naver\.com\/[^/]+\/(\d+)/,
    /place\.naver\.com\/(\d+)(?:[/?]|$)/,
  ];
  for (const pattern of patterns) {
    const match = url.match(pattern);
    if (match) return match[1];
  }
  return null;
}

// ============================
// Zod 스키마
// ============================

const PlaceCreateSchema = z.object({
  naver_place_url: z
    .string()
    .min(1, "네이버 플레이스 URL을 입력해주세요")
    .url("올바른 URL 형식이 아닙니다"),
  alias: z
    .string()
    .max(50, "별칭은 50자 이하여야 합니다")
    .optional()
    .transform((v) => (v?.trim() === "" ? undefined : v?.trim())),
});

type PlaceCreateForm = z.infer<typeof PlaceCreateSchema>;

// ============================
// URL 파싱 미리보기 상태
// ============================

type ParseStatus = "idle" | "success" | "fail";

// ============================
// 메인 컴포넌트
// ============================

export default function NewPlacePage() {
  const router = useRouter();
  const { workspace } = useAuthStore();
  const workspaceId = workspace?.id ?? "";

  const createMutation = useCreatePlace();

  // URL 파싱 미리보기 상태
  const [parseStatus, setParseStatus] = useState<ParseStatus>("idle");
  const [parsedPlaceId, setParsedPlaceId] = useState<string | null>(null);

  // API 에러 메시지 (한도 초과, 중복 등)
  const [apiError, setApiError] = useState<string | null>(null);
  const [isLimitReached, setIsLimitReached] = useState(false);

  const {
    register,
    handleSubmit,
    watch,
    formState: { errors },
  } = useForm<PlaceCreateForm>({
    resolver: zodResolver(PlaceCreateSchema),
    defaultValues: { naver_place_url: "", alias: "" },
  });

  // ============================
  // URL 실시간 파싱 감시
  // ============================
  const urlValue = watch("naver_place_url");

  useEffect(() => {
    if (!urlValue || urlValue.trim() === "") {
      setParseStatus("idle");
      setParsedPlaceId(null);
      return;
    }

    // 짧은 URL은 일단 무시
    if (urlValue.length < 20) {
      setParseStatus("idle");
      return;
    }

    const id = extractNaverPlaceId(urlValue);
    if (id) {
      setParseStatus("success");
      setParsedPlaceId(id);
    } else {
      setParseStatus("fail");
      setParsedPlaceId(null);
    }
  }, [urlValue]);

  // ============================
  // 폼 제출
  // ============================
  const onSubmit = async (data: PlaceCreateForm) => {
    setApiError(null);
    setIsLimitReached(false);

    try {
      const newPlace = await createMutation.mutateAsync({
        workspace_id: workspaceId,
        naver_place_url: data.naver_place_url,
        alias: data.alias,
      });

      toast.success("장소가 등록되었습니다!");
      router.push(`/places/${newPlace.id}`);
    } catch (error) {
      const msg =
        error instanceof Error ? error.message : "등록 중 오류가 발생했습니다";

      // 한도 초과 여부 판별
      if (msg.includes("플랜은 최대") || msg.includes("업그레이드")) {
        setIsLimitReached(true);
      }
      setApiError(msg);
    }
  };

  const isLoading = createMutation.isPending;

  // ============================
  // 렌더
  // ============================
  return (
    <div className="p-6 max-w-2xl mx-auto">
      {/* 헤더 */}
      <div className="mb-8">
        <Link
          href="/places"
          className="inline-flex items-center gap-1.5 text-sm mb-4 transition-colors"
          style={{ color: "#00d4ff" }}
        >
          <ArrowLeft size={15} />
          장소 목록으로
        </Link>
        <h1 className="text-2xl font-bold text-slate-100">새 장소 등록</h1>
        <p className="text-sm text-slate-400 mt-1">
          네이버 플레이스 URL을 입력해 순위 모니터링을 시작하세요.
        </p>
      </div>

      {/* 폼 카드 */}
      <div
        className="rounded-2xl p-6"
        style={{
          background: "rgba(255,255,255,0.04)",
          border: "1px solid rgba(255,255,255,0.08)",
        }}
      >
        {/* API 에러 배너 */}
        {apiError && (
          <div
            className="flex flex-col gap-2 p-4 rounded-xl mb-5"
            style={
              isLimitReached
                ? {
                    background: "rgba(245,158,11,0.1)",
                    border: "1px solid rgba(245,158,11,0.25)",
                    color: "#fcd34d",
                  }
                : {
                    background: "rgba(239,68,68,0.1)",
                    border: "1px solid rgba(239,68,68,0.25)",
                    color: "#fca5a5",
                  }
            }
          >
            <p className="text-sm font-medium">{apiError}</p>
            {isLimitReached && (
              <Link
                href="/billing/upgrade"
                className="inline-flex items-center gap-1.5 text-xs font-semibold underline"
              >
                플랜 업그레이드 하러가기
                <ExternalLink size={11} />
              </Link>
            )}
          </div>
        )}

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
          {/* ① URL 입력 */}
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-1.5">
              네이버 플레이스 URL
              <span className="text-red-400 ml-0.5">*</span>
            </label>
            <input
              {...register("naver_place_url")}
              type="url"
              className="w-full rounded-xl px-4 py-2.5 text-sm text-slate-100 placeholder:text-slate-600 outline-none transition-all"
              style={{
                background: "rgba(255,255,255,0.06)",
                border: `1px solid ${
                  errors.naver_place_url || parseStatus === "fail"
                    ? "rgba(239,68,68,0.5)"
                    : parseStatus === "success"
                    ? "rgba(34,197,94,0.5)"
                    : "rgba(255,255,255,0.1)"
                }`,
              }}
              onFocus={(e) => {
                if (parseStatus !== "fail" && parseStatus !== "success") {
                  e.currentTarget.style.borderColor = "#00d4ff";
                  e.currentTarget.style.boxShadow =
                    "0 0 0 3px rgba(0,212,255,0.1)";
                }
              }}
              onBlur={(e) => {
                e.currentTarget.style.boxShadow = "none";
              }}
              placeholder="https://map.naver.com/v5/entry/place/12345678"
              disabled={isLoading}
            />

            {/* 파싱 미리보기 */}
            {parseStatus === "success" && parsedPlaceId && (
              <div className="flex items-center gap-1.5 mt-2">
                <CheckCircle2 size={13} style={{ color: "#4ade80" }} />
                <p className="text-xs" style={{ color: "#4ade80" }}>
                  Place ID: {parsedPlaceId} 확인됨
                </p>
              </div>
            )}
            {parseStatus === "fail" && (
              <div className="flex items-center gap-1.5 mt-2">
                <XCircle size={13} style={{ color: "#f87171" }} />
                <p className="text-xs text-red-400">
                  올바른 네이버 플레이스 URL을 입력해주세요
                </p>
              </div>
            )}
            {errors.naver_place_url && (
              <p className="text-xs text-red-400 mt-1">
                {errors.naver_place_url.message}
              </p>
            )}

            {/* 도움말 */}
            <p className="text-xs text-slate-500 mt-2">
              네이버 지도에서 장소를 검색한 후 URL을 복사해 붙여넣으세요.
            </p>
          </div>

          {/* ② 별칭 입력 (선택) */}
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-1.5">
              장소 별칭{" "}
              <span className="text-slate-500 font-normal">(선택)</span>
            </label>
            <input
              {...register("alias")}
              type="text"
              className="w-full rounded-xl px-4 py-2.5 text-sm text-slate-100 placeholder:text-slate-600 outline-none transition-all"
              style={{
                background: "rgba(255,255,255,0.06)",
                border: `1px solid ${
                  errors.alias
                    ? "rgba(239,68,68,0.5)"
                    : "rgba(255,255,255,0.1)"
                }`,
              }}
              onFocus={(e) => {
                e.currentTarget.style.borderColor = "#00d4ff";
                e.currentTarget.style.boxShadow =
                  "0 0 0 3px rgba(0,212,255,0.1)";
              }}
              onBlur={(e) => {
                e.currentTarget.style.borderColor = errors.alias
                  ? "rgba(239,68,68,0.5)"
                  : "rgba(255,255,255,0.1)";
                e.currentTarget.style.boxShadow = "none";
              }}
              placeholder="예: 강남점, 본점 등 내부 관리용 이름"
              disabled={isLoading}
            />
            {errors.alias && (
              <p className="text-xs text-red-400 mt-1">{errors.alias.message}</p>
            )}
            <p className="text-xs text-slate-500 mt-2">
              여러 지점을 구분하거나 내부 코드명으로 관리할 때 사용합니다.
            </p>
          </div>

          {/* 제출 버튼 */}
          <button
            type="submit"
            disabled={isLoading || parseStatus === "fail"}
            className="w-full py-3 rounded-xl text-sm font-semibold transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            style={{
              background:
                isLoading || parseStatus === "fail"
                  ? "rgba(0,212,255,0.5)"
                  : "#00d4ff",
              color: "#0a0a0f",
            }}
          >
            {isLoading ? (
              <>
                <Loader2 size={15} className="animate-spin" />
                등록 중...
              </>
            ) : (
              "장소 등록하기"
            )}
          </button>
        </form>
      </div>

      {/* URL 형식 안내 */}
      <div
        className="mt-4 p-4 rounded-xl"
        style={{
          background: "rgba(255,255,255,0.02)",
          border: "1px solid rgba(255,255,255,0.06)",
        }}
      >
        <p className="text-xs text-slate-500 font-medium mb-2">
          지원하는 URL 형식
        </p>
        <ul className="space-y-1 text-xs text-slate-600">
          <li>• https://map.naver.com/v5/entry/place/12345678</li>
          <li>• https://map.naver.com/p/entry/place/12345678</li>
          <li>• https://place.naver.com/restaurant/12345678</li>
        </ul>
      </div>
    </div>
  );
}
