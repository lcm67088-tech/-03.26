"use client";

/**
 * 대시보드 메인 페이지 (Sprint 3 완성)
 *
 * - KPI 카드 4개 (장소, 키워드, 이번달 주문, 평균 순위)
 * - 장소별 순위 현황 섹션
 * - 최근 주문 섹션
 * - 로딩 스켈레톤, 에러 처리 완전 구현
 */
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ExternalLink, TrendingUp, ArrowRight, Plus, Flame } from "lucide-react";
import { useAuthStore } from "@/store/authStore";
import { useDashboardSummary } from "@/hooks/usePlaces";
import { StatusBadge } from "@/components/common/StatusBadge";
import EmptyState from "@/components/common/EmptyState";
import type { RankSummaryKeyword } from "@/hooks/usePlaces";

// ============================
// 숫자 포맷 헬퍼
// ============================

function formatKRW(amount: number): string {
  if (amount >= 1_000_000) {
    return `${(amount / 1_000_000).toFixed(1)}백만원`;
  }
  if (amount >= 10_000) {
    return `${(amount / 10_000).toFixed(0)}만원`;
  }
  return `${amount.toLocaleString("ko-KR")}원`;
}

// ============================
// 스켈레톤 컴포넌트
// ============================

function KpiSkeleton() {
  return (
    <div
      className="rounded-xl p-5 animate-pulse"
      style={{
        background: "rgba(255,255,255,0.04)",
        border: "1px solid rgba(255,255,255,0.08)",
      }}
    >
      <div
        className="h-3 w-20 rounded mb-3"
        style={{ background: "rgba(255,255,255,0.08)" }}
      />
      <div
        className="h-8 w-16 rounded mb-2"
        style={{ background: "rgba(255,255,255,0.08)" }}
      />
      <div
        className="h-3 w-24 rounded"
        style={{ background: "rgba(255,255,255,0.06)" }}
      />
    </div>
  );
}

function RankCardSkeleton() {
  return (
    <div
      className="rounded-xl p-5 animate-pulse"
      style={{
        background: "rgba(255,255,255,0.04)",
        border: "1px solid rgba(255,255,255,0.08)",
      }}
    >
      <div className="flex justify-between mb-4">
        <div
          className="h-4 w-32 rounded"
          style={{ background: "rgba(255,255,255,0.08)" }}
        />
        <div
          className="h-4 w-16 rounded"
          style={{ background: "rgba(255,255,255,0.06)" }}
        />
      </div>
      <div className="flex flex-wrap gap-2">
        {[1, 2, 3].map((i) => (
          <div
            key={i}
            className="h-6 w-20 rounded-full"
            style={{ background: "rgba(255,255,255,0.06)" }}
          />
        ))}
      </div>
    </div>
  );
}

// ============================
// 인라인 순위 칩 (대시보드용 간소화)
// ============================

function DashRankChip({ kw }: { kw: RankSummaryKeyword }) {
  const { keyword, rank, case_type, rank_change } = kw;

  const changeEl =
    rank_change !== null && rank_change !== undefined ? (
      rank_change > 0 ? (
        <span className="text-[10px] text-green-400 ml-0.5">▲{rank_change}</span>
      ) : rank_change < 0 ? (
        <span className="text-[10px] text-red-400 ml-0.5">▼{Math.abs(rank_change)}</span>
      ) : (
        <span className="text-[10px] text-gray-500 ml-0.5">–</span>
      )
    ) : null;

  if (!rank || case_type === "not_ranked") {
    return (
      <span
        className="inline-flex items-center px-2 py-0.5 rounded-full text-xs"
        style={{
          background: "rgba(239,68,68,0.12)",
          color: "#f87171",
          border: "1px solid rgba(239,68,68,0.18)",
        }}
      >
        {keyword} <span className="ml-1 opacity-60">미진입</span>
      </span>
    );
  }

  const style =
    rank <= 3
      ? { bg: "rgba(34,197,94,0.12)", color: "#4ade80", border: "rgba(34,197,94,0.18)" }
      : rank <= 10
      ? { bg: "rgba(59,130,246,0.12)", color: "#60a5fa", border: "rgba(59,130,246,0.18)" }
      : { bg: "rgba(107,114,128,0.12)", color: "#9ca3af", border: "rgba(107,114,128,0.18)" };

  return (
    <span
      className="inline-flex items-center px-2 py-0.5 rounded-full text-xs"
      style={{
        background: style.bg,
        color: style.color,
        border: `1px solid ${style.border}`,
      }}
    >
      {case_type === "popular" && <Flame size={9} className="mr-0.5" />}
      {keyword} <span className="font-bold ml-1">#{rank}</span>
      {changeEl}
    </span>
  );
}

// ============================
// KPI 카드 컴포넌트
// ============================

interface KpiCardProps {
  icon: string;
  label: string;
  value: string | number;
  sub?: React.ReactNode;
  alert?: "warn" | "danger" | null;
}

function KpiCard({ icon, label, value, sub, alert }: KpiCardProps) {
  const borderColor =
    alert === "danger"
      ? "rgba(239,68,68,0.4)"
      : alert === "warn"
      ? "rgba(245,158,11,0.4)"
      : "rgba(255,255,255,0.08)";

  return (
    <div
      className="rounded-xl p-5"
      style={{
        background: "rgba(255,255,255,0.04)",
        border: `1px solid ${borderColor}`,
      }}
    >
      <div className="flex items-center gap-2 mb-3">
        <span className="text-lg">{icon}</span>
        <span className="text-xs text-slate-400">{label}</span>
      </div>
      <p className="text-3xl font-bold text-slate-100 mb-1">{value}</p>
      {sub && <div className="text-xs text-slate-500">{sub}</div>}
      {alert === "danger" && (
        <Link
          href="/billing/upgrade"
          className="block text-xs mt-2 font-medium"
          style={{ color: "#f87171" }}
        >
          업그레이드 필요 →
        </Link>
      )}
    </div>
  );
}

// ============================
// 대시보드 메인
// ============================

const PLAN_LIMITS: Record<string, { max_places: number; max_keywords: number }> = {
  free: { max_places: 1, max_keywords: 5 },
  starter: { max_places: 5, max_keywords: 30 },
  pro: { max_places: 20, max_keywords: 100 },
  enterprise: { max_places: 999, max_keywords: 999 },
};

export default function DashboardPage() {
  const { user, workspace } = useAuthStore();
  const workspaceId = workspace?.id ?? "";
  const plan = workspace?.plan ?? "free";
  const limits = PLAN_LIMITS[plan] ?? PLAN_LIMITS.free;

  const { data, isLoading, isError, error } = useDashboardSummary(workspaceId);

  // ============================
  // 로딩 상태
  // ============================
  if (isLoading) {
    return (
      <div className="p-6 max-w-7xl mx-auto">
        {/* 환영 메시지 스켈레톤 */}
        <div className="mb-8">
          <div
            className="h-7 w-48 rounded animate-pulse mb-2"
            style={{ background: "rgba(255,255,255,0.08)" }}
          />
          <div
            className="h-4 w-72 rounded animate-pulse"
            style={{ background: "rgba(255,255,255,0.05)" }}
          />
        </div>

        {/* KPI 스켈레톤 */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {[1, 2, 3, 4].map((i) => (
            <KpiSkeleton key={i} />
          ))}
        </div>

        {/* 순위 현황 스켈레톤 */}
        <div className="mb-8">
          <div
            className="h-5 w-32 rounded animate-pulse mb-4"
            style={{ background: "rgba(255,255,255,0.08)" }}
          />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[1, 2, 3].map((i) => (
              <RankCardSkeleton key={i} />
            ))}
          </div>
        </div>
      </div>
    );
  }

  // ============================
  // 에러 상태
  // ============================
  if (isError) {
    return (
      <div className="p-6 max-w-7xl mx-auto">
        <div
          className="rounded-xl p-6 text-center"
          style={{
            background: "rgba(239,68,68,0.08)",
            border: "1px solid rgba(239,68,68,0.2)",
          }}
        >
          <p className="text-red-400 font-medium mb-1">데이터를 불러오지 못했습니다</p>
          <p className="text-xs text-slate-500">
            {error instanceof Error ? error.message : "잠시 후 다시 시도해주세요"}
          </p>
        </div>
      </div>
    );
  }

  // ============================
  // 정상 렌더
  // ============================
  const totalPlaces = data?.total_places ?? 0;
  const totalKeywords = data?.total_keywords ?? 0;
  const placeAlert =
    totalPlaces >= limits.max_places
      ? "danger"
      : totalPlaces >= limits.max_places * 0.8
      ? "warn"
      : null;

  return (
    <div className="p-6 max-w-7xl mx-auto">
      {/* 환영 메시지 */}
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-slate-100">
          안녕하세요, {user?.name ?? ""}님 👋
        </h1>
        <p className="text-slate-400 mt-1 text-sm">
          오늘도 순위 관리 시작해볼까요?
        </p>
      </div>

      {/* KPI 카드 4개 */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10">
        <KpiCard
          icon="🏪"
          label="등록 장소"
          value={totalPlaces}
          sub={`/ ${limits.max_places === 999 ? "무제한" : limits.max_places} 한도`}
          alert={placeAlert}
        />
        <KpiCard
          icon="🔑"
          label="모니터링 키워드"
          value={totalKeywords}
          sub={`/ ${limits.max_keywords === 999 ? "무제한" : limits.max_keywords} 한도`}
        />
        <KpiCard
          icon="📦"
          label="이번달 주문"
          value={data?.this_month_orders ?? 0}
          sub={
            data?.this_month_revenue
              ? formatKRW(data.this_month_revenue)
              : "0원"
          }
        />
        <KpiCard
          icon="📊"
          label="평균 순위"
          value={data?.avg_rank != null ? `${data.avg_rank}위` : "-"}
          sub="전체 키워드 기준"
        />
      </div>

      {/* 순위 현황 섹션 */}
      <section className="mb-10">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-base font-semibold text-slate-200">
            장소별 순위 현황
          </h2>
          <Link
            href="/places"
            className="flex items-center gap-1 text-xs font-medium transition-colors"
            style={{ color: "#00d4ff" }}
          >
            전체 보기
            <ArrowRight size={12} />
          </Link>
        </div>

        {!data?.rank_summary || data.rank_summary.length === 0 ? (
          <EmptyState
            icon="🏪"
            title="등록된 장소가 없습니다"
            description="네이버 플레이스 URL을 등록하고 순위 모니터링을 시작해보세요"
            action={
              <Link
                href="/places/new"
                className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold transition-all"
                style={{ background: "#00d4ff", color: "#0a0a0f" }}
              >
                <Plus size={14} />
                첫 장소 등록하기
              </Link>
            }
          />
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {data.rank_summary.slice(0, 3).map((place) => (
              <Link
                key={place.place_id}
                href={`/places/${place.place_id}`}
                className="block rounded-xl p-4 transition-all duration-200"
                style={{
                  background: "rgba(255,255,255,0.04)",
                  border: "1px solid rgba(255,255,255,0.08)",
                }}
                onMouseEnter={(e) => {
                  (e.currentTarget as HTMLAnchorElement).style.borderColor =
                    "rgba(0,212,255,0.25)";
                }}
                onMouseLeave={(e) => {
                  (e.currentTarget as HTMLAnchorElement).style.borderColor =
                    "rgba(255,255,255,0.08)";
                }}
              >
                {/* 장소명 + 외부 링크 */}
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-1.5 min-w-0">
                    <span className="text-base">🏪</span>
                    <p className="font-semibold text-sm text-slate-100 truncate">
                      {place.alias || place.place_name}
                    </p>
                  </div>
                  <a
                    href={`https://map.naver.com/v5/entry/place/${place.place_id}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={(e) => e.stopPropagation()}
                    className="flex-shrink-0 ml-2"
                    style={{ color: "#00d4ff" }}
                  >
                    <ExternalLink size={13} />
                  </a>
                </div>

                {/* 키워드 칩 */}
                {place.keywords.length > 0 ? (
                  <div className="flex flex-wrap gap-1.5">
                    {place.keywords.slice(0, 4).map((kw, idx) => (
                      <DashRankChip key={idx} kw={kw} />
                    ))}
                    {place.keywords.length > 4 && (
                      <span className="text-xs text-slate-500 self-center">
                        +{place.keywords.length - 4}
                      </span>
                    )}
                  </div>
                ) : (
                  <p className="text-xs text-slate-600">키워드 없음</p>
                )}
              </Link>
            ))}
          </div>
        )}
      </section>

      {/* 최근 주문 섹션 */}
      <section>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-base font-semibold text-slate-200">최근 주문</h2>
          <Link
            href="/orders"
            className="flex items-center gap-1 text-xs font-medium transition-colors"
            style={{ color: "#00d4ff" }}
          >
            전체 보기
            <ArrowRight size={12} />
          </Link>
        </div>

        {!data?.recent_orders || data.recent_orders.length === 0 ? (
          <EmptyState
            icon="📦"
            title="주문 내역이 없습니다"
            description="서비스를 주문하고 마케팅 성과를 높여보세요"
            action={
              <Link
                href="/orders/new"
                className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold transition-all"
                style={{ background: "#00d4ff", color: "#0a0a0f" }}
              >
                <Plus size={14} />
                주문하기
              </Link>
            }
          />
        ) : (
          <div
            className="rounded-xl overflow-hidden"
            style={{
              background: "rgba(255,255,255,0.03)",
              border: "1px solid rgba(255,255,255,0.08)",
            }}
          >
            {data.recent_orders.map((order, idx) => (
              <Link
                key={order.id}
                href={`/orders/${order.id}`}
                className="flex items-center justify-between px-5 py-3.5 transition-colors"
                style={{
                  borderBottom:
                    idx < data.recent_orders.length - 1
                      ? "1px solid rgba(255,255,255,0.05)"
                      : "none",
                }}
                onMouseEnter={(e) => {
                  (e.currentTarget as HTMLAnchorElement).style.background =
                    "rgba(255,255,255,0.03)";
                }}
                onMouseLeave={(e) => {
                  (e.currentTarget as HTMLAnchorElement).style.background = "transparent";
                }}
              >
                <div className="flex items-center gap-3 min-w-0">
                  <StatusBadge status={order.status as any} />
                  <span className="text-sm text-slate-200 truncate">
                    {order.product_name}
                  </span>
                </div>
                <div className="flex items-center gap-4 flex-shrink-0">
                  <span className="text-sm font-semibold text-slate-300">
                    {order.total_amount.toLocaleString("ko-KR")}원
                  </span>
                  {order.ordered_at && (
                    <span className="text-xs text-slate-500 hidden sm:block">
                      {new Date(order.ordered_at).toLocaleDateString("ko-KR")}
                    </span>
                  )}
                </div>
              </Link>
            ))}
          </div>
        )}
      </section>

      {/* 빠른 액션 버튼 */}
      <div className="flex gap-3 mt-10">
        <Link
          href="/places/new"
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold transition-all"
          style={{ background: "#00d4ff", color: "#0a0a0f" }}
        >
          <Plus size={15} />
          장소 등록
        </Link>
        <Link
          href="/orders/new"
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold transition-all"
          style={{
            background: "rgba(255,255,255,0.08)",
            color: "#e2e8f0",
            border: "1px solid rgba(255,255,255,0.12)",
          }}
        >
          <Plus size={15} />
          주문하기
        </Link>
      </div>
    </div>
  );
}
