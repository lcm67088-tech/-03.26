/**
 * 구독·결제 현황 페이지
 * Sprint 8: /billing
 *
 * 섹션:
 *   1. 현재 플랜 + 사용량 (progress bar)
 *   2. 결제 수단 (카드 정보 표시 / 등록 버튼)
 *   3. 결제 내역 (테이블 + 페이지네이션)
 */

"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import {
  CreditCard, Zap, ChevronRight, AlertCircle, RefreshCw,
  CheckCircle, XCircle, Clock, TrendingUp, Calendar,
  Receipt, ShieldCheck,
} from "lucide-react";
import { toast } from "sonner";
import {
  useSubscription,
  useBillingHistory,
  usePaymentMethod,
  useCancelSubscription,
  PLAN_LABELS,
  PLAN_FEATURES,
  PLAN_PRICES,
  SUBSCRIPTION_STATUS_LABELS,
  SUBSCRIPTION_STATUS_COLORS,
  BILLING_STATUS_COLORS,
  BILLING_TYPE_LABELS,
} from "@/hooks/useBilling";
import PaymentMethodModal from "@/components/billing/PaymentMethodModal";
import { formatKRW, formatDate } from "@/lib/utils";

// ─────────────────────────────────────────────────────────────
// 구독 상태 아이콘
// ─────────────────────────────────────────────────────────────
function StatusIcon({ status }: { status: string }) {
  if (status === "active") return <CheckCircle size={14} style={{ color: "#22c55e" }} />;
  if (status === "cancelled") return <Clock size={14} style={{ color: "#fcd34d" }} />;
  if (status === "past_due") return <AlertCircle size={14} style={{ color: "#f87171" }} />;
  return <XCircle size={14} style={{ color: "#94a3b8" }} />;
}

// ─────────────────────────────────────────────────────────────
// 플랜 색상
// ─────────────────────────────────────────────────────────────
const PLAN_COLORS: Record<string, string> = {
  free:       "#94a3b8",
  starter:    "#60a5fa",
  pro:        "#a78bfa",
  enterprise: "#fcd34d",
};

// ─────────────────────────────────────────────────────────────
// 사용량 Progress Bar 컴포넌트
// ─────────────────────────────────────────────────────────────
function UsageBar({
  label,
  current,
  max,
  color,
}: {
  label: string;
  current: number;
  max: number;
  color: string;
}) {
  const pct = max >= 999 ? 100 : Math.min(100, Math.round((current / max) * 100));
  const isUnlimited = max >= 999;
  const isWarning = !isUnlimited && pct >= 80;

  return (
    <div style={{ marginBottom: "14px" }}>
      {/* 레이블 + 수치 */}
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "6px" }}>
        <span style={{ fontSize: "13px", color: "rgba(255,255,255,0.6)" }}>{label}</span>
        <span
          style={{
            fontSize: "12px",
            fontWeight: 600,
            color: isWarning ? "#f87171" : "rgba(255,255,255,0.8)",
          }}
        >
          {isUnlimited ? `${current} / 무제한` : `${current} / ${max}개`}
        </span>
      </div>
      {/* 바 */}
      <div
        style={{
          height: "6px",
          borderRadius: "3px",
          background: "rgba(255,255,255,0.08)",
          overflow: "hidden",
        }}
      >
        <div
          style={{
            height: "100%",
            width: isUnlimited ? "30%" : `${pct}%`,
            borderRadius: "3px",
            background: isWarning ? "#f87171" : color,
            transition: "width 0.4s ease",
          }}
        />
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// 메인 페이지 컴포넌트
// ─────────────────────────────────────────────────────────────
export default function BillingPage() {
  const router = useRouter();
  const [historyPage, setHistoryPage] = useState(1);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [showCancelConfirm, setShowCancelConfirm] = useState(false);
  const [cancelReason, setCancelReason] = useState("");

  // 쿼리
  const { data: subscription, isLoading: subLoading, refetch: refetchSub } = useSubscription();
  const { data: historyData, isLoading: historyLoading } = useBillingHistory(historyPage);
  const { data: pmData } = usePaymentMethod();

  // 뮤테이션
  const { mutate: cancelSub, isPending: isCancelling } = useCancelSubscription();

  const pm = pmData?.payment_method ?? null;
  const totalHistoryPages = historyData ? Math.ceil(historyData.total / 20) : 1;

  // 구독 취소 처리
  function handleCancel() {
    cancelSub(
      { reason: cancelReason || undefined },
      {
        onSuccess: (res) => {
          toast.success(res.message);
          setShowCancelConfirm(false);
          setCancelReason("");
          refetchSub();
        },
        onError: (err: any) =>
          toast.error(err?.response?.data?.detail ?? "구독 취소에 실패했습니다."),
      }
    );
  }

  if (subLoading) {
    return (
      <div
        style={{
          minHeight: "60vh",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          color: "rgba(255,255,255,0.3)",
          fontSize: "14px",
        }}
      >
        <RefreshCw size={18} style={{ marginRight: "8px", opacity: 0.5 }} />
        구독 정보를 불러오는 중...
      </div>
    );
  }

  const plan = subscription?.plan ?? "free";
  const planColor = PLAN_COLORS[plan] ?? "#94a3b8";
  const planLabel = PLAN_LABELS[plan] ?? plan.toUpperCase();
  const statusLabel = SUBSCRIPTION_STATUS_LABELS[subscription?.status ?? "active"] ?? "이용 중";
  const statusColor = SUBSCRIPTION_STATUS_COLORS[subscription?.status ?? "active"];

  return (
    <div style={{ color: "#fff", fontFamily: "'Pretendard', sans-serif" }}>
      {/* ── 페이지 헤더 ──────────────────────────────────────── */}
      <div style={{ marginBottom: "28px" }}>
        <h1
          style={{
            fontSize: "22px",
            fontWeight: 700,
            margin: 0,
            marginBottom: "6px",
            display: "flex",
            alignItems: "center",
            gap: "10px",
          }}
        >
          <CreditCard size={20} style={{ color: "#00d4ff" }} />
          구독·결제
        </h1>
        <p style={{ color: "rgba(255,255,255,0.4)", margin: 0, fontSize: "13px" }}>
          현재 플랜과 결제 현황을 확인하세요.
        </p>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 340px", gap: "20px", alignItems: "start" }}>
        {/* ── 왼쪽 열 ────────────────────────────────────────── */}
        <div style={{ display: "flex", flexDirection: "column", gap: "20px" }}>

          {/* 현재 플랜 카드 */}
          <div
            style={{
              background: "rgba(255,255,255,0.04)",
              border: `1px solid ${planColor}30`,
              borderRadius: "14px",
              padding: "24px",
            }}
          >
            {/* 플랜명 + 상태 */}
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "flex-start",
                marginBottom: "20px",
              }}
            >
              <div>
                <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "6px" }}>
                  <span
                    style={{
                      fontSize: "22px",
                      fontWeight: 800,
                      color: planColor,
                      letterSpacing: "-0.5px",
                    }}
                  >
                    {planLabel}
                  </span>
                  <span
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: "4px",
                      padding: "3px 10px",
                      borderRadius: "20px",
                      fontSize: "12px",
                      fontWeight: 600,
                      background: `${statusColor}18`,
                      color: statusColor,
                      border: `1px solid ${statusColor}40`,
                    }}
                  >
                    <StatusIcon status={subscription?.status ?? "active"} />
                    {statusLabel}
                  </span>
                </div>

                {/* 금액 표시 */}
                {plan !== "free" && subscription && (
                  <div style={{ color: "rgba(255,255,255,0.6)", fontSize: "14px" }}>
                    {subscription.billing_cycle === "yearly" ? (
                      <>
                        <span style={{ fontSize: "18px", fontWeight: 700, color: "#fff" }}>
                          {formatKRW(subscription.amount)}
                        </span>
                        <span style={{ marginLeft: "6px", fontSize: "12px", color: "rgba(255,255,255,0.4)" }}>
                          / 월 (연간 결제)
                        </span>
                      </>
                    ) : (
                      <>
                        <span style={{ fontSize: "18px", fontWeight: 700, color: "#fff" }}>
                          {formatKRW(subscription.amount)}
                        </span>
                        <span style={{ marginLeft: "6px", fontSize: "12px", color: "rgba(255,255,255,0.4)" }}>
                          / 월
                        </span>
                      </>
                    )}
                  </div>
                )}
                {plan === "free" && (
                  <div style={{ fontSize: "18px", fontWeight: 700, color: "#94a3b8" }}>
                    무료
                  </div>
                )}
              </div>

              {/* 다음 결제일 */}
              {subscription?.next_billing_at && (
                <div
                  style={{
                    textAlign: "right",
                    padding: "10px 14px",
                    background: "rgba(255,255,255,0.04)",
                    borderRadius: "10px",
                    border: "1px solid rgba(255,255,255,0.07)",
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: "5px",
                      fontSize: "11px",
                      color: "rgba(255,255,255,0.4)",
                      marginBottom: "3px",
                    }}
                  >
                    <Calendar size={11} />
                    다음 결제일
                  </div>
                  <div style={{ fontSize: "13px", fontWeight: 600, color: "rgba(255,255,255,0.8)" }}>
                    {formatDate(subscription.next_billing_at).split(" ")[0]}
                  </div>
                </div>
              )}
            </div>

            {/* 현재 사용량 */}
            {subscription && (
              <>
                <div
                  style={{
                    fontSize: "12px",
                    fontWeight: 600,
                    color: "rgba(255,255,255,0.35)",
                    letterSpacing: "0.08em",
                    textTransform: "uppercase",
                    marginBottom: "14px",
                  }}
                >
                  현재 사용량
                </div>
                <UsageBar
                  label="장소"
                  current={subscription.current_places}
                  max={subscription.plan_limits.max_places}
                  color={planColor}
                />
                <UsageBar
                  label="키워드"
                  current={subscription.current_keywords}
                  max={subscription.plan_limits.max_keywords}
                  color={planColor}
                />
                <div
                  style={{
                    fontSize: "12px",
                    color: "rgba(255,255,255,0.3)",
                    marginTop: "4px",
                  }}
                >
                  일 크롤링: {subscription.plan_limits.crawl_per_day}회 / 일
                </div>
              </>
            )}

            {/* 액션 버튼 */}
            <div style={{ display: "flex", gap: "10px", marginTop: "20px" }}>
              {plan === "free" ? (
                <button
                  onClick={() => router.push("/billing/upgrade")}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: "6px",
                    padding: "10px 20px",
                    borderRadius: "8px",
                    border: "1px solid rgba(0,212,255,0.4)",
                    background: "rgba(0,212,255,0.1)",
                    color: "#00d4ff",
                    fontSize: "13px",
                    fontWeight: 600,
                    cursor: "pointer",
                  }}
                >
                  <Zap size={14} />
                  플랜 업그레이드
                </button>
              ) : (
                <>
                  <button
                    onClick={() => router.push("/billing/upgrade")}
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: "6px",
                      padding: "10px 20px",
                      borderRadius: "8px",
                      border: "1px solid rgba(0,212,255,0.4)",
                      background: "rgba(0,212,255,0.08)",
                      color: "#00d4ff",
                      fontSize: "13px",
                      fontWeight: 600,
                      cursor: "pointer",
                    }}
                  >
                    <TrendingUp size={14} />
                    플랜 변경
                  </button>
                  {subscription?.status === "active" && (
                    <button
                      onClick={() => setShowCancelConfirm(true)}
                      style={{
                        display: "flex",
                        alignItems: "center",
                        gap: "6px",
                        padding: "10px 20px",
                        borderRadius: "8px",
                        border: "1px solid rgba(248,113,113,0.3)",
                        background: "transparent",
                        color: "#f87171",
                        fontSize: "13px",
                        cursor: "pointer",
                      }}
                    >
                      구독 취소
                    </button>
                  )}
                </>
              )}
            </div>
          </div>

          {/* 결제 내역 테이블 */}
          <div
            style={{
              background: "rgba(255,255,255,0.04)",
              border: "1px solid rgba(255,255,255,0.08)",
              borderRadius: "14px",
              overflow: "hidden",
            }}
          >
            <div
              style={{
                padding: "16px 20px",
                borderBottom: "1px solid rgba(255,255,255,0.06)",
                display: "flex",
                alignItems: "center",
                gap: "8px",
              }}
            >
              <Receipt size={16} style={{ color: "#00d4ff" }} />
              <span style={{ fontSize: "15px", fontWeight: 600 }}>결제 내역</span>
              {historyData && (
                <span
                  style={{
                    marginLeft: "auto",
                    fontSize: "12px",
                    color: "rgba(255,255,255,0.3)",
                  }}
                >
                  총 {historyData.total}건
                </span>
              )}
            </div>

            {/* 테이블 헤더 */}
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "160px 1fr 100px 110px 80px",
                padding: "10px 20px",
                background: "rgba(255,255,255,0.02)",
                borderBottom: "1px solid rgba(255,255,255,0.05)",
              }}
            >
              {["날짜", "내용", "플랜", "금액", "상태"].map((col) => (
                <span
                  key={col}
                  style={{
                    fontSize: "11px",
                    color: "rgba(255,255,255,0.3)",
                    fontWeight: 600,
                    letterSpacing: "0.04em",
                  }}
                >
                  {col}
                </span>
              ))}
            </div>

            {/* 테이블 바디 */}
            {historyLoading ? (
              <div
                style={{
                  padding: "40px",
                  textAlign: "center",
                  color: "rgba(255,255,255,0.3)",
                  fontSize: "13px",
                }}
              >
                불러오는 중...
              </div>
            ) : !historyData || historyData.items.length === 0 ? (
              <div
                style={{
                  padding: "40px",
                  textAlign: "center",
                  color: "rgba(255,255,255,0.3)",
                  fontSize: "13px",
                }}
              >
                결제 내역이 없습니다.
              </div>
            ) : (
              historyData.items.map((item, idx) => {
                const statusColor = BILLING_STATUS_COLORS[item.status] ?? "#94a3b8";
                const typeLabel = BILLING_TYPE_LABELS[item.type] ?? item.type;

                return (
                  <div
                    key={item.id}
                    style={{
                      display: "grid",
                      gridTemplateColumns: "160px 1fr 100px 110px 80px",
                      padding: "12px 20px",
                      borderBottom:
                        idx < historyData.items.length - 1
                          ? "1px solid rgba(255,255,255,0.04)"
                          : "none",
                      alignItems: "center",
                    }}
                  >
                    {/* 날짜 */}
                    <span style={{ fontSize: "12px", color: "rgba(255,255,255,0.4)" }}>
                      {formatDate(item.created_at).split(" ")[0]}
                    </span>
                    {/* 내용 */}
                    <div>
                      <div style={{ fontSize: "13px", color: "rgba(255,255,255,0.8)" }}>
                        {typeLabel}
                      </div>
                      {item.description && (
                        <div
                          style={{
                            fontSize: "11px",
                            color: "rgba(255,255,255,0.3)",
                            marginTop: "2px",
                            overflow: "hidden",
                            textOverflow: "ellipsis",
                            whiteSpace: "nowrap",
                          }}
                        >
                          {item.description}
                        </div>
                      )}
                    </div>
                    {/* 플랜 */}
                    <span
                      style={{
                        fontSize: "12px",
                        fontWeight: 600,
                        color: PLAN_COLORS[item.plan] ?? "#94a3b8",
                      }}
                    >
                      {PLAN_LABELS[item.plan] ?? item.plan.toUpperCase()}
                    </span>
                    {/* 금액 */}
                    <span
                      style={{
                        fontSize: "13px",
                        fontWeight: 600,
                        color: item.amount > 0 ? "rgba(255,255,255,0.9)" : "rgba(255,255,255,0.4)",
                      }}
                    >
                      {item.amount > 0 ? formatKRW(item.amount) : "—"}
                    </span>
                    {/* 상태 */}
                    <span
                      style={{
                        display: "inline-flex",
                        alignItems: "center",
                        padding: "3px 8px",
                        borderRadius: "6px",
                        fontSize: "11px",
                        fontWeight: 600,
                        background: `${statusColor}18`,
                        color: statusColor,
                        width: "fit-content",
                      }}
                    >
                      {item.status === "paid" ? "결제완료" : item.status === "failed" ? "실패" : "환불"}
                    </span>
                  </div>
                );
              })
            )}

            {/* 페이지네이션 */}
            {totalHistoryPages > 1 && (
              <div
                style={{
                  display: "flex",
                  justifyContent: "center",
                  gap: "6px",
                  padding: "14px",
                  borderTop: "1px solid rgba(255,255,255,0.05)",
                }}
              >
                {Array.from({ length: totalHistoryPages }, (_, i) => i + 1).map((p) => (
                  <button
                    key={p}
                    onClick={() => setHistoryPage(p)}
                    style={{
                      width: "32px",
                      height: "32px",
                      borderRadius: "6px",
                      border:
                        p === historyPage
                          ? "1px solid rgba(0,212,255,0.4)"
                          : "1px solid rgba(255,255,255,0.1)",
                      background:
                        p === historyPage ? "rgba(0,212,255,0.1)" : "transparent",
                      color:
                        p === historyPage ? "#00d4ff" : "rgba(255,255,255,0.4)",
                      fontSize: "12px",
                      fontWeight: p === historyPage ? 700 : 400,
                      cursor: "pointer",
                    }}
                  >
                    {p}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* ── 오른쪽 열 ───────────────────────────────────────── */}
        <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>

          {/* 결제 수단 카드 */}
          <div
            style={{
              background: "rgba(255,255,255,0.04)",
              border: "1px solid rgba(255,255,255,0.08)",
              borderRadius: "14px",
              padding: "20px",
            }}
          >
            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: "8px",
                marginBottom: "16px",
              }}
            >
              <ShieldCheck size={15} style={{ color: "#00d4ff" }} />
              <span style={{ fontSize: "14px", fontWeight: 600 }}>결제 수단</span>
            </div>

            {pm ? (
              <>
                {/* 카드 표시 */}
                <div
                  style={{
                    padding: "14px",
                    borderRadius: "10px",
                    background: "rgba(0,212,255,0.06)",
                    border: "1px solid rgba(0,212,255,0.15)",
                    marginBottom: "12px",
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: "8px",
                      marginBottom: "4px",
                    }}
                  >
                    <CreditCard size={16} style={{ color: "#00d4ff" }} />
                    <span style={{ fontSize: "14px", fontWeight: 600, color: "#00d4ff" }}>
                      {pm.card_brand}
                    </span>
                  </div>
                  <div style={{ fontSize: "15px", fontWeight: 700, letterSpacing: "2px" }}>
                    **** **** **** {pm.card_number_last4}
                  </div>
                  <div style={{ fontSize: "12px", color: "rgba(255,255,255,0.4)", marginTop: "4px" }}>
                    유효기간 {pm.exp_month}/{pm.exp_year}
                  </div>
                </div>
                <button
                  onClick={() => setShowPaymentModal(true)}
                  style={{
                    width: "100%",
                    padding: "9px",
                    borderRadius: "8px",
                    border: "1px solid rgba(255,255,255,0.1)",
                    background: "transparent",
                    color: "rgba(255,255,255,0.5)",
                    fontSize: "12px",
                    cursor: "pointer",
                  }}
                >
                  카드 변경
                </button>
              </>
            ) : (
              <>
                <p
                  style={{
                    fontSize: "13px",
                    color: "rgba(255,255,255,0.3)",
                    marginBottom: "12px",
                    textAlign: "center",
                  }}
                >
                  등록된 결제 수단이 없습니다
                </p>
                <button
                  onClick={() => setShowPaymentModal(true)}
                  style={{
                    width: "100%",
                    padding: "10px",
                    borderRadius: "8px",
                    border: "1px solid rgba(0,212,255,0.3)",
                    background: "rgba(0,212,255,0.07)",
                    color: "#00d4ff",
                    fontSize: "13px",
                    fontWeight: 600,
                    cursor: "pointer",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    gap: "6px",
                  }}
                >
                  <CreditCard size={14} />
                  카드 등록
                </button>
              </>
            )}
          </div>

          {/* 플랜 비교 빠른 링크 */}
          <div
            style={{
              background: "rgba(124,58,237,0.06)",
              border: "1px solid rgba(124,58,237,0.2)",
              borderRadius: "14px",
              padding: "18px",
            }}
          >
            <div style={{ fontSize: "13px", fontWeight: 600, marginBottom: "10px", color: "#a78bfa" }}>
              플랜별 혜택 비교
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
              {(PLAN_FEATURES[plan] ?? []).map((f) => (
                <div
                  key={f}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: "7px",
                    fontSize: "12px",
                    color: "rgba(255,255,255,0.6)",
                  }}
                >
                  <div
                    style={{
                      width: "5px",
                      height: "5px",
                      borderRadius: "50%",
                      background: "#a78bfa",
                      flexShrink: 0,
                    }}
                  />
                  {f}
                </div>
              ))}
            </div>
            <button
              onClick={() => router.push("/billing/upgrade")}
              style={{
                marginTop: "14px",
                width: "100%",
                padding: "9px",
                borderRadius: "8px",
                border: "1px solid rgba(124,58,237,0.3)",
                background: "rgba(124,58,237,0.1)",
                color: "#a78bfa",
                fontSize: "12px",
                fontWeight: 600,
                cursor: "pointer",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                gap: "6px",
              }}
            >
              전체 플랜 비교
              <ChevronRight size={13} />
            </button>
          </div>
        </div>
      </div>

      {/* ── 결제 수단 등록 모달 ─────────────────────────────────── */}
      {showPaymentModal && (
        <PaymentMethodModal
          onClose={() => setShowPaymentModal(false)}
          existingCard={pm ?? undefined}
        />
      )}

      {/* ── 구독 취소 확인 모달 ─────────────────────────────────── */}
      {showCancelConfirm && (
        <div
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(0,0,0,0.7)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 1000,
          }}
        >
          <div
            style={{
              background: "#111118",
              border: "1px solid rgba(248,113,113,0.25)",
              borderRadius: "14px",
              padding: "28px",
              width: "420px",
              maxWidth: "90vw",
            }}
          >
            <h3
              style={{
                fontSize: "16px",
                fontWeight: 700,
                margin: "0 0 8px",
                color: "#f87171",
                display: "flex",
                alignItems: "center",
                gap: "8px",
              }}
            >
              <AlertCircle size={16} />
              구독 취소
            </h3>
            <p style={{ fontSize: "13px", color: "rgba(255,255,255,0.5)", margin: "0 0 16px" }}>
              구독을 취소하면 현재 결제 기간 종료 후 free 플랜으로 전환됩니다.
              {subscription?.next_billing_at && (
                <strong style={{ color: "rgba(255,255,255,0.7)" }}>
                  {" "}({formatDate(subscription.next_billing_at).split(" ")[0]}까지 유지)
                </strong>
              )}
            </p>
            <textarea
              value={cancelReason}
              onChange={(e) => setCancelReason(e.target.value)}
              placeholder="취소 사유 (선택)"
              rows={3}
              style={{
                width: "100%",
                padding: "10px 14px",
                borderRadius: "8px",
                border: "1px solid rgba(255,255,255,0.1)",
                background: "rgba(255,255,255,0.04)",
                color: "#fff",
                fontSize: "13px",
                outline: "none",
                resize: "none",
                boxSizing: "border-box",
                marginBottom: "16px",
              }}
            />
            <div style={{ display: "flex", gap: "10px" }}>
              <button
                onClick={() => setShowCancelConfirm(false)}
                style={{
                  flex: 1,
                  padding: "10px",
                  borderRadius: "8px",
                  border: "1px solid rgba(255,255,255,0.1)",
                  background: "transparent",
                  color: "rgba(255,255,255,0.5)",
                  fontSize: "13px",
                  cursor: "pointer",
                }}
              >
                돌아가기
              </button>
              <button
                onClick={handleCancel}
                disabled={isCancelling}
                style={{
                  flex: 1,
                  padding: "10px",
                  borderRadius: "8px",
                  border: "1px solid rgba(248,113,113,0.4)",
                  background: "rgba(248,113,113,0.1)",
                  color: "#f87171",
                  fontSize: "13px",
                  fontWeight: 600,
                  cursor: isCancelling ? "not-allowed" : "pointer",
                  opacity: isCancelling ? 0.6 : 1,
                }}
              >
                {isCancelling ? "취소 중..." : "구독 취소 확인"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
