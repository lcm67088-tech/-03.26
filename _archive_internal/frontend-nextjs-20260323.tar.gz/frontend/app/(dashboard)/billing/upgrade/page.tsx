"use client";

/**
 * 플랜 업그레이드/다운그레이드 페이지 (Sprint 8)
 * /billing/upgrade
 *
 * 구성:
 *   1. 플랜 카드 (Free / Starter / Pro / Enterprise)
 *      - 가격, 특징 목록, 뱃지, 선택 UI
 *   2. 결제 주기 토글 (월간 / 연간 — 연간 20% 할인)
 *   3. 결제 정보 (등록된 카드 표시 또는 카드 입력 폼)
 *   4. 다운그레이드 경고 문구
 *   5. 제출 버튼 → useUpgradePlan / useDowngradePlan
 */

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import {
  ArrowLeft, Check, Star, Zap, Building2, AlertTriangle,
  CreditCard, ChevronRight, Sparkles, Shield, Infinity,
} from "lucide-react";
import { toast } from "sonner";
import {
  useSubscription,
  useUpgradePlan,
  useDowngradePlan,
  usePaymentMethod,
  PLAN_LABELS,
  PLAN_FEATURES,
  PLAN_PRICES,
  PLAN_ORDER,
  getPlanRank,
  PlanChangeRequest,
} from "@/hooks/useBilling";
import { formatKRW } from "@/lib/utils";

// ─────────────────────────────────────────────────────────────
// 플랜 메타데이터
// ─────────────────────────────────────────────────────────────
interface PlanMeta {
  id: string;
  label: string;
  badge?: string;
  badgeColor?: string;
  accentColor: string;
  gradientFrom: string;
  gradientTo: string;
  icon: React.ReactNode;
  description: string;
  features: string[];
  priceMonthly: number;
  priceYearly: number;
}

const PLAN_META: PlanMeta[] = [
  {
    id: "free",
    label: "Free",
    accentColor: "#94a3b8",
    gradientFrom: "rgba(148,163,184,0.1)",
    gradientTo: "rgba(148,163,184,0.02)",
    icon: <Shield size={20} style={{ color: "#94a3b8" }} />,
    description: "소규모 테스트 및 개인 사용",
    features: PLAN_FEATURES.free,
    priceMonthly: PLAN_PRICES.free.monthly,
    priceYearly: PLAN_PRICES.free.yearly,
  },
  {
    id: "starter",
    label: "Starter",
    accentColor: "#60a5fa",
    gradientFrom: "rgba(96,165,250,0.12)",
    gradientTo: "rgba(96,165,250,0.02)",
    icon: <Zap size={20} style={{ color: "#60a5fa" }} />,
    description: "소상공인 및 성장 중인 비즈니스",
    features: PLAN_FEATURES.starter,
    priceMonthly: PLAN_PRICES.starter.monthly,
    priceYearly: PLAN_PRICES.starter.yearly,
  },
  {
    id: "pro",
    label: "Pro",
    badge: "가장 인기",
    badgeColor: "#a78bfa",
    accentColor: "#a78bfa",
    gradientFrom: "rgba(167,139,250,0.15)",
    gradientTo: "rgba(167,139,250,0.02)",
    icon: <Star size={20} style={{ color: "#a78bfa" }} />,
    description: "전문 마케터 및 에이전시",
    features: PLAN_FEATURES.pro,
    priceMonthly: PLAN_PRICES.pro.monthly,
    priceYearly: PLAN_PRICES.pro.yearly,
  },
  {
    id: "enterprise",
    label: "Enterprise",
    badge: "대기업",
    badgeColor: "#fcd34d",
    accentColor: "#fcd34d",
    gradientFrom: "rgba(252,211,77,0.12)",
    gradientTo: "rgba(252,211,77,0.02)",
    icon: <Building2 size={20} style={{ color: "#fcd34d" }} />,
    description: "대규모 운영 및 기업 고객",
    features: PLAN_FEATURES.enterprise,
    priceMonthly: PLAN_PRICES.enterprise.monthly,
    priceYearly: PLAN_PRICES.enterprise.yearly,
  },
];

// ─────────────────────────────────────────────────────────────
// 플랜 카드 컴포넌트
// ─────────────────────────────────────────────────────────────
function PlanCard({
  meta,
  isSelected,
  isCurrent,
  billingCycle,
  onClick,
}: {
  meta: PlanMeta;
  isSelected: boolean;
  isCurrent: boolean;
  billingCycle: "monthly" | "yearly";
  onClick: () => void;
}) {
  const price = billingCycle === "yearly" ? meta.priceYearly : meta.priceMonthly;
  const isFree = price === 0;

  return (
    <div
      onClick={onClick}
      style={{
        background: isSelected
          ? `linear-gradient(135deg, ${meta.gradientFrom}, ${meta.gradientTo})`
          : "rgba(255,255,255,0.03)",
        border: isSelected
          ? `2px solid ${meta.accentColor}`
          : "2px solid rgba(255,255,255,0.08)",
        borderRadius: "16px",
        padding: "20px",
        cursor: isCurrent ? "default" : "pointer",
        transition: "all 0.2s",
        position: "relative",
        opacity: isCurrent ? 0.7 : 1,
      }}
    >
      {/* 배지 */}
      {meta.badge && (
        <div
          style={{
            position: "absolute",
            top: "-10px",
            left: "50%",
            transform: "translateX(-50%)",
            background: meta.badgeColor,
            color: "#000",
            fontSize: "11px",
            fontWeight: 700,
            padding: "3px 10px",
            borderRadius: "20px",
            whiteSpace: "nowrap",
          }}
        >
          {meta.badge}
        </div>
      )}

      {/* 현재 플랜 뱃지 */}
      {isCurrent && (
        <div
          style={{
            position: "absolute",
            top: "12px",
            right: "12px",
            background: "rgba(34,197,94,0.15)",
            border: "1px solid rgba(34,197,94,0.3)",
            color: "#22c55e",
            fontSize: "11px",
            fontWeight: 600,
            padding: "2px 8px",
            borderRadius: "20px",
          }}
        >
          현재 플랜
        </div>
      )}

      {/* 선택 체크 */}
      {isSelected && !isCurrent && (
        <div
          style={{
            position: "absolute",
            top: "12px",
            right: "12px",
            width: "22px",
            height: "22px",
            background: meta.accentColor,
            borderRadius: "50%",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <Check size={13} style={{ color: "#000" }} />
        </div>
      )}

      {/* 아이콘 + 이름 */}
      <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "12px" }}>
        <div
          style={{
            width: "38px",
            height: "38px",
            background: `${meta.accentColor}1a`,
            border: `1px solid ${meta.accentColor}33`,
            borderRadius: "10px",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          {meta.icon}
        </div>
        <div>
          <div style={{ fontSize: "15px", fontWeight: 700, color: "#fff" }}>{meta.label}</div>
          <div style={{ fontSize: "11px", color: "rgba(255,255,255,0.4)", marginTop: "1px" }}>
            {meta.description}
          </div>
        </div>
      </div>

      {/* 가격 */}
      <div style={{ marginBottom: "16px" }}>
        {isFree ? (
          <div style={{ fontSize: "26px", fontWeight: 800, color: meta.accentColor }}>
            무료
          </div>
        ) : (
          <div style={{ display: "flex", alignItems: "baseline", gap: "4px" }}>
            <span style={{ fontSize: "26px", fontWeight: 800, color: meta.accentColor }}>
              {formatKRW(price)}
            </span>
            <span style={{ fontSize: "13px", color: "rgba(255,255,255,0.4)" }}>
              / {billingCycle === "yearly" ? "월 (연간)" : "월"}
            </span>
          </div>
        )}
        {billingCycle === "yearly" && !isFree && (
          <div
            style={{
              display: "inline-block",
              background: "rgba(34,197,94,0.12)",
              border: "1px solid rgba(34,197,94,0.2)",
              color: "#22c55e",
              fontSize: "11px",
              fontWeight: 600,
              padding: "2px 7px",
              borderRadius: "20px",
              marginTop: "6px",
            }}
          >
            연간 결제 시 20% 할인
          </div>
        )}
      </div>

      {/* 특징 목록 */}
      <ul style={{ listStyle: "none", margin: 0, padding: 0 }}>
        {meta.features.map((feat, idx) => (
          <li
            key={idx}
            style={{
              display: "flex",
              alignItems: "center",
              gap: "8px",
              fontSize: "12px",
              color: "rgba(255,255,255,0.65)",
              marginBottom: idx < meta.features.length - 1 ? "6px" : 0,
            }}
          >
            <Check size={12} style={{ color: meta.accentColor, flexShrink: 0 }} />
            {feat}
          </li>
        ))}
      </ul>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// 메인 페이지
// ─────────────────────────────────────────────────────────────
export default function BillingUpgradePage() {
  const router = useRouter();
  const { data: subscription, isLoading: subLoading } = useSubscription();
  const { data: pmData } = usePaymentMethod();
  const upgradePlan = useUpgradePlan();
  const downgradePlan = useDowngradePlan();

  // 현재 플랜
  const currentPlan = subscription?.plan ?? "free";

  // 선택된 플랜 (기본값: 현재 플랜)
  const [selectedPlan, setSelectedPlan] = useState<string>(currentPlan);
  // 결제 주기
  const [billingCycle, setBillingCycle] = useState<"monthly" | "yearly">("monthly");
  // 신규 카드 입력 여부
  const [useNewCard, setUseNewCard] = useState<boolean>(false);
  // 신규 카드 폼 필드
  const [cardForm, setCardForm] = useState({
    card_number_last4: "",
    card_brand: "",
    exp_month: "",
    exp_year: "",
  });

  // 구독 정보 로드 후 선택 플랜 초기화
  useEffect(() => {
    if (subscription) {
      setSelectedPlan(subscription.plan);
      setBillingCycle(subscription.billing_cycle ?? "monthly");
    }
  }, [subscription]);

  const currentRank = getPlanRank(currentPlan);
  const selectedRank = getPlanRank(selectedPlan);
  const isUpgrade = selectedRank > currentRank;
  const isDowngrade = selectedRank < currentRank;
  const isSamePlan = selectedPlan === currentPlan;
  const isFreeSelected = selectedPlan === "free";

  // 결제 수단 정보
  const paymentMethod = pmData?.payment_method;
  const hasPaymentMethod = !!paymentMethod;

  // 선택 플랜의 가격
  const selectedMeta = PLAN_META.find((m) => m.id === selectedPlan);
  const selectedPrice =
    billingCycle === "yearly"
      ? (selectedMeta?.priceYearly ?? 0)
      : (selectedMeta?.priceMonthly ?? 0);

  // 카드 폼 변경
  function handleCardChange(e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) {
    const { name, value } = e.target;
    setCardForm((prev) => ({ ...prev, [name]: value }));
  }

  // 제출 핸들러
  async function handleSubmit() {
    if (isSamePlan) {
      toast.info("현재 플랜과 동일합니다.");
      return;
    }

    // 유료 플랜 선택 시 결제 수단 필요
    if (!isFreeSelected && !hasPaymentMethod && !useNewCard) {
      toast.error("결제 수단을 등록하거나 카드 정보를 입력하세요.");
      setUseNewCard(true);
      return;
    }

    if (!isFreeSelected && useNewCard) {
      if (!cardForm.card_number_last4 || cardForm.card_number_last4.length !== 4) {
        toast.error("카드 번호 끝 4자리를 입력하세요.");
        return;
      }
      if (!cardForm.card_brand) {
        toast.error("카드 브랜드를 선택하세요.");
        return;
      }
    }

    const payload: PlanChangeRequest = {
      plan: selectedPlan,
      billing_cycle: billingCycle,
    };

    const mutate = isUpgrade ? upgradePlan : downgradePlan;

    mutate.mutate(payload, {
      onSuccess: (data) => {
        const typeLabel = isUpgrade ? "업그레이드" : "다운그레이드";
        toast.success(`${PLAN_LABELS[selectedPlan]} 플랜으로 ${typeLabel}되었습니다.`);
        if (data.deactivated_places > 0 || data.deactivated_keywords > 0) {
          toast.warning(
            `초과 항목 비활성화: 장소 ${data.deactivated_places}개, 키워드 ${data.deactivated_keywords}개`
          );
        }
        router.push("/billing");
      },
      onError: (err: any) => {
        const msg = err?.response?.data?.detail || "플랜 변경에 실패했습니다.";
        toast.error(msg);
      },
    });
  }

  // ─────────────────────────────────────────────────────────────
  // 로딩 상태
  // ─────────────────────────────────────────────────────────────
  if (subLoading) {
    return (
      <div
        style={{
          minHeight: "100vh",
          background: "#0a0a0f",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <div style={{ textAlign: "center" }}>
          <div
            style={{
              width: "40px",
              height: "40px",
              border: "3px solid rgba(0,212,255,0.2)",
              borderTop: "3px solid #00d4ff",
              borderRadius: "50%",
              animation: "spin 1s linear infinite",
              margin: "0 auto 12px",
            }}
          />
          <p style={{ color: "rgba(255,255,255,0.4)", fontSize: "14px" }}>
            구독 정보를 불러오는 중...
          </p>
        </div>
        <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
      </div>
    );
  }

  const inputStyle: React.CSSProperties = {
    width: "100%",
    padding: "10px 12px",
    background: "rgba(255,255,255,0.05)",
    border: "1px solid rgba(255,255,255,0.12)",
    borderRadius: "8px",
    color: "#fff",
    fontSize: "14px",
    outline: "none",
    boxSizing: "border-box",
  };

  const labelStyle: React.CSSProperties = {
    display: "block",
    fontSize: "13px",
    color: "rgba(255,255,255,0.6)",
    marginBottom: "6px",
    fontWeight: 500,
  };

  // ─────────────────────────────────────────────────────────────
  // 렌더링
  // ─────────────────────────────────────────────────────────────
  return (
    <div
      style={{
        minHeight: "100vh",
        background: "#0a0a0f",
        fontFamily: "'Pretendard', -apple-system, sans-serif",
        padding: "32px 24px",
        maxWidth: "1000px",
        margin: "0 auto",
      }}
    >
      {/* 헤더 */}
      <div style={{ display: "flex", alignItems: "center", gap: "12px", marginBottom: "8px" }}>
        <button
          onClick={() => router.push("/billing")}
          style={{
            background: "rgba(255,255,255,0.05)",
            border: "1px solid rgba(255,255,255,0.1)",
            borderRadius: "8px",
            color: "rgba(255,255,255,0.6)",
            cursor: "pointer",
            padding: "8px",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <ArrowLeft size={16} />
        </button>
        <div>
          <h1 style={{ fontSize: "20px", fontWeight: 700, color: "#fff", margin: 0 }}>
            플랜 변경
          </h1>
          <p style={{ fontSize: "13px", color: "rgba(255,255,255,0.4)", margin: "2px 0 0" }}>
            현재 플랜: <span style={{ color: "#00d4ff" }}>{PLAN_LABELS[currentPlan]}</span>
          </p>
        </div>
      </div>

      {/* 결제 주기 토글 */}
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          marginBottom: "32px",
          marginTop: "28px",
        }}
      >
        <div
          style={{
            display: "inline-flex",
            background: "rgba(255,255,255,0.05)",
            border: "1px solid rgba(255,255,255,0.1)",
            borderRadius: "10px",
            padding: "4px",
            gap: "4px",
          }}
        >
          {(["monthly", "yearly"] as const).map((cycle) => (
            <button
              key={cycle}
              onClick={() => setBillingCycle(cycle)}
              style={{
                padding: "8px 20px",
                borderRadius: "8px",
                border: "none",
                background:
                  billingCycle === cycle
                    ? "linear-gradient(135deg, rgba(0,212,255,0.2), rgba(124,58,237,0.2))"
                    : "transparent",
                color: billingCycle === cycle ? "#fff" : "rgba(255,255,255,0.4)",
                fontSize: "13px",
                fontWeight: billingCycle === cycle ? 600 : 400,
                cursor: "pointer",
                transition: "all 0.2s",
                display: "flex",
                alignItems: "center",
                gap: "6px",
              }}
            >
              {cycle === "monthly" ? "월간 결제" : (
                <>
                  연간 결제
                  <span
                    style={{
                      background: "#22c55e",
                      color: "#000",
                      fontSize: "10px",
                      fontWeight: 700,
                      padding: "1px 5px",
                      borderRadius: "4px",
                    }}
                  >
                    -20%
                  </span>
                </>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* 플랜 카드 그리드 */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
          gap: "16px",
          marginBottom: "32px",
        }}
      >
        {PLAN_META.map((meta) => (
          <PlanCard
            key={meta.id}
            meta={meta}
            isSelected={selectedPlan === meta.id}
            isCurrent={currentPlan === meta.id}
            billingCycle={billingCycle}
            onClick={() => {
              if (currentPlan !== meta.id) setSelectedPlan(meta.id);
            }}
          />
        ))}
      </div>

      {/* 다운그레이드 경고 */}
      {isDowngrade && (
        <div
          style={{
            display: "flex",
            alignItems: "flex-start",
            gap: "12px",
            background: "rgba(252,211,77,0.08)",
            border: "1px solid rgba(252,211,77,0.2)",
            borderRadius: "12px",
            padding: "16px",
            marginBottom: "24px",
          }}
        >
          <AlertTriangle size={18} style={{ color: "#fcd34d", flexShrink: 0, marginTop: "1px" }} />
          <div>
            <div style={{ fontSize: "14px", fontWeight: 600, color: "#fcd34d", marginBottom: "4px" }}>
              다운그레이드 주의사항
            </div>
            <div style={{ fontSize: "13px", color: "rgba(255,255,255,0.6)", lineHeight: 1.6 }}>
              {selectedPlan === "free" ? (
                <>
                  Free 플랜으로 전환 시 <strong style={{ color: "#fff" }}>즉시 적용</strong>됩니다.
                  플랜 한도를 초과하는 장소 및 키워드는 <strong style={{ color: "#fcd34d" }}>자동 비활성화</strong>됩니다.
                </>
              ) : (
                <>
                  {PLAN_LABELS[selectedPlan]} 플랜 한도를 초과하는 장소 및 키워드는{" "}
                  <strong style={{ color: "#fcd34d" }}>자동 비활성화</strong>됩니다.
                  데이터는 보존되며 언제든지 재활성화할 수 있습니다.
                </>
              )}
            </div>
          </div>
        </div>
      )}

      {/* 결제 정보 섹션 (무료 플랜이 아닐 때) */}
      {!isFreeSelected && !isSamePlan && (
        <div
          style={{
            background: "rgba(255,255,255,0.03)",
            border: "1px solid rgba(255,255,255,0.08)",
            borderRadius: "16px",
            padding: "20px",
            marginBottom: "24px",
          }}
        >
          <h3
            style={{
              fontSize: "15px",
              fontWeight: 600,
              color: "#fff",
              margin: "0 0 16px",
              display: "flex",
              alignItems: "center",
              gap: "8px",
            }}
          >
            <CreditCard size={16} style={{ color: "#00d4ff" }} />
            결제 정보
          </h3>

          {hasPaymentMethod && !useNewCard ? (
            /* 등록된 카드 표시 */
            <div>
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                  padding: "12px 14px",
                  background: "rgba(0,212,255,0.05)",
                  border: "1px solid rgba(0,212,255,0.15)",
                  borderRadius: "10px",
                  marginBottom: "12px",
                }}
              >
                <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                  <CreditCard size={16} style={{ color: "#00d4ff" }} />
                  <span style={{ fontSize: "14px", color: "#fff" }}>
                    {paymentMethod!.display}
                  </span>
                </div>
                <span
                  style={{
                    fontSize: "11px",
                    background: "rgba(34,197,94,0.12)",
                    border: "1px solid rgba(34,197,94,0.2)",
                    color: "#22c55e",
                    padding: "2px 7px",
                    borderRadius: "20px",
                  }}
                >
                  등록됨
                </span>
              </div>
              <button
                onClick={() => setUseNewCard(true)}
                style={{
                  background: "transparent",
                  border: "none",
                  color: "rgba(0,212,255,0.7)",
                  fontSize: "12px",
                  cursor: "pointer",
                  padding: 0,
                  textDecoration: "underline",
                }}
              >
                다른 카드 사용
              </button>
            </div>
          ) : (
            /* 카드 입력 폼 */
            <div>
              {hasPaymentMethod && (
                <button
                  onClick={() => setUseNewCard(false)}
                  style={{
                    background: "transparent",
                    border: "none",
                    color: "rgba(0,212,255,0.7)",
                    fontSize: "12px",
                    cursor: "pointer",
                    padding: 0,
                    textDecoration: "underline",
                    marginBottom: "12px",
                    display: "block",
                  }}
                >
                  ← 등록된 카드 사용
                </button>
              )}
              {/* 카드 브랜드 */}
              <div style={{ marginBottom: "12px" }}>
                <label style={labelStyle}>카드 브랜드</label>
                <select
                  name="card_brand"
                  value={cardForm.card_brand}
                  onChange={handleCardChange}
                  style={{ ...inputStyle, cursor: "pointer" }}
                >
                  <option value="" style={{ background: "#13131a" }}>선택하세요</option>
                  {["Visa", "Mastercard", "Amex", "KakaoBank", "TossBank", "Shinhan", "KB", "Hyundai", "Lotte", "Hana", "Samsung"].map((b) => (
                    <option key={b} value={b} style={{ background: "#13131a" }}>{b}</option>
                  ))}
                </select>
              </div>
              {/* 카드 번호 끝 4자리 */}
              <div style={{ marginBottom: "12px" }}>
                <label style={labelStyle}>카드 번호 끝 4자리</label>
                <input
                  name="card_number_last4"
                  type="text"
                  inputMode="numeric"
                  maxLength={4}
                  placeholder="1234"
                  value={cardForm.card_number_last4}
                  onChange={handleCardChange}
                  style={inputStyle}
                />
              </div>
              {/* 유효기간 */}
              <div>
                <label style={labelStyle}>유효기간</label>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "10px" }}>
                  <input
                    name="exp_month"
                    type="text"
                    inputMode="numeric"
                    maxLength={2}
                    placeholder="MM"
                    value={cardForm.exp_month}
                    onChange={handleCardChange}
                    style={inputStyle}
                  />
                  <input
                    name="exp_year"
                    type="text"
                    inputMode="numeric"
                    maxLength={2}
                    placeholder="YY"
                    value={cardForm.exp_year}
                    onChange={handleCardChange}
                    style={inputStyle}
                  />
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* 요약 + 제출 */}
      {!isSamePlan && (
        <div
          style={{
            background: "rgba(255,255,255,0.03)",
            border: "1px solid rgba(255,255,255,0.08)",
            borderRadius: "16px",
            padding: "20px",
          }}
        >
          {/* 결제 요약 */}
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: "16px",
            }}
          >
            <div>
              <div style={{ fontSize: "13px", color: "rgba(255,255,255,0.5)", marginBottom: "4px" }}>
                변경 요약
              </div>
              <div style={{ fontSize: "15px", fontWeight: 600, color: "#fff" }}>
                {PLAN_LABELS[currentPlan]}{" "}
                <span style={{ color: "rgba(255,255,255,0.4)", fontWeight: 400 }}>→</span>{" "}
                {PLAN_LABELS[selectedPlan]}
                {" "}
                <span
                  style={{
                    fontSize: "12px",
                    color: isUpgrade ? "#22c55e" : "#f87171",
                    fontWeight: 600,
                  }}
                >
                  ({isUpgrade ? "업그레이드" : "다운그레이드"})
                </span>
              </div>
            </div>
            {!isFreeSelected && (
              <div style={{ textAlign: "right" }}>
                <div style={{ fontSize: "11px", color: "rgba(255,255,255,0.4)", marginBottom: "2px" }}>
                  {billingCycle === "yearly" ? "연간 결제" : "월간 결제"}
                </div>
                <div style={{ fontSize: "22px", fontWeight: 800, color: "#00d4ff" }}>
                  {formatKRW(billingCycle === "yearly" ? selectedPrice * 12 : selectedPrice)}
                </div>
                {billingCycle === "yearly" && (
                  <div style={{ fontSize: "11px", color: "rgba(255,255,255,0.4)" }}>
                    월 {formatKRW(selectedPrice)}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* 제출 버튼 */}
          <button
            onClick={handleSubmit}
            disabled={upgradePlan.isPending || downgradePlan.isPending}
            style={{
              width: "100%",
              padding: "13px 0",
              background:
                upgradePlan.isPending || downgradePlan.isPending
                  ? "rgba(0,212,255,0.3)"
                  : isDowngrade
                  ? "linear-gradient(135deg, #f59e0b, #ef4444)"
                  : "linear-gradient(135deg, #00d4ff, #7c3aed)",
              border: "none",
              borderRadius: "10px",
              color: "#fff",
              fontSize: "15px",
              fontWeight: 700,
              cursor:
                upgradePlan.isPending || downgradePlan.isPending ? "not-allowed" : "pointer",
              transition: "opacity 0.2s",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              gap: "8px",
            }}
          >
            {upgradePlan.isPending || downgradePlan.isPending ? (
              "처리 중..."
            ) : (
              <>
                {isUpgrade ? (
                  <>
                    <Sparkles size={16} />
                    {PLAN_LABELS[selectedPlan]} 플랜으로 업그레이드
                  </>
                ) : (
                  <>
                    <ChevronRight size={16} />
                    {PLAN_LABELS[selectedPlan]} 플랜으로 변경
                  </>
                )}
              </>
            )}
          </button>

          <p
            style={{
              textAlign: "center",
              fontSize: "11px",
              color: "rgba(255,255,255,0.3)",
              marginTop: "10px",
              marginBottom: 0,
            }}
          >
            변경 후 즉시 적용됩니다. 언제든지 취소하거나 변경할 수 있습니다.
          </p>
        </div>
      )}

      {/* 현재 플랜 선택 시 안내 */}
      {isSamePlan && (
        <div
          style={{
            textAlign: "center",
            padding: "24px",
            color: "rgba(255,255,255,0.4)",
            fontSize: "14px",
          }}
        >
          현재 이용 중인 플랜입니다. 다른 플랜을 선택해 변경하세요.
        </div>
      )}

      {/* 스피너 애니메이션 */}
      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}
