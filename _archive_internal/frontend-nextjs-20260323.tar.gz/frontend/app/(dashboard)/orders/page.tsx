"use client";

/**
 * 주문 목록 페이지 (Sprint 5)
 *
 * - 헤더: 제목 + "새 주문" 버튼
 * - 상태별 필터 탭 (전체 / 결제완료 / 확정 / 진행중 / 완료 / 취소/환불)
 * - 검색 입력 (상품명 클라이언트 필터)
 * - 주문 테이블 (20건씩 페이지네이션)
 * - 빈 상태 안내
 * - 스켈레톤 로딩
 */
import { useState, useMemo } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  Plus,
  Search,
  ShoppingBag,
  Loader2,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import { useAuthStore } from "@/store/authStore";
import { useOrders, type OrderListItem } from "@/hooks/useOrders";
import { formatDate, formatKRW } from "@/lib/utils";

// ============================
// 상태 필터 탭 정의
// ============================

interface FilterTab {
  value: string | null;  // null = 전체
  label: string;
  dotColor: string;
}

const FILTER_TABS: FilterTab[] = [
  { value: null,          label: "전체",    dotColor: "bg-slate-400" },
  { value: "pending",     label: "결제완료", dotColor: "bg-blue-400" },
  { value: "confirmed",   label: "주문확정", dotColor: "bg-indigo-400" },
  { value: "in_progress", label: "진행중",  dotColor: "bg-yellow-400" },
  { value: "completed",   label: "완료",    dotColor: "bg-green-400" },
  { value: "cancelled",   label: "취소",    dotColor: "bg-slate-500" },
  { value: "disputed",    label: "분쟁",    dotColor: "bg-orange-400" },
];

// ============================
// 상태 배지 스타일
// ============================

const STATUS_BADGE: Record<
  string,
  { label: string; className: string }
> = {
  pending:     { label: "결제완료", className: "bg-blue-500/15 text-blue-300 border-blue-500/30" },
  confirmed:   { label: "주문확정", className: "bg-indigo-500/15 text-indigo-300 border-indigo-500/30" },
  in_progress: { label: "진행중",  className: "bg-yellow-500/15 text-yellow-300 border-yellow-500/30" },
  completed:   { label: "완료",    className: "bg-green-500/15 text-green-300 border-green-500/30" },
  cancelled:   { label: "취소",    className: "bg-slate-500/15 text-slate-400 border-slate-500/30" },
  refunded:    { label: "환불",    className: "bg-slate-500/15 text-slate-400 border-slate-500/30" },
  disputed:    { label: "분쟁처리", className: "bg-orange-500/15 text-orange-300 border-orange-500/30" },
};

function StatusBadge({ status }: { status: string }) {
  const info = STATUS_BADGE[status] ?? { label: status, className: "bg-slate-500/15 text-slate-400 border-slate-500/30" };
  return (
    <span
      className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${info.className}`}
    >
      {info.label}
    </span>
  );
}

// ============================
// 스켈레톤 로딩
// ============================

function TableSkeleton() {
  return (
    <div className="space-y-2">
      {Array.from({ length: 5 }).map((_, i) => (
        <div
          key={i}
          className="animate-pulse h-16 rounded-xl"
          style={{ background: "rgba(255,255,255,0.04)" }}
        />
      ))}
    </div>
  );
}

// ============================
// 빈 상태
// ============================

function OrderEmptyState({ hasFilter }: { hasFilter: boolean }) {
  return (
    <div
      className="flex flex-col items-center justify-center py-20 rounded-2xl text-center"
      style={{
        background: "rgba(255,255,255,0.02)",
        border: "1px dashed rgba(255,255,255,0.1)",
      }}
    >
      <ShoppingBag className="w-12 h-12 text-slate-600 mb-4" />
      <p className="text-slate-400 font-medium">
        {hasFilter ? "해당 조건의 주문이 없습니다" : "아직 주문 내역이 없습니다"}
      </p>
      <p className="text-slate-600 text-sm mt-1">
        {hasFilter
          ? "다른 필터를 선택하거나 전체 목록을 확인해보세요."
          : "새 주문 버튼을 클릭하여 첫 주문을 만들어보세요."}
      </p>
      {!hasFilter && (
        <Link
          href="/orders/new"
          className="mt-6 inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-semibold text-white"
          style={{ background: "rgba(59,130,246,0.8)" }}
        >
          <Plus className="w-4 h-4" />
          첫 주문 만들기
        </Link>
      )}
    </div>
  );
}

// ============================
// 메인 페이지
// ============================

const PAGE_SIZE = 20;

export default function OrdersPage() {
  const router = useRouter();
  const { workspace } = useAuthStore();
  const workspaceId = workspace?.id ?? "";

  // ── 필터 + 검색 상태 ─────────────────────────────────────
  const [activeTab, setActiveTab] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);

  // ── 탭 변경 시 페이지 초기화 ─────────────────────────────
  function handleTabChange(value: string | null) {
    setActiveTab(value);
    setPage(1);
  }

  // ── 데이터 조회 ──────────────────────────────────────────
  const { data, isLoading, isError } = useOrders(
    workspaceId,
    activeTab,
    page,
    PAGE_SIZE,
  );

  // ── 클라이언트 사이드 검색 필터 ──────────────────────────
  const filteredItems = useMemo<OrderListItem[]>(() => {
    if (!data?.items) return [];
    if (!search.trim()) return data.items;
    const q = search.trim().toLowerCase();
    return data.items.filter(
      (o) =>
        o.product_name.toLowerCase().includes(q) ||
        (o.place_name ?? "").toLowerCase().includes(q),
    );
  }, [data?.items, search]);

  const totalPages = data ? Math.ceil(data.total / PAGE_SIZE) : 0;
  const hasFilter = !!activeTab || !!search.trim();

  return (
    <div className="space-y-6">
      {/* ── 헤더 ────────────────────────────────────────── */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-white text-xl font-bold">주문 관리</h1>
          <p className="text-slate-500 text-sm mt-0.5">
            마케팅 서비스 주문 내역을 확인하고 관리합니다.
          </p>
        </div>
        <Link
          href="/orders/new"
          className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold text-white"
          style={{ background: "rgba(59,130,246,0.8)" }}
        >
          <Plus className="w-4 h-4" />
          새 주문
        </Link>
      </div>

      {/* ── 필터 탭 ─────────────────────────────────────── */}
      <div
        className="flex items-center gap-1 p-1 rounded-xl overflow-x-auto"
        style={{ background: "rgba(255,255,255,0.04)" }}
      >
        {FILTER_TABS.map((tab) => {
          const isActive = activeTab === tab.value;
          return (
            <button
              key={tab.label}
              onClick={() => handleTabChange(tab.value)}
              className={`
                flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium transition whitespace-nowrap
                ${isActive
                  ? "bg-white/10 text-white"
                  : "text-slate-500 hover:text-slate-300 hover:bg-white/5"
                }
              `}
            >
              <span className={`w-1.5 h-1.5 rounded-full ${tab.dotColor}`} />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* ── 검색 입력 ────────────────────────────────────── */}
      <div className="relative">
        <Search
          className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500"
        />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="상품명 또는 장소명으로 검색..."
          className="w-full pl-11 pr-4 py-2.5 rounded-xl text-sm text-white outline-none"
          style={{
            background: "rgba(255,255,255,0.05)",
            border: "1px solid rgba(255,255,255,0.08)",
          }}
        />
      </div>

      {/* ── 테이블 ───────────────────────────────────────── */}
      {isLoading ? (
        <TableSkeleton />
      ) : isError ? (
        <div className="text-center py-12 text-red-400 text-sm">
          주문 목록을 불러오지 못했습니다.
        </div>
      ) : filteredItems.length === 0 ? (
        <OrderEmptyState hasFilter={hasFilter} />
      ) : (
        <>
          {/* 테이블 컨테이너 */}
          <div
            className="rounded-2xl overflow-hidden"
            style={{ border: "1px solid rgba(255,255,255,0.08)" }}
          >
            {/* 헤더 행 */}
            <div
              className="grid grid-cols-12 px-5 py-3 text-xs text-slate-500 font-medium uppercase tracking-wide"
              style={{ background: "rgba(255,255,255,0.04)" }}
            >
              <div className="col-span-4">상품명 / 장소</div>
              <div className="col-span-2 text-center">상태</div>
              <div className="col-span-2 text-right">수량</div>
              <div className="col-span-2 text-right">금액</div>
              <div className="col-span-2 text-right">주문일시</div>
            </div>

            {/* 데이터 행 */}
            {filteredItems.map((order, idx) => (
              <div
                key={order.id}
                onClick={() => router.push(`/orders/${order.id}`)}
                className="grid grid-cols-12 px-5 py-4 cursor-pointer transition hover:bg-white/5 items-center"
                style={{
                  borderTop: idx === 0 ? "none" : "1px solid rgba(255,255,255,0.05)",
                }}
              >
                {/* 상품명 + 장소 */}
                <div className="col-span-4 min-w-0">
                  <p className="text-white text-sm font-medium truncate">
                    {order.product_name}
                  </p>
                  {order.place_name && (
                    <p className="text-slate-500 text-xs mt-0.5 truncate">
                      {order.place_name}
                    </p>
                  )}
                </div>

                {/* 상태 배지 */}
                <div className="col-span-2 flex justify-center">
                  <StatusBadge status={order.status} />
                </div>

                {/* 수량 */}
                <div className="col-span-2 text-right">
                  <span className="text-slate-300 text-sm">{order.quantity.toLocaleString()}</span>
                </div>

                {/* 금액 */}
                <div className="col-span-2 text-right">
                  <span className="text-white text-sm font-semibold">
                    {formatKRW(order.total_amount)}
                  </span>
                </div>

                {/* 주문일시 */}
                <div className="col-span-2 text-right">
                  <span className="text-slate-500 text-xs">
                    {order.ordered_at
                      ? formatDate(order.ordered_at)
                      : formatDate(order.created_at)}
                  </span>
                </div>
              </div>
            ))}
          </div>

          {/* ── 페이지네이션 ───────────────────────────────── */}
          {totalPages > 1 && (
            <div className="flex items-center justify-between pt-2">
              {/* 요약 텍스트 */}
              <p className="text-slate-500 text-sm">
                전체 {data?.total ?? 0}건 중{" "}
                {Math.min((page - 1) * PAGE_SIZE + 1, data?.total ?? 0)}–
                {Math.min(page * PAGE_SIZE, data?.total ?? 0)}건
              </p>

              {/* 페이지 버튼 */}
              <div className="flex items-center gap-1">
                {/* 이전 */}
                <button
                  onClick={() => setPage((p) => Math.max(1, p - 1))}
                  disabled={page === 1}
                  className="p-1.5 rounded-lg disabled:opacity-30 hover:bg-white/10 text-slate-400 transition"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>

                {/* 페이지 번호 */}
                {Array.from({ length: totalPages }, (_, i) => i + 1)
                  .filter(
                    (p) => p === 1 || p === totalPages || Math.abs(p - page) <= 2,
                  )
                  .map((p, idx, arr) => {
                    const prev = arr[idx - 1];
                    const showEllipsis = prev && p - prev > 1;
                    return (
                      <span key={p} className="flex items-center gap-1">
                        {showEllipsis && (
                          <span className="text-slate-600 text-sm px-1">…</span>
                        )}
                        <button
                          onClick={() => setPage(p)}
                          className={`w-8 h-8 rounded-lg text-sm font-medium transition ${
                            p === page
                              ? "bg-blue-500/80 text-white"
                              : "text-slate-400 hover:bg-white/10"
                          }`}
                        >
                          {p}
                        </button>
                      </span>
                    );
                  })}

                {/* 다음 */}
                <button
                  onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                  disabled={page === totalPages}
                  className="p-1.5 rounded-lg disabled:opacity-30 hover:bg-white/10 text-slate-400 transition"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}
