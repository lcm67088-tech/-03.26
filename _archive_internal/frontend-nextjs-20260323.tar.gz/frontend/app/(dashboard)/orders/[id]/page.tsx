"use client";

/**
 * 주문 상세 페이지 (Sprint 5)
 *
 * - 헤더: 뒤로가기 + 주문 번호 + 상태 배지
 * - 주문 정보 카드 (상품명, 수량, 금액, 장소, 키워드, 특이사항)
 * - 결제 정보 카드 (결제 수단, 결제 금액, PG 거래 번호)
 * - 주문 상태 타임라인 (OrderStatusTimeline)
 * - 증빙 URL 섹션 (있을 때만)
 * - 액션 버튼:
 *     pending     → 취소 버튼
 *     completed / in_progress → 환불 요청 버튼
 * - RefundModal 포함
 */
import { useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import {
  ChevronLeft,
  Loader2,
  ShoppingBag,
  CreditCard,
  MapPin,
  Tag,
  FileText,
  ExternalLink,
  XCircle,
  RefreshCcw,
  AlertCircle,
} from "lucide-react";
import { toast } from "sonner";
import { useOrder, useCancelOrder } from "@/hooks/useOrders";
import OrderStatusTimeline from "@/components/orders/OrderStatusTimeline";
import RefundModal from "@/components/orders/RefundModal";
import { formatDate, formatKRW } from "@/lib/utils";
import { getApiErrorMessage } from "@/lib/api";
import type { OrderStatusValue } from "@/components/orders/OrderStatusTimeline";

// ============================
// 상태 배지
// ============================

const STATUS_BADGE: Record<string, { label: string; className: string }> = {
  pending:     { label: "결제완료",  className: "bg-blue-500/15 text-blue-300 border-blue-500/30" },
  confirmed:   { label: "주문확정",  className: "bg-indigo-500/15 text-indigo-300 border-indigo-500/30" },
  in_progress: { label: "진행중",   className: "bg-yellow-500/15 text-yellow-300 border-yellow-500/30" },
  completed:   { label: "완료",     className: "bg-green-500/15 text-green-300 border-green-500/30" },
  cancelled:   { label: "취소",     className: "bg-slate-500/15 text-slate-400 border-slate-500/30" },
  refunded:    { label: "환불",     className: "bg-slate-500/15 text-slate-400 border-slate-500/30" },
  disputed:    { label: "분쟁처리", className: "bg-orange-500/15 text-orange-300 border-orange-500/30" },
};

function StatusBadge({ status }: { status: string }) {
  const info = STATUS_BADGE[status] ?? {
    label: status,
    className: "bg-slate-500/15 text-slate-400 border-slate-500/30",
  };
  return (
    <span
      className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold border ${info.className}`}
    >
      {info.label}
    </span>
  );
}

// ============================
// 정보 행 컴포넌트
// ============================

function InfoRow({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex justify-between items-start py-3 border-b border-white/5 last:border-0">
      <span className="text-slate-500 text-sm shrink-0 mr-4">{label}</span>
      <span className="text-white text-sm text-right">{children}</span>
    </div>
  );
}

// ============================
// 결제 수단 한글화
// ============================

const PAYMENT_METHOD_LABEL: Record<string, string> = {
  card:      "신용/체크카드",
  kakaopay:  "카카오페이",
  naverpay:  "네이버페이",
};

// ============================
// 스켈레톤 로딩
// ============================

function OrderDetailSkeleton() {
  return (
    <div className="space-y-6 animate-pulse">
      <div className="h-8 w-60 rounded-lg bg-white/8" />
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-4">
          <div className="h-48 rounded-2xl bg-white/4" />
          <div className="h-32 rounded-2xl bg-white/4" />
        </div>
        <div className="h-60 rounded-2xl bg-white/4" />
      </div>
    </div>
  );
}

// ============================
// 메인 페이지
// ============================

export default function OrderDetailPage() {
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const orderId = params.id;

  // ── 데이터 ───────────────────────────────────────────────
  const { data: order, isLoading, isError } = useOrder(orderId);
  const cancelMutation = useCancelOrder(orderId);

  // ── 모달 상태 ────────────────────────────────────────────
  const [refundModalOpen, setRefundModalOpen] = useState(false);

  // ── 취소 핸들러 ──────────────────────────────────────────
  async function handleCancel() {
    if (!confirm("정말 주문을 취소하시겠습니까?")) return;
    try {
      await cancelMutation.mutateAsync();
      toast.success("주문이 취소되었습니다.");
    } catch (err) {
      toast.error(getApiErrorMessage(err));
    }
  }

  // ── 로딩/에러 처리 ─────────────────────────────────────
  if (isLoading) return <OrderDetailSkeleton />;

  if (isError || !order) {
    return (
      <div className="flex flex-col items-center justify-center py-24 gap-4">
        <AlertCircle className="w-10 h-10 text-red-400" />
        <p className="text-slate-400">주문 정보를 불러오지 못했습니다.</p>
        <Link
          href="/orders"
          className="text-blue-400 hover:text-blue-300 text-sm underline"
        >
          주문 목록으로 돌아가기
        </Link>
      </div>
    );
  }

  // ── 액션 버튼 표시 여부 ─────────────────────────────────
  const canCancel = order.status === "pending";
  const canRefund =
    order.status === "completed" || order.status === "in_progress";

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* ── 헤더 ────────────────────────────────────────── */}
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div className="flex items-center gap-3">
          <Link
            href="/orders"
            className="flex items-center gap-1 text-slate-400 hover:text-white text-sm transition"
          >
            <ChevronLeft className="w-4 h-4" />
            주문 목록
          </Link>
          <span className="text-slate-700">|</span>
          <h1 className="text-white font-bold text-lg">주문 상세</h1>
        </div>
        <StatusBadge status={order.status} />
      </div>

      {/* ── 주문 번호 ────────────────────────────────────── */}
      <p className="text-slate-600 text-xs font-mono">주문 번호: {order.id}</p>

      {/* ── 본문 그리드 ─────────────────────────────────── */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* 왼쪽 2 컬럼 — 상세 정보 */}
        <div className="lg:col-span-2 space-y-5">
          {/* 주문 정보 카드 */}
          <div
            className="rounded-2xl p-6"
            style={{
              background: "rgba(255,255,255,0.03)",
              border: "1px solid rgba(255,255,255,0.08)",
            }}
          >
            <div className="flex items-center gap-2 mb-4">
              <ShoppingBag className="w-4 h-4 text-blue-400" />
              <h2 className="text-white font-semibold text-sm">주문 정보</h2>
            </div>

            <InfoRow label="상품명">{order.product_name}</InfoRow>
            <InfoRow label="수량">
              {order.quantity.toLocaleString()} {/* 단위는 상품 정보에서 가져오기 어려우므로 건으로 표기 */}
            </InfoRow>
            <InfoRow label="단가">{formatKRW(order.unit_price)}</InfoRow>
            <InfoRow label="결제 금액">
              <span className="font-bold text-blue-300 text-base">
                {formatKRW(order.total_amount)}
              </span>
            </InfoRow>

            {/* 장소 */}
            {order.place && (
              <InfoRow label="대상 장소">
                <span className="flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-slate-500" />
                  {order.place.alias ?? order.place.name}
                </span>
              </InfoRow>
            )}

            {/* 키워드 */}
            {order.keywords && order.keywords.length > 0 && (
              <div className="py-3 border-b border-white/5">
                <p className="text-slate-500 text-sm mb-2">대상 키워드</p>
                <div className="flex flex-wrap gap-2">
                  {order.keywords.map((kw) => (
                    <span
                      key={kw.id}
                      className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs"
                      style={{
                        background: "rgba(59,130,246,0.1)",
                        border: "1px solid rgba(59,130,246,0.2)",
                        color: "#93c5fd",
                      }}
                    >
                      <Tag className="w-2.5 h-2.5" />
                      {kw.keyword}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* 특이사항 */}
            {order.special_requests && (
              <InfoRow label="특이사항">
                <span className="text-slate-300 text-xs leading-relaxed">
                  {order.special_requests}
                </span>
              </InfoRow>
            )}

            {/* 주문/완료 시각 */}
            {order.ordered_at && (
              <InfoRow label="결제 완료">
                {formatDate(order.ordered_at)}
              </InfoRow>
            )}
            {order.completed_at && (
              <InfoRow label="작업 완료">
                {formatDate(order.completed_at)}
              </InfoRow>
            )}
          </div>

          {/* 결제 정보 카드 */}
          {order.payment && (
            <div
              className="rounded-2xl p-6"
              style={{
                background: "rgba(255,255,255,0.03)",
                border: "1px solid rgba(255,255,255,0.08)",
              }}
            >
              <div className="flex items-center gap-2 mb-4">
                <CreditCard className="w-4 h-4 text-green-400" />
                <h2 className="text-white font-semibold text-sm">결제 정보</h2>
              </div>

              <InfoRow label="결제 수단">
                {order.payment.method
                  ? PAYMENT_METHOD_LABEL[order.payment.method] ?? order.payment.method
                  : "-"}
              </InfoRow>
              <InfoRow label="결제 금액">
                {formatKRW(order.payment.amount)}
              </InfoRow>
              <InfoRow label="결제 상태">
                <span
                  className={
                    order.payment.status === "completed"
                      ? "text-green-400"
                      : order.payment.status === "refunded"
                      ? "text-yellow-400"
                      : "text-slate-400"
                  }
                >
                  {order.payment.status === "completed"
                    ? "결제 완료"
                    : order.payment.status === "pending"
                    ? "대기 중"
                    : order.payment.status === "refunded"
                    ? "환불됨"
                    : order.payment.status}
                </span>
              </InfoRow>
              {order.payment.pg_transaction_id && (
                <InfoRow label="거래 번호">
                  <span className="font-mono text-xs text-slate-400">
                    {order.payment.pg_transaction_id}
                  </span>
                </InfoRow>
              )}
              {order.payment.paid_at && (
                <InfoRow label="결제 시각">
                  {formatDate(order.payment.paid_at)}
                </InfoRow>
              )}
            </div>
          )}

          {/* 증빙 URL (어드민이 업로드 시 표시) */}
          {order.proof_url && (
            <div
              className="rounded-2xl p-5 flex items-center gap-3"
              style={{
                background: "rgba(34, 197, 94, 0.06)",
                border: "1px solid rgba(34, 197, 94, 0.2)",
              }}
            >
              <FileText className="w-5 h-5 text-green-400 shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="text-green-300 font-medium text-sm">작업 증빙 파일</p>
                <a
                  href={order.proof_url}
                  target="_blank"
                  rel="noreferrer"
                  className="text-green-400 text-xs hover:underline flex items-center gap-1 mt-0.5 truncate"
                >
                  {order.proof_url}
                  <ExternalLink className="w-3 h-3 shrink-0" />
                </a>
              </div>
            </div>
          )}

          {/* 매체사 정보 (어드민 배정 후) */}
          {order.media_company_name && (
            <div
              className="rounded-2xl p-5"
              style={{
                background: "rgba(255,255,255,0.03)",
                border: "1px solid rgba(255,255,255,0.08)",
              }}
            >
              <p className="text-slate-400 text-sm">
                담당 매체사:{" "}
                <span className="text-white font-medium">
                  {order.media_company_name}
                </span>
              </p>
            </div>
          )}
        </div>

        {/* 오른쪽 1 컬럼 — 타임라인 + 액션 버튼 */}
        <div className="space-y-5">
          {/* 상태 타임라인 */}
          <div
            className="rounded-2xl p-5"
            style={{
              background: "rgba(255,255,255,0.03)",
              border: "1px solid rgba(255,255,255,0.08)",
            }}
          >
            <h2 className="text-white font-semibold text-sm mb-5">
              주문 진행 상태
            </h2>
            <OrderStatusTimeline
              currentStatus={order.status as OrderStatusValue}
              orderedAt={order.ordered_at}
              completedAt={order.completed_at}
            />
          </div>

          {/* 액션 버튼 */}
          {(canCancel || canRefund) && (
            <div
              className="rounded-2xl p-5 space-y-3"
              style={{
                background: "rgba(255,255,255,0.03)",
                border: "1px solid rgba(255,255,255,0.08)",
              }}
            >
              <h2 className="text-white font-semibold text-sm mb-2">
                주문 관리
              </h2>

              {/* 취소 버튼 */}
              {canCancel && (
                <button
                  onClick={handleCancel}
                  disabled={cancelMutation.isPending}
                  className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm font-medium transition disabled:opacity-50"
                  style={{
                    background: "rgba(239, 68, 68, 0.1)",
                    border: "1px solid rgba(239, 68, 68, 0.3)",
                    color: "#fca5a5",
                  }}
                >
                  {cancelMutation.isPending ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <XCircle className="w-4 h-4" />
                  )}
                  주문 취소
                </button>
              )}

              {/* 환불 요청 버튼 */}
              {canRefund && (
                <button
                  onClick={() => setRefundModalOpen(true)}
                  className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm font-medium transition"
                  style={{
                    background: "rgba(249, 115, 22, 0.1)",
                    border: "1px solid rgba(249, 115, 22, 0.3)",
                    color: "#fdba74",
                  }}
                >
                  <RefreshCcw className="w-4 h-4" />
                  환불 요청
                </button>
              )}

              {/* 주의 안내문 */}
              <p className="text-slate-600 text-xs leading-relaxed pt-1">
                {canCancel
                  ? "취소는 결제 완료(pending) 상태에서만 가능합니다."
                  : "환불 요청은 작업 진행 중 또는 완료 후 신청 가능합니다."}
              </p>
            </div>
          )}

          {/* 이미 분쟁/취소/환불 상태 안내 */}
          {(order.status === "disputed" ||
            order.status === "cancelled" ||
            order.status === "refunded") && (
            <div
              className="rounded-2xl p-5"
              style={{
                background: "rgba(255,255,255,0.03)",
                border: "1px solid rgba(255,255,255,0.08)",
              }}
            >
              <p className="text-slate-500 text-sm leading-relaxed">
                {order.status === "disputed" &&
                  "환불 요청이 접수되었습니다. 영업일 기준 1~3일 내 처리됩니다."}
                {order.status === "cancelled" &&
                  "취소된 주문입니다. 새 주문을 생성해주세요."}
                {order.status === "refunded" &&
                  "환불 완료된 주문입니다."}
              </p>
            </div>
          )}
        </div>
      </div>

      {/* ── 환불 요청 모달 ───────────────────────────────── */}
      <RefundModal
        orderId={orderId}
        open={refundModalOpen}
        onClose={() => setRefundModalOpen(false)}
        onSuccess={() => {
          setRefundModalOpen(false);
        }}
      />
    </div>
  );
}
