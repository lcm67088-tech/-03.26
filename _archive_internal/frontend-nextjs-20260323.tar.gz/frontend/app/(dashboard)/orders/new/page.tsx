"use client";

/**
 * 새 주문 위저드 페이지 (Sprint 5)
 *
 * 3단계 위저드로 구성:
 *   Step 1. 상품 선택   — 유형별 상품 카드 목록, 수량 입력
 *   Step 2. 장소/키워드 — 장소 선택 (선택), 키워드 체크 (선택)
 *   Step 3. 결제        — 결제 수단 선택, 주문 요약, Mock 결제 처리
 *
 * 위저드 전체 상태를 하나의 useState로 관리.
 * 단계 이동 시 데이터 유지.
 */
import { useState, useMemo } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import {
  ChevronLeft,
  ChevronRight,
  Check,
  Loader2,
  ShoppingBag,
  MapPin,
  CreditCard,
  Tag,
  Star,
  Zap,
} from "lucide-react";
import { toast } from "sonner";
import { useAuthStore } from "@/store/authStore";
import { usePlaces } from "@/hooks/usePlaces";
import { useKeywords } from "@/hooks/useKeywords";
import {
  useProducts,
  useCreateOrder,
  useCompletePayment,
  type ProductTypeWithProducts,
  type ProductResponse,
} from "@/hooks/useOrders";
import { formatKRW } from "@/lib/utils";
import { getApiErrorMessage } from "@/lib/api";

// ============================
// 위저드 상태 타입
// ============================

interface WizardState {
  // Step 1
  selectedProduct: ProductResponse | null;
  quantity: number;
  // Step 2
  selectedPlaceId: string | null;
  selectedKeywordIds: string[];
  specialRequests: string;
  // Step 3
  paymentMethod: "kakaopay" | "naverpay" | "card";
}

const INITIAL_WIZARD: WizardState = {
  selectedProduct: null,
  quantity: 1,
  selectedPlaceId: null,
  selectedKeywordIds: [],
  specialRequests: "",
  paymentMethod: "card",
};

// ============================
// 단계 바 컴포넌트
// ============================

const STEP_LABELS = ["상품 선택", "장소 / 키워드", "결제"];

function StepBar({ current }: { current: number }) {
  return (
    <div className="flex items-center gap-0">
      {STEP_LABELS.map((label, idx) => {
        const step = idx + 1;
        const isDone = step < current;
        const isCurrent = step === current;
        return (
          <div key={step} className="flex items-center">
            {/* 단계 원 */}
            <div className="flex flex-col items-center">
              <div
                className={`
                  w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold border-2 transition
                  ${isDone ? "bg-green-500 border-green-500 text-white"
                    : isCurrent ? "bg-blue-500 border-blue-500 text-white"
                    : "bg-transparent border-slate-700 text-slate-600"}
                `}
              >
                {isDone ? <Check className="w-4 h-4" /> : step}
              </div>
              <span
                className={`mt-1 text-xs font-medium ${
                  isCurrent ? "text-blue-400" : isDone ? "text-green-400" : "text-slate-600"
                }`}
              >
                {label}
              </span>
            </div>
            {/* 연결선 */}
            {idx < STEP_LABELS.length - 1 && (
              <div
                className={`h-0.5 w-20 mx-2 mb-5 transition ${isDone ? "bg-green-500" : "bg-slate-700"}`}
              />
            )}
          </div>
        );
      })}
    </div>
  );
}

// ============================
// Step 1: 상품 선택
// ============================

interface Step1Props {
  wizard: WizardState;
  setWizard: React.Dispatch<React.SetStateAction<WizardState>>;
}

function Step1ProductSelect({ wizard, setWizard }: Step1Props) {
  const { data: productsData, isLoading } = useProducts();

  // 수량 입력 변경
  function handleQuantityChange(value: string) {
    const num = parseInt(value, 10);
    if (isNaN(num) || num < 1) return;
    const min = wizard.selectedProduct?.min_quantity ?? 1;
    const max = wizard.selectedProduct?.max_quantity ?? 99999;
    setWizard((prev) => ({
      ...prev,
      quantity: Math.min(Math.max(num, min), max),
    }));
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-6 h-6 animate-spin text-slate-500" />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {productsData?.product_types.map((pt: ProductTypeWithProducts) => (
        <div key={pt.id}>
          {/* 유형 헤더 */}
          <div className="flex items-center gap-2 mb-4">
            <Tag className="w-4 h-4 text-blue-400" />
            <h3 className="text-white font-semibold text-base">{pt.name}</h3>
            {pt.description && (
              <span className="text-slate-500 text-sm">— {pt.description}</span>
            )}
          </div>

          {/* 상품 카드 그리드 */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {pt.products.map((product) => {
              const isSelected = wizard.selectedProduct?.id === product.id;
              return (
                <button
                  key={product.id}
                  onClick={() =>
                    setWizard((prev) => ({
                      ...prev,
                      selectedProduct: product,
                      quantity: Math.max(
                        prev.quantity,
                        product.min_quantity,
                      ),
                    }))
                  }
                  className="text-left rounded-2xl p-5 transition relative flex flex-col gap-3"
                  style={{
                    background: isSelected
                      ? "rgba(59, 130, 246, 0.12)"
                      : "rgba(255,255,255,0.04)",
                    border: isSelected
                      ? "2px solid rgba(59, 130, 246, 0.6)"
                      : "2px solid rgba(255,255,255,0.08)",
                  }}
                >
                  {/* 배지 */}
                  {product.badge && (
                    <span
                      className="absolute top-4 right-4 text-xs font-bold px-2 py-0.5 rounded-full"
                      style={{
                        background:
                          product.badge === "인기"
                            ? "rgba(239,68,68,0.15)"
                            : "rgba(59,130,246,0.15)",
                        color:
                          product.badge === "인기" ? "#f87171" : "#93c5fd",
                      }}
                    >
                      {product.badge}
                    </span>
                  )}

                  {/* 선택 체크 아이콘 */}
                  {isSelected && (
                    <div className="absolute top-4 right-4 w-5 h-5 rounded-full bg-blue-500 flex items-center justify-center">
                      <Check className="w-3 h-3 text-white" />
                    </div>
                  )}

                  {/* 상품명 */}
                  <p className={`font-semibold text-sm ${isSelected ? "text-blue-300" : "text-white"}`}>
                    {product.name}
                  </p>

                  {/* 설명 */}
                  {product.description && (
                    <p className="text-slate-500 text-xs leading-relaxed line-clamp-2">
                      {product.description}
                    </p>
                  )}

                  {/* 특징 목록 */}
                  {product.features.length > 0 && (
                    <ul className="space-y-1">
                      {product.features.map((f, i) => (
                        <li key={i} className="flex items-center gap-1.5 text-xs text-slate-400">
                          <Check className="w-3 h-3 text-green-400 shrink-0" />
                          {f}
                        </li>
                      ))}
                    </ul>
                  )}

                  {/* 가격 */}
                  <div className="mt-auto pt-2 border-t border-white/5">
                    <span className="text-white font-bold">
                      {formatKRW(product.base_price)}
                    </span>
                    <span className="text-slate-500 text-xs ml-1">
                      / {product.unit}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      ))}

      {/* 수량 입력 (상품 선택 후) */}
      {wizard.selectedProduct && (
        <div
          className="rounded-2xl p-5 space-y-4"
          style={{
            background: "rgba(59, 130, 246, 0.06)",
            border: "1px solid rgba(59, 130, 246, 0.2)",
          }}
        >
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-4 h-4 text-blue-400" />
            <p className="text-blue-300 font-semibold text-sm">선택된 상품</p>
          </div>
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div>
              <p className="text-white font-medium">{wizard.selectedProduct.name}</p>
              <p className="text-slate-400 text-xs mt-0.5">
                {formatKRW(wizard.selectedProduct.base_price)} / {wizard.selectedProduct.unit}
                {" · "}
                최소 {wizard.selectedProduct.min_quantity.toLocaleString()}{wizard.selectedProduct.unit}
                {wizard.selectedProduct.max_quantity && (
                  <> ~ 최대 {wizard.selectedProduct.max_quantity.toLocaleString()}{wizard.selectedProduct.unit}</>
                )}
              </p>
            </div>
            {/* 수량 입력 */}
            <div className="flex items-center gap-2">
              <label className="text-slate-400 text-sm">수량</label>
              <input
                type="number"
                min={wizard.selectedProduct.min_quantity}
                max={wizard.selectedProduct.max_quantity ?? 99999}
                value={wizard.quantity}
                onChange={(e) => handleQuantityChange(e.target.value)}
                className="w-28 text-center rounded-xl px-3 py-2 text-white text-sm outline-none"
                style={{
                  background: "rgba(255,255,255,0.08)",
                  border: "1px solid rgba(255,255,255,0.15)",
                }}
              />
              <span className="text-slate-400 text-sm">{wizard.selectedProduct.unit}</span>
            </div>
          </div>
          {/* 소계 */}
          <div className="flex justify-end">
            <span className="text-slate-400 text-sm">소계: </span>
            <span className="text-white font-bold text-sm ml-2">
              {formatKRW(wizard.selectedProduct.base_price * wizard.quantity)}
            </span>
          </div>
        </div>
      )}
    </div>
  );
}

// ============================
// Step 2: 장소 / 키워드 선택
// ============================

interface Step2Props {
  wizard: WizardState;
  setWizard: React.Dispatch<React.SetStateAction<WizardState>>;
  workspaceId: string;
}

function Step2PlaceKeyword({ wizard, setWizard, workspaceId }: Step2Props) {
  const { data: placesData, isLoading: placesLoading } = usePlaces(workspaceId);
  const { data: keywordsData, isLoading: keywordsLoading } = useKeywords(
    wizard.selectedPlaceId ?? "",
  );

  // 키워드 체크박스 토글
  function toggleKeyword(id: string) {
    setWizard((prev) => {
      const set = new Set(prev.selectedKeywordIds);
      if (set.has(id)) set.delete(id);
      else set.add(id);
      return { ...prev, selectedKeywordIds: Array.from(set) };
    });
  }

  return (
    <div className="space-y-6">
      {/* 장소 선택 (선택 사항) */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <MapPin className="w-4 h-4 text-blue-400" />
          <h3 className="text-white font-semibold text-sm">
            대상 장소 선택{" "}
            <span className="text-slate-500 font-normal">(선택 사항)</span>
          </h3>
        </div>

        {placesLoading ? (
          <div className="flex items-center gap-2 py-4 text-slate-500 text-sm">
            <Loader2 className="w-4 h-4 animate-spin" />
            장소 목록 로딩 중...
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* 선택 안함 */}
            <button
              onClick={() =>
                setWizard((prev) => ({
                  ...prev,
                  selectedPlaceId: null,
                  selectedKeywordIds: [],
                }))
              }
              className="text-left p-4 rounded-xl transition"
              style={{
                background:
                  wizard.selectedPlaceId === null
                    ? "rgba(59,130,246,0.1)"
                    : "rgba(255,255,255,0.04)",
                border:
                  wizard.selectedPlaceId === null
                    ? "2px solid rgba(59,130,246,0.5)"
                    : "2px solid rgba(255,255,255,0.08)",
              }}
            >
              <p className="text-slate-300 text-sm font-medium">선택 안함</p>
              <p className="text-slate-600 text-xs mt-0.5">
                특정 장소와 무관한 서비스
              </p>
            </button>

            {placesData?.items.map((place) => {
              const isSelected = wizard.selectedPlaceId === place.id;
              return (
                <button
                  key={place.id}
                  onClick={() =>
                    setWizard((prev) => ({
                      ...prev,
                      selectedPlaceId: place.id,
                      selectedKeywordIds: [],
                    }))
                  }
                  className="text-left p-4 rounded-xl transition"
                  style={{
                    background: isSelected
                      ? "rgba(59,130,246,0.1)"
                      : "rgba(255,255,255,0.04)",
                    border: isSelected
                      ? "2px solid rgba(59,130,246,0.5)"
                      : "2px solid rgba(255,255,255,0.08)",
                  }}
                >
                  <div className="flex items-center justify-between">
                    <p className="text-white text-sm font-medium truncate">
                      {place.alias ?? place.name}
                    </p>
                    {isSelected && <Check className="w-4 h-4 text-blue-400 shrink-0" />}
                  </div>
                  <p className="text-slate-500 text-xs mt-0.5 truncate">{place.name}</p>
                </button>
              );
            })}
          </div>
        )}
      </div>

      {/* 키워드 선택 (장소 선택 시) */}
      {wizard.selectedPlaceId && (
        <div>
          <div className="flex items-center gap-2 mb-3">
            <Star className="w-4 h-4 text-yellow-400" />
            <h3 className="text-white font-semibold text-sm">
              대상 키워드 선택{" "}
              <span className="text-slate-500 font-normal">(선택 사항)</span>
            </h3>
          </div>

          {keywordsLoading ? (
            <div className="flex items-center gap-2 py-4 text-slate-500 text-sm">
              <Loader2 className="w-4 h-4 animate-spin" />
              키워드 목록 로딩 중...
            </div>
          ) : keywordsData && keywordsData.items.length > 0 ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {keywordsData.items.map((kw) => {
                const isChecked = wizard.selectedKeywordIds.includes(kw.id);
                return (
                  <label
                    key={kw.id}
                    className="flex items-center gap-2 p-3 rounded-xl cursor-pointer transition"
                    style={{
                      background: isChecked
                        ? "rgba(59,130,246,0.1)"
                        : "rgba(255,255,255,0.04)",
                      border: isChecked
                        ? "1px solid rgba(59,130,246,0.4)"
                        : "1px solid rgba(255,255,255,0.07)",
                    }}
                  >
                    <input
                      type="checkbox"
                      checked={isChecked}
                      onChange={() => toggleKeyword(kw.id)}
                      className="hidden"
                    />
                    <div
                      className={`w-4 h-4 rounded flex items-center justify-center shrink-0 ${
                        isChecked ? "bg-blue-500" : "bg-white/10"
                      }`}
                    >
                      {isChecked && <Check className="w-2.5 h-2.5 text-white" />}
                    </div>
                    <span className="text-sm truncate">
                      <span className={isChecked ? "text-blue-300" : "text-slate-300"}>
                        {kw.keyword}
                      </span>
                      {kw.latest_rank != null && (
                        <span className="text-slate-600 ml-1 text-xs">
                          {kw.latest_rank}위
                        </span>
                      )}
                    </span>
                    {kw.is_primary && (
                      <Star className="w-3 h-3 text-yellow-400 shrink-0 ml-auto" />
                    )}
                  </label>
                );
              })}
            </div>
          ) : (
            <p className="text-slate-500 text-sm py-4">
              선택한 장소에 등록된 키워드가 없습니다.
            </p>
          )}
        </div>
      )}

      {/* 특이사항 */}
      <div>
        <label className="block text-sm font-medium text-slate-300 mb-2">
          특이사항 / 요청사항{" "}
          <span className="text-slate-500 font-normal">(선택)</span>
        </label>
        <textarea
          value={wizard.specialRequests}
          onChange={(e) =>
            setWizard((prev) => ({
              ...prev,
              specialRequests: e.target.value,
            }))
          }
          placeholder="작업 관련 특이사항이나 요청사항을 입력해주세요."
          rows={3}
          maxLength={1000}
          className="w-full rounded-xl px-4 py-3 text-sm text-white bg-white/5 border border-white/10 resize-none outline-none placeholder:text-slate-600 focus:border-blue-500/50"
        />
        <p className="text-xs text-slate-600 text-right mt-1">
          {wizard.specialRequests.length} / 1000
        </p>
      </div>
    </div>
  );
}

// ============================
// Step 3: 결제
// ============================

interface Step3Props {
  wizard: WizardState;
  setWizard: React.Dispatch<React.SetStateAction<WizardState>>;
  onSubmit: () => void;
  isSubmitting: boolean;
  workspaceId: string;
}

const PAYMENT_METHODS: {
  value: "kakaopay" | "naverpay" | "card";
  label: string;
  icon: string;
}[] = [
  { value: "card",      label: "신용/체크카드", icon: "💳" },
  { value: "kakaopay",  label: "카카오페이",    icon: "🟡" },
  { value: "naverpay",  label: "네이버페이",    icon: "🟢" },
];

function Step3Payment({ wizard, setWizard, onSubmit, isSubmitting, workspaceId }: Step3Props) {
  const { data: placesData } = usePlaces(workspaceId);
  const selectedPlace = placesData?.items.find(
    (p) => p.id === wizard.selectedPlaceId,
  );

  const total = wizard.selectedProduct
    ? wizard.selectedProduct.base_price * wizard.quantity
    : 0;

  return (
    <div className="space-y-6">
      {/* 주문 요약 */}
      <div
        className="rounded-2xl p-5 space-y-4"
        style={{
          background: "rgba(255,255,255,0.04)",
          border: "1px solid rgba(255,255,255,0.08)",
        }}
      >
        <p className="text-white font-semibold text-sm flex items-center gap-2">
          <ShoppingBag className="w-4 h-4 text-blue-400" />
          주문 요약
        </p>

        <div className="space-y-2 text-sm">
          {/* 상품 */}
          <div className="flex justify-between">
            <span className="text-slate-400">상품</span>
            <span className="text-white">{wizard.selectedProduct?.name}</span>
          </div>
          {/* 수량 */}
          <div className="flex justify-between">
            <span className="text-slate-400">수량</span>
            <span className="text-white">
              {wizard.quantity.toLocaleString()}{" "}
              {wizard.selectedProduct?.unit}
            </span>
          </div>
          {/* 단가 */}
          <div className="flex justify-between">
            <span className="text-slate-400">단가</span>
            <span className="text-white">
              {formatKRW(wizard.selectedProduct?.base_price)} / {wizard.selectedProduct?.unit}
            </span>
          </div>
          {/* 장소 */}
          {selectedPlace && (
            <div className="flex justify-between">
              <span className="text-slate-400">대상 장소</span>
              <span className="text-white">
                {selectedPlace.alias ?? selectedPlace.name}
              </span>
            </div>
          )}
          {/* 키워드 수 */}
          {wizard.selectedKeywordIds.length > 0 && (
            <div className="flex justify-between">
              <span className="text-slate-400">대상 키워드</span>
              <span className="text-white">
                {wizard.selectedKeywordIds.length}개
              </span>
            </div>
          )}
          {/* 특이사항 */}
          {wizard.specialRequests.trim() && (
            <div className="flex justify-between items-start">
              <span className="text-slate-400 shrink-0">특이사항</span>
              <span className="text-slate-300 text-right ml-4 text-xs">
                {wizard.specialRequests.slice(0, 50)}
                {wizard.specialRequests.length > 50 ? "..." : ""}
              </span>
            </div>
          )}

          {/* 구분선 */}
          <div className="border-t border-white/8 my-1" />

          {/* 합계 */}
          <div className="flex justify-between">
            <span className="text-white font-semibold">결제 금액</span>
            <span className="text-blue-300 font-bold text-lg">
              {formatKRW(total)}
            </span>
          </div>
        </div>
      </div>

      {/* 결제 수단 선택 */}
      <div>
        <p className="text-slate-300 font-medium text-sm mb-3 flex items-center gap-2">
          <CreditCard className="w-4 h-4 text-blue-400" />
          결제 수단
        </p>
        <div className="grid grid-cols-3 gap-3">
          {PAYMENT_METHODS.map((pm) => {
            const isSelected = wizard.paymentMethod === pm.value;
            return (
              <button
                key={pm.value}
                onClick={() =>
                  setWizard((prev) => ({
                    ...prev,
                    paymentMethod: pm.value,
                  }))
                }
                className="flex flex-col items-center gap-2 p-4 rounded-xl transition"
                style={{
                  background: isSelected
                    ? "rgba(59,130,246,0.12)"
                    : "rgba(255,255,255,0.04)",
                  border: isSelected
                    ? "2px solid rgba(59,130,246,0.5)"
                    : "2px solid rgba(255,255,255,0.08)",
                }}
              >
                <span className="text-2xl">{pm.icon}</span>
                <span
                  className={`text-xs font-medium ${
                    isSelected ? "text-blue-300" : "text-slate-400"
                  }`}
                >
                  {pm.label}
                </span>
                {isSelected && (
                  <Check className="w-3.5 h-3.5 text-blue-400" />
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Mock 결제 안내 */}
      <div
        className="rounded-xl p-4 text-xs text-slate-500 leading-relaxed flex gap-2"
        style={{
          background: "rgba(255,255,255,0.03)",
          border: "1px solid rgba(255,255,255,0.07)",
        }}
      >
        <Zap className="w-4 h-4 text-yellow-400 shrink-0 mt-0.5" />
        <p>
          <span className="text-yellow-400 font-semibold">개발 환경 안내:</span>{" "}
          현재는 Mock 결제로 처리됩니다. &apos;결제하기&apos; 클릭 시 즉시
          결제 완료 처리됩니다.
        </p>
      </div>

      {/* 결제 버튼 */}
      <button
        onClick={onSubmit}
        disabled={isSubmitting}
        className="w-full py-3.5 rounded-2xl font-bold text-white text-base flex items-center justify-center gap-2 transition disabled:opacity-50"
        style={{
          background: isSubmitting
            ? "rgba(59,130,246,0.4)"
            : "rgba(59,130,246,0.8)",
        }}
      >
        {isSubmitting ? (
          <>
            <Loader2 className="w-5 h-5 animate-spin" />
            결제 처리 중...
          </>
        ) : (
          <>
            <CreditCard className="w-5 h-5" />
            {formatKRW(total)} 결제하기
          </>
        )}
      </button>
    </div>
  );
}

// ============================
// 메인 위저드 페이지
// ============================

export default function NewOrderPage() {
  const router = useRouter();
  const { workspace } = useAuthStore();
  const workspaceId = workspace?.id ?? "";

  // ── 단계 + 위저드 상태 ───────────────────────────────────
  const [step, setStep] = useState(1);
  const [wizard, setWizard] = useState<WizardState>(INITIAL_WIZARD);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const createOrderMutation = useCreateOrder();
  // completePayment 훅은 orderId가 필요하므로 동적으로 처리
  const [createdOrderId, setCreatedOrderId] = useState<string>("");
  const completePaymentMutation = useCompletePayment(createdOrderId);

  // ── 다음 단계 이동 전 유효성 검사 ───────────────────────────
  function canProceed(): boolean {
    if (step === 1) {
      return wizard.selectedProduct !== null && wizard.quantity >= (wizard.selectedProduct?.min_quantity ?? 1);
    }
    return true; // Step 2 이후는 선택사항이므로 항상 진행 가능
  }

  // ── 결제 + 주문 완료 처리 ────────────────────────────────
  async function handlePayment() {
    if (!wizard.selectedProduct || !workspaceId) return;
    setIsSubmitting(true);

    try {
      // 1. 주문 생성
      const res = await createOrderMutation.mutateAsync({
        workspace_id: workspaceId,
        product_id: wizard.selectedProduct.id,
        place_id: wizard.selectedPlaceId,
        keyword_ids: wizard.selectedKeywordIds,
        quantity: wizard.quantity,
        payment_method: wizard.paymentMethod,
        special_requests: wizard.specialRequests.trim() || null,
      });

      const paymentId = res.payment.id;
      const orderId = res.order.id;
      setCreatedOrderId(orderId);

      // 2. Mock PG 결제 완료 처리
      const mockTransactionId = `mock_${Date.now()}`;
      await completePaymentMutation.mutateAsync({
        paymentId,
        body: {
          pg_transaction_id: mockTransactionId,
          method: wizard.paymentMethod,
        },
      });

      toast.success("주문이 완료되었습니다! 담당자가 확인 후 작업을 시작합니다.");
      router.push(`/orders/${orderId}`);
    } catch (err) {
      toast.error(getApiErrorMessage(err));
      setIsSubmitting(false);
    }
  }

  // ── 렌더링 ───────────────────────────────────────────────
  return (
    <div className="max-w-3xl mx-auto space-y-8">
      {/* 헤더 */}
      <div className="flex items-center gap-4">
        <Link
          href="/orders"
          className="flex items-center gap-1 text-slate-400 hover:text-white text-sm transition"
        >
          <ChevronLeft className="w-4 h-4" />
          주문 목록
        </Link>
        <h1 className="text-white text-xl font-bold">새 주문</h1>
      </div>

      {/* 단계 바 */}
      <div className="flex justify-center">
        <StepBar current={step} />
      </div>

      {/* 단계별 컨텐츠 */}
      <div
        className="rounded-2xl p-6 md:p-8"
        style={{
          background: "rgba(255,255,255,0.03)",
          border: "1px solid rgba(255,255,255,0.08)",
        }}
      >
        {step === 1 && (
          <Step1ProductSelect wizard={wizard} setWizard={setWizard} />
        )}
        {step === 2 && (
          <Step2PlaceKeyword
            wizard={wizard}
            setWizard={setWizard}
            workspaceId={workspaceId}
          />
        )}
        {step === 3 && (
          <Step3Payment
            wizard={wizard}
            setWizard={setWizard}
            onSubmit={handlePayment}
            isSubmitting={isSubmitting}
            workspaceId={workspaceId}
          />
        )}
      </div>

      {/* 하단 네비게이션 (Step 3은 자체 버튼 사용) */}
      {step < 3 && (
        <div className="flex justify-between">
          <button
            onClick={() => setStep((s) => s - 1)}
            disabled={step === 1}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium transition disabled:opacity-30"
            style={{
              background: "rgba(255,255,255,0.06)",
              border: "1px solid rgba(255,255,255,0.1)",
              color: "rgba(255,255,255,0.7)",
            }}
          >
            <ChevronLeft className="w-4 h-4" />
            이전
          </button>

          <button
            onClick={() => setStep((s) => s + 1)}
            disabled={!canProceed()}
            className="flex items-center gap-2 px-6 py-2.5 rounded-xl text-sm font-semibold text-white transition disabled:opacity-40"
            style={{ background: "rgba(59,130,246,0.8)" }}
          >
            다음
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      )}
    </div>
  );
}
