/**
 * 계정 설정 페이지
 * Sprint 7: /account
 * - 프로필 수정 (이름/전화번호/프로필 이미지)
 * - 비밀번호 변경
 * - 소속 워크스페이스 목록 및 새 워크스페이스 생성
 */

"use client";

import { useState } from "react";
import { User, Lock, Building2, Plus, Eye, EyeOff } from "lucide-react";
import { toast } from "sonner";
import {
  useProfile,
  useUpdateProfile,
  useChangePassword,
  useMyWorkspaces,
  useCreateWorkspace,
  ROLE_LABELS,
  ROLE_COLORS,
} from "@/hooks/useAccount";

type Tab = "profile" | "password" | "workspaces";

const TABS: { id: Tab; label: string }[] = [
  { id: "profile", label: "프로필" },
  { id: "password", label: "비밀번호" },
  { id: "workspaces", label: "워크스페이스" },
];

const inputStyle: React.CSSProperties = {
  width: "100%",
  padding: "10px 14px",
  borderRadius: "8px",
  border: "1px solid rgba(255,255,255,0.1)",
  background: "rgba(255,255,255,0.04)",
  color: "#fff",
  fontSize: "14px",
  outline: "none",
  boxSizing: "border-box",
};

const labelStyle: React.CSSProperties = {
  fontSize: "13px",
  color: "rgba(255,255,255,0.55)",
  marginBottom: "6px",
  display: "block",
};

export default function AccountPage() {
  const [activeTab, setActiveTab] = useState<Tab>("profile");
  const { data: profile, isLoading: profileLoading } = useProfile();
  const { mutate: updateProfile, isPending: isUpdating } = useUpdateProfile();
  const { mutate: changePassword, isPending: isChangingPassword } = useChangePassword();
  const { data: workspaces, isLoading: workspacesLoading } = useMyWorkspaces();
  const { mutate: createWorkspace, isPending: isCreating } = useCreateWorkspace();

  const [profileForm, setProfileForm] = useState({ name: "", phone: "", profile_image_url: "" });
  const [pwForm, setPwForm] = useState({ current_password: "", new_password: "", confirm_password: "" });
  const [showPw, setShowPw] = useState({ current: false, new: false, confirm: false });
  const [newWsName, setNewWsName] = useState("");
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [profileInitialized, setProfileInitialized] = useState(false);

  if (profile && !profileLoading && !profileInitialized) {
    setProfileForm({ name: profile.name ?? "", phone: profile.phone ?? "", profile_image_url: profile.profile_image_url ?? "" });
    setProfileInitialized(true);
  }

  function handleProfileSave() {
    updateProfile(
      { name: profileForm.name || undefined, phone: profileForm.phone || undefined, profile_image_url: profileForm.profile_image_url || undefined },
      {
        onSuccess: () => toast.success("프로필이 저장되었습니다."),
        onError: (err: any) => toast.error(err?.response?.data?.detail ?? "저장에 실패했습니다."),
      }
    );
  }

  function handlePasswordChange() {
    if (pwForm.new_password !== pwForm.confirm_password) { toast.error("새 비밀번호가 일치하지 않습니다."); return; }
    if (pwForm.new_password.length < 8) { toast.error("비밀번호는 8자 이상이어야 합니다."); return; }
    changePassword(pwForm, {
      onSuccess: () => { toast.success("비밀번호가 변경되었습니다."); setPwForm({ current_password: "", new_password: "", confirm_password: "" }); },
      onError: (err: any) => toast.error(err?.response?.data?.detail ?? "변경에 실패했습니다."),
    });
  }

  function handleCreateWorkspace() {
    if (!newWsName.trim()) { toast.error("이름을 입력해주세요."); return; }
    createWorkspace({ name: newWsName.trim() }, {
      onSuccess: (ws) => { toast.success(`'${ws.name}' 워크스페이스가 생성되었습니다.`); setNewWsName(""); setShowCreateForm(false); },
      onError: (err: any) => toast.error(err?.response?.data?.detail ?? "생성에 실패했습니다."),
    });
  }

  const cardStyle: React.CSSProperties = {
    maxWidth: "560px", background: "rgba(255,255,255,0.04)",
    border: "1px solid rgba(255,255,255,0.08)", borderRadius: "12px", padding: "24px",
  };

  return (
    <div style={{ minHeight: "100vh", background: "#0a0a0f", color: "#fff", padding: "32px", fontFamily: "'Pretendard', sans-serif" }}>
      {/* 헤더 */}
      <div style={{ marginBottom: "28px" }}>
        <h1 style={{ fontSize: "24px", fontWeight: 700, margin: "0 0 6px", display: "flex", alignItems: "center", gap: "10px" }}>
          <User size={22} style={{ color: "#00d4ff" }} />계정 설정
        </h1>
        <p style={{ color: "rgba(255,255,255,0.4)", margin: 0, fontSize: "14px" }}>프로필, 비밀번호, 워크스페이스를 관리합니다.</p>
      </div>

      {/* 탭 바 */}
      <div style={{ display: "flex", gap: "4px", marginBottom: "24px", background: "rgba(255,255,255,0.04)", borderRadius: "10px", padding: "4px", width: "fit-content" }}>
        {TABS.map((tab) => (
          <button key={tab.id} onClick={() => setActiveTab(tab.id)} style={{
            padding: "8px 20px", borderRadius: "7px", border: "none",
            background: activeTab === tab.id ? "rgba(0,212,255,0.12)" : "transparent",
            color: activeTab === tab.id ? "#00d4ff" : "rgba(255,255,255,0.45)",
            fontSize: "13px", fontWeight: activeTab === tab.id ? 600 : 400, cursor: "pointer",
          }}>{tab.label}</button>
        ))}
      </div>

      {/* ── 프로필 탭 ─────────────────────────────────────── */}
      {activeTab === "profile" && (
        <div style={cardStyle}>
          <h2 style={{ fontSize: "16px", fontWeight: 600, margin: "0 0 20px" }}>프로필 정보</h2>
          <div style={{ marginBottom: "16px" }}>
            <label style={labelStyle}>이메일 (변경 불가)</label>
            <input type="email" value={profile?.email ?? ""} readOnly style={{ ...inputStyle, color: "rgba(255,255,255,0.35)", cursor: "not-allowed" }} />
          </div>
          {[
            { key: "name" as const, label: "이름", type: "text", placeholder: "이름을 입력하세요" },
            { key: "phone" as const, label: "전화번호", type: "tel", placeholder: "010-0000-0000" },
            { key: "profile_image_url" as const, label: "프로필 이미지 URL", type: "url", placeholder: "https://example.com/avatar.png" },
          ].map((f) => (
            <div key={f.key} style={{ marginBottom: "16px" }}>
              <label style={labelStyle}>{f.label}</label>
              <input type={f.type} value={profileForm[f.key]} onChange={(e) => setProfileForm((p) => ({ ...p, [f.key]: e.target.value }))} placeholder={f.placeholder} style={inputStyle} />
            </div>
          ))}
          <button onClick={handleProfileSave} disabled={isUpdating || profileLoading} style={{
            width: "100%", padding: "11px", borderRadius: "8px", marginTop: "8px",
            border: "1px solid rgba(0,212,255,0.4)", background: "rgba(0,212,255,0.1)",
            color: "#00d4ff", fontSize: "14px", fontWeight: 600, cursor: isUpdating ? "not-allowed" : "pointer", opacity: isUpdating ? 0.6 : 1,
          }}>{isUpdating ? "저장 중..." : "프로필 저장"}</button>
        </div>
      )}

      {/* ── 비밀번호 탭 ──────────────────────────────────── */}
      {activeTab === "password" && (
        <div style={cardStyle}>
          <h2 style={{ fontSize: "16px", fontWeight: 600, margin: "0 0 20px" }}>비밀번호 변경</h2>
          {(["current", "new", "confirm"] as const).map((field) => {
            const cfg = {
              current: { key: "current_password" as const, label: "현재 비밀번호", placeholder: "현재 비밀번호" },
              new: { key: "new_password" as const, label: "새 비밀번호 (8자 이상)", placeholder: "새 비밀번호" },
              confirm: { key: "confirm_password" as const, label: "새 비밀번호 확인", placeholder: "새 비밀번호 확인" },
            }[field];
            return (
              <div key={field} style={{ marginBottom: "16px" }}>
                <label style={labelStyle}>{cfg.label}</label>
                <div style={{ position: "relative" }}>
                  <input type={showPw[field] ? "text" : "password"} value={pwForm[cfg.key]} onChange={(e) => setPwForm((p) => ({ ...p, [cfg.key]: e.target.value }))} placeholder={cfg.placeholder} style={{ ...inputStyle, paddingRight: "44px" }} />
                  <button type="button" onClick={() => setShowPw((p) => ({ ...p, [field]: !p[field] }))} style={{ position: "absolute", right: "12px", top: "50%", transform: "translateY(-50%)", background: "none", border: "none", color: "rgba(255,255,255,0.3)", cursor: "pointer", padding: 0 }}>
                    {showPw[field] ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
              </div>
            );
          })}
          <button onClick={handlePasswordChange} disabled={isChangingPassword} style={{
            width: "100%", padding: "11px", borderRadius: "8px", marginTop: "8px",
            border: "1px solid rgba(124,58,237,0.4)", background: "rgba(124,58,237,0.1)",
            color: "#7c3aed", fontSize: "14px", fontWeight: 600, cursor: isChangingPassword ? "not-allowed" : "pointer", opacity: isChangingPassword ? 0.6 : 1,
          }}>{isChangingPassword ? "변경 중..." : "비밀번호 변경"}</button>
        </div>
      )}

      {/* ── 워크스페이스 탭 ──────────────────────────────── */}
      {activeTab === "workspaces" && (
        <div style={{ maxWidth: "640px" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "16px" }}>
            <p style={{ color: "rgba(255,255,255,0.4)", margin: 0, fontSize: "13px" }}>소속 워크스페이스 ({workspaces?.length ?? 0}/5)</p>
            <button onClick={() => setShowCreateForm((v) => !v)} style={{ display: "flex", alignItems: "center", gap: "6px", padding: "7px 14px", borderRadius: "8px", border: "1px solid rgba(0,212,255,0.3)", background: "rgba(0,212,255,0.07)", color: "#00d4ff", fontSize: "13px", cursor: "pointer" }}>
              <Plus size={14} />새 워크스페이스
            </button>
          </div>

          {showCreateForm && (
            <div style={{ background: "rgba(0,212,255,0.05)", border: "1px solid rgba(0,212,255,0.15)", borderRadius: "10px", padding: "16px", marginBottom: "16px", display: "flex", gap: "10px" }}>
              <input type="text" value={newWsName} onChange={(e) => setNewWsName(e.target.value)} onKeyDown={(e) => e.key === "Enter" && handleCreateWorkspace()} placeholder="워크스페이스 이름" style={{ ...inputStyle, flex: 1 }} autoFocus />
              <button onClick={handleCreateWorkspace} disabled={isCreating} style={{ padding: "10px 18px", borderRadius: "8px", border: "1px solid rgba(0,212,255,0.4)", background: "rgba(0,212,255,0.12)", color: "#00d4ff", fontSize: "13px", fontWeight: 600, cursor: isCreating ? "not-allowed" : "pointer", whiteSpace: "nowrap", opacity: isCreating ? 0.6 : 1 }}>
                {isCreating ? "생성 중..." : "생성"}
              </button>
            </div>
          )}

          <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
            {workspacesLoading ? (
              <p style={{ color: "rgba(255,255,255,0.3)", textAlign: "center", padding: "40px", fontSize: "13px" }}>불러오는 중...</p>
            ) : !workspaces || workspaces.length === 0 ? (
              <div style={{ padding: "40px", textAlign: "center", color: "rgba(255,255,255,0.3)", fontSize: "13px", background: "rgba(255,255,255,0.04)", borderRadius: "10px", border: "1px solid rgba(255,255,255,0.06)" }}>소속 워크스페이스가 없습니다.</div>
            ) : (
              workspaces.map((ws) => (
                <div key={ws.id} style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: "10px", padding: "14px 18px", display: "flex", alignItems: "center", gap: "12px" }}>
                  <div style={{ width: "40px", height: "40px", borderRadius: "8px", background: "rgba(124,58,237,0.15)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "16px", fontWeight: 700, flexShrink: 0 }}>{ws.name[0].toUpperCase()}</div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "3px" }}>
                      <span style={{ fontSize: "14px", fontWeight: 600, color: "rgba(255,255,255,0.9)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{ws.name}</span>
                      <span style={{ padding: "2px 8px", borderRadius: "6px", fontSize: "11px", fontWeight: 600, background: `${ROLE_COLORS[ws.role] ?? "#a3a3a3"}18`, color: ROLE_COLORS[ws.role] ?? "#a3a3a3", flexShrink: 0 }}>{ROLE_LABELS[ws.role] ?? ws.role}</span>
                    </div>
                    <div style={{ display: "flex", gap: "12px", fontSize: "12px", color: "rgba(255,255,255,0.35)" }}>
                      <span>플랜: {ws.plan.toUpperCase()}</span><span>멤버 {ws.member_count}명</span><span>플레이스 {ws.place_count}개</span>
                    </div>
                  </div>
                  <button onClick={() => window.location.href = `/workspaces/${ws.id}/members`} style={{ padding: "6px 14px", borderRadius: "7px", border: "1px solid rgba(255,255,255,0.1)", background: "transparent", color: "rgba(255,255,255,0.45)", fontSize: "12px", cursor: "pointer", flexShrink: 0 }}>멤버 관리</button>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}
