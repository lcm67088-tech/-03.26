/**
 * 알림 설정 페이지
 * Sprint 7: /notifications/settings
 * - 25가지 알림 타입별 채널(인앱/이메일/카카오/SMS) 설정
 * - 카테고리별 그룹 표시
 * - 토글 스위치 UI
 * - 저장 시 upsert API 호출
 */

"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Settings, ArrowLeft, Save } from "lucide-react";
import { toast } from "sonner";
import {
  useNotificationSettings,
  useUpdateNotificationSettings,
  NotificationSettingItem,
  NotificationType,
  NOTIFICATION_CATEGORIES,
  NOTIFICATION_TYPE_LABELS,
} from "@/hooks/useNotifications";

// ─────────────────────────────────────────────────────────────
// 토글 스위치 컴포넌트
// ─────────────────────────────────────────────────────────────
function Toggle({
  checked,
  onChange,
  disabled = false,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={() => !disabled && onChange(!checked)}
      style={{
        width: "36px",
        height: "20px",
        borderRadius: "10px",
        border: "none",
        background: checked ? "#00d4ff" : "rgba(255,255,255,0.12)",
        cursor: disabled ? "not-allowed" : "pointer",
        position: "relative",
        transition: "background 0.2s",
        opacity: disabled ? 0.5 : 1,
        flexShrink: 0,
      }}
    >
      <div
        style={{
          position: "absolute",
          top: "3px",
          left: checked ? "19px" : "3px",
          width: "14px",
          height: "14px",
          borderRadius: "50%",
          background: "#fff",
          transition: "left 0.2s",
        }}
      />
    </button>
  );
}

// ─────────────────────────────────────────────────────────────
// 채널 정보
// ─────────────────────────────────────────────────────────────
const CHANNELS: Array<{
  key: keyof Omit<NotificationSettingItem, "notification_type">;
  label: string;
  badge?: string;
}> = [
  { key: "in_app_enabled", label: "인앱" },
  { key: "email_enabled", label: "이메일" },
  { key: "kakao_enabled", label: "카카오", badge: "Mock" },
  { key: "sms_enabled", label: "SMS", badge: "Mock" },
];

// ─────────────────────────────────────────────────────────────
// 알림 설정 페이지
// ─────────────────────────────────────────────────────────────
export default function NotificationSettingsPage() {
  const router = useRouter();
  const { data, isLoading } = useNotificationSettings();
  const { mutate: updateSettings, isPending: isSaving } =
    useUpdateNotificationSettings();

  // 로컬 설정 상태 (편집용)
  const [localSettings, setLocalSettings] = useState<
    Record<NotificationType, Omit<NotificationSettingItem, "notification_type">>
  >({} as any);

  // 서버 데이터 수신 시 로컬 상태 초기화
  useEffect(() => {
    if (data?.settings) {
      const map: Record<string, any> = {};
      data.settings.forEach((s) => {
        map[s.notification_type] = {
          in_app_enabled: s.in_app_enabled,
          email_enabled: s.email_enabled,
          kakao_enabled: s.kakao_enabled,
          sms_enabled: s.sms_enabled,
        };
      });
      setLocalSettings(map as any);
    }
  }, [data]);

  // 개별 설정 변경
  function handleToggle(
    type: NotificationType,
    channel: keyof Omit<NotificationSettingItem, "notification_type">,
    value: boolean
  ) {
    setLocalSettings((prev) => ({
      ...prev,
      [type]: {
        ...prev[type],
        [channel]: value,
      },
    }));
  }

  // 카테고리 전체 채널 토글
  function handleCategoryChannelToggle(
    types: NotificationType[],
    channel: keyof Omit<NotificationSettingItem, "notification_type">,
    value: boolean
  ) {
    setLocalSettings((prev) => {
      const updated = { ...prev };
      types.forEach((type) => {
        updated[type] = { ...updated[type], [channel]: value };
      });
      return updated;
    });
  }

  // 저장
  function handleSave() {
    const settings: NotificationSettingItem[] = Object.entries(
      localSettings
    ).map(([type, channels]) => ({
      notification_type: type as NotificationType,
      ...channels,
    }));

    updateSettings(
      { settings },
      {
        onSuccess: () => toast.success("알림 설정이 저장되었습니다."),
        onError: () => toast.error("설정 저장에 실패했습니다."),
      }
    );
  }

  if (isLoading) {
    return (
      <div
        style={{
          minHeight: "100vh",
          background: "#0a0a0f",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          color: "rgba(255,255,255,0.3)",
        }}
      >
        설정을 불러오는 중...
      </div>
    );
  }

  return (
    <div
      style={{
        minHeight: "100vh",
        background: "#0a0a0f",
        color: "#fff",
        padding: "32px",
        fontFamily: "'Pretendard', sans-serif",
      }}
    >
      {/* 페이지 헤더 */}
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "flex-start",
          marginBottom: "28px",
        }}
      >
        <div>
          <button
            onClick={() => router.push("/notifications")}
            style={{
              display: "flex",
              alignItems: "center",
              gap: "6px",
              background: "none",
              border: "none",
              color: "rgba(255,255,255,0.4)",
              fontSize: "13px",
              cursor: "pointer",
              marginBottom: "8px",
              padding: 0,
            }}
          >
            <ArrowLeft size={14} />
            알림 센터로
          </button>
          <h1
            style={{
              fontSize: "24px",
              fontWeight: 700,
              color: "#fff",
              margin: 0,
              marginBottom: "6px",
              display: "flex",
              alignItems: "center",
              gap: "10px",
            }}
          >
            <Settings size={22} style={{ color: "#7c3aed" }} />
            알림 설정
          </h1>
          <p
            style={{
              color: "rgba(255,255,255,0.4)",
              margin: 0,
              fontSize: "14px",
            }}
          >
            알림 타입별로 수신 채널을 설정합니다. 카카오/SMS는 현재 Mock
            처리됩니다.
          </p>
        </div>

        {/* 저장 버튼 */}
        <button
          onClick={handleSave}
          disabled={isSaving}
          style={{
            display: "flex",
            alignItems: "center",
            gap: "6px",
            padding: "10px 20px",
            borderRadius: "8px",
            border: "1px solid rgba(0, 212, 255, 0.4)",
            background: "rgba(0, 212, 255, 0.1)",
            color: "#00d4ff",
            fontSize: "14px",
            fontWeight: 600,
            cursor: isSaving ? "not-allowed" : "pointer",
            opacity: isSaving ? 0.6 : 1,
          }}
        >
          <Save size={15} />
          {isSaving ? "저장 중..." : "설정 저장"}
        </button>
      </div>

      {/* 채널 범례 */}
      <div
        style={{
          display: "flex",
          gap: "12px",
          marginBottom: "24px",
          padding: "12px 16px",
          background: "rgba(255,255,255,0.03)",
          borderRadius: "8px",
          border: "1px solid rgba(255,255,255,0.06)",
          flexWrap: "wrap",
        }}
      >
        <span style={{ color: "rgba(255,255,255,0.35)", fontSize: "12px" }}>
          채널:
        </span>
        {CHANNELS.map((ch) => (
          <span
            key={ch.key}
            style={{
              fontSize: "12px",
              color: "rgba(255,255,255,0.6)",
              display: "flex",
              alignItems: "center",
              gap: "4px",
            }}
          >
            {ch.label}
            {ch.badge && (
              <span
                style={{
                  padding: "1px 6px",
                  borderRadius: "4px",
                  background: "rgba(252, 211, 77, 0.12)",
                  color: "#fcd34d",
                  fontSize: "10px",
                }}
              >
                {ch.badge}
              </span>
            )}
          </span>
        ))}
      </div>

      {/* 카테고리별 설정 그룹 */}
      <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
        {Object.entries(NOTIFICATION_CATEGORIES).map(([category, types]) => (
          <div
            key={category}
            style={{
              background: "rgba(255,255,255,0.04)",
              border: "1px solid rgba(255,255,255,0.08)",
              borderRadius: "12px",
              overflow: "hidden",
            }}
          >
            {/* 카테고리 헤더 */}
            <div
              style={{
                padding: "12px 16px",
                background: "rgba(255,255,255,0.03)",
                borderBottom: "1px solid rgba(255,255,255,0.06)",
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
              }}
            >
              <span
                style={{
                  fontSize: "13px",
                  fontWeight: 600,
                  color: "rgba(255,255,255,0.7)",
                }}
              >
                {category}
              </span>
              {/* 카테고리 전체 인앱 토글 */}
              <div
                style={{
                  display: "flex",
                  gap: "12px",
                  alignItems: "center",
                }}
              >
                {CHANNELS.map((ch) => (
                  <div
                    key={ch.key}
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: "6px",
                      width: "80px",
                      justifyContent: "center",
                    }}
                  >
                    <span
                      style={{
                        fontSize: "11px",
                        color: "rgba(255,255,255,0.35)",
                      }}
                    >
                      전체
                    </span>
                    <Toggle
                      checked={types.every(
                        (t) => localSettings[t]?.[ch.key] ?? false
                      )}
                      onChange={(v) =>
                        handleCategoryChannelToggle(types as NotificationType[], ch.key, v)
                      }
                    />
                  </div>
                ))}
              </div>
            </div>

            {/* 열 헤더 */}
            <div
              style={{
                display: "flex",
                padding: "8px 16px",
                borderBottom: "1px solid rgba(255,255,255,0.05)",
              }}
            >
              <div style={{ flex: 1 }} />
              {CHANNELS.map((ch) => (
                <div
                  key={ch.key}
                  style={{
                    width: "80px",
                    textAlign: "center",
                    fontSize: "11px",
                    color: "rgba(255,255,255,0.35)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    gap: "4px",
                  }}
                >
                  {ch.label}
                  {ch.badge && (
                    <span
                      style={{
                        padding: "1px 4px",
                        borderRadius: "3px",
                        background: "rgba(252, 211, 77, 0.1)",
                        color: "#fcd34d",
                        fontSize: "9px",
                      }}
                    >
                      {ch.badge}
                    </span>
                  )}
                </div>
              ))}
            </div>

            {/* 알림 타입별 행 */}
            {types.map((type, idx) => (
              <div
                key={type}
                style={{
                  display: "flex",
                  alignItems: "center",
                  padding: "10px 16px",
                  borderBottom:
                    idx < types.length - 1
                      ? "1px solid rgba(255,255,255,0.04)"
                      : "none",
                }}
              >
                {/* 타입 레이블 */}
                <div style={{ flex: 1, fontSize: "13px", color: "rgba(255,255,255,0.7)" }}>
                  {NOTIFICATION_TYPE_LABELS[type as NotificationType]}
                </div>

                {/* 채널별 토글 */}
                {CHANNELS.map((ch) => (
                  <div
                    key={ch.key}
                    style={{
                      width: "80px",
                      display: "flex",
                      justifyContent: "center",
                    }}
                  >
                    <Toggle
                      checked={localSettings[type as NotificationType]?.[ch.key] ?? false}
                      onChange={(v) =>
                        handleToggle(type as NotificationType, ch.key, v)
                      }
                    />
                  </div>
                ))}
              </div>
            ))}
          </div>
        ))}
      </div>

      {/* 하단 저장 버튼 */}
      <div
        style={{
          display: "flex",
          justifyContent: "flex-end",
          marginTop: "28px",
        }}
      >
        <button
          onClick={handleSave}
          disabled={isSaving}
          style={{
            display: "flex",
            alignItems: "center",
            gap: "6px",
            padding: "12px 28px",
            borderRadius: "8px",
            border: "1px solid rgba(0, 212, 255, 0.4)",
            background: "rgba(0, 212, 255, 0.1)",
            color: "#00d4ff",
            fontSize: "14px",
            fontWeight: 600,
            cursor: isSaving ? "not-allowed" : "pointer",
            opacity: isSaving ? 0.6 : 1,
          }}
        >
          <Save size={15} />
          {isSaving ? "저장 중..." : "설정 저장"}
        </button>
      </div>
    </div>
  );
}
