/**
 * 알림 센터 페이지
 * Sprint 7: /notifications
 * - 전체/카테고리별 알림 목록 (20개 페이지네이션)
 * - 읽음 필터 탭 (전체 / 미읽음 / 읽음)
 * - 전체 읽음 처리 / 개별 삭제
 */

"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Bell, Settings, CheckCheck, RefreshCw } from "lucide-react";
import { toast } from "sonner";
import {
  useNotifications,
  useUnreadCount,
  useMarkAllRead,
  useMarkNotificationRead,
  useDeleteNotification,
  NotificationType,
} from "@/hooks/useNotifications";
import NotificationItem from "@/components/notifications/NotificationItem";

// ─────────────────────────────────────────────────────────────
// 읽음 상태 탭 정의
// ─────────────────────────────────────────────────────────────
const READ_TABS = [
  { label: "전체", value: null },
  { label: "미읽음", value: false },
  { label: "읽음", value: true },
] as const;

export default function NotificationsPage() {
  const router = useRouter();
  const [readFilter, setReadFilter] = useState<boolean | null>(null);
  const [page, setPage] = useState(1);
  const LIMIT = 20;

  // 알림 목록 조회
  const {
    data,
    isLoading,
    refetch,
    isFetching,
  } = useNotifications({
    page,
    limit: LIMIT,
    is_read: readFilter,
  });

  // 읽지 않은 수 조회
  const { data: unreadData } = useUnreadCount();
  const unreadCount = unreadData?.total ?? 0;

  // 뮤테이션 훅
  const { mutate: markAllRead, isPending: isMarkingAll } = useMarkAllRead();
  const { mutate: markRead, isPending: isMarkingRead } = useMarkNotificationRead();
  const { mutate: deleteNotif, isPending: isDeleting } = useDeleteNotification();

  // 전체 읽음 처리
  function handleMarkAllRead() {
    markAllRead(undefined, {
      onSuccess: ({ count }) => {
        toast.success(`${count}개의 알림을 읽음 처리했습니다.`);
      },
      onError: () => toast.error("읽음 처리에 실패했습니다."),
    });
  }

  // 탭 변경 시 페이지 초기화
  function handleTabChange(value: boolean | null) {
    setReadFilter(value);
    setPage(1);
  }

  const totalPages = data ? Math.ceil(data.total / LIMIT) : 1;

  return (
    <div
      style={{
        minHeight: "100vh",
        background: "#0a0a0f",
        color: "#fff",
        padding: "32px",
        fontFamily: "'Pretendard', sans-serif",
      }}
    >
      {/* 페이지 헤더 */}
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "flex-start",
          marginBottom: "28px",
        }}
      >
        <div>
          <h1
            style={{
              fontSize: "24px",
              fontWeight: 700,
              color: "#fff",
              margin: 0,
              marginBottom: "6px",
              display: "flex",
              alignItems: "center",
              gap: "10px",
            }}
          >
            <Bell size={22} style={{ color: "#00d4ff" }} />
            알림 센터
            {unreadCount > 0 && (
              <span
                style={{
                  padding: "3px 10px",
                  borderRadius: "12px",
                  background: "rgba(248, 113, 113, 0.15)",
                  color: "#f87171",
                  fontSize: "13px",
                  fontWeight: 600,
                }}
              >
                {unreadCount}
              </span>
            )}
          </h1>
          <p style={{ color: "rgba(255,255,255,0.4)", margin: 0, fontSize: "14px" }}>
            주문, 랭킹, 시스템 알림을 한 곳에서 확인하세요.
          </p>
        </div>

        {/* 액션 버튼 그룹 */}
        <div style={{ display: "flex", gap: "8px" }}>
          <button
            onClick={() => refetch()}
            disabled={isFetching}
            style={{
              display: "flex",
              alignItems: "center",
              gap: "6px",
              padding: "8px 14px",
              borderRadius: "8px",
              border: "1px solid rgba(255,255,255,0.1)",
              background: "rgba(255,255,255,0.04)",
              color: "rgba(255,255,255,0.6)",
              fontSize: "13px",
              cursor: "pointer",
              opacity: isFetching ? 0.5 : 1,
            }}
          >
            <RefreshCw size={14} />
            새로고침
          </button>

          {unreadCount > 0 && (
            <button
              onClick={handleMarkAllRead}
              disabled={isMarkingAll}
              style={{
                display: "flex",
                alignItems: "center",
                gap: "6px",
                padding: "8px 14px",
                borderRadius: "8px",
                border: "1px solid rgba(0, 212, 255, 0.3)",
                background: "rgba(0, 212, 255, 0.08)",
                color: "#00d4ff",
                fontSize: "13px",
                cursor: "pointer",
                opacity: isMarkingAll ? 0.5 : 1,
              }}
            >
              <CheckCheck size={14} />
              전체 읽음
            </button>
          )}

          <button
            onClick={() => router.push("/notifications/settings")}
            style={{
              display: "flex",
              alignItems: "center",
              gap: "6px",
              padding: "8px 14px",
              borderRadius: "8px",
              border: "1px solid rgba(124, 58, 237, 0.3)",
              background: "rgba(124, 58, 237, 0.08)",
              color: "#7c3aed",
              fontSize: "13px",
              cursor: "pointer",
            }}
          >
            <Settings size={14} />
            알림 설정
          </button>
        </div>
      </div>

      {/* 읽음 상태 탭 */}
      <div
        style={{
          display: "flex",
          gap: "4px",
          marginBottom: "20px",
          background: "rgba(255,255,255,0.04)",
          borderRadius: "10px",
          padding: "4px",
          width: "fit-content",
        }}
      >
        {READ_TABS.map((tab) => (
          <button
            key={String(tab.value)}
            onClick={() => handleTabChange(tab.value)}
            style={{
              padding: "7px 18px",
              borderRadius: "7px",
              border: "none",
              background:
                readFilter === tab.value
                  ? "rgba(0, 212, 255, 0.15)"
                  : "transparent",
              color:
                readFilter === tab.value
                  ? "#00d4ff"
                  : "rgba(255,255,255,0.45)",
              fontSize: "13px",
              fontWeight: readFilter === tab.value ? 600 : 400,
              cursor: "pointer",
              transition: "all 0.15s",
            }}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* 알림 목록 카드 */}
      <div
        style={{
          background: "rgba(255,255,255,0.04)",
          border: "1px solid rgba(255,255,255,0.08)",
          borderRadius: "12px",
          overflow: "hidden",
        }}
      >
        {isLoading ? (
          <div
            style={{
              padding: "60px",
              textAlign: "center",
              color: "rgba(255,255,255,0.3)",
            }}
          >
            알림을 불러오는 중...
          </div>
        ) : !data || data.items.length === 0 ? (
          <div
            style={{
              padding: "60px",
              textAlign: "center",
              color: "rgba(255,255,255,0.3)",
            }}
          >
            <Bell
              size={36}
              style={{ marginBottom: "12px", opacity: 0.2 }}
            />
            <p style={{ margin: 0, fontSize: "14px" }}>알림이 없습니다.</p>
          </div>
        ) : (
          data.items.map((n) => (
            <NotificationItem
              key={n.id}
              notification={n}
              onMarkRead={(id) =>
                markRead(id, {
                  onError: () => toast.error("읽음 처리에 실패했습니다."),
                })
              }
              onDelete={(id) =>
                deleteNotif(id, {
                  onSuccess: () => toast.success("알림이 삭제되었습니다."),
                  onError: () => toast.error("삭제에 실패했습니다."),
                })
              }
              isMarkingRead={isMarkingRead}
              isDeleting={isDeleting}
            />
          ))
        )}
      </div>

      {/* 페이지네이션 */}
      {totalPages > 1 && (
        <div
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            gap: "8px",
            marginTop: "24px",
          }}
        >
          <button
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            disabled={page === 1}
            style={{
              padding: "7px 16px",
              borderRadius: "8px",
              border: "1px solid rgba(255,255,255,0.1)",
              background: "rgba(255,255,255,0.04)",
              color: page === 1 ? "rgba(255,255,255,0.2)" : "rgba(255,255,255,0.6)",
              fontSize: "13px",
              cursor: page === 1 ? "not-allowed" : "pointer",
            }}
          >
            이전
          </button>

          {Array.from({ length: totalPages }, (_, i) => i + 1)
            .filter(
              (p) =>
                p === 1 || p === totalPages || Math.abs(p - page) <= 2
            )
            .map((p, idx, arr) => (
              <span key={p}>
                {idx > 0 && arr[idx - 1] !== p - 1 && (
                  <span style={{ color: "rgba(255,255,255,0.3)", padding: "0 4px" }}>
                    ...
                  </span>
                )}
                <button
                  onClick={() => setPage(p)}
                  style={{
                    width: "36px",
                    height: "36px",
                    borderRadius: "8px",
                    border:
                      p === page
                        ? "1px solid rgba(0, 212, 255, 0.4)"
                        : "1px solid rgba(255,255,255,0.1)",
                    background:
                      p === page
                        ? "rgba(0, 212, 255, 0.12)"
                        : "rgba(255,255,255,0.04)",
                    color: p === page ? "#00d4ff" : "rgba(255,255,255,0.5)",
                    fontSize: "13px",
                    fontWeight: p === page ? 600 : 400,
                    cursor: "pointer",
                  }}
                >
                  {p}
                </button>
              </span>
            ))}

          <button
            onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
            disabled={page === totalPages}
            style={{
              padding: "7px 16px",
              borderRadius: "8px",
              border: "1px solid rgba(255,255,255,0.1)",
              background: "rgba(255,255,255,0.04)",
              color:
                page === totalPages
                  ? "rgba(255,255,255,0.2)"
                  : "rgba(255,255,255,0.6)",
              fontSize: "13px",
              cursor: page === totalPages ? "not-allowed" : "pointer",
            }}
          >
            다음
          </button>
        </div>
      )}

      {/* 전체 수 표시 */}
      {data && (
        <p
          style={{
            textAlign: "center",
            marginTop: "12px",
            color: "rgba(255,255,255,0.25)",
            fontSize: "12px",
          }}
        >
          전체 {data.total}개 알림 중 {(page - 1) * LIMIT + 1}–
          {Math.min(page * LIMIT, data.total)}개 표시
        </p>
      )}
    </div>
  );
}
