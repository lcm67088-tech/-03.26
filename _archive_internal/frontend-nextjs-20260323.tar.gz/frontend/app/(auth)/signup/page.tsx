"use client";

/**
 * 회원가입 페이지 (Sprint 2 완성)
 * - 비밀번호 강도 바
 * - 약관 동의
 * - 성공 시 이메일 인증 안내 화면으로 전환
 */
import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import Link from "next/link";
import { Eye, EyeOff, AlertCircle, CheckCircle2, Check } from "lucide-react";

import { useAuthStore } from "@/store/authStore";

// ============================
// Zod 스키마
// ============================
const signupSchema = z
  .object({
    name: z
      .string()
      .min(2, "이름은 2자 이상이어야 합니다")
      .max(50, "이름은 50자 이하여야 합니다"),
    email: z
      .string()
      .min(1, "이메일을 입력해주세요")
      .email("올바른 이메일 형식이 아닙니다"),
    phone: z
      .string()
      .optional()
      .transform((v) => v?.replace(/\D/g, "") || undefined)
      .refine(
        (v) => !v || /^01[0-9]{8,9}$/.test(v),
        "올바른 전화번호 형식이 아닙니다"
      ),
    password: z
      .string()
      .min(8, "비밀번호는 8자 이상이어야 합니다")
      .regex(/[A-Z]/, "대문자를 포함해야 합니다")
      .regex(/[a-z]/, "소문자를 포함해야 합니다")
      .regex(/\d/, "숫자를 포함해야 합니다"),
    passwordConfirm: z.string().min(1, "비밀번호 확인을 입력해주세요"),
    agreeTerms: z.boolean().refine((v) => v, "서비스 이용약관에 동의해주세요"),
    agreePrivacy: z
      .boolean()
      .refine((v) => v, "개인정보처리방침에 동의해주세요"),
    agreeMarketing: z.boolean().optional(),
  })
  .refine((data) => data.password === data.passwordConfirm, {
    message: "비밀번호가 일치하지 않습니다",
    path: ["passwordConfirm"],
  });

type SignupFormData = z.infer<typeof signupSchema>;

// ============================
// 비밀번호 강도 계산
// ============================
function getPasswordStrength(pw: string): {
  level: 0 | 1 | 2 | 3;
  label: string;
  color: string;
} {
  if (!pw) return { level: 0, label: "", color: "" };
  let score = 0;
  if (pw.length >= 8) score++;
  if (/[A-Z]/.test(pw) && /[a-z]/.test(pw)) score++;
  if (/\d/.test(pw)) score++;
  if (pw.length >= 10 && /[^A-Za-z0-9]/.test(pw)) score++;

  if (score <= 1) return { level: 1, label: "약함", color: "#ef4444" };
  if (score === 2) return { level: 2, label: "보통", color: "#f59e0b" };
  return { level: 3, label: "강함", color: "#10b981" };
}

// ============================
// 전화번호 자동 포맷팅
// ============================
function formatPhone(value: string): string {
  const digits = value.replace(/\D/g, "").slice(0, 11);
  if (digits.length <= 3) return digits;
  if (digits.length <= 7) return `${digits.slice(0, 3)}-${digits.slice(3)}`;
  if (digits.startsWith("02")) {
    if (digits.length <= 9)
      return `${digits.slice(0, 2)}-${digits.slice(2, 6)}-${digits.slice(6)}`;
    return `${digits.slice(0, 2)}-${digits.slice(2, 6)}-${digits.slice(6, 10)}`;
  }
  if (digits.length <= 10)
    return `${digits.slice(0, 3)}-${digits.slice(3, 6)}-${digits.slice(6)}`;
  return `${digits.slice(0, 3)}-${digits.slice(3, 7)}-${digits.slice(7)}`;
}

// ============================
// 성공 화면 컴포넌트
// ============================
function EmailSentSuccess({ email }: { email: string }) {
  return (
    <div
      className="rounded-2xl p-8 text-center"
      style={{
        background: "rgba(255,255,255,0.04)",
        backdropFilter: "blur(20px)",
        border: "1px solid rgba(255,255,255,0.08)",
      }}
    >
      <div className="text-5xl mb-4">✉️</div>
      <h2 className="text-xl font-bold text-slate-100 mb-2">
        이메일을 확인해주세요
      </h2>
      <p className="text-slate-400 text-sm mb-1">
        <span className="text-slate-200 font-medium">{email}</span> 주소로
      </p>
      <p className="text-slate-400 text-sm mb-6">인증 링크를 발송했습니다.</p>
      <div
        className="p-3 rounded-xl text-xs text-slate-400 mb-6"
        style={{ background: "rgba(255,255,255,0.04)" }}
      >
        이메일이 오지 않으면 스팸함을 확인하거나, 잠시 후 다시 시도해주세요.
      </div>
      <p className="text-sm text-slate-400">
        이미 계정이 있으신가요?{" "}
        <Link
          href="/login"
          className="font-medium hover:underline"
          style={{ color: "#00d4ff" }}
        >
          로그인
        </Link>
      </p>
    </div>
  );
}

// ============================
// 메인 컴포넌트
// ============================
export default function SignupPage() {
  const { register: registerUser, isLoading } = useAuthStore();

  const [showPassword, setShowPassword] = useState(false);
  const [showPasswordConfirm, setShowPasswordConfirm] = useState(false);
  const [apiError, setApiError] = useState<string | null>(null);
  const [successEmail, setSuccessEmail] = useState<string | null>(null);
  const [phoneDisplay, setPhoneDisplay] = useState("");
  const [passwordValue, setPasswordValue] = useState("");
  const [agreeAll, setAgreeAll] = useState(false);

  const {
    register,
    handleSubmit,
    setValue,
    watch,
    formState: { errors },
  } = useForm<SignupFormData>({
    resolver: zodResolver(signupSchema),
    defaultValues: {
      agreeTerms: false,
      agreePrivacy: false,
      agreeMarketing: false,
    },
  });

  const watchTerms = watch("agreeTerms");
  const watchPrivacy = watch("agreePrivacy");
  const watchMarketing = watch("agreeMarketing");

  const passwordStrength = getPasswordStrength(passwordValue);

  // 전체 동의 토글
  const handleAgreeAll = (checked: boolean) => {
    setAgreeAll(checked);
    setValue("agreeTerms", checked);
    setValue("agreePrivacy", checked);
    setValue("agreeMarketing", checked);
  };

  // 전화번호 입력 처리
  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formatted = formatPhone(e.target.value);
    setPhoneDisplay(formatted);
    setValue("phone", formatted);
  };

  // 폼 제출
  const onSubmit = async (data: SignupFormData) => {
    setApiError(null);
    try {
      await registerUser({
        email: data.email,
        password: data.password,
        name: data.name,
        phone: data.phone,
      });
      setSuccessEmail(data.email);
    } catch (error) {
      const msg =
        error instanceof Error ? error.message : "회원가입에 실패했습니다";
      setApiError(msg);
    }
  };

  // 성공 화면으로 전환
  if (successEmail) {
    return <EmailSentSuccess email={successEmail} />;
  }

  return (
    <div
      className="rounded-2xl p-8"
      style={{
        background: "rgba(255,255,255,0.04)",
        backdropFilter: "blur(20px)",
        border: "1px solid rgba(255,255,255,0.08)",
      }}
    >
      {/* 로고 */}
      <div className="text-center mb-6">
        <div className="text-4xl mb-2">🏪</div>
        <h1 className="text-2xl font-bold">
          <span style={{ color: "#00d4ff" }}>nplace</span>
          <span className="text-white">.io</span>
        </h1>
        <p className="text-sm text-gray-400 mt-1">계정을 만들어 시작하세요</p>
      </div>

      {/* API 에러 */}
      {apiError && (
        <div
          className="flex items-start gap-2 p-3 rounded-xl mb-4 text-sm"
          style={{
            background: "rgba(239,68,68,0.12)",
            border: "1px solid rgba(239,68,68,0.25)",
            color: "#fca5a5",
          }}
        >
          <AlertCircle size={16} className="flex-shrink-0 mt-0.5" />
          <span>{apiError}</span>
        </div>
      )}

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        {/* 이름 */}
        <div>
          <label className="block text-sm font-medium text-slate-300 mb-1.5">
            이름
          </label>
          <input
            {...register("name")}
            type="text"
            className="w-full rounded-xl px-4 py-2.5 text-sm text-slate-100 placeholder:text-slate-500 outline-none transition-all"
            style={{
              background: "rgba(255,255,255,0.06)",
              border: `1px solid ${errors.name ? "rgba(239,68,68,0.5)" : "rgba(255,255,255,0.1)"}`,
            }}
            onFocus={(e) => {
              e.currentTarget.style.borderColor = "#00d4ff";
              e.currentTarget.style.boxShadow = "0 0 0 3px rgba(0,212,255,0.1)";
            }}
            onBlur={(e) => {
              e.currentTarget.style.borderColor = errors.name
                ? "rgba(239,68,68,0.5)"
                : "rgba(255,255,255,0.1)";
              e.currentTarget.style.boxShadow = "none";
            }}
            placeholder="홍길동"
          />
          {errors.name && (
            <p className="mt-1 text-xs text-red-400">{errors.name.message}</p>
          )}
        </div>

        {/* 이메일 */}
        <div>
          <label className="block text-sm font-medium text-slate-300 mb-1.5">
            이메일
          </label>
          <input
            {...register("email")}
            type="email"
            className="w-full rounded-xl px-4 py-2.5 text-sm text-slate-100 placeholder:text-slate-500 outline-none transition-all"
            style={{
              background: "rgba(255,255,255,0.06)",
              border: `1px solid ${errors.email ? "rgba(239,68,68,0.5)" : "rgba(255,255,255,0.1)"}`,
            }}
            onFocus={(e) => {
              e.currentTarget.style.borderColor = "#00d4ff";
              e.currentTarget.style.boxShadow = "0 0 0 3px rgba(0,212,255,0.1)";
            }}
            onBlur={(e) => {
              e.currentTarget.style.borderColor = errors.email
                ? "rgba(239,68,68,0.5)"
                : "rgba(255,255,255,0.1)";
              e.currentTarget.style.boxShadow = "none";
            }}
            placeholder="hello@example.com"
          />
          {errors.email && (
            <p className="mt-1 text-xs text-red-400">{errors.email.message}</p>
          )}
        </div>

        {/* 연락처 (선택) */}
        <div>
          <label className="block text-sm font-medium text-slate-300 mb-1.5">
            연락처{" "}
            <span className="text-slate-500 font-normal text-xs">(선택)</span>
          </label>
          <input
            type="tel"
            value={phoneDisplay}
            onChange={handlePhoneChange}
            className="w-full rounded-xl px-4 py-2.5 text-sm text-slate-100 placeholder:text-slate-500 outline-none transition-all"
            style={{
              background: "rgba(255,255,255,0.06)",
              border: `1px solid ${errors.phone ? "rgba(239,68,68,0.5)" : "rgba(255,255,255,0.1)"}`,
            }}
            onFocus={(e) => {
              e.currentTarget.style.borderColor = "#00d4ff";
              e.currentTarget.style.boxShadow = "0 0 0 3px rgba(0,212,255,0.1)";
            }}
            onBlur={(e) => {
              e.currentTarget.style.borderColor = errors.phone
                ? "rgba(239,68,68,0.5)"
                : "rgba(255,255,255,0.1)";
              e.currentTarget.style.boxShadow = "none";
            }}
            placeholder="010-0000-0000"
            maxLength={13}
          />
          {errors.phone && (
            <p className="mt-1 text-xs text-red-400">{errors.phone.message}</p>
          )}
        </div>

        {/* 비밀번호 */}
        <div>
          <label className="block text-sm font-medium text-slate-300 mb-1.5">
            비밀번호
          </label>
          <div className="relative">
            <input
              {...register("password")}
              type={showPassword ? "text" : "password"}
              onChange={(e) => {
                register("password").onChange(e);
                setPasswordValue(e.target.value);
              }}
              className="w-full rounded-xl px-4 py-2.5 text-sm text-slate-100 placeholder:text-slate-500 outline-none transition-all pr-11"
              style={{
                background: "rgba(255,255,255,0.06)",
                border: `1px solid ${errors.password ? "rgba(239,68,68,0.5)" : "rgba(255,255,255,0.1)"}`,
              }}
              onFocus={(e) => {
                e.currentTarget.style.borderColor = "#00d4ff";
                e.currentTarget.style.boxShadow =
                  "0 0 0 3px rgba(0,212,255,0.1)";
              }}
              onBlur={(e) => {
                e.currentTarget.style.borderColor = errors.password
                  ? "rgba(239,68,68,0.5)"
                  : "rgba(255,255,255,0.1)";
                e.currentTarget.style.boxShadow = "none";
              }}
              placeholder="8자 이상, 대소문자+숫자 포함"
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 transition-colors"
            >
              {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
            </button>
          </div>

          {/* 비밀번호 강도 바 */}
          {passwordValue && (
            <div className="mt-2">
              <div className="flex gap-1 mb-1">
                {[1, 2, 3].map((i) => (
                  <div
                    key={i}
                    className="h-1 flex-1 rounded-full transition-all duration-300"
                    style={{
                      background:
                        i <= passwordStrength.level
                          ? passwordStrength.color
                          : "rgba(255,255,255,0.1)",
                    }}
                  />
                ))}
              </div>
              {passwordStrength.level > 0 && (
                <p
                  className="text-xs"
                  style={{ color: passwordStrength.color }}
                >
                  {passwordStrength.label}
                </p>
              )}
            </div>
          )}

          {errors.password && (
            <p className="mt-1 text-xs text-red-400">
              {errors.password.message}
            </p>
          )}
        </div>

        {/* 비밀번호 확인 */}
        <div>
          <label className="block text-sm font-medium text-slate-300 mb-1.5">
            비밀번호 확인
          </label>
          <div className="relative">
            <input
              {...register("passwordConfirm")}
              type={showPasswordConfirm ? "text" : "password"}
              className="w-full rounded-xl px-4 py-2.5 text-sm text-slate-100 placeholder:text-slate-500 outline-none transition-all pr-11"
              style={{
                background: "rgba(255,255,255,0.06)",
                border: `1px solid ${errors.passwordConfirm ? "rgba(239,68,68,0.5)" : "rgba(255,255,255,0.1)"}`,
              }}
              onFocus={(e) => {
                e.currentTarget.style.borderColor = "#00d4ff";
                e.currentTarget.style.boxShadow =
                  "0 0 0 3px rgba(0,212,255,0.1)";
              }}
              onBlur={(e) => {
                e.currentTarget.style.borderColor = errors.passwordConfirm
                  ? "rgba(239,68,68,0.5)"
                  : "rgba(255,255,255,0.1)";
                e.currentTarget.style.boxShadow = "none";
              }}
              placeholder="비밀번호를 다시 입력하세요"
            />
            <button
              type="button"
              onClick={() => setShowPasswordConfirm(!showPasswordConfirm)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 transition-colors"
            >
              {showPasswordConfirm ? <EyeOff size={16} /> : <Eye size={16} />}
            </button>
          </div>
          {errors.passwordConfirm && (
            <p className="mt-1 text-xs text-red-400">
              {errors.passwordConfirm.message}
            </p>
          )}
        </div>

        {/* 약관 동의 */}
        <div
          className="rounded-xl p-4 space-y-2"
          style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.06)" }}
        >
          {/* 전체 동의 */}
          <label className="flex items-center gap-2.5 cursor-pointer">
            <div
              className="w-4 h-4 rounded flex items-center justify-center flex-shrink-0 transition-all"
              style={{
                background: agreeAll ? "#00d4ff" : "transparent",
                border: `1.5px solid ${agreeAll ? "#00d4ff" : "rgba(255,255,255,0.2)"}`,
              }}
              onClick={() => handleAgreeAll(!agreeAll)}
            >
              {agreeAll && <Check size={10} color="#0a0a0f" strokeWidth={3} />}
            </div>
            <span className="text-sm font-medium text-slate-200">
              전체 동의
            </span>
          </label>

          <div
            className="h-px"
            style={{ background: "rgba(255,255,255,0.06)" }}
          />

          {/* 이용약관 */}
          <label className="flex items-center gap-2.5 cursor-pointer">
            <input
              type="checkbox"
              {...register("agreeTerms")}
              className="sr-only"
            />
            <div
              className="w-4 h-4 rounded flex items-center justify-center flex-shrink-0 transition-all"
              style={{
                background: watchTerms ? "#00d4ff" : "transparent",
                border: `1.5px solid ${watchTerms ? "#00d4ff" : "rgba(255,255,255,0.2)"}`,
              }}
              onClick={() => setValue("agreeTerms", !watchTerms)}
            >
              {watchTerms && (
                <Check size={10} color="#0a0a0f" strokeWidth={3} />
              )}
            </div>
            <span className="text-xs text-slate-400 flex-1">
              <span className="text-slate-300">[필수]</span> 서비스 이용약관
              동의
            </span>
            <button
              type="button"
              className="text-xs hover:underline flex-shrink-0"
              style={{ color: "#00d4ff" }}
              onClick={(e) => {
                e.preventDefault();
                window.open("/terms", "_blank");
              }}
            >
              보기
            </button>
          </label>

          {errors.agreeTerms && (
            <p className="text-xs text-red-400 pl-7">
              {errors.agreeTerms.message}
            </p>
          )}

          {/* 개인정보처리방침 */}
          <label className="flex items-center gap-2.5 cursor-pointer">
            <input
              type="checkbox"
              {...register("agreePrivacy")}
              className="sr-only"
            />
            <div
              className="w-4 h-4 rounded flex items-center justify-center flex-shrink-0 transition-all"
              style={{
                background: watchPrivacy ? "#00d4ff" : "transparent",
                border: `1.5px solid ${watchPrivacy ? "#00d4ff" : "rgba(255,255,255,0.2)"}`,
              }}
              onClick={() => setValue("agreePrivacy", !watchPrivacy)}
            >
              {watchPrivacy && (
                <Check size={10} color="#0a0a0f" strokeWidth={3} />
              )}
            </div>
            <span className="text-xs text-slate-400 flex-1">
              <span className="text-slate-300">[필수]</span> 개인정보처리방침
              동의
            </span>
            <button
              type="button"
              className="text-xs hover:underline flex-shrink-0"
              style={{ color: "#00d4ff" }}
              onClick={(e) => {
                e.preventDefault();
                window.open("/privacy", "_blank");
              }}
            >
              보기
            </button>
          </label>

          {errors.agreePrivacy && (
            <p className="text-xs text-red-400 pl-7">
              {errors.agreePrivacy.message}
            </p>
          )}

          {/* 마케팅 동의 (선택) */}
          <label className="flex items-center gap-2.5 cursor-pointer">
            <input
              type="checkbox"
              {...register("agreeMarketing")}
              className="sr-only"
            />
            <div
              className="w-4 h-4 rounded flex items-center justify-center flex-shrink-0 transition-all"
              style={{
                background: watchMarketing ? "#00d4ff" : "transparent",
                border: `1.5px solid ${watchMarketing ? "#00d4ff" : "rgba(255,255,255,0.2)"}`,
              }}
              onClick={() => setValue("agreeMarketing", !watchMarketing)}
            >
              {watchMarketing && (
                <Check size={10} color="#0a0a0f" strokeWidth={3} />
              )}
            </div>
            <span className="text-xs text-slate-400">
              <span className="text-slate-500">[선택]</span> 마케팅 정보 수신
              동의
            </span>
          </label>
        </div>

        {/* 회원가입 버튼 */}
        <button
          type="submit"
          disabled={isLoading || !watchTerms || !watchPrivacy}
          className="w-full py-2.5 rounded-xl font-semibold text-sm transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          style={{
            background:
              isLoading || !watchTerms || !watchPrivacy
                ? "rgba(0,212,255,0.4)"
                : "#00d4ff",
            color: "#0a0a0f",
          }}
        >
          {isLoading ? (
            <>
              <div
                className="w-4 h-4 border-2 rounded-full animate-spin"
                style={{
                  borderColor: "rgba(10,10,15,0.3)",
                  borderTopColor: "#0a0a0f",
                }}
              />
              처리 중...
            </>
          ) : (
            "회원가입"
          )}
        </button>
      </form>

      {/* 로그인 링크 */}
      <p className="mt-5 text-center text-sm text-slate-400">
        이미 계정이 있으신가요?{" "}
        <Link
          href="/login"
          className="font-medium hover:underline"
          style={{ color: "#00d4ff" }}
        >
          로그인
        </Link>
      </p>
    </div>
  );
}
