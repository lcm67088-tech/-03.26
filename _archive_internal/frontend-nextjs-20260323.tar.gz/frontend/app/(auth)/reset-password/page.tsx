"use client";

/**
 * 비밀번호 재설정 페이지 (Sprint 2 완성)
 * URL: /reset-password?token=xxxxx
 * - token 없으면 에러 표시
 * - 성공 시 2초 후 /login 리다이렉트
 */
import { useState, useEffect, Suspense } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Eye, EyeOff, AlertCircle, CheckCircle2 } from "lucide-react";
import axios from "axios";
import { toast } from "sonner";

import { getApiErrorMessage } from "@/lib/api";

// ============================
// Zod 스키마
// ============================
const resetSchema = z
  .object({
    newPassword: z
      .string()
      .min(8, "비밀번호는 8자 이상이어야 합니다")
      .regex(/[A-Z]/, "대문자를 포함해야 합니다")
      .regex(/[a-z]/, "소문자를 포함해야 합니다")
      .regex(/\d/, "숫자를 포함해야 합니다"),
    confirmPassword: z.string().min(1, "비밀번호 확인을 입력해주세요"),
  })
  .refine((data) => data.newPassword === data.confirmPassword, {
    message: "비밀번호가 일치하지 않습니다",
    path: ["confirmPassword"],
  });

type ResetFormData = z.infer<typeof resetSchema>;

const API_BASE = `${process.env.NEXT_PUBLIC_API_URL || ""}/api/v1`;

// ============================
// 비밀번호 강도
// ============================
function getPasswordStrength(pw: string): {
  level: 0 | 1 | 2 | 3;
  label: string;
  color: string;
} {
  if (!pw) return { level: 0, label: "", color: "" };
  let score = 0;
  if (pw.length >= 8) score++;
  if (/[A-Z]/.test(pw) && /[a-z]/.test(pw)) score++;
  if (/\d/.test(pw)) score++;
  if (pw.length >= 10 && /[^A-Za-z0-9]/.test(pw)) score++;
  if (score <= 1) return { level: 1, label: "약함", color: "#ef4444" };
  if (score === 2) return { level: 2, label: "보통", color: "#f59e0b" };
  return { level: 3, label: "강함", color: "#10b981" };
}

// ============================
// 실제 페이지 내용 (Suspense 래핑)
// ============================
function ResetPasswordContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const token = searchParams.get("token");

  const [showNew, setShowNew] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [apiError, setApiError] = useState<string | null>(null);
  const [isSuccess, setIsSuccess] = useState(false);
  const [countdown, setCountdown] = useState(3);
  const [passwordValue, setPasswordValue] = useState("");

  const passwordStrength = getPasswordStrength(passwordValue);

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<ResetFormData>({
    resolver: zodResolver(resetSchema),
  });

  // 성공 후 카운트다운 + 리다이렉트
  useEffect(() => {
    if (!isSuccess) return;
    if (countdown <= 0) {
      router.replace("/login");
      return;
    }
    const timer = setInterval(() => {
      setCountdown((prev) => prev - 1);
    }, 1000);
    return () => clearInterval(timer);
  }, [isSuccess, countdown, router]);

  // 토큰 없음 → 에러 표시
  if (!token) {
    return (
      <div
        className="rounded-2xl p-8 text-center"
        style={{
          background: "rgba(255,255,255,0.04)",
          backdropFilter: "blur(20px)",
          border: "1px solid rgba(255,255,255,0.08)",
        }}
      >
        <div
          className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4"
          style={{
            background: "rgba(239,68,68,0.1)",
            border: "1px solid rgba(239,68,68,0.2)",
          }}
        >
          <AlertCircle size={28} className="text-red-400" />
        </div>
        <h2 className="text-xl font-bold text-slate-100 mb-2">
          유효하지 않은 링크입니다
        </h2>
        <p className="text-slate-400 text-sm mb-6">
          링크가 만료되었거나 올바르지 않습니다.
          <br />
          비밀번호 찾기를 다시 시도해주세요.
        </p>
        <a
          href="/forgot-password"
          className="inline-block py-2.5 px-6 rounded-xl font-semibold text-sm"
          style={{ background: "#00d4ff", color: "#0a0a0f" }}
        >
          비밀번호 찾기로 이동
        </a>
      </div>
    );
  }

  // 성공 화면
  if (isSuccess) {
    return (
      <div
        className="rounded-2xl p-8 text-center"
        style={{
          background: "rgba(255,255,255,0.04)",
          backdropFilter: "blur(20px)",
          border: "1px solid rgba(255,255,255,0.08)",
        }}
      >
        <div
          className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4"
          style={{
            background: "rgba(16,185,129,0.1)",
            border: "1px solid rgba(16,185,129,0.2)",
          }}
        >
          <CheckCircle2 size={28} className="text-green-400" />
        </div>
        <h2 className="text-xl font-bold text-slate-100 mb-2">
          비밀번호가 변경되었습니다
        </h2>
        <p className="text-slate-400 text-sm mb-2">
          새 비밀번호로 로그인해주세요.
        </p>
        <p className="text-slate-500 text-xs mb-6">
          {countdown}초 후 자동으로 로그인 페이지로 이동합니다
        </p>
        <a
          href="/login"
          className="inline-block py-2.5 px-6 rounded-xl font-semibold text-sm"
          style={{ background: "#00d4ff", color: "#0a0a0f" }}
        >
          로그인하기
        </a>
      </div>
    );
  }

  // 폼 제출
  const onSubmit = async (data: ResetFormData) => {
    setIsLoading(true);
    setApiError(null);
    try {
      await axios.post(`${API_BASE}/auth/reset-password`, {
        token,
        new_password: data.newPassword,
      });
      toast.success("비밀번호가 변경되었습니다");
      setIsSuccess(true);
    } catch (error) {
      setApiError(getApiErrorMessage(error));
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div
      className="rounded-2xl p-8"
      style={{
        background: "rgba(255,255,255,0.04)",
        backdropFilter: "blur(20px)",
        border: "1px solid rgba(255,255,255,0.08)",
      }}
    >
      {/* 타이틀 */}
      <div className="text-center mb-6">
        <div className="text-4xl mb-3">🔑</div>
        <h1 className="text-xl font-bold text-slate-100 mb-1">
          새 비밀번호 설정
        </h1>
        <p className="text-sm text-slate-400">
          새로운 비밀번호를 입력해주세요
        </p>
      </div>

      {/* API 에러 */}
      {apiError && (
        <div
          className="flex items-start gap-2 p-3 rounded-xl mb-4 text-sm"
          style={{
            background: "rgba(239,68,68,0.12)",
            border: "1px solid rgba(239,68,68,0.25)",
            color: "#fca5a5",
          }}
        >
          <AlertCircle size={16} className="flex-shrink-0 mt-0.5" />
          <span>{apiError}</span>
        </div>
      )}

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        {/* 새 비밀번호 */}
        <div>
          <label className="block text-sm font-medium text-slate-300 mb-1.5">
            새 비밀번호
          </label>
          <div className="relative">
            <input
              {...register("newPassword")}
              type={showNew ? "text" : "password"}
              onChange={(e) => {
                register("newPassword").onChange(e);
                setPasswordValue(e.target.value);
              }}
              className="w-full rounded-xl px-4 py-2.5 text-sm text-slate-100 placeholder:text-slate-500 outline-none transition-all pr-11"
              style={{
                background: "rgba(255,255,255,0.06)",
                border: `1px solid ${errors.newPassword ? "rgba(239,68,68,0.5)" : "rgba(255,255,255,0.1)"}`,
              }}
              onFocus={(e) => {
                e.currentTarget.style.borderColor = "#00d4ff";
                e.currentTarget.style.boxShadow =
                  "0 0 0 3px rgba(0,212,255,0.1)";
              }}
              onBlur={(e) => {
                e.currentTarget.style.borderColor = errors.newPassword
                  ? "rgba(239,68,68,0.5)"
                  : "rgba(255,255,255,0.1)";
                e.currentTarget.style.boxShadow = "none";
              }}
              placeholder="8자 이상, 대소문자+숫자 포함"
            />
            <button
              type="button"
              onClick={() => setShowNew(!showNew)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 transition-colors"
            >
              {showNew ? <EyeOff size={16} /> : <Eye size={16} />}
            </button>
          </div>

          {/* 비밀번호 강도 바 */}
          {passwordValue && (
            <div className="mt-2">
              <div className="flex gap-1 mb-1">
                {[1, 2, 3].map((i) => (
                  <div
                    key={i}
                    className="h-1 flex-1 rounded-full transition-all duration-300"
                    style={{
                      background:
                        i <= passwordStrength.level
                          ? passwordStrength.color
                          : "rgba(255,255,255,0.1)",
                    }}
                  />
                ))}
              </div>
              {passwordStrength.level > 0 && (
                <p className="text-xs" style={{ color: passwordStrength.color }}>
                  {passwordStrength.label}
                </p>
              )}
            </div>
          )}

          {errors.newPassword && (
            <p className="mt-1 text-xs text-red-400">
              {errors.newPassword.message}
            </p>
          )}
        </div>

        {/* 비밀번호 확인 */}
        <div>
          <label className="block text-sm font-medium text-slate-300 mb-1.5">
            비밀번호 확인
          </label>
          <div className="relative">
            <input
              {...register("confirmPassword")}
              type={showConfirm ? "text" : "password"}
              className="w-full rounded-xl px-4 py-2.5 text-sm text-slate-100 placeholder:text-slate-500 outline-none transition-all pr-11"
              style={{
                background: "rgba(255,255,255,0.06)",
                border: `1px solid ${errors.confirmPassword ? "rgba(239,68,68,0.5)" : "rgba(255,255,255,0.1)"}`,
              }}
              onFocus={(e) => {
                e.currentTarget.style.borderColor = "#00d4ff";
                e.currentTarget.style.boxShadow =
                  "0 0 0 3px rgba(0,212,255,0.1)";
              }}
              onBlur={(e) => {
                e.currentTarget.style.borderColor = errors.confirmPassword
                  ? "rgba(239,68,68,0.5)"
                  : "rgba(255,255,255,0.1)";
                e.currentTarget.style.boxShadow = "none";
              }}
              placeholder="비밀번호를 다시 입력하세요"
            />
            <button
              type="button"
              onClick={() => setShowConfirm(!showConfirm)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 transition-colors"
            >
              {showConfirm ? <EyeOff size={16} /> : <Eye size={16} />}
            </button>
          </div>
          {errors.confirmPassword && (
            <p className="mt-1 text-xs text-red-400">
              {errors.confirmPassword.message}
            </p>
          )}
        </div>

        {/* 변경 버튼 */}
        <button
          type="submit"
          disabled={isLoading}
          className="w-full py-2.5 rounded-xl font-semibold text-sm transition-all disabled:opacity-60 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          style={{
            background: isLoading ? "rgba(0,212,255,0.6)" : "#00d4ff",
            color: "#0a0a0f",
          }}
        >
          {isLoading ? (
            <>
              <div
                className="w-4 h-4 border-2 rounded-full animate-spin"
                style={{
                  borderColor: "rgba(10,10,15,0.3)",
                  borderTopColor: "#0a0a0f",
                }}
              />
              변경 중...
            </>
          ) : (
            "비밀번호 변경"
          )}
        </button>
      </form>
    </div>
  );
}

// ============================
// 페이지 (Suspense 필수: useSearchParams 사용)
// ============================
export default function ResetPasswordPage() {
  return (
    <Suspense fallback={
      <div className="rounded-2xl p-8 text-center" style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)" }}>
        <div className="w-8 h-8 border-2 rounded-full animate-spin mx-auto" style={{ borderColor: "rgba(0,212,255,0.2)", borderTopColor: "#00d4ff" }} />
      </div>
    }>
      <ResetPasswordContent />
    </Suspense>
  );
}
