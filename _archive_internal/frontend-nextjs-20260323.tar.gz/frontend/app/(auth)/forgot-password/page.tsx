"use client";

/**
 * 비밀번호 찾기 페이지 (Sprint 2 완성)
 * - 이메일 입력 → 발송 성공 화면 전환
 * - 다시 보내기 60초 쿨다운
 */
import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import Link from "next/link";
import { ArrowLeft, AlertCircle, Mail } from "lucide-react";
import axios from "axios";

import { getApiErrorMessage } from "@/lib/api";

// ============================
// Zod 스키마
// ============================
const forgotSchema = z.object({
  email: z
    .string()
    .min(1, "이메일을 입력해주세요")
    .email("올바른 이메일 형식이 아닙니다"),
});

type ForgotFormData = z.infer<typeof forgotSchema>;

const API_BASE = `${process.env.NEXT_PUBLIC_API_URL || ""}/api/v1`;

// ============================
// 발송 성공 화면
// ============================
function SentSuccess({
  email,
  onResend,
  cooldown,
}: {
  email: string;
  onResend: () => void;
  cooldown: number;
}) {
  return (
    <div
      className="rounded-2xl p-8"
      style={{
        background: "rgba(255,255,255,0.04)",
        backdropFilter: "blur(20px)",
        border: "1px solid rgba(255,255,255,0.08)",
      }}
    >
      {/* 뒤로가기 */}
      <Link
        href="/login"
        className="inline-flex items-center gap-1.5 text-sm text-slate-400 hover:text-slate-200 transition-colors mb-6"
      >
        <ArrowLeft size={14} />
        로그인으로 돌아가기
      </Link>

      <div className="text-center py-4">
        <div
          className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4"
          style={{ background: "rgba(0,212,255,0.1)", border: "1px solid rgba(0,212,255,0.2)" }}
        >
          <Mail size={28} style={{ color: "#00d4ff" }} />
        </div>
        <h2 className="text-xl font-bold text-slate-100 mb-2">
          이메일을 발송했습니다
        </h2>
        <p className="text-slate-400 text-sm mb-1">
          <span className="text-slate-200 font-medium">{email}</span>
        </p>
        <p className="text-slate-400 text-sm mb-6">
          주소로 비밀번호 재설정 링크를 보냈습니다.
        </p>

        <div
          className="p-3 rounded-xl text-xs text-slate-400 mb-6 text-left"
          style={{ background: "rgba(255,255,255,0.04)" }}
        >
          <p className="mb-1">📬 이메일을 받지 못하셨나요?</p>
          <p>· 스팸 또는 정크 폴더를 확인해주세요</p>
          <p>· 이메일이 정확한지 확인해주세요</p>
        </div>

        {/* 다시 보내기 버튼 */}
        <button
          onClick={onResend}
          disabled={cooldown > 0}
          className="w-full py-2.5 rounded-xl text-sm font-medium transition-all disabled:opacity-50 disabled:cursor-not-allowed"
          style={{
            background: "rgba(255,255,255,0.06)",
            border: "1px solid rgba(255,255,255,0.1)",
            color: cooldown > 0 ? "#64748b" : "#e2e8f0",
          }}
        >
          {cooldown > 0
            ? `다시 보내기 (${cooldown}초 후 가능)`
            : "다시 보내기"}
        </button>
      </div>
    </div>
  );
}

// ============================
// 메인 컴포넌트
// ============================
export default function ForgotPasswordPage() {
  const [isSent, setIsSent] = useState(false);
  const [sentEmail, setSentEmail] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [apiError, setApiError] = useState<string | null>(null);
  const [cooldown, setCooldown] = useState(0);

  const {
    register,
    handleSubmit,
    getValues,
    formState: { errors },
  } = useForm<ForgotFormData>({
    resolver: zodResolver(forgotSchema),
  });

  // 쿨다운 카운트다운
  useEffect(() => {
    if (cooldown <= 0) return;
    const timer = setInterval(() => {
      setCooldown((prev) => prev - 1);
    }, 1000);
    return () => clearInterval(timer);
  }, [cooldown]);

  // 이메일 발송
  const sendResetEmail = async (email: string) => {
    setIsLoading(true);
    setApiError(null);
    try {
      await axios.post(`${API_BASE}/auth/forgot-password`, { email });
      setSentEmail(email);
      setIsSent(true);
      setCooldown(60);
    } catch (error) {
      setApiError(getApiErrorMessage(error));
    } finally {
      setIsLoading(false);
    }
  };

  const onSubmit = async (data: ForgotFormData) => {
    await sendResetEmail(data.email);
  };

  const handleResend = () => {
    sendResetEmail(sentEmail);
    setCooldown(60);
  };

  // 성공 화면
  if (isSent) {
    return (
      <SentSuccess email={sentEmail} onResend={handleResend} cooldown={cooldown} />
    );
  }

  return (
    <div
      className="rounded-2xl p-8"
      style={{
        background: "rgba(255,255,255,0.04)",
        backdropFilter: "blur(20px)",
        border: "1px solid rgba(255,255,255,0.08)",
      }}
    >
      {/* 뒤로가기 */}
      <Link
        href="/login"
        className="inline-flex items-center gap-1.5 text-sm text-slate-400 hover:text-slate-200 transition-colors mb-6"
      >
        <ArrowLeft size={14} />
        로그인으로 돌아가기
      </Link>

      {/* 타이틀 */}
      <div className="mb-6">
        <h1 className="text-xl font-bold text-slate-100 mb-1">
          비밀번호 재설정
        </h1>
        <p className="text-sm text-slate-400">
          가입하신 이메일 주소를 입력하시면 재설정 링크를 보내드립니다.
        </p>
      </div>

      {/* API 에러 */}
      {apiError && (
        <div
          className="flex items-start gap-2 p-3 rounded-xl mb-4 text-sm"
          style={{
            background: "rgba(239,68,68,0.12)",
            border: "1px solid rgba(239,68,68,0.25)",
            color: "#fca5a5",
          }}
        >
          <AlertCircle size={16} className="flex-shrink-0 mt-0.5" />
          <span>{apiError}</span>
        </div>
      )}

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        {/* 이메일 */}
        <div>
          <label className="block text-sm font-medium text-slate-300 mb-1.5">
            이메일
          </label>
          <input
            {...register("email")}
            type="email"
            className="w-full rounded-xl px-4 py-2.5 text-sm text-slate-100 placeholder:text-slate-500 outline-none transition-all"
            style={{
              background: "rgba(255,255,255,0.06)",
              border: `1px solid ${errors.email ? "rgba(239,68,68,0.5)" : "rgba(255,255,255,0.1)"}`,
            }}
            onFocus={(e) => {
              e.currentTarget.style.borderColor = "#00d4ff";
              e.currentTarget.style.boxShadow = "0 0 0 3px rgba(0,212,255,0.1)";
            }}
            onBlur={(e) => {
              e.currentTarget.style.borderColor = errors.email
                ? "rgba(239,68,68,0.5)"
                : "rgba(255,255,255,0.1)";
              e.currentTarget.style.boxShadow = "none";
            }}
            placeholder="hello@example.com"
          />
          {errors.email && (
            <p className="mt-1 text-xs text-red-400">{errors.email.message}</p>
          )}
        </div>

        {/* 발송 버튼 */}
        <button
          type="submit"
          disabled={isLoading}
          className="w-full py-2.5 rounded-xl font-semibold text-sm transition-all disabled:opacity-60 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          style={{
            background: isLoading ? "rgba(0,212,255,0.6)" : "#00d4ff",
            color: "#0a0a0f",
          }}
        >
          {isLoading ? (
            <>
              <div
                className="w-4 h-4 border-2 rounded-full animate-spin"
                style={{
                  borderColor: "rgba(10,10,15,0.3)",
                  borderTopColor: "#0a0a0f",
                }}
              />
              발송 중...
            </>
          ) : (
            "재설정 링크 보내기"
          )}
        </button>
      </form>
    </div>
  );
}
