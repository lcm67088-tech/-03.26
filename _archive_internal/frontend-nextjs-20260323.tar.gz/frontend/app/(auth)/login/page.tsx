"use client";

/**
 * 로그인 페이지 (Sprint 2 완성)
 * React Hook Form + Zod 검증
 * 소셜 로그인 버튼 (준비 중 토스트)
 * 로그인 잠금 / 에러 처리
 */
import { useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import Link from "next/link";
import { Eye, EyeOff, AlertCircle } from "lucide-react";
import { toast } from "sonner";

import { useAuthStore } from "@/store/authStore";

// ============================
// Zod 스키마
// ============================
const loginSchema = z.object({
  email: z
    .string()
    .min(1, "이메일을 입력해주세요")
    .email("올바른 이메일 형식이 아닙니다"),
  password: z.string().min(1, "비밀번호를 입력해주세요"),
});

type LoginFormData = z.infer<typeof loginSchema>;

// ============================
// 컴포넌트
// ============================
export default function LoginPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const redirect = searchParams.get("redirect") || "/dashboard";

  const { login, isLoading } = useAuthStore();

  const [showPassword, setShowPassword] = useState(false);
  const [apiError, setApiError] = useState<string | null>(null);

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<LoginFormData>({
    resolver: zodResolver(loginSchema),
  });

  // ============================
  // 폼 제출
  // ============================
  const onSubmit = async (data: LoginFormData) => {
    setApiError(null);
    try {
      await login(data.email, data.password);
      toast.success("로그인되었습니다");
      router.push(redirect);
    } catch (error) {
      const msg = error instanceof Error ? error.message : "로그인에 실패했습니다";
      setApiError(msg);
    }
  };

  // 소셜 로그인 클릭
  const handleSocialLogin = (provider: string) => {
    toast.info(`${provider} 로그인은 준비 중입니다`);
  };

  return (
    <div
      className="rounded-2xl p-8"
      style={{
        background: "rgba(255,255,255,0.04)",
        backdropFilter: "blur(20px)",
        border: "1px solid rgba(255,255,255,0.08)",
      }}
    >
      {/* 로고 */}
      <div className="text-center mb-8">
        <div className="text-4xl mb-3">🏪</div>
        <h1 className="text-2xl font-bold">
          <span style={{ color: "#00d4ff" }}>nplace</span>
          <span className="text-white">.io</span>
        </h1>
        <p className="text-sm text-gray-400 mt-1">
          네이버 플레이스 마케팅 최적화 플랫폼
        </p>
      </div>

      {/* API 에러 알림 */}
      {apiError && (
        <div
          className="flex items-start gap-2 p-3 rounded-xl mb-5 text-sm"
          style={{
            background: "rgba(239,68,68,0.12)",
            border: "1px solid rgba(239,68,68,0.25)",
            color: "#fca5a5",
          }}
        >
          <AlertCircle size={16} className="flex-shrink-0 mt-0.5" />
          <span>{apiError}</span>
        </div>
      )}

      {/* 폼 */}
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        {/* 이메일 */}
        <div>
          <label className="block text-sm font-medium text-slate-300 mb-1.5">
            이메일
          </label>
          <input
            {...register("email")}
            type="email"
            className="w-full rounded-xl px-4 py-2.5 text-sm text-slate-100 placeholder:text-slate-500 outline-none transition-all"
            style={{
              background: "rgba(255,255,255,0.06)",
              border: `1px solid ${errors.email ? "rgba(239,68,68,0.5)" : "rgba(255,255,255,0.1)"}`,
            }}
            onFocus={(e) => {
              e.currentTarget.style.borderColor = "#00d4ff";
              e.currentTarget.style.boxShadow = "0 0 0 3px rgba(0,212,255,0.1)";
            }}
            onBlur={(e) => {
              e.currentTarget.style.borderColor = errors.email
                ? "rgba(239,68,68,0.5)"
                : "rgba(255,255,255,0.1)";
              e.currentTarget.style.boxShadow = "none";
            }}
            placeholder="hello@example.com"
          />
          {errors.email && (
            <p className="mt-1 text-xs text-red-400">{errors.email.message}</p>
          )}
        </div>

        {/* 비밀번호 */}
        <div>
          <label className="block text-sm font-medium text-slate-300 mb-1.5">
            비밀번호
          </label>
          <div className="relative">
            <input
              {...register("password")}
              type={showPassword ? "text" : "password"}
              className="w-full rounded-xl px-4 py-2.5 text-sm text-slate-100 placeholder:text-slate-500 outline-none transition-all pr-11"
              style={{
                background: "rgba(255,255,255,0.06)",
                border: `1px solid ${errors.password ? "rgba(239,68,68,0.5)" : "rgba(255,255,255,0.1)"}`,
              }}
              onFocus={(e) => {
                e.currentTarget.style.borderColor = "#00d4ff";
                e.currentTarget.style.boxShadow = "0 0 0 3px rgba(0,212,255,0.1)";
              }}
              onBlur={(e) => {
                e.currentTarget.style.borderColor = errors.password
                  ? "rgba(239,68,68,0.5)"
                  : "rgba(255,255,255,0.1)";
                e.currentTarget.style.boxShadow = "none";
              }}
              placeholder="비밀번호를 입력하세요"
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 transition-colors"
            >
              {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
            </button>
          </div>
          {errors.password && (
            <p className="mt-1 text-xs text-red-400">{errors.password.message}</p>
          )}
        </div>

        {/* 로그인 버튼 */}
        <button
          type="submit"
          disabled={isLoading}
          className="w-full py-2.5 rounded-xl font-semibold text-sm transition-all disabled:opacity-60 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          style={{
            background: isLoading ? "rgba(0,212,255,0.6)" : "#00d4ff",
            color: "#0a0a0f",
          }}
          onMouseEnter={(e) => {
            if (!isLoading) e.currentTarget.style.background = "rgba(0,212,255,0.85)";
          }}
          onMouseLeave={(e) => {
            if (!isLoading) e.currentTarget.style.background = "#00d4ff";
          }}
        >
          {isLoading ? (
            <>
              <div
                className="w-4 h-4 border-2 rounded-full animate-spin"
                style={{ borderColor: "rgba(10,10,15,0.3)", borderTopColor: "#0a0a0f" }}
              />
              로그인 중...
            </>
          ) : (
            "로그인"
          )}
        </button>
      </form>

      {/* 구분선 */}
      <div className="flex items-center gap-3 my-5">
        <div className="flex-1 h-px" style={{ background: "rgba(255,255,255,0.08)" }} />
        <span className="text-xs text-slate-500">또는</span>
        <div className="flex-1 h-px" style={{ background: "rgba(255,255,255,0.08)" }} />
      </div>

      {/* 소셜 로그인 */}
      <div className="space-y-2">
        {/* 카카오 */}
        <button
          type="button"
          onClick={() => handleSocialLogin("카카오")}
          className="w-full py-2.5 rounded-xl font-semibold text-sm transition-all flex items-center justify-center gap-2 hover:opacity-90"
          style={{ background: "#FEE500", color: "#000000" }}
        >
          <span className="text-base font-bold">K</span>
          카카오로 로그인
        </button>

        {/* 구글 */}
        <button
          type="button"
          onClick={() => handleSocialLogin("구글")}
          className="w-full py-2.5 rounded-xl font-semibold text-sm transition-all flex items-center justify-center gap-2 hover:opacity-90"
          style={{
            background: "white",
            color: "#1f1f1f",
            border: "1px solid rgba(0,0,0,0.1)",
          }}
        >
          <svg width="18" height="18" viewBox="0 0 24 24">
            <path
              fill="#4285F4"
              d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
            />
            <path
              fill="#34A853"
              d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
            />
            <path
              fill="#FBBC05"
              d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
            />
            <path
              fill="#EA4335"
              d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
            />
          </svg>
          구글로 로그인
        </button>
      </div>

      {/* 하단 링크 */}
      <div className="mt-6 space-y-2 text-center">
        <p className="text-sm text-slate-400">
          계정이 없으신가요?{" "}
          <Link
            href="/signup"
            className="font-medium transition-colors hover:underline"
            style={{ color: "#00d4ff" }}
          >
            회원가입
          </Link>
        </p>
        <Link
          href="/forgot-password"
          className="block text-xs text-slate-500 hover:text-slate-400 transition-colors"
        >
          비밀번호를 잊으셨나요?
        </Link>
      </div>
    </div>
  );
}
