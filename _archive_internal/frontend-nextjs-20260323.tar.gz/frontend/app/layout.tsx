import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { Providers } from "./providers";
import { Toaster } from "sonner";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "nplace.io | 네이버 플레이스 마케팅 최적화",
  description: "네이버 플레이스 순위 관리, 키워드 분석, 마케팅 서비스를 한 곳에서",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="ko" className="dark">
      <head>
        <link
          rel="stylesheet"
          as="style"
          crossOrigin="anonymous"
          href="https://cdn.jsdelivr.net/gh/orioncactus/pretendard@v1.3.9/dist/web/variable/pretendardvariable.min.css"
        />
      </head>
      <body
        className={`${inter.className} bg-brand-dark text-slate-100 antialiased`}
        style={{ fontFamily: "'Pretendard Variable', 'Pretendard', sans-serif" }}
      >
        <Providers>
          {children}
          <Toaster
            position="top-right"
            theme="dark"
            richColors
            toastOptions={{
              style: {
                background: "rgba(15,15,25,0.95)",
                border: "1px solid rgba(0,212,255,0.2)",
                color: "#e2e8f0",
              },
            }}
          />
        </Providers>
      </body>
    </html>
  );
}
