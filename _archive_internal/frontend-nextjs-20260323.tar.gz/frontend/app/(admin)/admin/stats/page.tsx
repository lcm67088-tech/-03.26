"use client";

/**
 * 어드민 통계 대시보드 페이지 (Sprint 9)
 *
 * KPI 카드:
 *   - 오늘 주문 / 오늘 매출
 *   - 이번 달 신규 유저 / 신규 워크스페이스
 *   - MRR / ARR
 *
 * 차트:
 *   - 플랜별 분포 PieChart (Recharts)
 *   - 최근 6개월 매출 AreaChart (Recharts)
 *
 * 자동 갱신: 5분
 */

import { useEffect, useState } from "react";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
} from "recharts";
import { useStatsOverview, useMonthlyRevenue } from "@/hooks/useAdminAdvanced";

// ── 플랜 색상 ────────────────────────────────────────────────
const PLAN_COLORS: Record<string, string> = {
  free: "#64748b",
  starter: "#3b82f6",
  pro: "#00d4ff",
  enterprise: "#7c3aed",
};

// ── KPI 카드 컴포넌트 ─────────────────────────────────────────
interface KpiCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  color?: string;
  icon?: string;
}

function KpiCard({ title, value, subtitle, color = "text-white", icon }: KpiCardProps) {
  return (
    <div className="bg-[#12121a] border border-slate-800 rounded-xl p-5 space-y-2 hover:border-slate-700 transition">
      <div className="flex items-center justify-between">
        <p className="text-slate-400 text-sm">{title}</p>
        {icon && <span className="text-2xl opacity-80">{icon}</span>}
      </div>
      <p className={`text-2xl font-bold ${color}`}>{value}</p>
      {subtitle && <p className="text-slate-500 text-xs">{subtitle}</p>}
    </div>
  );
}

// ── 숫자 포맷 헬퍼 ────────────────────────────────────────────
function fmtKRW(n: number): string {
  if (n >= 1_000_000_000) return `${(n / 1_000_000_000).toFixed(1)}B`;
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}K`;
  return n.toLocaleString();
}

export default function AdminStatsDashboardPage() {
  // ── 쿼리 ────────────────────────────────────────────────────
  const {
    data: overview,
    isLoading: overviewLoading,
    dataUpdatedAt,
  } = useStatsOverview();
  const { data: revenue } = useMonthlyRevenue(6);

  // ── 마지막 갱신 시각 표시 ────────────────────────────────────
  const [lastUpdated, setLastUpdated] = useState<string>("");
  useEffect(() => {
    if (dataUpdatedAt) {
      setLastUpdated(new Date(dataUpdatedAt).toLocaleTimeString("ko-KR"));
    }
  }, [dataUpdatedAt]);

  // ── 플랜 분포 파이 차트 데이터 변환 ──────────────────────────
  const pieData = overview
    ? [
        { name: "Free", value: overview.plan_distribution.free, key: "free" },
        { name: "Starter", value: overview.plan_distribution.starter, key: "starter" },
        { name: "Pro", value: overview.plan_distribution.pro, key: "pro" },
        { name: "Enterprise", value: overview.plan_distribution.enterprise, key: "enterprise" },
      ].filter((d) => d.value > 0)
    : [];

  // ── 월별 매출 Area 차트 데이터 변환 ──────────────────────────
  const areaData = revenue?.items.map((item) => ({
    month: item.month.slice(5), // "YYYY-MM" → "MM"
    revenue: item.revenue,
    orders: item.order_count,
    newUsers: item.new_users,
  })) ?? [];

  if (overviewLoading) {
    return (
      <div className="flex items-center justify-center h-60 text-slate-400">
        통계 로딩 중...
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* 헤더 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">통계 대시보드</h1>
          <p className="text-slate-400 text-sm mt-1">
            실시간 KPI 지표와 매출 추이를 확인합니다
          </p>
        </div>
        <div className="text-right">
          <p className="text-xs text-slate-500">마지막 갱신</p>
          <p className="text-sm text-cyan-400">{lastUpdated || "—"}</p>
          <p className="text-xs text-slate-600 mt-0.5">5분마다 자동 갱신</p>
        </div>
      </div>

      {/* ── KPI 카드 1행: 오늘 ─────────────────────────────────── */}
      <section>
        <h2 className="text-slate-400 text-xs font-semibold uppercase tracking-wider mb-3">오늘</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <KpiCard
            title="오늘 주문"
            value={overview?.today_orders.toLocaleString() ?? "—"}
            icon="📦"
            color="text-cyan-400"
          />
          <KpiCard
            title="오늘 매출"
            value={overview ? `${fmtKRW(overview.today_revenue)}원` : "—"}
            icon="💳"
            color="text-green-400"
          />
          <KpiCard
            title="대기 주문"
            value={overview?.pending_orders.toLocaleString() ?? "—"}
            subtitle="처리 필요"
            icon="⏳"
            color="text-yellow-400"
          />
          <KpiCard
            title="활성 워크스페이스"
            value={overview?.active_workspaces.toLocaleString() ?? "—"}
            subtitle={`전체 ${overview?.total_workspaces ?? "—"}개`}
            icon="🏢"
            color="text-purple-400"
          />
        </div>
      </section>

      {/* ── KPI 카드 2행: 이번 달 신규 ────────────────────────── */}
      <section>
        <h2 className="text-slate-400 text-xs font-semibold uppercase tracking-wider mb-3">이번 달 신규</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <KpiCard
            title="신규 유저"
            value={overview?.month_new_users.toLocaleString() ?? "—"}
            subtitle={`전체 ${overview?.total_users ?? "—"}명`}
            icon="👤"
            color="text-blue-400"
          />
          <KpiCard
            title="신규 워크스페이스"
            value={overview?.month_new_workspaces.toLocaleString() ?? "—"}
            icon="🆕"
            color="text-cyan-400"
          />
          <KpiCard
            title="MRR"
            value={overview ? `${fmtKRW(overview.mrr)}원` : "—"}
            subtitle="이번 달 구독 매출"
            icon="📈"
            color="text-green-400"
          />
          <KpiCard
            title="ARR"
            value={overview ? `${fmtKRW(overview.arr)}원` : "—"}
            subtitle="MRR × 12"
            icon="🎯"
            color="text-purple-400"
          />
        </div>
      </section>

      {/* ── 차트 영역 ─────────────────────────────────────────── */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* 월별 매출 AreaChart (2/3) */}
        <div className="lg:col-span-2 bg-[#12121a] border border-slate-800 rounded-xl p-6">
          <h3 className="text-white font-semibold mb-1">월별 매출 추이</h3>
          <p className="text-slate-500 text-xs mb-5">최근 6개월 paid 청구 합산</p>
          <div style={{ height: 280 }}>
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={areaData} margin={{ top: 5, right: 5, bottom: 5, left: 5 }}>
                <defs>
                  <linearGradient id="revenueGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#00d4ff" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#00d4ff" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="month" tick={{ fill: "#94a3b8", fontSize: 12 }} />
                <YAxis
                  tick={{ fill: "#94a3b8", fontSize: 11 }}
                  tickFormatter={(v: number) => fmtKRW(v)}
                />
                <Tooltip
                  contentStyle={{ background: "#1e293b", border: "1px solid #334155", borderRadius: 8 }}
                  labelStyle={{ color: "#e2e8f0" }}
                  formatter={(val: number) => [`${val.toLocaleString()}원`, "매출"]}
                />
                <Area
                  type="monotone"
                  dataKey="revenue"
                  stroke="#00d4ff"
                  strokeWidth={2}
                  fill="url(#revenueGrad)"
                  dot={{ fill: "#00d4ff", r: 4 }}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* 플랜 분포 PieChart (1/3) */}
        <div className="bg-[#12121a] border border-slate-800 rounded-xl p-6">
          <h3 className="text-white font-semibold mb-1">플랜별 분포</h3>
          <p className="text-slate-500 text-xs mb-4">활성 워크스페이스 기준</p>
          {pieData.length === 0 ? (
            <div className="flex items-center justify-center h-60 text-slate-500 text-sm">
              데이터가 없습니다
            </div>
          ) : (
            <div style={{ height: 280 }}>
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="45%"
                    innerRadius={55}
                    outerRadius={85}
                    paddingAngle={4}
                    dataKey="value"
                    label={({ name, percent }) =>
                      `${name} ${(percent * 100).toFixed(0)}%`
                    }
                    labelLine={false}
                  >
                    {pieData.map((entry) => (
                      <Cell
                        key={entry.key}
                        fill={PLAN_COLORS[entry.key] ?? "#64748b"}
                      />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{ background: "#1e293b", border: "1px solid #334155", borderRadius: 8 }}
                    labelStyle={{ color: "#e2e8f0" }}
                    formatter={(val: number, name: string) => [`${val}개`, name]}
                  />
                  <Legend
                    iconType="circle"
                    iconSize={8}
                    wrapperStyle={{ fontSize: 12, color: "#94a3b8" }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>
      </div>

      {/* ── 신규 유저/주문 수 보조 Area ──────────────────────────── */}
      <div className="bg-[#12121a] border border-slate-800 rounded-xl p-6">
        <h3 className="text-white font-semibold mb-1">월별 신규 유저 · 주문 수</h3>
        <p className="text-slate-500 text-xs mb-5">최근 6개월</p>
        <div style={{ height: 220 }}>
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={areaData} margin={{ top: 5, right: 5, bottom: 5, left: 5 }}>
              <defs>
                <linearGradient id="usersGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#7c3aed" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#7c3aed" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="ordersGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#22c55e" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#22c55e" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="month" tick={{ fill: "#94a3b8", fontSize: 12 }} />
              <YAxis tick={{ fill: "#94a3b8", fontSize: 11 }} allowDecimals={false} />
              <Tooltip
                contentStyle={{ background: "#1e293b", border: "1px solid #334155", borderRadius: 8 }}
                labelStyle={{ color: "#e2e8f0" }}
              />
              <Area
                type="monotone"
                dataKey="newUsers"
                name="신규 유저"
                stroke="#7c3aed"
                strokeWidth={2}
                fill="url(#usersGrad)"
                dot={{ fill: "#7c3aed", r: 3 }}
              />
              <Area
                type="monotone"
                dataKey="orders"
                name="주문 수"
                stroke="#22c55e"
                strokeWidth={2}
                fill="url(#ordersGrad)"
                dot={{ fill: "#22c55e", r: 3 }}
              />
              <Legend
                iconType="circle"
                iconSize={8}
                wrapperStyle={{ fontSize: 12, color: "#94a3b8" }}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
