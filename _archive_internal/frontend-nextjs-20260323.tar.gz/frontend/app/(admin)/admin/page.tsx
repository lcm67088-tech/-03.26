"use client";

/**
 * 어드민 대시보드 페이지 (Sprint 6 완성)
 *
 * - 실시간 시계 (1초 갱신)
 * - 마지막 업데이트 시각 + 수동 갱신 버튼
 * - 2×2 그리드 KPI 카드 (오늘 주문, 오늘 매출, 대기 주문(≥10 빨강), 이번달 매출)
 * - 플랜 분포 막대 차트
 * - 최근 주문 5개 테이블
 * - 5분 자동 갱신 (useAdminDashboard)
 */
import { useState, useEffect } from "react";
import Link from "next/link";
import { format } from "date-fns";
import { ko } from "date-fns/locale";
import { RefreshCw, TrendingUp, ShoppingCart, Clock, BarChart2, AlertCircle } from "lucide-react";
import { useAdminDashboard } from "@/hooks/useAdmin";
import { StatusBadge } from "@/components/common/StatusBadge";

// ============================
// 금액 포맷
// ============================
function formatKRW(amount: number): string {
  if (amount >= 1_000_000) {
    return `₩${(amount / 1_000_000).toFixed(1)}M`;
  }
  if (amount >= 10_000) {
    return `₩${(amount / 10_000).toFixed(0)}만`;
  }
  return `₩${amount.toLocaleString()}`;
}

// ============================
// KPI 카드
// ============================
interface KpiCardProps {
  label: string;
  value: string | number;
  icon: React.ReactNode;
  color: string;         // Tailwind text 색
  bgColor: string;       // Tailwind bg 색
  alert?: boolean;       // 빨간 강조
  sub?: string;
}

function KpiCard({ label, value, icon, color, bgColor, alert, sub }: KpiCardProps) {
  return (
    <div
      className={`card p-5 flex flex-col gap-3 ${
        alert ? "ring-1 ring-red-500/50" : ""
      }`}
    >
      <div className="flex items-center justify-between">
        <p className="text-slate-400 text-sm">{label}</p>
        <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${bgColor}`}>
          {icon}
        </div>
      </div>
      <div>
        <p className={`text-3xl font-bold ${alert ? "text-red-400" : color}`}>
          {value}
        </p>
        {sub && <p className="text-slate-500 text-xs mt-1">{sub}</p>}
      </div>
    </div>
  );
}

// ============================
// 플랜 분포 막대
// ============================
function PlanBar({
  label,
  count,
  total,
  color,
}: {
  label: string;
  count: number;
  total: number;
  color: string;
}) {
  const pct = total > 0 ? Math.round((count / total) * 100) : 0;
  return (
    <div className="flex items-center gap-3 text-sm">
      <span className="w-20 text-slate-400 text-right capitalize">{label}</span>
      <div className="flex-1 bg-slate-800 rounded-full h-2.5 overflow-hidden">
        <div
          className={`h-full rounded-full ${color} transition-all duration-500`}
          style={{ width: `${pct}%` }}
        />
      </div>
      <span className="w-12 text-slate-300 text-right">{count}개</span>
      <span className="w-8 text-slate-500 text-right text-xs">{pct}%</span>
    </div>
  );
}

// ============================
// 메인 컴포넌트
// ============================
export default function AdminDashboardPage() {
  const { data, isLoading, isError, refetch, dataUpdatedAt } =
    useAdminDashboard();

  // 실시간 시계
  const [now, setNow] = useState(new Date());
  useEffect(() => {
    const timer = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  // 마지막 업데이트 시각
  const lastUpdated = dataUpdatedAt
    ? format(new Date(dataUpdatedAt), "HH:mm:ss", { locale: ko })
    : "-";

  // 로딩 / 에러
  if (isLoading) {
    return (
      <div className="space-y-6 animate-pulse">
        <div className="h-8 w-48 bg-slate-800 rounded-lg" />
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="card h-32" />
          ))}
        </div>
        <div className="card h-40" />
        <div className="card h-56" />
      </div>
    );
  }

  if (isError || !data) {
    return (
      <div className="card p-8 text-center">
        <AlertCircle className="mx-auto mb-3 text-red-400" size={32} />
        <p className="text-slate-300">대시보드 데이터를 불러올 수 없습니다</p>
        <button
          onClick={() => refetch()}
          className="mt-4 btn-primary text-sm"
        >
          다시 시도
        </button>
      </div>
    );
  }

  const {
    today_orders,
    today_revenue,
    pending_orders,
    this_month_revenue,
    total_workspaces,
    active_workspaces,
    plan_distribution,
    recent_orders,
  } = data;

  const totalPlanCount =
    plan_distribution.free +
    plan_distribution.starter +
    plan_distribution.pro +
    plan_distribution.enterprise;

  return (
    <div className="space-y-6">
      {/* ── 페이지 헤더 ── */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-slate-100">어드민 대시보드</h1>
          <p className="text-slate-400 text-sm mt-0.5">
            {format(now, "yyyy년 MM월 dd일 (eee) HH:mm:ss", { locale: ko })}
          </p>
        </div>

        <div className="flex items-center gap-3">
          {/* 마지막 업데이트 */}
          <span className="text-slate-500 text-xs">
            마지막 갱신: {lastUpdated}
          </span>
          {/* 수동 갱신 버튼 */}
          <button
            onClick={() => refetch()}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm text-slate-300 hover:text-slate-100 hover:bg-slate-700 transition-colors"
          >
            <RefreshCw size={14} />
            새로고침
          </button>
          {/* ADMIN 배지 */}
          <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-red-500/10 text-red-400 border border-red-500/20">
            ADMIN
          </span>
        </div>
      </div>

      {/* ── KPI 카드 2×2 ── */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <KpiCard
          label="오늘 신규 주문"
          value={today_orders}
          icon={<ShoppingCart size={18} className="text-cyan-400" />}
          color="text-cyan-400"
          bgColor="bg-cyan-500/10"
          sub="취소·환불 제외"
        />
        <KpiCard
          label="오늘 매출"
          value={formatKRW(today_revenue)}
          icon={<TrendingUp size={18} className="text-emerald-400" />}
          color="text-emerald-400"
          bgColor="bg-emerald-500/10"
          sub="완료 주문 기준"
        />
        <KpiCard
          label="처리 대기 주문"
          value={pending_orders}
          icon={<Clock size={18} className={pending_orders >= 10 ? "text-red-400" : "text-amber-400"} />}
          color="text-amber-400"
          bgColor={pending_orders >= 10 ? "bg-red-500/10" : "bg-amber-500/10"}
          alert={pending_orders >= 10}
          sub={pending_orders >= 10 ? "⚠️ 즉시 처리 필요" : "confirmed 상태"}
        />
        <KpiCard
          label="이번달 매출"
          value={formatKRW(this_month_revenue)}
          icon={<BarChart2 size={18} className="text-violet-400" />}
          color="text-violet-400"
          bgColor="bg-violet-500/10"
          sub="완료 주문 합산"
        />
      </div>

      {/* ── 하단 2열 ── */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* 플랜 분포 */}
        <div className="card p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-semibold text-slate-200">플랜 분포</h2>
            <div className="text-xs text-slate-500">
              총 {total_workspaces}개 워크스페이스
              <span className="ml-2 text-cyan-400">
                (활성 {active_workspaces}개)
              </span>
            </div>
          </div>

          <div className="space-y-3">
            <PlanBar
              label="Free"
              count={plan_distribution.free}
              total={totalPlanCount}
              color="bg-slate-500"
            />
            <PlanBar
              label="Starter"
              count={plan_distribution.starter}
              total={totalPlanCount}
              color="bg-blue-500"
            />
            <PlanBar
              label="Pro"
              count={plan_distribution.pro}
              total={totalPlanCount}
              color="bg-purple-500"
            />
            <PlanBar
              label="Enterprise"
              count={plan_distribution.enterprise}
              total={totalPlanCount}
              color="bg-yellow-500"
            />
          </div>
        </div>

        {/* 최근 주문 5개 */}
        <div className="card p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-semibold text-slate-200">최근 주문</h2>
            <Link
              href="/admin/orders"
              className="text-xs text-cyan-400 hover:text-cyan-300 transition-colors"
            >
              전체 보기 →
            </Link>
          </div>

          {recent_orders.length === 0 ? (
            <p className="text-center text-slate-500 text-sm py-6">
              주문 내역이 없습니다
            </p>
          ) : (
            <div className="space-y-2">
              {recent_orders.map((order) => (
                <Link
                  key={order.id}
                  href={`/admin/orders/${order.id}`}
                  className="flex items-center justify-between p-2.5 rounded-lg hover:bg-slate-800 transition-colors"
                >
                  <div className="min-w-0">
                    <p className="text-sm text-slate-200 truncate">
                      {order.product_name}
                    </p>
                    <p className="text-xs text-slate-500 truncate">
                      {order.workspace_name} ·{" "}
                      {order.ordered_at
                        ? format(new Date(order.ordered_at), "MM/dd HH:mm")
                        : "-"}
                    </p>
                  </div>
                  <div className="flex items-center gap-2 ml-3 flex-shrink-0">
                    <StatusBadge status={order.status} />
                    <span className="text-sm font-medium text-slate-300">
                      ₩{order.total_amount.toLocaleString()}
                    </span>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
