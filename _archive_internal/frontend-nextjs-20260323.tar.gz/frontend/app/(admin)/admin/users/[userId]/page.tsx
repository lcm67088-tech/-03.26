"use client";

/**
 * 어드민 유저 상세 페이지 (Sprint 9)
 *
 * 표시 정보:
 *   - 기본 정보 (이메일, 이름, 역할, 상태, 가입일)
 *   - 소유 워크스페이스 카드 목록
 *   - 최근 주문 테이블 (최근 10건)
 */

import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import {
  useAdminUser,
  usePatchUserRole,
  usePatchUserStatus,
  useForceLogout,
} from "@/hooks/useAdminAdvanced";
import { getApiErrorMessage } from "@/lib/api";
import { useState } from "react";

// ── 역할 뱃지 ────────────────────────────────────────────────
const ROLE_BADGE: Record<string, string> = {
  superadmin: "bg-purple-600/20 text-purple-400 border border-purple-500/30",
  admin: "bg-cyan-600/20 text-cyan-400 border border-cyan-500/30",
  user: "bg-slate-600/20 text-slate-400 border border-slate-500/30",
};
const ROLE_LABEL: Record<string, string> = {
  superadmin: "슈퍼어드민",
  admin: "어드민",
  user: "일반",
};

// ── 주문 상태 뱃지 ────────────────────────────────────────────
const STATUS_BADGE: Record<string, string> = {
  pending: "bg-yellow-600/20 text-yellow-400",
  confirmed: "bg-blue-600/20 text-blue-400",
  in_progress: "bg-cyan-600/20 text-cyan-400",
  completed: "bg-green-600/20 text-green-400",
  cancelled: "bg-slate-600/20 text-slate-400",
  refund_requested: "bg-orange-600/20 text-orange-400",
  refunded: "bg-red-600/20 text-red-400",
};

export default function AdminUserDetailPage() {
  const { userId } = useParams<{ userId: string }>();
  const router = useRouter();

  const { data: user, isLoading, isError } = useAdminUser(userId);
  const patchRole = usePatchUserRole(userId);
  const patchStatus = usePatchUserStatus(userId);
  const forceLogout = useForceLogout(userId);

  const [toast, setToast] = useState<{ msg: string; ok: boolean } | null>(null);
  const [showRoleDialog, setShowRoleDialog] = useState(false);
  const [roleInput, setRoleInput] = useState("");
  const [roleReason, setRoleReason] = useState("");

  const showToast = (msg: string, ok = true) => {
    setToast({ msg, ok });
    setTimeout(() => setToast(null), 3000);
  };

  const handleRoleSubmit = async () => {
    try {
      await patchRole.mutateAsync({ role: roleInput, reason: roleReason });
      showToast("역할이 변경되었습니다");
      setShowRoleDialog(false);
    } catch (e) {
      showToast(getApiErrorMessage(e), false);
    }
  };

  const handleToggleStatus = async () => {
    if (!user) return;
    const newStatus = !user.is_active;
    try {
      await patchStatus.mutateAsync({ is_active: newStatus });
      showToast(`계정이 ${newStatus ? "활성화" : "비활성화"}되었습니다`);
    } catch (e) {
      showToast(getApiErrorMessage(e), false);
    }
  };

  const handleForceLogout = async () => {
    try {
      await forceLogout.mutateAsync();
      showToast("강제 로그아웃 처리되었습니다");
    } catch (e) {
      showToast(getApiErrorMessage(e), false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-60 text-slate-400">
        로딩 중...
      </div>
    );
  }
  if (isError || !user) {
    return (
      <div className="flex flex-col items-center justify-center h-60 gap-4 text-slate-400">
        <p>유저를 찾을 수 없습니다</p>
        <button
          onClick={() => router.back()}
          className="px-4 py-2 rounded-lg bg-slate-700 hover:bg-slate-600 text-sm transition"
        >
          뒤로 가기
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* 상단 헤더 */}
      <div className="flex items-center gap-4">
        <button
          onClick={() => router.back()}
          className="text-slate-400 hover:text-white transition text-sm"
        >
          ← 목록
        </button>
        <h1 className="text-xl font-bold text-white">{user.email}</h1>
        <span className={`px-2 py-1 rounded-full text-xs font-medium ${ROLE_BADGE[user.role] ?? ""}`}>
          {ROLE_LABEL[user.role] ?? user.role}
        </span>
        <span className={`px-2 py-1 rounded-full text-xs font-medium ${user.is_active
          ? "bg-green-600/20 text-green-400 border border-green-500/30"
          : "bg-red-600/20 text-red-400 border border-red-500/30"
        }`}>
          {user.is_active ? "활성" : "비활성"}
        </span>
      </div>

      {/* 기본 정보 + 액션 */}
      <div className="bg-[#12121a] border border-slate-800 rounded-xl p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-3">
          <h2 className="text-white font-semibold">기본 정보</h2>
          <div className="grid grid-cols-2 gap-2 text-sm">
            <span className="text-slate-400">ID</span>
            <span className="text-slate-300 font-mono text-xs">{user.id}</span>
            <span className="text-slate-400">이메일</span>
            <span className="text-white">{user.email}</span>
            <span className="text-slate-400">이름</span>
            <span className="text-white">{user.name}</span>
            <span className="text-slate-400">전화번호</span>
            <span className="text-slate-300">{user.phone ?? "-"}</span>
            <span className="text-slate-400">이메일 인증</span>
            <span className={user.email_verified ? "text-green-400" : "text-yellow-400"}>
              {user.email_verified ? "완료" : "미완료"}
            </span>
            <span className="text-slate-400">가입일</span>
            <span className="text-slate-300">
              {new Date(user.created_at).toLocaleDateString("ko-KR")}
            </span>
          </div>
        </div>
        <div className="space-y-3">
          <h2 className="text-white font-semibold">액션</h2>
          <div className="flex flex-col gap-2">
            <button
              onClick={() => { setShowRoleDialog(true); setRoleInput(user.role); setRoleReason(""); }}
              className="px-4 py-2 rounded-lg bg-purple-600/20 hover:bg-purple-600/40 text-purple-400 text-sm border border-purple-500/30 transition text-left"
            >
              역할 변경
            </button>
            <button
              onClick={handleToggleStatus}
              disabled={patchStatus.isPending}
              className={`px-4 py-2 rounded-lg text-sm transition text-left disabled:opacity-60 ${
                user.is_active
                  ? "bg-red-600/20 hover:bg-red-600/40 text-red-400 border border-red-500/30"
                  : "bg-green-600/20 hover:bg-green-600/40 text-green-400 border border-green-500/30"
              }`}
            >
              {patchStatus.isPending ? "처리 중..." : user.is_active ? "계정 비활성화" : "계정 활성화"}
            </button>
            <button
              onClick={handleForceLogout}
              disabled={forceLogout.isPending}
              className="px-4 py-2 rounded-lg bg-orange-600/20 hover:bg-orange-600/40 text-orange-400 text-sm border border-orange-500/30 disabled:opacity-60 transition text-left"
            >
              {forceLogout.isPending ? "처리 중..." : "강제 로그아웃"}
            </button>
          </div>
        </div>
      </div>

      {/* 워크스페이스 카드 */}
      <div>
        <h2 className="text-white font-semibold mb-3">
          소유 워크스페이스 ({user.workspace_count})
        </h2>
        {user.workspaces.length === 0 ? (
          <p className="text-slate-500 text-sm">소유 중인 워크스페이스가 없습니다</p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {user.workspaces.map((ws) => (
              <Link
                key={ws.id}
                href={`/admin/workspaces/${ws.id}`}
                className="bg-[#12121a] border border-slate-800 rounded-xl p-4 hover:border-cyan-500/40 transition block"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-white font-medium">{ws.name}</span>
                  <span className={`px-2 py-0.5 rounded text-xs ${ws.is_active
                    ? "bg-green-600/20 text-green-400"
                    : "bg-red-600/20 text-red-400"
                  }`}>
                    {ws.is_active ? "활성" : "비활성"}
                  </span>
                </div>
                <div className="text-xs text-slate-400 space-y-1">
                  <p>플랜: <span className="text-cyan-400">{ws.plan}</span></p>
                  <p>멤버: {ws.member_count}명 · 플레이스: {ws.place_count}개</p>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>

      {/* 최근 주문 테이블 */}
      <div>
        <h2 className="text-white font-semibold mb-3">
          최근 주문 ({user.order_count}건 중 최근 10건)
        </h2>
        {user.recent_orders.length === 0 ? (
          <p className="text-slate-500 text-sm">주문 내역이 없습니다</p>
        ) : (
          <div className="bg-[#12121a] border border-slate-800 rounded-xl overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400">
                  <th className="px-4 py-3 text-left">상품명</th>
                  <th className="px-4 py-3 text-left">워크스페이스</th>
                  <th className="px-4 py-3 text-center">상태</th>
                  <th className="px-4 py-3 text-right">금액</th>
                  <th className="px-4 py-3 text-left">주문일</th>
                </tr>
              </thead>
              <tbody>
                {user.recent_orders.map((order) => (
                  <tr key={order.id} className="border-b border-slate-800/50">
                    <td className="px-4 py-3 text-white">{order.product_name}</td>
                    <td className="px-4 py-3 text-slate-400">{order.workspace_name}</td>
                    <td className="px-4 py-3 text-center">
                      <span className={`px-2 py-1 rounded text-xs ${STATUS_BADGE[order.status] ?? "bg-slate-700 text-slate-300"}`}>
                        {order.status}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right text-white">
                      {order.total_amount.toLocaleString()}원
                    </td>
                    <td className="px-4 py-3 text-slate-400 text-xs">
                      {order.ordered_at
                        ? new Date(order.ordered_at).toLocaleDateString("ko-KR")
                        : new Date(order.created_at).toLocaleDateString("ko-KR")
                      }
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* 역할 변경 다이얼로그 */}
      {showRoleDialog && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60">
          <div className="bg-[#12121a] border border-slate-700 rounded-2xl p-6 w-[400px] space-y-4">
            <h3 className="text-white font-bold text-lg">역할 변경</h3>
            <p className="text-slate-400 text-sm">{user.email}</p>
            <select
              value={roleInput}
              onChange={(e) => setRoleInput(e.target.value)}
              className="w-full bg-slate-800 text-white px-3 py-2 rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-cyan-500"
            >
              <option value="user">일반 (user)</option>
              <option value="admin">어드민 (admin)</option>
              <option value="superadmin">슈퍼어드민 (superadmin)</option>
            </select>
            <textarea
              placeholder="변경 사유 (선택)"
              value={roleReason}
              onChange={(e) => setRoleReason(e.target.value)}
              rows={2}
              className="w-full bg-slate-800 text-white placeholder-slate-500 px-3 py-2 rounded-lg text-sm resize-none focus:outline-none focus:ring-1 focus:ring-cyan-500"
            />
            <div className="flex gap-3 justify-end">
              <button
                onClick={() => setShowRoleDialog(false)}
                className="px-4 py-2 rounded-lg bg-slate-700 hover:bg-slate-600 text-slate-300 text-sm transition"
              >
                취소
              </button>
              <button
                onClick={handleRoleSubmit}
                disabled={patchRole.isPending}
                className="px-4 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-sm font-medium disabled:opacity-60 transition"
              >
                {patchRole.isPending ? "처리 중..." : "변경"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 토스트 */}
      {toast && (
        <div className={`fixed bottom-6 right-6 z-50 px-5 py-3 rounded-xl shadow-lg text-sm font-medium ${
          toast.ok ? "bg-green-600 text-white" : "bg-red-600 text-white"
        }`}>
          {toast.msg}
        </div>
      )}
    </div>
  );
}
