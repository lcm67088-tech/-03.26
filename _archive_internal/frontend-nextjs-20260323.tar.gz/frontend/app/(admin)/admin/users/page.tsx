"use client";

/**
 * 어드민 유저 목록 페이지 (Sprint 9)
 *
 * 기능:
 *   - 이메일/이름 검색
 *   - 역할·활성화 여부 필터
 *   - CSV 내보내기
 *   - 역할 변경 / 상태 변경 / 강제 로그아웃 액션 드롭다운
 *   - 유저 상세 페이지 이동
 */

import { useState, useCallback } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import {
  useAdminUsers,
  usePatchUserRole,
  usePatchUserStatus,
  useForceLogout,
  type AdminUserListItem,
} from "@/hooks/useAdminAdvanced";
import { getApiErrorMessage } from "@/lib/api";

// ── 역할 뱃지 컬러 ─────────────────────────────────────────────
const ROLE_BADGE: Record<string, string> = {
  superadmin: "bg-purple-600/20 text-purple-400 border border-purple-500/30",
  admin: "bg-cyan-600/20 text-cyan-400 border border-cyan-500/30",
  user: "bg-slate-600/20 text-slate-400 border border-slate-500/30",
};

const ROLE_LABEL: Record<string, string> = {
  superadmin: "슈퍼어드민",
  admin: "어드민",
  user: "일반",
};

// ── 다이얼로그 상태 타입 ───────────────────────────────────────
type DialogType = "role" | "status" | "logout" | null;

interface DialogState {
  type: DialogType;
  user: AdminUserListItem | null;
}

export default function AdminUsersPage() {
  const router = useRouter();

  // ── 필터 상태 ────────────────────────────────────────────────
  const [search, setSearch] = useState("");
  const [roleFilter, setRoleFilter] = useState<string>("");
  const [activeFilter, setActiveFilter] = useState<boolean | undefined>(undefined);
  const [page, setPage] = useState(0);
  const limit = 20;

  // ── 다이얼로그 상태 ──────────────────────────────────────────
  const [dialog, setDialog] = useState<DialogState>({ type: null, user: null });
  const [roleInput, setRoleInput] = useState("user");
  const [roleReason, setRoleReason] = useState("");
  const [statusReason, setStatusReason] = useState("");
  const [toast, setToast] = useState<{ msg: string; ok: boolean } | null>(null);

  // ── 쿼리 ────────────────────────────────────────────────────
  const { data, isLoading, isError, refetch } = useAdminUsers(
    search || undefined,
    roleFilter || undefined,
    activeFilter,
    page * limit,
    limit,
  );

  // ── 뮤테이션 훅 (다이얼로그 열릴 때 userId 확정) ──────────────
  const patchRole = usePatchUserRole(dialog.user?.id ?? "");
  const patchStatus = usePatchUserStatus(dialog.user?.id ?? "");
  const forceLogout = useForceLogout(dialog.user?.id ?? "");

  // ── 토스트 헬퍼 ──────────────────────────────────────────────
  const showToast = useCallback((msg: string, ok = true) => {
    setToast({ msg, ok });
    setTimeout(() => setToast(null), 3000);
  }, []);

  // ── 역할 변경 제출 ────────────────────────────────────────────
  const handleRoleSubmit = async () => {
    if (!dialog.user) return;
    try {
      await patchRole.mutateAsync({ role: roleInput, reason: roleReason });
      showToast(`역할이 ${ROLE_LABEL[roleInput] ?? roleInput}으로 변경되었습니다`);
      setDialog({ type: null, user: null });
    } catch (e) {
      showToast(getApiErrorMessage(e), false);
    }
  };

  // ── 상태 변경 제출 ────────────────────────────────────────────
  const handleStatusSubmit = async (activate: boolean) => {
    if (!dialog.user) return;
    try {
      await patchStatus.mutateAsync({ is_active: activate, reason: statusReason });
      showToast(`계정이 ${activate ? "활성화" : "비활성화"}되었습니다`);
      setDialog({ type: null, user: null });
    } catch (e) {
      showToast(getApiErrorMessage(e), false);
    }
  };

  // ── 강제 로그아웃 제출 ────────────────────────────────────────
  const handleForceLogout = async () => {
    if (!dialog.user) return;
    try {
      await forceLogout.mutateAsync();
      showToast("강제 로그아웃 처리되었습니다");
      setDialog({ type: null, user: null });
    } catch (e) {
      showToast(getApiErrorMessage(e), false);
    }
  };

  // ── CSV 내보내기 ──────────────────────────────────────────────
  const handleExportCSV = () => {
    const params = new URLSearchParams();
    if (search) params.append("search", search);
    if (roleFilter) params.append("role", roleFilter);
    if (activeFilter !== undefined) params.append("is_active", String(activeFilter));
    window.open(
      `${process.env.NEXT_PUBLIC_API_URL ?? ""}/api/v1/admin/users/export/csv?${params.toString()}`,
      "_blank"
    );
  };

  const total = data?.total ?? 0;
  const totalPages = Math.ceil(total / limit);

  return (
    <div className="space-y-6">
      {/* 헤더 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">유저 관리</h1>
          <p className="text-slate-400 text-sm mt-1">
            전체 유저 목록을 조회하고 역할·상태를 관리합니다
          </p>
        </div>
        <button
          onClick={handleExportCSV}
          className="flex items-center gap-2 px-4 py-2 rounded-lg bg-slate-700 hover:bg-slate-600 text-white text-sm transition"
        >
          <span>📥</span>
          CSV 내보내기
        </button>
      </div>

      {/* 필터 바 */}
      <div className="flex flex-wrap gap-3 bg-[#12121a] border border-slate-800 rounded-xl p-4">
        {/* 검색 */}
        <input
          type="text"
          placeholder="이메일 / 이름 검색"
          value={search}
          onChange={(e) => { setSearch(e.target.value); setPage(0); }}
          className="flex-1 min-w-[200px] bg-slate-800 text-white placeholder-slate-500 px-3 py-2 rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-cyan-500"
        />
        {/* 역할 필터 */}
        <select
          value={roleFilter}
          onChange={(e) => { setRoleFilter(e.target.value); setPage(0); }}
          className="bg-slate-800 text-white px-3 py-2 rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-cyan-500"
        >
          <option value="">전체 역할</option>
          <option value="user">일반</option>
          <option value="admin">어드민</option>
          <option value="superadmin">슈퍼어드민</option>
        </select>
        {/* 활성화 필터 */}
        <select
          value={activeFilter === undefined ? "" : String(activeFilter)}
          onChange={(e) => {
            setActiveFilter(e.target.value === "" ? undefined : e.target.value === "true");
            setPage(0);
          }}
          className="bg-slate-800 text-white px-3 py-2 rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-cyan-500"
        >
          <option value="">전체 상태</option>
          <option value="true">활성</option>
          <option value="false">비활성</option>
        </select>
        <button
          onClick={() => { setSearch(""); setRoleFilter(""); setActiveFilter(undefined); setPage(0); }}
          className="px-3 py-2 rounded-lg bg-slate-700 hover:bg-slate-600 text-slate-300 text-sm transition"
        >
          초기화
        </button>
      </div>

      {/* 테이블 */}
      <div className="bg-[#12121a] border border-slate-800 rounded-xl overflow-hidden">
        {isLoading ? (
          <div className="flex items-center justify-center h-40 text-slate-400">
            로딩 중...
          </div>
        ) : isError ? (
          <div className="flex items-center justify-center h-40 text-red-400">
            데이터 로딩 실패
          </div>
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400">
                <th className="px-4 py-3 text-left">이메일 / 이름</th>
                <th className="px-4 py-3 text-left">역할</th>
                <th className="px-4 py-3 text-center">상태</th>
                <th className="px-4 py-3 text-center">워크스페이스</th>
                <th className="px-4 py-3 text-center">주문수</th>
                <th className="px-4 py-3 text-left">가입일</th>
                <th className="px-4 py-3 text-center">액션</th>
              </tr>
            </thead>
            <tbody>
              {(data?.items ?? []).length === 0 ? (
                <tr>
                  <td colSpan={7} className="text-center py-12 text-slate-500">
                    검색 결과가 없습니다
                  </td>
                </tr>
              ) : (
                (data?.items ?? []).map((user) => (
                  <tr
                    key={user.id}
                    className="border-b border-slate-800/50 hover:bg-slate-800/30 transition"
                  >
                    <td className="px-4 py-3">
                      <Link
                        href={`/admin/users/${user.id}`}
                        className="font-medium text-white hover:text-cyan-400 transition"
                      >
                        {user.email}
                      </Link>
                      <p className="text-slate-500 text-xs">{user.name}</p>
                    </td>
                    <td className="px-4 py-3">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${ROLE_BADGE[user.role] ?? ""}`}>
                        {ROLE_LABEL[user.role] ?? user.role}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-center">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${user.is_active
                        ? "bg-green-600/20 text-green-400 border border-green-500/30"
                        : "bg-red-600/20 text-red-400 border border-red-500/30"
                      }`}>
                        {user.is_active ? "활성" : "비활성"}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-center text-slate-300">
                      {user.workspace_count}
                    </td>
                    <td className="px-4 py-3 text-center text-slate-300">
                      {user.order_count}
                    </td>
                    <td className="px-4 py-3 text-slate-400 text-xs">
                      {new Date(user.created_at).toLocaleDateString("ko-KR")}
                    </td>
                    <td className="px-4 py-3 text-center">
                      <div className="relative group inline-block">
                        <button className="px-2 py-1 rounded bg-slate-700 hover:bg-slate-600 text-slate-300 text-xs transition">
                          ⋯
                        </button>
                        {/* 드롭다운 */}
                        <div className="absolute right-0 top-8 z-10 hidden group-hover:block w-40 bg-[#1a1a2e] border border-slate-700 rounded-lg shadow-xl overflow-hidden">
                          <button
                            onClick={() => router.push(`/admin/users/${user.id}`)}
                            className="w-full px-3 py-2 text-left text-sm text-slate-300 hover:bg-slate-700 transition"
                          >
                            상세 보기
                          </button>
                          <button
                            onClick={() => {
                              setDialog({ type: "role", user });
                              setRoleInput(user.role);
                              setRoleReason("");
                            }}
                            className="w-full px-3 py-2 text-left text-sm text-slate-300 hover:bg-slate-700 transition"
                          >
                            역할 변경
                          </button>
                          <button
                            onClick={() => {
                              setDialog({ type: "status", user });
                              setStatusReason("");
                            }}
                            className="w-full px-3 py-2 text-left text-sm text-slate-300 hover:bg-slate-700 transition"
                          >
                            {user.is_active ? "비활성화" : "활성화"}
                          </button>
                          <button
                            onClick={() => setDialog({ type: "logout", user })}
                            className="w-full px-3 py-2 text-left text-sm text-red-400 hover:bg-slate-700 transition"
                          >
                            강제 로그아웃
                          </button>
                        </div>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        )}
      </div>

      {/* 페이지네이션 */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between text-sm text-slate-400">
          <span>총 {total.toLocaleString()}명</span>
          <div className="flex gap-2">
            <button
              onClick={() => setPage((p) => Math.max(0, p - 1))}
              disabled={page === 0}
              className="px-3 py-1 rounded bg-slate-700 hover:bg-slate-600 disabled:opacity-40 disabled:cursor-not-allowed transition"
            >
              이전
            </button>
            <span className="px-3 py-1">{page + 1} / {totalPages}</span>
            <button
              onClick={() => setPage((p) => Math.min(totalPages - 1, p + 1))}
              disabled={page >= totalPages - 1}
              className="px-3 py-1 rounded bg-slate-700 hover:bg-slate-600 disabled:opacity-40 disabled:cursor-not-allowed transition"
            >
              다음
            </button>
          </div>
        </div>
      )}

      {/* 역할 변경 다이얼로그 */}
      {dialog.type === "role" && dialog.user && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60">
          <div className="bg-[#12121a] border border-slate-700 rounded-2xl p-6 w-[400px] space-y-4">
            <h3 className="text-white font-bold text-lg">역할 변경</h3>
            <p className="text-slate-400 text-sm">{dialog.user.email}</p>
            <select
              value={roleInput}
              onChange={(e) => setRoleInput(e.target.value)}
              className="w-full bg-slate-800 text-white px-3 py-2 rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-cyan-500"
            >
              <option value="user">일반 (user)</option>
              <option value="admin">어드민 (admin)</option>
              <option value="superadmin">슈퍼어드민 (superadmin)</option>
            </select>
            <textarea
              placeholder="변경 사유 (선택)"
              value={roleReason}
              onChange={(e) => setRoleReason(e.target.value)}
              rows={2}
              className="w-full bg-slate-800 text-white placeholder-slate-500 px-3 py-2 rounded-lg text-sm resize-none focus:outline-none focus:ring-1 focus:ring-cyan-500"
            />
            <div className="flex gap-3 justify-end">
              <button
                onClick={() => setDialog({ type: null, user: null })}
                className="px-4 py-2 rounded-lg bg-slate-700 hover:bg-slate-600 text-slate-300 text-sm transition"
              >
                취소
              </button>
              <button
                onClick={handleRoleSubmit}
                disabled={patchRole.isPending}
                className="px-4 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-sm font-medium disabled:opacity-60 transition"
              >
                {patchRole.isPending ? "처리 중..." : "변경"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 상태 변경 다이얼로그 */}
      {dialog.type === "status" && dialog.user && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60">
          <div className="bg-[#12121a] border border-slate-700 rounded-2xl p-6 w-[400px] space-y-4">
            <h3 className="text-white font-bold text-lg">
              계정 {dialog.user.is_active ? "비활성화" : "활성화"}
            </h3>
            <p className="text-slate-400 text-sm">{dialog.user.email}</p>
            <textarea
              placeholder="변경 사유 (선택)"
              value={statusReason}
              onChange={(e) => setStatusReason(e.target.value)}
              rows={2}
              className="w-full bg-slate-800 text-white placeholder-slate-500 px-3 py-2 rounded-lg text-sm resize-none focus:outline-none focus:ring-1 focus:ring-cyan-500"
            />
            <div className="flex gap-3 justify-end">
              <button
                onClick={() => setDialog({ type: null, user: null })}
                className="px-4 py-2 rounded-lg bg-slate-700 hover:bg-slate-600 text-slate-300 text-sm transition"
              >
                취소
              </button>
              <button
                onClick={() => handleStatusSubmit(!dialog.user!.is_active)}
                disabled={patchStatus.isPending}
                className={`px-4 py-2 rounded-lg text-white text-sm font-medium disabled:opacity-60 transition ${
                  dialog.user.is_active
                    ? "bg-red-600 hover:bg-red-500"
                    : "bg-green-600 hover:bg-green-500"
                }`}
              >
                {patchStatus.isPending ? "처리 중..." : dialog.user.is_active ? "비활성화" : "활성화"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 강제 로그아웃 다이얼로그 */}
      {dialog.type === "logout" && dialog.user && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60">
          <div className="bg-[#12121a] border border-slate-700 rounded-2xl p-6 w-[400px] space-y-4">
            <h3 className="text-white font-bold text-lg">강제 로그아웃</h3>
            <p className="text-slate-400 text-sm">
              <span className="text-white">{dialog.user.email}</span> 유저를 강제 로그아웃하시겠습니까?
              <br />
              <span className="text-yellow-400">다음 API 요청부터 즉시 거부됩니다.</span>
            </p>
            <div className="flex gap-3 justify-end">
              <button
                onClick={() => setDialog({ type: null, user: null })}
                className="px-4 py-2 rounded-lg bg-slate-700 hover:bg-slate-600 text-slate-300 text-sm transition"
              >
                취소
              </button>
              <button
                onClick={handleForceLogout}
                disabled={forceLogout.isPending}
                className="px-4 py-2 rounded-lg bg-red-600 hover:bg-red-500 text-white text-sm font-medium disabled:opacity-60 transition"
              >
                {forceLogout.isPending ? "처리 중..." : "강제 로그아웃"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 토스트 */}
      {toast && (
        <div className={`fixed bottom-6 right-6 z-50 px-5 py-3 rounded-xl shadow-lg text-sm font-medium ${
          toast.ok ? "bg-green-600 text-white" : "bg-red-600 text-white"
        }`}>
          {toast.msg}
        </div>
      )}
    </div>
  );
}
