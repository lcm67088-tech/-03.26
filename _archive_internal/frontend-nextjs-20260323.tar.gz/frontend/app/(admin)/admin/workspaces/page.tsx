"use client";

/**
 * 어드민 워크스페이스 목록 페이지 (Sprint 9)
 *
 * 기능:
 *   - 이름/소유자 검색
 *   - 플랜·활성화 여부 필터
 *   - CSV 내보내기
 *   - 플랜 변경 모달 (ForceChangePlanModal)
 *   - 비활성화 액션
 *   - 상세 페이지 이동
 */

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import {
  useAdminWorkspaces,
  useDeactivateWorkspace,
  type AdminWorkspaceListItem,
} from "@/hooks/useAdminAdvanced";
import ForceChangePlanModal from "@/components/admin/ForceChangePlanModal";
import { getApiErrorMessage } from "@/lib/api";

// ── 플랜 뱃지 ────────────────────────────────────────────────
const PLAN_BADGE: Record<string, string> = {
  free: "bg-slate-600/20 text-slate-400 border border-slate-500/30",
  starter: "bg-blue-600/20 text-blue-400 border border-blue-500/30",
  pro: "bg-cyan-600/20 text-cyan-400 border border-cyan-500/30",
  enterprise: "bg-purple-600/20 text-purple-400 border border-purple-500/30",
};

export default function AdminWorkspacesPage() {
  const router = useRouter();

  // ── 필터 상태 ────────────────────────────────────────────────
  const [search, setSearch] = useState("");
  const [planFilter, setPlanFilter] = useState("");
  const [activeFilter, setActiveFilter] = useState<boolean | undefined>(undefined);
  const [page, setPage] = useState(0);
  const limit = 20;

  // ── 플랜 변경 모달 ────────────────────────────────────────────
  const [planModal, setPlanModal] = useState<AdminWorkspaceListItem | null>(null);

  // ── 비활성화 확인 다이얼로그 ──────────────────────────────────
  const [deactivateTarget, setDeactivateTarget] = useState<AdminWorkspaceListItem | null>(null);
  const [deactivateReason, setDeactivateReason] = useState("");
  const deactivate = useDeactivateWorkspace(deactivateTarget?.id ?? "");

  const [toast, setToast] = useState<{ msg: string; ok: boolean } | null>(null);
  const showToast = (msg: string, ok = true) => {
    setToast({ msg, ok });
    setTimeout(() => setToast(null), 3000);
  };

  // ── 쿼리 ────────────────────────────────────────────────────
  const { data, isLoading, isError } = useAdminWorkspaces(
    search || undefined,
    planFilter || undefined,
    activeFilter,
    page * limit,
    limit,
  );

  // ── 비활성화 제출 ──────────────────────────────────────────────
  const handleDeactivate = async () => {
    if (!deactivateTarget) return;
    try {
      await deactivate.mutateAsync({ reason: deactivateReason });
      showToast(`${deactivateTarget.name} 워크스페이스가 비활성화되었습니다`);
      setDeactivateTarget(null);
    } catch (e) {
      showToast(getApiErrorMessage(e), false);
    }
  };

  // ── CSV 내보내기 ──────────────────────────────────────────────
  const handleExportCSV = () => {
    const params = new URLSearchParams();
    if (search) params.append("search", search);
    if (planFilter) params.append("plan", planFilter);
    if (activeFilter !== undefined) params.append("is_active", String(activeFilter));
    window.open(
      `${process.env.NEXT_PUBLIC_API_URL ?? ""}/api/v1/admin/workspaces/export/csv?${params.toString()}`,
      "_blank"
    );
  };

  const total = data?.total ?? 0;
  const totalPages = Math.ceil(total / limit);

  return (
    <div className="space-y-6">
      {/* 헤더 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">워크스페이스 관리</h1>
          <p className="text-slate-400 text-sm mt-1">
            전체 워크스페이스를 조회하고 플랜·상태를 관리합니다
          </p>
        </div>
        <button
          onClick={handleExportCSV}
          className="flex items-center gap-2 px-4 py-2 rounded-lg bg-slate-700 hover:bg-slate-600 text-white text-sm transition"
        >
          <span>📥</span>
          CSV 내보내기
        </button>
      </div>

      {/* 필터 바 */}
      <div className="flex flex-wrap gap-3 bg-[#12121a] border border-slate-800 rounded-xl p-4">
        <input
          type="text"
          placeholder="워크스페이스명 / 소유자 검색"
          value={search}
          onChange={(e) => { setSearch(e.target.value); setPage(0); }}
          className="flex-1 min-w-[200px] bg-slate-800 text-white placeholder-slate-500 px-3 py-2 rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-cyan-500"
        />
        <select
          value={planFilter}
          onChange={(e) => { setPlanFilter(e.target.value); setPage(0); }}
          className="bg-slate-800 text-white px-3 py-2 rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-cyan-500"
        >
          <option value="">전체 플랜</option>
          <option value="free">Free</option>
          <option value="starter">Starter</option>
          <option value="pro">Pro</option>
          <option value="enterprise">Enterprise</option>
        </select>
        <select
          value={activeFilter === undefined ? "" : String(activeFilter)}
          onChange={(e) => {
            setActiveFilter(e.target.value === "" ? undefined : e.target.value === "true");
            setPage(0);
          }}
          className="bg-slate-800 text-white px-3 py-2 rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-cyan-500"
        >
          <option value="">전체 상태</option>
          <option value="true">활성</option>
          <option value="false">비활성</option>
        </select>
        <button
          onClick={() => { setSearch(""); setPlanFilter(""); setActiveFilter(undefined); setPage(0); }}
          className="px-3 py-2 rounded-lg bg-slate-700 hover:bg-slate-600 text-slate-300 text-sm transition"
        >
          초기화
        </button>
      </div>

      {/* 테이블 */}
      <div className="bg-[#12121a] border border-slate-800 rounded-xl overflow-hidden">
        {isLoading ? (
          <div className="flex items-center justify-center h-40 text-slate-400">로딩 중...</div>
        ) : isError ? (
          <div className="flex items-center justify-center h-40 text-red-400">데이터 로딩 실패</div>
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400">
                <th className="px-4 py-3 text-left">워크스페이스</th>
                <th className="px-4 py-3 text-left">소유자</th>
                <th className="px-4 py-3 text-center">플랜</th>
                <th className="px-4 py-3 text-center">상태</th>
                <th className="px-4 py-3 text-center">멤버</th>
                <th className="px-4 py-3 text-center">플레이스</th>
                <th className="px-4 py-3 text-right">이번달 청구</th>
                <th className="px-4 py-3 text-center">액션</th>
              </tr>
            </thead>
            <tbody>
              {(data?.items ?? []).length === 0 ? (
                <tr>
                  <td colSpan={8} className="text-center py-12 text-slate-500">
                    검색 결과가 없습니다
                  </td>
                </tr>
              ) : (
                (data?.items ?? []).map((ws) => (
                  <tr
                    key={ws.id}
                    className="border-b border-slate-800/50 hover:bg-slate-800/30 transition"
                  >
                    <td className="px-4 py-3">
                      <Link
                        href={`/admin/workspaces/${ws.id}`}
                        className="font-medium text-white hover:text-cyan-400 transition"
                      >
                        {ws.name}
                      </Link>
                    </td>
                    <td className="px-4 py-3">
                      <p className="text-slate-300">{ws.owner_email}</p>
                      <p className="text-slate-500 text-xs">{ws.owner_name}</p>
                    </td>
                    <td className="px-4 py-3 text-center">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${PLAN_BADGE[ws.plan] ?? ""}`}>
                        {ws.plan}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-center">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${ws.is_active
                        ? "bg-green-600/20 text-green-400 border border-green-500/30"
                        : "bg-red-600/20 text-red-400 border border-red-500/30"
                      }`}>
                        {ws.is_active ? "활성" : "비활성"}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-center text-slate-300">{ws.member_count}</td>
                    <td className="px-4 py-3 text-center text-slate-300">{ws.place_count}</td>
                    <td className="px-4 py-3 text-right text-slate-300">
                      {ws.monthly_spend > 0
                        ? `${ws.monthly_spend.toLocaleString()}원`
                        : "-"}
                    </td>
                    <td className="px-4 py-3 text-center">
                      <div className="relative group inline-block">
                        <button className="px-2 py-1 rounded bg-slate-700 hover:bg-slate-600 text-slate-300 text-xs transition">
                          ⋯
                        </button>
                        <div className="absolute right-0 top-8 z-10 hidden group-hover:block w-44 bg-[#1a1a2e] border border-slate-700 rounded-lg shadow-xl overflow-hidden">
                          <button
                            onClick={() => router.push(`/admin/workspaces/${ws.id}`)}
                            className="w-full px-3 py-2 text-left text-sm text-slate-300 hover:bg-slate-700 transition"
                          >
                            상세 보기
                          </button>
                          <button
                            onClick={() => setPlanModal(ws)}
                            className="w-full px-3 py-2 text-left text-sm text-slate-300 hover:bg-slate-700 transition"
                          >
                            플랜 변경
                          </button>
                          {ws.is_active && (
                            <button
                              onClick={() => { setDeactivateTarget(ws); setDeactivateReason(""); }}
                              className="w-full px-3 py-2 text-left text-sm text-red-400 hover:bg-slate-700 transition"
                            >
                              비활성화
                            </button>
                          )}
                        </div>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        )}
      </div>

      {/* 페이지네이션 */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between text-sm text-slate-400">
          <span>총 {total.toLocaleString()}개</span>
          <div className="flex gap-2">
            <button
              onClick={() => setPage((p) => Math.max(0, p - 1))}
              disabled={page === 0}
              className="px-3 py-1 rounded bg-slate-700 hover:bg-slate-600 disabled:opacity-40 disabled:cursor-not-allowed transition"
            >
              이전
            </button>
            <span className="px-3 py-1">{page + 1} / {totalPages}</span>
            <button
              onClick={() => setPage((p) => Math.min(totalPages - 1, p + 1))}
              disabled={page >= totalPages - 1}
              className="px-3 py-1 rounded bg-slate-700 hover:bg-slate-600 disabled:opacity-40 disabled:cursor-not-allowed transition"
            >
              다음
            </button>
          </div>
        </div>
      )}

      {/* 플랜 변경 모달 */}
      {planModal && (
        <ForceChangePlanModal
          workspaceId={planModal.id}
          workspaceName={planModal.name}
          currentPlan={planModal.plan}
          onClose={() => setPlanModal(null)}
          onSuccess={(newPlan) => {
            showToast(`플랜이 ${newPlan}으로 변경되었습니다`);
            setPlanModal(null);
          }}
        />
      )}

      {/* 비활성화 다이얼로그 */}
      {deactivateTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60">
          <div className="bg-[#12121a] border border-slate-700 rounded-2xl p-6 w-[400px] space-y-4">
            <h3 className="text-white font-bold text-lg">워크스페이스 비활성화</h3>
            <p className="text-slate-400 text-sm">
              <span className="text-white">{deactivateTarget.name}</span>을 비활성화하시겠습니까?
              <br />
              <span className="text-yellow-400">진행 중인 주문이 있으면 취소됩니다.</span>
            </p>
            <textarea
              placeholder="비활성화 사유 (필수)"
              value={deactivateReason}
              onChange={(e) => setDeactivateReason(e.target.value)}
              rows={3}
              className="w-full bg-slate-800 text-white placeholder-slate-500 px-3 py-2 rounded-lg text-sm resize-none focus:outline-none focus:ring-1 focus:ring-red-500"
            />
            <div className="flex gap-3 justify-end">
              <button
                onClick={() => setDeactivateTarget(null)}
                className="px-4 py-2 rounded-lg bg-slate-700 hover:bg-slate-600 text-slate-300 text-sm transition"
              >
                취소
              </button>
              <button
                onClick={handleDeactivate}
                disabled={!deactivateReason.trim() || deactivate.isPending}
                className="px-4 py-2 rounded-lg bg-red-600 hover:bg-red-500 text-white text-sm font-medium disabled:opacity-60 transition"
              >
                {deactivate.isPending ? "처리 중..." : "비활성화"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 토스트 */}
      {toast && (
        <div className={`fixed bottom-6 right-6 z-50 px-5 py-3 rounded-xl shadow-lg text-sm font-medium ${
          toast.ok ? "bg-green-600 text-white" : "bg-red-600 text-white"
        }`}>
          {toast.msg}
        </div>
      )}
    </div>
  );
}
