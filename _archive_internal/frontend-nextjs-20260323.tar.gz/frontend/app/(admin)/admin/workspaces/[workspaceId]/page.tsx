"use client";

/**
 * 어드민 워크스페이스 상세 페이지 (Sprint 9)
 *
 * 탭 구성:
 *   - 멤버 탭 (멤버 목록)
 *   - 플레이스 탭 (등록된 플레이스 목록)
 *   - 빌링 탭 (최근 청구 내역)
 */

import { useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import {
  useAdminWorkspace,
  useDeactivateWorkspace,
} from "@/hooks/useAdminAdvanced";
import ForceChangePlanModal from "@/components/admin/ForceChangePlanModal";
import { getApiErrorMessage } from "@/lib/api";

type TabType = "members" | "places" | "billing";

// ── 플랜 뱃지 ────────────────────────────────────────────────
const PLAN_BADGE: Record<string, string> = {
  free: "bg-slate-600/20 text-slate-400 border border-slate-500/30",
  starter: "bg-blue-600/20 text-blue-400 border border-blue-500/30",
  pro: "bg-cyan-600/20 text-cyan-400 border border-cyan-500/30",
  enterprise: "bg-purple-600/20 text-purple-400 border border-purple-500/30",
};

export default function AdminWorkspaceDetailPage() {
  const { workspaceId } = useParams<{ workspaceId: string }>();
  const router = useRouter();

  const { data: ws, isLoading, isError } = useAdminWorkspace(workspaceId);
  const deactivate = useDeactivateWorkspace(workspaceId);

  const [activeTab, setActiveTab] = useState<TabType>("members");
  const [showPlanModal, setShowPlanModal] = useState(false);
  const [showDeactivateDialog, setShowDeactivateDialog] = useState(false);
  const [deactivateReason, setDeactivateReason] = useState("");
  const [toast, setToast] = useState<{ msg: string; ok: boolean } | null>(null);

  const showToast = (msg: string, ok = true) => {
    setToast({ msg, ok });
    setTimeout(() => setToast(null), 3000);
  };

  const handleDeactivate = async () => {
    try {
      await deactivate.mutateAsync({ reason: deactivateReason });
      showToast("워크스페이스가 비활성화되었습니다");
      setShowDeactivateDialog(false);
    } catch (e) {
      showToast(getApiErrorMessage(e), false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-60 text-slate-400">로딩 중...</div>
    );
  }
  if (isError || !ws) {
    return (
      <div className="flex flex-col items-center justify-center h-60 gap-4 text-slate-400">
        <p>워크스페이스를 찾을 수 없습니다</p>
        <button onClick={() => router.back()} className="px-4 py-2 rounded-lg bg-slate-700 hover:bg-slate-600 text-sm transition">
          뒤로 가기
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* 헤더 */}
      <div className="flex items-center gap-4">
        <button onClick={() => router.back()} className="text-slate-400 hover:text-white transition text-sm">
          ← 목록
        </button>
        <h1 className="text-xl font-bold text-white">{ws.name}</h1>
        <span className={`px-2 py-1 rounded-full text-xs font-medium ${PLAN_BADGE[ws.plan] ?? ""}`}>
          {ws.plan}
        </span>
        <span className={`px-2 py-1 rounded-full text-xs font-medium ${ws.is_active
          ? "bg-green-600/20 text-green-400 border border-green-500/30"
          : "bg-red-600/20 text-red-400 border border-red-500/30"
        }`}>
          {ws.is_active ? "활성" : "비활성"}
        </span>
      </div>

      {/* 기본 정보 + KPI + 액션 */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* 기본 정보 */}
        <div className="md:col-span-2 bg-[#12121a] border border-slate-800 rounded-xl p-5 space-y-3">
          <h2 className="text-white font-semibold">기본 정보</h2>
          <div className="grid grid-cols-2 gap-2 text-sm">
            <span className="text-slate-400">ID</span>
            <span className="text-slate-300 font-mono text-xs">{ws.id}</span>
            <span className="text-slate-400">소유자</span>
            <div>
              <p className="text-white">{ws.owner_email}</p>
              <p className="text-slate-500 text-xs">{ws.owner_name}</p>
            </div>
            <span className="text-slate-400">생성일</span>
            <span className="text-slate-300">{new Date(ws.created_at).toLocaleDateString("ko-KR")}</span>
            <span className="text-slate-400">이번달 청구</span>
            <span className="text-white font-medium">
              {ws.monthly_spend > 0 ? `${ws.monthly_spend.toLocaleString()}원` : "-"}
            </span>
          </div>
        </div>

        {/* KPI 카드 */}
        <div className="bg-[#12121a] border border-slate-800 rounded-xl p-5 space-y-3">
          <h2 className="text-white font-semibold">현황</h2>
          <div className="grid grid-cols-2 gap-3">
            {[
              { label: "멤버", value: ws.member_count, color: "text-cyan-400" },
              { label: "플레이스", value: ws.place_count, color: "text-purple-400" },
              { label: "주문", value: ws.order_count, color: "text-green-400" },
              { label: "이번달 청구", value: ws.monthly_spend > 0 ? `${ws.monthly_spend.toLocaleString()}` : "0", color: "text-yellow-400" },
            ].map((kpi) => (
              <div key={kpi.label} className="bg-slate-800/50 rounded-lg p-3 text-center">
                <p className={`text-lg font-bold ${kpi.color}`}>{kpi.value}</p>
                <p className="text-slate-500 text-xs">{kpi.label}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* 액션 버튼 */}
      <div className="flex gap-3 flex-wrap">
        <button
          onClick={() => setShowPlanModal(true)}
          className="px-4 py-2 rounded-lg bg-cyan-600/20 hover:bg-cyan-600/40 text-cyan-400 border border-cyan-500/30 text-sm transition"
        >
          플랜 변경
        </button>
        {ws.is_active && (
          <button
            onClick={() => { setShowDeactivateDialog(true); setDeactivateReason(""); }}
            className="px-4 py-2 rounded-lg bg-red-600/20 hover:bg-red-600/40 text-red-400 border border-red-500/30 text-sm transition"
          >
            비활성화
          </button>
        )}
        <Link
          href={`/admin/users/${ws.owner_id}`}
          className="px-4 py-2 rounded-lg bg-slate-700 hover:bg-slate-600 text-slate-300 text-sm transition"
        >
          소유자 상세 →
        </Link>
      </div>

      {/* 탭 */}
      <div className="bg-[#12121a] border border-slate-800 rounded-xl overflow-hidden">
        {/* 탭 헤더 */}
        <div className="flex border-b border-slate-800">
          {(["members", "places", "billing"] as TabType[]).map((tab) => {
            const labels: Record<TabType, string> = {
              members: `멤버 (${ws.member_count})`,
              places: `플레이스 (${ws.place_count})`,
              billing: "청구 내역",
            };
            return (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-5 py-3 text-sm transition ${activeTab === tab
                  ? "text-cyan-400 border-b-2 border-cyan-400"
                  : "text-slate-400 hover:text-white"
                }`}
              >
                {labels[tab]}
              </button>
            );
          })}
        </div>

        {/* 멤버 탭 */}
        {activeTab === "members" && (
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400">
                <th className="px-4 py-3 text-left">이메일</th>
                <th className="px-4 py-3 text-left">이름</th>
                <th className="px-4 py-3 text-center">역할</th>
                <th className="px-4 py-3 text-left">가입일</th>
              </tr>
            </thead>
            <tbody>
              {ws.members.length === 0 ? (
                <tr>
                  <td colSpan={4} className="text-center py-10 text-slate-500">
                    멤버가 없습니다
                  </td>
                </tr>
              ) : ws.members.map((m) => (
                <tr key={m.id} className="border-b border-slate-800/50">
                  <td className="px-4 py-3">
                    <Link href={`/admin/users/${m.user_id}`} className="text-white hover:text-cyan-400 transition">
                      {m.user_email}
                    </Link>
                  </td>
                  <td className="px-4 py-3 text-slate-400">{m.user_name}</td>
                  <td className="px-4 py-3 text-center">
                    <span className="px-2 py-1 rounded text-xs bg-slate-700 text-slate-300">{m.role}</span>
                  </td>
                  <td className="px-4 py-3 text-slate-400 text-xs">
                    {new Date(m.joined_at).toLocaleDateString("ko-KR")}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}

        {/* 플레이스 탭 */}
        {activeTab === "places" && (
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400">
                <th className="px-4 py-3 text-left">플레이스명</th>
                <th className="px-4 py-3 text-left">카테고리</th>
                <th className="px-4 py-3 text-center">키워드</th>
                <th className="px-4 py-3 text-center">상태</th>
                <th className="px-4 py-3 text-left">등록일</th>
              </tr>
            </thead>
            <tbody>
              {ws.places.length === 0 ? (
                <tr>
                  <td colSpan={5} className="text-center py-10 text-slate-500">
                    등록된 플레이스가 없습니다
                  </td>
                </tr>
              ) : ws.places.map((pl) => (
                <tr key={pl.id} className="border-b border-slate-800/50">
                  <td className="px-4 py-3">
                    <p className="text-white">{pl.name}</p>
                    <p className="text-slate-500 text-xs">{pl.alias ?? pl.naver_place_id}</p>
                  </td>
                  <td className="px-4 py-3 text-slate-400">{pl.category ?? "-"}</td>
                  <td className="px-4 py-3 text-center text-slate-300">{pl.keyword_count}</td>
                  <td className="px-4 py-3 text-center">
                    <span className={`px-2 py-1 rounded text-xs ${pl.is_active
                      ? "bg-green-600/20 text-green-400"
                      : "bg-red-600/20 text-red-400"
                    }`}>
                      {pl.is_active ? "활성" : "비활성"}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-slate-400 text-xs">
                    {new Date(pl.created_at).toLocaleDateString("ko-KR")}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}

        {/* 빌링 탭 */}
        {activeTab === "billing" && (
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400">
                <th className="px-4 py-3 text-left">타입</th>
                <th className="px-4 py-3 text-left">플랜</th>
                <th className="px-4 py-3 text-right">금액</th>
                <th className="px-4 py-3 text-center">상태</th>
                <th className="px-4 py-3 text-left">설명</th>
                <th className="px-4 py-3 text-left">생성일</th>
              </tr>
            </thead>
            <tbody>
              {ws.recent_billing.length === 0 ? (
                <tr>
                  <td colSpan={6} className="text-center py-10 text-slate-500">
                    청구 내역이 없습니다
                  </td>
                </tr>
              ) : ws.recent_billing.map((b) => (
                <tr key={b.id} className="border-b border-slate-800/50">
                  <td className="px-4 py-3 text-slate-300">{b.type}</td>
                  <td className="px-4 py-3 text-slate-300">{b.plan}</td>
                  <td className="px-4 py-3 text-right text-white">{b.amount.toLocaleString()}원</td>
                  <td className="px-4 py-3 text-center">
                    <span className={`px-2 py-1 rounded text-xs ${
                      b.status === "paid" ? "bg-green-600/20 text-green-400" : "bg-red-600/20 text-red-400"
                    }`}>
                      {b.status}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-slate-500 text-xs max-w-xs truncate">{b.description ?? "-"}</td>
                  <td className="px-4 py-3 text-slate-400 text-xs">
                    {new Date(b.created_at).toLocaleDateString("ko-KR")}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* 플랜 변경 모달 */}
      {showPlanModal && (
        <ForceChangePlanModal
          workspaceId={workspaceId}
          workspaceName={ws.name}
          currentPlan={ws.plan}
          onClose={() => setShowPlanModal(false)}
          onSuccess={(newPlan) => {
            showToast(`플랜이 ${newPlan}으로 변경되었습니다`);
            setShowPlanModal(false);
          }}
        />
      )}

      {/* 비활성화 다이얼로그 */}
      {showDeactivateDialog && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60">
          <div className="bg-[#12121a] border border-slate-700 rounded-2xl p-6 w-[400px] space-y-4">
            <h3 className="text-white font-bold text-lg">워크스페이스 비활성화</h3>
            <p className="text-slate-400 text-sm">
              <span className="text-white">{ws.name}</span>을 비활성화하시겠습니까?
            </p>
            <textarea
              placeholder="비활성화 사유 (필수)"
              value={deactivateReason}
              onChange={(e) => setDeactivateReason(e.target.value)}
              rows={3}
              className="w-full bg-slate-800 text-white placeholder-slate-500 px-3 py-2 rounded-lg text-sm resize-none focus:outline-none focus:ring-1 focus:ring-red-500"
            />
            <div className="flex gap-3 justify-end">
              <button
                onClick={() => setShowDeactivateDialog(false)}
                className="px-4 py-2 rounded-lg bg-slate-700 hover:bg-slate-600 text-slate-300 text-sm transition"
              >
                취소
              </button>
              <button
                onClick={handleDeactivate}
                disabled={!deactivateReason.trim() || deactivate.isPending}
                className="px-4 py-2 rounded-lg bg-red-600 hover:bg-red-500 text-white text-sm font-medium disabled:opacity-60 transition"
              >
                {deactivate.isPending ? "처리 중..." : "비활성화"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 토스트 */}
      {toast && (
        <div className={`fixed bottom-6 right-6 z-50 px-5 py-3 rounded-xl shadow-lg text-sm font-medium ${
          toast.ok ? "bg-green-600 text-white" : "bg-red-600 text-white"
        }`}>
          {toast.msg}
        </div>
      )}
    </div>
  );
}
