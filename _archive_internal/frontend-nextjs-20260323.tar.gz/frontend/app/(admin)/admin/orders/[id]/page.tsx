"use client";

/**
 * 어드민 주문 상세 페이지 (Sprint 6)
 *
 * - 2열 레이아웃: 좌측 주문 정보 / 우측 어드민 액션 패널
 * - 좌측: 기본 정보, 상품·결제·장소, 워크스페이스, admin_notes 타임라인
 * - 우측: 미디어사 배정, 상태 변경, 완료 처리(증빙 URL), 환불 처리 (상태별 노출)
 * - 완료 상태 뱃지 (completed badge)
 * - 분쟁 패널 (disputed panel)
 * - 각 액션 성공 시 toast + 쿼리 무효화
 */
import { useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import { format } from "date-fns";
import { ko } from "date-fns/locale";
import {
  ArrowLeft,
  ExternalLink,
  ClipboardCheck,
  AlertTriangle,
  ChevronDown,
} from "lucide-react";
import { toast } from "sonner";
import { useAdminOrder, useUpdateOrderStatus, useMediaCompanies } from "@/hooks/useAdmin";
import { StatusBadge } from "@/components/common/StatusBadge";
import AssignModal from "@/components/admin/AssignModal";
import CompleteOrderModal from "@/components/admin/CompleteOrderModal";
import RefundDecisionModal from "@/components/admin/RefundDecisionModal";
import { getApiErrorMessage } from "@/lib/api";

// ============================
// 상태 변경 드롭다운 옵션
// ============================
const STATUS_OPTIONS: Record<string, { value: string; label: string }[]> = {
  confirmed: [
    { value: "in_progress", label: "진행중으로 전환" },
    { value: "cancelled",   label: "취소 처리" },
    { value: "disputed",    label: "분쟁 등록" },
  ],
  in_progress: [
    { value: "completed", label: "완료 처리" },
    { value: "cancelled", label: "취소 처리" },
    { value: "disputed",  label: "분쟁 등록" },
  ],
  completed: [
    { value: "disputed", label: "분쟁 등록" },
  ],
};

// ============================
// 정보 행 컴포넌트
// ============================
function InfoRow({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex justify-between py-2.5 border-b border-slate-800 last:border-0">
      <span className="text-sm text-slate-400 flex-shrink-0 mr-4">{label}</span>
      <div className="text-sm text-slate-200 text-right">{children}</div>
    </div>
  );
}

// ============================
// 어드민 노트 타임라인 아이템
// ============================
function NoteItem({
  note,
}: {
  note: { timestamp: string; note: string; admin_id: string };
}) {
  return (
    <div className="relative pl-5">
      {/* 타임라인 점 */}
      <div className="absolute left-0 top-1.5 w-2 h-2 rounded-full bg-slate-600" />
      {/* 라인 (다음 항목 연결) */}
      <div className="absolute left-[3px] top-3.5 bottom-0 w-px bg-slate-700" />

      <p className="text-xs text-slate-500">
        {format(new Date(note.timestamp), "yyyy/MM/dd HH:mm:ss", { locale: ko })}
        <span className="ml-2 text-slate-600">admin·{note.admin_id.slice(0, 6)}</span>
      </p>
      <p className="text-sm text-slate-300 mt-0.5">{note.note}</p>
    </div>
  );
}

// ============================
// 메인 컴포넌트
// ============================
export default function AdminOrderDetailPage() {
  const { id } = useParams<{ id: string }>();
  const router  = useRouter();

  const { data: order, isLoading, isError, refetch } = useAdminOrder(id);
  const statusMutation = useUpdateOrderStatus(id);

  // 모달 상태
  const [assignOpen,   setAssignOpen]   = useState(false);
  const [completeOpen, setCompleteOpen] = useState(false);
  const [refundOpen,   setRefundOpen]   = useState(false);
  const [statusNote,   setStatusNote]   = useState("");

  // 상태 변경 핸들러
  const handleStatusChange = async (newStatus: string) => {
    try {
      await statusMutation.mutateAsync({ status: newStatus, note: statusNote || undefined });
      toast.success(`상태가 "${newStatus}"으로 변경되었습니다`);
      setStatusNote("");
    } catch (err) {
      toast.error(getApiErrorMessage(err));
    }
  };

  // ── 로딩
  if (isLoading) {
    return (
      <div className="space-y-4 animate-pulse">
        <div className="h-8 w-48 bg-slate-800 rounded-lg" />
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 card h-64" />
          <div className="card h-64" />
        </div>
      </div>
    );
  }

  // ── 에러
  if (isError || !order) {
    return (
      <div className="card p-8 text-center">
        <AlertTriangle className="mx-auto mb-3 text-red-400" size={32} />
        <p className="text-slate-300">주문 정보를 불러올 수 없습니다</p>
        <Link href="/admin/orders" className="mt-4 inline-block text-sm text-cyan-400 hover:text-cyan-300">
          ← 목록으로
        </Link>
      </div>
    );
  }

  const statusOptions = STATUS_OPTIONS[order.status] ?? [];
  const canAssign    = ["confirmed", "in_progress"].includes(order.status);
  const canComplete  = ["confirmed", "in_progress"].includes(order.status);
  const canRefund    = order.status === "disputed";
  const isCompleted  = order.status === "completed";
  const isDisputed   = order.status === "disputed";

  return (
    <div className="space-y-5">
      {/* ── 헤더 ── */}
      <div className="flex items-center gap-3">
        <Link
          href="/admin/orders"
          className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-700 transition-colors"
        >
          <ArrowLeft size={18} />
        </Link>
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-slate-100">
              주문 #{order.id.slice(0, 8).toUpperCase()}
            </h1>
            <StatusBadge status={order.status} type="order" />
            {isCompleted && (
              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-500/15 text-emerald-400 border border-emerald-500/20">
                <ClipboardCheck size={12} />
                완료됨
              </span>
            )}
          </div>
          <p className="text-slate-500 text-xs mt-0.5">
            생성: {format(new Date(order.created_at), "yyyy/MM/dd HH:mm", { locale: ko })}
          </p>
        </div>
      </div>

      {/* ── 2열 레이아웃 ── */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

        {/* ─── 좌측: 주문 정보 ─── */}
        <div className="lg:col-span-2 space-y-4">

          {/* 기본 정보 */}
          <div className="card p-5">
            <h2 className="text-sm font-semibold text-slate-200 mb-3">주문 정보</h2>
            <InfoRow label="상품명">{order.product_name}</InfoRow>
            {order.description && (
              <InfoRow label="설명">
                <span className="text-slate-400 text-xs">{order.description}</span>
              </InfoRow>
            )}
            <InfoRow label="수량">{order.quantity}개</InfoRow>
            <InfoRow label="단가">₩{order.unit_price.toLocaleString()}</InfoRow>
            <InfoRow label="총 금액">
              <span className="font-semibold text-slate-100">
                ₩{order.total_amount.toLocaleString()}
              </span>
            </InfoRow>
            {order.special_requests && (
              <InfoRow label="특이사항">
                <span className="text-amber-300 text-xs">{order.special_requests}</span>
              </InfoRow>
            )}
          </div>

          {/* 장소 · 키워드 */}
          {(order.place || order.keywords.length > 0) && (
            <div className="card p-5">
              <h2 className="text-sm font-semibold text-slate-200 mb-3">장소 · 키워드</h2>
              {order.place && (
                <InfoRow label="장소">
                  <span>{order.place.alias || order.place.name}</span>
                </InfoRow>
              )}
              {order.keywords.length > 0 && (
                <InfoRow label="키워드">
                  <div className="flex flex-wrap gap-1.5 justify-end">
                    {order.keywords.map((kw) => (
                      <span
                        key={kw.id}
                        className="px-2 py-0.5 rounded bg-slate-700 text-slate-300 text-xs"
                      >
                        {kw.keyword}
                      </span>
                    ))}
                  </div>
                </InfoRow>
              )}
            </div>
          )}

          {/* 워크스페이스 · 결제 */}
          <div className="card p-5">
            <h2 className="text-sm font-semibold text-slate-200 mb-3">워크스페이스 · 결제</h2>
            {order.workspace && (
              <>
                <InfoRow label="워크스페이스">{order.workspace.name}</InfoRow>
                <InfoRow label="플랜">
                  <StatusBadge status={order.workspace.plan} type="plan" />
                </InfoRow>
              </>
            )}
            {order.payment && (
              <>
                <InfoRow label="결제 상태">
                  <StatusBadge status={order.payment.status} type="payment" />
                </InfoRow>
                <InfoRow label="결제 방법">
                  {order.payment.method ?? "-"}
                </InfoRow>
                {order.payment.pg_transaction_id && (
                  <InfoRow label="PG 거래 ID">
                    <span className="font-mono text-xs text-slate-400">
                      {order.payment.pg_transaction_id}
                    </span>
                  </InfoRow>
                )}
                {order.payment.paid_at && (
                  <InfoRow label="결제 일시">
                    {format(new Date(order.payment.paid_at), "yyyy/MM/dd HH:mm")}
                  </InfoRow>
                )}
              </>
            )}
          </div>

          {/* 증빙 URL (완료된 경우) */}
          {isCompleted && order.proof_url && (
            <div className="card p-5 bg-emerald-500/5 border border-emerald-500/20">
              <h2 className="text-sm font-semibold text-emerald-400 mb-2 flex items-center gap-1.5">
                <ClipboardCheck size={14} />
                완료 증빙
              </h2>
              <a
                href={order.proof_url}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1.5 text-sm text-cyan-400 hover:text-cyan-300 transition-colors break-all"
              >
                <ExternalLink size={13} />
                {order.proof_url}
              </a>
              {order.completed_at && (
                <p className="text-xs text-slate-500 mt-1">
                  완료일: {format(new Date(order.completed_at), "yyyy/MM/dd HH:mm")}
                </p>
              )}
            </div>
          )}

          {/* 어드민 노트 타임라인 */}
          {order.admin_notes.length > 0 && (
            <div className="card p-5">
              <h2 className="text-sm font-semibold text-slate-200 mb-4">어드민 노트</h2>
              <div className="space-y-4">
                {order.admin_notes
                  .slice()
                  .reverse()
                  .map((note, i) => (
                    <NoteItem key={i} note={note} />
                  ))}
              </div>
            </div>
          )}
        </div>

        {/* ─── 우측: 어드민 액션 패널 ─── */}
        <div className="space-y-4">

          {/* 미디어사 현황 */}
          <div className="card p-5">
            <h2 className="text-sm font-semibold text-slate-200 mb-3">미디어사</h2>
            {order.media_company ? (
              <div className="flex items-center justify-between">
                <span className="text-cyan-400 font-medium">
                  {order.media_company.name}
                </span>
                {canAssign && (
                  <button
                    onClick={() => setAssignOpen(true)}
                    className="text-xs text-slate-400 hover:text-slate-200 transition-colors"
                  >
                    변경
                  </button>
                )}
              </div>
            ) : (
              <div className="text-center py-3">
                <p className="text-slate-500 text-sm mb-3">배정된 미디어사가 없습니다</p>
                {canAssign && (
                  <button
                    onClick={() => setAssignOpen(true)}
                    className="w-full px-4 py-2 rounded-lg text-sm font-medium bg-blue-600 hover:bg-blue-500 text-white transition-colors"
                  >
                    미디어사 배정
                  </button>
                )}
              </div>
            )}
          </div>

          {/* 상태 변경 */}
          {statusOptions.length > 0 && (
            <div className="card p-5">
              <h2 className="text-sm font-semibold text-slate-200 mb-3">상태 변경</h2>
              <div className="space-y-2">
                <textarea
                  value={statusNote}
                  onChange={(e) => setStatusNote(e.target.value)}
                  placeholder="처리 메모 (선택, admin_notes에 기록)"
                  rows={2}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-slate-200 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500/50 resize-none text-xs"
                />
                <div className="flex flex-col gap-1.5">
                  {statusOptions.map((opt) => (
                    <button
                      key={opt.value}
                      onClick={() => handleStatusChange(opt.value)}
                      disabled={statusMutation.isPending}
                      className={`w-full px-3 py-2 rounded-lg text-sm font-medium transition-colors disabled:opacity-40 ${
                        opt.value === "cancelled" || opt.value === "disputed"
                          ? "bg-red-500/15 text-red-400 hover:bg-red-500/25"
                          : "bg-slate-700 text-slate-200 hover:bg-slate-600"
                      }`}
                    >
                      {statusMutation.isPending ? "처리 중…" : opt.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* 완료 처리 */}
          {canComplete && (
            <button
              onClick={() => setCompleteOpen(true)}
              className="w-full card p-4 text-left hover:bg-slate-800/80 transition-colors"
            >
              <div className="flex items-center gap-2 text-emerald-400 font-medium text-sm mb-1">
                <ClipboardCheck size={15} />
                작업 완료 처리
              </div>
              <p className="text-xs text-slate-500">증빙 URL을 등록하고 완료 처리합니다</p>
            </button>
          )}

          {/* 분쟁(환불 요청) 패널 */}
          {isDisputed && (
            <div className="card p-5 bg-amber-500/5 border border-amber-500/20">
              <div className="flex items-center gap-2 text-amber-400 font-semibold text-sm mb-3">
                <AlertTriangle size={15} />
                환불 요청 접수됨
              </div>
              <p className="text-xs text-slate-400 mb-4">
                유저가 환불을 요청하였습니다.
                승인 시 주문·결제가 환불 처리됩니다.
              </p>
              <button
                onClick={() => setRefundOpen(true)}
                className="w-full px-4 py-2 rounded-lg text-sm font-medium bg-amber-600 hover:bg-amber-500 text-white transition-colors"
              >
                환불 결정하기
              </button>
            </div>
          )}

          {/* 미디어사 정보 요약 */}
          {order.media_company && (
            <div className="card p-5">
              <h2 className="text-sm font-semibold text-slate-200 mb-2">미디어사 정보</h2>
              <p className="text-slate-400 text-xs">
                ID: {order.media_company.id.slice(0, 8)}…
              </p>
              <Link
                href={`/admin/media-companies`}
                className="text-xs text-cyan-400 hover:text-cyan-300 transition-colors"
              >
                미디어사 관리 →
              </Link>
            </div>
          )}
        </div>
      </div>

      {/* ── 모달들 ── */}
      {assignOpen && (
        <AssignModal
          order={order}
          onClose={() => setAssignOpen(false)}
          onSuccess={() => refetch()}
        />
      )}
      {completeOpen && (
        <CompleteOrderModal
          order={order}
          onClose={() => setCompleteOpen(false)}
          onSuccess={() => refetch()}
        />
      )}
      {refundOpen && (
        <RefundDecisionModal
          order={order}
          onClose={() => setRefundOpen(false)}
          onSuccess={() => refetch()}
        />
      )}
    </div>
  );
}
