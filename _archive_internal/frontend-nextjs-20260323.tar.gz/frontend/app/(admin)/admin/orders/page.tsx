"use client";

/**
 * 어드민 주문 목록 페이지 (Sprint 6)
 *
 * - 총 주문 수 배지
 * - 상태 필터 탭
 * - 미디어사 셀렉트 필터
 * - 검색창 (상품명, 워크스페이스명)
 * - 테이블: 주문번호, 워크스페이스, 상품, 장소, 금액, 미디어사, 상태, 일시, 액션
 * - 행 액션: 배정, 완료처리, 환불결정
 * - 페이지네이션 (skip/limit)
 */
import { useState, useMemo } from "react";
import Link from "next/link";
import { format } from "date-fns";
import { Search, ChevronLeft, ChevronRight } from "lucide-react";
import { toast } from "sonner";
import { useAdminOrders, useMediaCompanies } from "@/hooks/useAdmin";
import type { AdminOrderListItem } from "@/hooks/useAdmin";
import { StatusBadge } from "@/components/common/StatusBadge";
import AssignModal from "@/components/admin/AssignModal";
import CompleteOrderModal from "@/components/admin/CompleteOrderModal";
import RefundDecisionModal from "@/components/admin/RefundDecisionModal";
import { useAdminOrder } from "@/hooks/useAdmin";

// ============================
// 상태 탭 설정
// ============================
const STATUS_TABS = [
  { value: null,          label: "전체" },
  { value: "pending",     label: "결제대기" },
  { value: "confirmed",   label: "확정" },
  { value: "in_progress", label: "진행중" },
  { value: "completed",   label: "완료" },
  { value: "disputed",    label: "분쟁" },
  { value: "cancelled",   label: "취소" },
  { value: "refunded",    label: "환불" },
];

const PAGE_LIMIT = 20;

// ============================
// 주문 행 컴포넌트 (모달 액션 포함)
// ============================
function OrderRow({ item }: { item: AdminOrderListItem }) {
  const [assignOpen, setAssignOpen] = useState(false);
  const [completeOpen, setCompleteOpen] = useState(false);
  const [refundOpen, setRefundOpen] = useState(false);

  // 상세 데이터 (모달용 — 클릭 시 로드)
  const [loadDetail, setLoadDetail] = useState(false);
  const { data: detail } = useAdminOrder(loadDetail ? item.id : "");

  const handleActionClick = (action: "assign" | "complete" | "refund") => {
    setLoadDetail(true);
    setTimeout(() => {
      if (action === "assign") setAssignOpen(true);
      if (action === "complete") setCompleteOpen(true);
      if (action === "refund") setRefundOpen(true);
    }, 100);
  };

  const canAssign   = ["confirmed", "in_progress"].includes(item.status);
  const canComplete = ["confirmed", "in_progress"].includes(item.status);
  const canRefund   = item.status === "disputed";

  return (
    <>
      <tr className="border-b border-slate-800 hover:bg-slate-800/40 transition-colors">
        {/* 주문번호 */}
        <td className="px-4 py-3">
          <Link
            href={`/admin/orders/${item.id}`}
            className="text-cyan-400 hover:text-cyan-300 font-mono text-xs transition-colors"
          >
            #{item.id.slice(0, 8).toUpperCase()}
          </Link>
        </td>

        {/* 워크스페이스 */}
        <td className="px-4 py-3">
          <div className="text-sm text-slate-200">{item.workspace_name}</div>
          <div className="text-xs text-slate-500 capitalize">{item.workspace_plan}</div>
        </td>

        {/* 상품 */}
        <td className="px-4 py-3">
          <div className="text-sm text-slate-200 max-w-[140px] truncate">
            {item.product_name}
          </div>
          {item.place_name && (
            <div className="text-xs text-slate-500 truncate max-w-[140px]">
              📍 {item.place_name}
            </div>
          )}
        </td>

        {/* 금액 */}
        <td className="px-4 py-3 text-right">
          <span className="text-sm font-medium text-slate-200">
            ₩{item.total_amount.toLocaleString()}
          </span>
        </td>

        {/* 미디어사 */}
        <td className="px-4 py-3">
          {item.media_company_name ? (
            <span className="text-sm text-cyan-400">{item.media_company_name}</span>
          ) : (
            <span className="text-xs text-slate-600">미배정</span>
          )}
        </td>

        {/* 상태 */}
        <td className="px-4 py-3">
          <StatusBadge status={item.status} type="order" />
        </td>

        {/* 일시 */}
        <td className="px-4 py-3 text-xs text-slate-500 whitespace-nowrap">
          {item.ordered_at
            ? format(new Date(item.ordered_at), "MM/dd HH:mm")
            : format(new Date(item.created_at), "MM/dd HH:mm")}
        </td>

        {/* 액션 */}
        <td className="px-4 py-3">
          <div className="flex items-center gap-1">
            {/* 배정 버튼 */}
            {canAssign && (
              <button
                onClick={() => handleActionClick("assign")}
                className="px-2 py-1 rounded text-xs bg-blue-500/15 text-blue-400 hover:bg-blue-500/25 transition-colors"
              >
                배정
              </button>
            )}
            {/* 완료 버튼 */}
            {canComplete && (
              <button
                onClick={() => handleActionClick("complete")}
                className="px-2 py-1 rounded text-xs bg-emerald-500/15 text-emerald-400 hover:bg-emerald-500/25 transition-colors"
              >
                완료
              </button>
            )}
            {/* 환불 버튼 */}
            {canRefund && (
              <button
                onClick={() => handleActionClick("refund")}
                className="px-2 py-1 rounded text-xs bg-red-500/15 text-red-400 hover:bg-red-500/25 transition-colors"
              >
                환불처리
              </button>
            )}
            {/* 상세 링크 */}
            <Link
              href={`/admin/orders/${item.id}`}
              className="px-2 py-1 rounded text-xs text-slate-400 hover:text-slate-200 hover:bg-slate-700 transition-colors"
            >
              상세
            </Link>
          </div>
        </td>
      </tr>

      {/* 배정 모달 */}
      {assignOpen && detail && (
        <AssignModal
          order={detail}
          onClose={() => setAssignOpen(false)}
        />
      )}

      {/* 완료 모달 */}
      {completeOpen && detail && (
        <CompleteOrderModal
          order={detail}
          onClose={() => setCompleteOpen(false)}
        />
      )}

      {/* 환불 결정 모달 */}
      {refundOpen && detail && (
        <RefundDecisionModal
          order={detail}
          onClose={() => setRefundOpen(false)}
        />
      )}
    </>
  );
}

// ============================
// 메인 페이지
// ============================
export default function AdminOrdersPage() {
  const [statusFilter, setStatusFilter] = useState<string | null>(null);
  const [mediaFilter, setMediaFilter]   = useState<string | null>(null);
  const [search, setSearch]             = useState("");
  const [page, setPage]                 = useState(0); // skip = page * limit

  const { data, isLoading, isError } = useAdminOrders(
    statusFilter,
    null,
    mediaFilter,
    page * PAGE_LIMIT,
    PAGE_LIMIT,
  );

  const { data: companies = [] } = useMediaCompanies(false);

  // 클라이언트 사이드 검색 (상품명 / 워크스페이스명)
  const filteredItems = useMemo(() => {
    if (!data?.items) return [];
    if (!search.trim()) return data.items;
    const q = search.toLowerCase();
    return data.items.filter(
      (o) =>
        o.product_name.toLowerCase().includes(q) ||
        o.workspace_name.toLowerCase().includes(q) ||
        (o.place_name ?? "").toLowerCase().includes(q)
    );
  }, [data?.items, search]);

  const totalPages = data ? Math.ceil(data.total / PAGE_LIMIT) : 0;

  // 탭 변경 시 페이지 리셋
  const handleStatusChange = (v: string | null) => {
    setStatusFilter(v);
    setPage(0);
  };

  return (
    <div className="space-y-5">
      {/* ── 헤더 ── */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <h1 className="text-xl font-bold text-slate-100">주문 관리</h1>
          <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-cyan-500/15 text-cyan-400 border border-cyan-500/20">
            총 {data?.total ?? 0}건
          </span>
        </div>
      </div>

      {/* ── 상태 탭 ── */}
      <div className="flex flex-wrap gap-1">
        {STATUS_TABS.map((tab) => (
          <button
            key={tab.value ?? "all"}
            onClick={() => handleStatusChange(tab.value)}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
              statusFilter === tab.value
                ? "bg-cyan-600 text-white"
                : "text-slate-400 hover:text-slate-200 hover:bg-slate-700"
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* ── 필터 바 ── */}
      <div className="flex flex-col sm:flex-row gap-3">
        {/* 미디어사 필터 */}
        <select
          value={mediaFilter ?? ""}
          onChange={(e) => {
            setMediaFilter(e.target.value || null);
            setPage(0);
          }}
          className="bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-slate-300 focus:outline-none focus:ring-2 focus:ring-cyan-500/50 min-w-[160px]"
        >
          <option value="">미디어사 전체</option>
          {companies.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name}
            </option>
          ))}
        </select>

        {/* 검색 */}
        <div className="relative flex-1 max-w-sm">
          <Search
            size={15}
            className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500"
          />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="상품명, 워크스페이스, 장소 검색"
            className="w-full bg-slate-800 border border-slate-700 rounded-lg pl-9 pr-3 py-2 text-sm text-slate-200 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500/50"
          />
        </div>
      </div>

      {/* ── 테이블 ── */}
      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-700 bg-slate-800/50">
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-400 uppercase tracking-wide">주문번호</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-400 uppercase tracking-wide">워크스페이스</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-400 uppercase tracking-wide">상품/장소</th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-slate-400 uppercase tracking-wide">금액</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-400 uppercase tracking-wide">미디어사</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-400 uppercase tracking-wide">상태</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-400 uppercase tracking-wide">일시</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-400 uppercase tracking-wide">액션</th>
              </tr>
            </thead>
            <tbody>
              {isLoading && (
                [...Array(5)].map((_, i) => (
                  <tr key={i} className="border-b border-slate-800">
                    {[...Array(8)].map((_, j) => (
                      <td key={j} className="px-4 py-3">
                        <div className="h-4 bg-slate-800 rounded animate-pulse" />
                      </td>
                    ))}
                  </tr>
                ))
              )}
              {!isLoading && filteredItems.length === 0 && (
                <tr>
                  <td colSpan={8} className="px-4 py-12 text-center text-slate-500">
                    조건에 맞는 주문이 없습니다
                  </td>
                </tr>
              )}
              {!isLoading &&
                filteredItems.map((item) => (
                  <OrderRow key={item.id} item={item} />
                ))}
            </tbody>
          </table>
        </div>

        {/* ── 페이지네이션 ── */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between px-4 py-3 border-t border-slate-700">
            <span className="text-xs text-slate-500">
              {page * PAGE_LIMIT + 1}–
              {Math.min((page + 1) * PAGE_LIMIT, data?.total ?? 0)}건 /
              전체 {data?.total ?? 0}건
            </span>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setPage((p) => Math.max(0, p - 1))}
                disabled={page === 0}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-700 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
              >
                <ChevronLeft size={16} />
              </button>
              <span className="text-xs text-slate-400">
                {page + 1} / {totalPages}
              </span>
              <button
                onClick={() => setPage((p) => Math.min(totalPages - 1, p + 1))}
                disabled={page >= totalPages - 1}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-700 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
              >
                <ChevronRight size={16} />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
