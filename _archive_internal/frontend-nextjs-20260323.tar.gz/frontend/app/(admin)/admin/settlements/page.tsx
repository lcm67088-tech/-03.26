"use client";

/**
 * 어드민 정산 관리 페이지 (Sprint 9)
 *
 * 기능:
 *   - 월 선택 필터 (YYYY-MM)
 *   - 상태 필터 (pending/approved/paid)
 *   - 미디어사 필터
 *   - 정산 생성 버튼 (GenerateModal)
 *   - CSV 내보내기
 *   - 승인 / 지급 처리 액션
 *   - 정산 상세 모달
 */

import { useState } from "react";
import {
  useAdminSettlements,
  useAdminSettlement,
  useGenerateSettlement,
  useApproveSettlement,
  usePaySettlement,
  type SettlementListItem,
} from "@/hooks/useAdminAdvanced";
import { useMediaCompanies } from "@/hooks/useAdmin";
import { getApiErrorMessage } from "@/lib/api";

// ── 정산 상태 뱃지 ────────────────────────────────────────────
const STATUS_BADGE: Record<string, string> = {
  pending: "bg-yellow-600/20 text-yellow-400 border border-yellow-500/30",
  approved: "bg-blue-600/20 text-blue-400 border border-blue-500/30",
  paid: "bg-green-600/20 text-green-400 border border-green-500/30",
};
const STATUS_LABEL: Record<string, string> = {
  pending: "승인 대기",
  approved: "승인 완료",
  paid: "지급 완료",
};

// ── 이번 달 기본값 ───────────────────────────────────────────
function getCurrentMonth() {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
}

export default function AdminSettlementsPage() {
  // ── 필터 ────────────────────────────────────────────────────
  const [monthFilter, setMonthFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [mediaFilter, setMediaFilter] = useState("");
  const [page, setPage] = useState(0);
  const limit = 20;

  // ── 상세 모달 ─────────────────────────────────────────────────
  const [detailId, setDetailId] = useState<string | null>(null);

  // ── 정산 생성 모달 ────────────────────────────────────────────
  const [showGenerate, setShowGenerate] = useState(false);
  const [genMonth, setGenMonth] = useState(getCurrentMonth());
  const [genMediaId, setGenMediaId] = useState("");
  const [genRate, setGenRate] = useState(0.7);

  // ── 승인/지급 확인 ────────────────────────────────────────────
  const [approveTarget, setApproveTarget] = useState<SettlementListItem | null>(null);
  const [approveNote, setApproveNote] = useState("");
  const [payTarget, setPayTarget] = useState<SettlementListItem | null>(null);

  const [toast, setToast] = useState<{ msg: string; ok: boolean } | null>(null);
  const showToast = (msg: string, ok = true) => {
    setToast({ msg, ok });
    setTimeout(() => setToast(null), 3000);
  };

  // ── 쿼리 ────────────────────────────────────────────────────
  const { data, isLoading, isError } = useAdminSettlements(
    monthFilter || undefined,
    mediaFilter || undefined,
    statusFilter || undefined,
    page * limit,
    limit,
  );
  const { data: detailData } = useAdminSettlement(detailId ?? "");
  const { data: mediaCompanies } = useMediaCompanies(true);

  // ── 뮤테이션 ────────────────────────────────────────────────
  const generate = useGenerateSettlement();
  const approve = useApproveSettlement(approveTarget?.id ?? "");
  const pay = usePaySettlement(payTarget?.id ?? "");

  // ── 정산 생성 ─────────────────────────────────────────────────
  const handleGenerate = async () => {
    if (!genMediaId) { showToast("미디어사를 선택해주세요", false); return; }
    try {
      await generate.mutateAsync({
        media_company_id: genMediaId,
        month: genMonth,
        commission_rate: genRate,
      });
      showToast("정산이 생성되었습니다");
      setShowGenerate(false);
    } catch (e) {
      showToast(getApiErrorMessage(e), false);
    }
  };

  // ── 승인 처리 ─────────────────────────────────────────────────
  const handleApprove = async () => {
    try {
      await approve.mutateAsync({ note: approveNote });
      showToast("정산이 승인되었습니다");
      setApproveTarget(null);
    } catch (e) {
      showToast(getApiErrorMessage(e), false);
    }
  };

  // ── 지급 처리 ─────────────────────────────────────────────────
  const handlePay = async () => {
    try {
      await pay.mutateAsync();
      showToast("지급 처리가 완료되었습니다");
      setPayTarget(null);
    } catch (e) {
      showToast(getApiErrorMessage(e), false);
    }
  };

  // ── CSV 내보내기 ──────────────────────────────────────────────
  const handleExportCSV = () => {
    const params = new URLSearchParams();
    if (monthFilter) params.append("month", monthFilter);
    if (statusFilter) params.append("status", statusFilter);
    if (mediaFilter) params.append("media_company_id", mediaFilter);
    window.open(
      `${process.env.NEXT_PUBLIC_API_URL ?? ""}/api/v1/admin/settlements/export/csv?${params.toString()}`,
      "_blank"
    );
  };

  const total = data?.total ?? 0;
  const totalPages = Math.ceil(total / limit);

  return (
    <div className="space-y-6">
      {/* 헤더 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">정산 관리</h1>
          <p className="text-slate-400 text-sm mt-1">미디어사 월별 정산을 생성·승인·지급 처리합니다</p>
        </div>
        <div className="flex gap-3">
          <button
            onClick={() => setShowGenerate(true)}
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-sm font-medium transition"
          >
            <span>+</span>
            정산 생성
          </button>
          <button
            onClick={handleExportCSV}
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-slate-700 hover:bg-slate-600 text-white text-sm transition"
          >
            <span>📥</span>
            CSV
          </button>
        </div>
      </div>

      {/* 필터 바 */}
      <div className="flex flex-wrap gap-3 bg-[#12121a] border border-slate-800 rounded-xl p-4">
        <input
          type="month"
          value={monthFilter}
          onChange={(e) => { setMonthFilter(e.target.value); setPage(0); }}
          className="bg-slate-800 text-white px-3 py-2 rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-cyan-500"
        />
        <select
          value={statusFilter}
          onChange={(e) => { setStatusFilter(e.target.value); setPage(0); }}
          className="bg-slate-800 text-white px-3 py-2 rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-cyan-500"
        >
          <option value="">전체 상태</option>
          <option value="pending">승인 대기</option>
          <option value="approved">승인 완료</option>
          <option value="paid">지급 완료</option>
        </select>
        <select
          value={mediaFilter}
          onChange={(e) => { setMediaFilter(e.target.value); setPage(0); }}
          className="bg-slate-800 text-white px-3 py-2 rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-cyan-500"
        >
          <option value="">전체 미디어사</option>
          {(mediaCompanies ?? []).map((mc) => (
            <option key={mc.id} value={mc.id}>{mc.name}</option>
          ))}
        </select>
        <button
          onClick={() => { setMonthFilter(""); setStatusFilter(""); setMediaFilter(""); setPage(0); }}
          className="px-3 py-2 rounded-lg bg-slate-700 hover:bg-slate-600 text-slate-300 text-sm transition"
        >
          초기화
        </button>
      </div>

      {/* 테이블 */}
      <div className="bg-[#12121a] border border-slate-800 rounded-xl overflow-hidden">
        {isLoading ? (
          <div className="flex items-center justify-center h-40 text-slate-400">로딩 중...</div>
        ) : isError ? (
          <div className="flex items-center justify-center h-40 text-red-400">데이터 로딩 실패</div>
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400">
                <th className="px-4 py-3 text-left">미디어사</th>
                <th className="px-4 py-3 text-center">정산월</th>
                <th className="px-4 py-3 text-center">상태</th>
                <th className="px-4 py-3 text-center">주문수</th>
                <th className="px-4 py-3 text-right">총금액</th>
                <th className="px-4 py-3 text-right">지급액</th>
                <th className="px-4 py-3 text-center">수수료율</th>
                <th className="px-4 py-3 text-center">액션</th>
              </tr>
            </thead>
            <tbody>
              {(data?.items ?? []).length === 0 ? (
                <tr>
                  <td colSpan={8} className="text-center py-12 text-slate-500">
                    정산 내역이 없습니다
                  </td>
                </tr>
              ) : (data?.items ?? []).map((s) => (
                <tr key={s.id} className="border-b border-slate-800/50 hover:bg-slate-800/30 transition">
                  <td className="px-4 py-3 text-white">{s.media_company_name}</td>
                  <td className="px-4 py-3 text-center text-slate-300 font-mono">{s.month}</td>
                  <td className="px-4 py-3 text-center">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${STATUS_BADGE[s.status] ?? ""}`}>
                      {STATUS_LABEL[s.status] ?? s.status}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-center text-slate-300">{s.total_orders}</td>
                  <td className="px-4 py-3 text-right text-slate-300">
                    {s.total_amount.toLocaleString()}원
                  </td>
                  <td className="px-4 py-3 text-right text-cyan-400 font-medium">
                    {s.commission_amount.toLocaleString()}원
                  </td>
                  <td className="px-4 py-3 text-center text-slate-400">
                    {(s.commission_rate * 100).toFixed(0)}%
                  </td>
                  <td className="px-4 py-3 text-center">
                    <div className="flex gap-1 justify-center">
                      <button
                        onClick={() => setDetailId(s.id)}
                        className="px-2 py-1 rounded bg-slate-700 hover:bg-slate-600 text-slate-300 text-xs transition"
                      >
                        상세
                      </button>
                      {s.status === "pending" && (
                        <button
                          onClick={() => { setApproveTarget(s); setApproveNote(""); }}
                          className="px-2 py-1 rounded bg-blue-600/20 hover:bg-blue-600/40 text-blue-400 text-xs border border-blue-500/30 transition"
                        >
                          승인
                        </button>
                      )}
                      {s.status === "approved" && (
                        <button
                          onClick={() => setPayTarget(s)}
                          className="px-2 py-1 rounded bg-green-600/20 hover:bg-green-600/40 text-green-400 text-xs border border-green-500/30 transition"
                        >
                          지급
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* 페이지네이션 */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between text-sm text-slate-400">
          <span>총 {total}건</span>
          <div className="flex gap-2">
            <button onClick={() => setPage(p => Math.max(0, p - 1))} disabled={page === 0}
              className="px-3 py-1 rounded bg-slate-700 hover:bg-slate-600 disabled:opacity-40 transition">이전</button>
            <span className="px-3 py-1">{page + 1} / {totalPages}</span>
            <button onClick={() => setPage(p => Math.min(totalPages - 1, p + 1))} disabled={page >= totalPages - 1}
              className="px-3 py-1 rounded bg-slate-700 hover:bg-slate-600 disabled:opacity-40 transition">다음</button>
          </div>
        </div>
      )}

      {/* 정산 상세 모달 */}
      {detailId && detailData && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <div className="bg-[#12121a] border border-slate-700 rounded-2xl p-6 w-full max-w-2xl max-h-[80vh] overflow-y-auto space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-white font-bold text-lg">
                정산 상세 — {detailData.media_company_name} ({detailData.month})
              </h3>
              <button onClick={() => setDetailId(null)} className="text-slate-500 hover:text-white text-xl">✕</button>
            </div>
            <div className="grid grid-cols-2 gap-3 text-sm">
              {[
                ["상태", STATUS_LABEL[detailData.status] ?? detailData.status],
                ["총 주문수", `${detailData.total_orders}건`],
                ["총 금액", `${detailData.total_amount.toLocaleString()}원`],
                ["수수료율", `${(detailData.commission_rate * 100).toFixed(0)}%`],
                ["지급액", `${detailData.commission_amount.toLocaleString()}원`],
                ["생성일", new Date(detailData.created_at).toLocaleDateString("ko-KR")],
              ].map(([k, v]) => (
                <div key={k} className="bg-slate-800/50 rounded-lg p-3">
                  <p className="text-slate-400 text-xs">{k}</p>
                  <p className="text-white mt-1 font-medium">{v}</p>
                </div>
              ))}
            </div>
            <h4 className="text-slate-300 text-sm font-medium pt-2">포함된 주문 ({detailData.items.length}건)</h4>
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b border-slate-700 text-slate-400">
                  <th className="py-2 text-left">상품명</th>
                  <th className="py-2 text-left">워크스페이스</th>
                  <th className="py-2 text-right">금액</th>
                  <th className="py-2 text-right">지급액</th>
                </tr>
              </thead>
              <tbody>
                {detailData.items.map((item) => (
                  <tr key={item.id} className="border-b border-slate-800/50">
                    <td className="py-2 text-slate-300">{item.product_name ?? "-"}</td>
                    <td className="py-2 text-slate-400">{item.workspace_name ?? "-"}</td>
                    <td className="py-2 text-right text-slate-300">{item.amount.toLocaleString()}원</td>
                    <td className="py-2 text-right text-cyan-400">{item.commission_amount.toLocaleString()}원</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 정산 생성 모달 */}
      {showGenerate && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60">
          <div className="bg-[#12121a] border border-slate-700 rounded-2xl p-6 w-[440px] space-y-4">
            <h3 className="text-white font-bold text-lg">정산 생성</h3>
            <div className="space-y-3">
              <div>
                <label className="text-sm text-slate-400 block mb-1">미디어사</label>
                <select
                  value={genMediaId}
                  onChange={(e) => setGenMediaId(e.target.value)}
                  className="w-full bg-slate-800 text-white px-3 py-2 rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-cyan-500"
                >
                  <option value="">선택...</option>
                  {(mediaCompanies ?? []).map((mc) => (
                    <option key={mc.id} value={mc.id}>{mc.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-sm text-slate-400 block mb-1">정산 월</label>
                <input
                  type="month"
                  value={genMonth}
                  onChange={(e) => setGenMonth(e.target.value)}
                  className="w-full bg-slate-800 text-white px-3 py-2 rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-cyan-500"
                />
              </div>
              <div>
                <label className="text-sm text-slate-400 block mb-1">
                  수수료율 ({(genRate * 100).toFixed(0)}%)
                </label>
                <input
                  type="range"
                  min={0} max={1} step={0.05}
                  value={genRate}
                  onChange={(e) => setGenRate(parseFloat(e.target.value))}
                  className="w-full accent-cyan-500"
                />
                <div className="flex justify-between text-xs text-slate-500 mt-1">
                  <span>0%</span><span>50%</span><span>100%</span>
                </div>
              </div>
            </div>
            <div className="flex gap-3 justify-end">
              <button
                onClick={() => setShowGenerate(false)}
                className="px-4 py-2 rounded-lg bg-slate-700 hover:bg-slate-600 text-slate-300 text-sm transition"
              >
                취소
              </button>
              <button
                onClick={handleGenerate}
                disabled={generate.isPending || !genMediaId}
                className="px-4 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-sm font-medium disabled:opacity-60 transition"
              >
                {generate.isPending ? "생성 중..." : "정산 생성"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 승인 다이얼로그 */}
      {approveTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60">
          <div className="bg-[#12121a] border border-slate-700 rounded-2xl p-6 w-[400px] space-y-4">
            <h3 className="text-white font-bold text-lg">정산 승인</h3>
            <p className="text-slate-400 text-sm">
              <span className="text-white">{approveTarget.media_company_name}</span> ({approveTarget.month}) 정산을 승인하시겠습니까?
              <br />
              지급액: <span className="text-cyan-400 font-medium">{approveTarget.commission_amount.toLocaleString()}원</span>
            </p>
            <textarea
              placeholder="승인 메모 (선택)"
              value={approveNote}
              onChange={(e) => setApproveNote(e.target.value)}
              rows={2}
              className="w-full bg-slate-800 text-white placeholder-slate-500 px-3 py-2 rounded-lg text-sm resize-none focus:outline-none focus:ring-1 focus:ring-cyan-500"
            />
            <div className="flex gap-3 justify-end">
              <button onClick={() => setApproveTarget(null)} className="px-4 py-2 rounded-lg bg-slate-700 hover:bg-slate-600 text-slate-300 text-sm transition">취소</button>
              <button onClick={handleApprove} disabled={approve.isPending}
                className="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-sm font-medium disabled:opacity-60 transition">
                {approve.isPending ? "처리 중..." : "승인"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 지급 다이얼로그 */}
      {payTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60">
          <div className="bg-[#12121a] border border-slate-700 rounded-2xl p-6 w-[400px] space-y-4">
            <h3 className="text-white font-bold text-lg">지급 처리</h3>
            <p className="text-slate-400 text-sm">
              <span className="text-white">{payTarget.media_company_name}</span> ({payTarget.month}) 정산 지급을 처리하시겠습니까?
              <br />
              지급액: <span className="text-green-400 font-medium text-base">{payTarget.commission_amount.toLocaleString()}원</span>
            </p>
            <div className="flex gap-3 justify-end">
              <button onClick={() => setPayTarget(null)} className="px-4 py-2 rounded-lg bg-slate-700 hover:bg-slate-600 text-slate-300 text-sm transition">취소</button>
              <button onClick={handlePay} disabled={pay.isPending}
                className="px-4 py-2 rounded-lg bg-green-600 hover:bg-green-500 text-white text-sm font-medium disabled:opacity-60 transition">
                {pay.isPending ? "처리 중..." : "지급 완료"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 토스트 */}
      {toast && (
        <div className={`fixed bottom-6 right-6 z-50 px-5 py-3 rounded-xl shadow-lg text-sm font-medium ${
          toast.ok ? "bg-green-600 text-white" : "bg-red-600 text-white"
        }`}>
          {toast.msg}
        </div>
      )}
    </div>
  );
}
