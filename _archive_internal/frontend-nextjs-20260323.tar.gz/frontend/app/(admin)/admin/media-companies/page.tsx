"use client";

/**
 * 미디어사 관리 페이지 (Sprint 6)
 *
 * - 헤더: 총 미디어사 수 + 신규 등록 버튼
 * - 테이블: 이름, 연락처, 총 주문, 완료율, 평균 처리일, 상태 토글, 액션(수정/삭제)
 * - 등록/수정 모달 다이얼로그 (동일 컴포넌트, mode로 분기)
 * - 비활성 포함 토글
 * - 삭제: 진행중 주문이 있으면 400 처리
 */
import { useState } from "react";
import { format } from "date-fns";
import { ko } from "date-fns/locale";
import { Plus, Edit2, Trash2, Eye, EyeOff, AlertTriangle, X } from "lucide-react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { toast } from "sonner";
import {
  useMediaCompanies,
  useCreateMediaCompany,
  useUpdateMediaCompany,
  useDeleteMediaCompany,
} from "@/hooks/useAdmin";
import type { MediaCompanyResponse } from "@/hooks/useAdmin";
import { getApiErrorMessage } from "@/lib/api";

// ============================
// Zod 스키마
// ============================
const mediaCompanySchema = z.object({
  name:          z.string().min(1, "이름을 입력해주세요").max(100),
  contact_email: z.string().email("유효한 이메일").max(255).optional().or(z.literal("")),
  contact_phone: z.string().max(20).optional().or(z.literal("")),
  bank_account:  z.string().max(200).optional().or(z.literal("")),
});

type MediaCompanyFormData = z.infer<typeof mediaCompanySchema>;

// ============================
// 등록/수정 모달
// ============================
interface MediaCompanyModalProps {
  mode: "create" | "edit";
  target?: MediaCompanyResponse;
  onClose: () => void;
}

function MediaCompanyModal({ mode, target, onClose }: MediaCompanyModalProps) {
  const createMutation = useCreateMediaCompany();
  const updateMutation = useUpdateMediaCompany(target?.id ?? "");

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<MediaCompanyFormData>({
    resolver: zodResolver(mediaCompanySchema),
    defaultValues: {
      name:          target?.name          ?? "",
      contact_email: target?.contact_email ?? "",
      contact_phone: target?.contact_phone ?? "",
      bank_account:  target?.bank_account  ?? "",
    },
  });

  const onSubmit = async (data: MediaCompanyFormData) => {
    try {
      if (mode === "create") {
        await createMutation.mutateAsync({
          name:          data.name,
          contact_email: data.contact_email || undefined,
          contact_phone: data.contact_phone || undefined,
          bank_account:  data.bank_account  || undefined,
        });
        toast.success(`"${data.name}" 미디어사가 등록되었습니다`);
      } else {
        await updateMutation.mutateAsync({
          name:          data.name,
          contact_email: data.contact_email || null,
          contact_phone: data.contact_phone || null,
          bank_account:  data.bank_account  || null,
        });
        toast.success("미디어사 정보가 수정되었습니다");
      }
      onClose();
    } catch (err) {
      toast.error(getApiErrorMessage(err));
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm"
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <div className="bg-slate-900 border border-slate-700 rounded-xl shadow-2xl w-full max-w-md mx-4">
        {/* 헤더 */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-700">
          <h2 className="text-lg font-semibold text-slate-100">
            {mode === "create" ? "미디어사 등록" : "미디어사 수정"}
          </h2>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-200 transition-colors">
            <X size={18} />
          </button>
        </div>

        {/* 폼 */}
        <form onSubmit={handleSubmit(onSubmit)}>
          <div className="px-6 py-5 space-y-4">
            {/* 이름 */}
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1.5">
                미디어사명 <span className="text-red-400">*</span>
              </label>
              <input
                {...register("name")}
                type="text"
                placeholder="(주)미디어사"
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2.5 text-slate-200 text-sm placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500/50"
              />
              {errors.name && (
                <p className="text-red-400 text-xs mt-1">{errors.name.message}</p>
              )}
            </div>

            {/* 이메일 */}
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1.5">
                담당자 이메일
              </label>
              <input
                {...register("contact_email")}
                type="email"
                placeholder="contact@example.com"
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2.5 text-slate-200 text-sm placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500/50"
              />
              {errors.contact_email && (
                <p className="text-red-400 text-xs mt-1">{errors.contact_email.message}</p>
              )}
            </div>

            {/* 전화번호 */}
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1.5">
                담당자 전화번호
              </label>
              <input
                {...register("contact_phone")}
                type="text"
                placeholder="010-1234-5678"
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2.5 text-slate-200 text-sm placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500/50"
              />
            </div>

            {/* 정산 계좌 */}
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1.5">
                정산 계좌
              </label>
              <input
                {...register("bank_account")}
                type="text"
                placeholder="신한은행 110-123-456789 홍길동"
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2.5 text-slate-200 text-sm placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500/50"
              />
              <p className="text-slate-500 text-xs mt-1">
                계좌 정보는 서버에 암호화 저장이 필요합니다 (Sprint 8 예정)
              </p>
            </div>
          </div>

          {/* 버튼 */}
          <div className="flex justify-end gap-3 px-6 py-4 border-t border-slate-700">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg text-sm text-slate-300 hover:text-slate-100 hover:bg-slate-700 transition-colors"
            >
              취소
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-5 py-2 rounded-lg text-sm font-medium bg-cyan-600 hover:bg-cyan-500 text-white disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
            >
              {isSubmitting
                ? "저장 중…"
                : mode === "create"
                ? "등록"
                : "저장"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

// ============================
// 완료율 바
// ============================
function CompletionBar({ rate }: { rate: number }) {
  const color =
    rate >= 80
      ? "bg-emerald-500"
      : rate >= 50
      ? "bg-amber-500"
      : "bg-red-500";

  return (
    <div className="flex items-center gap-2">
      <div className="w-16 bg-slate-700 rounded-full h-1.5 overflow-hidden">
        <div
          className={`h-full rounded-full ${color} transition-all`}
          style={{ width: `${rate}%` }}
        />
      </div>
      <span className="text-xs text-slate-400">{rate}%</span>
    </div>
  );
}

// ============================
// 메인 페이지
// ============================
export default function AdminMediaCompaniesPage() {
  const [includeInactive, setIncludeInactive] = useState(false);
  const [modalOpen, setModalOpen]             = useState(false);
  const [editTarget, setEditTarget]           = useState<MediaCompanyResponse | null>(null);

  const { data: companies = [], isLoading } = useMediaCompanies(includeInactive);
  const deleteMutation = useDeleteMediaCompany();

  // ── 삭제 처리
  const handleDelete = async (mc: MediaCompanyResponse) => {
    if (mc.order_count > 0) {
      const ok = confirm(
        `"${mc.name}"에 진행/완료 주문이 있습니다.\n삭제(비활성) 처리할까요?\n진행중 주문이 있으면 실패합니다.`
      );
      if (!ok) return;
    } else {
      const ok = confirm(`"${mc.name}"을 삭제(비활성)하시겠습니까?`);
      if (!ok) return;
    }

    try {
      await deleteMutation.mutateAsync(mc.id);
      toast.success(`"${mc.name}" 미디어사가 비활성 처리되었습니다`);
    } catch (err) {
      toast.error(getApiErrorMessage(err));
    }
  };

  // ── 수정 열기
  const handleEdit = (mc: MediaCompanyResponse) => {
    setEditTarget(mc);
    setModalOpen(true);
  };

  // ── 등록 열기
  const handleCreate = () => {
    setEditTarget(null);
    setModalOpen(true);
  };

  return (
    <div className="space-y-5">
      {/* ── 헤더 ── */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <h1 className="text-xl font-bold text-slate-100">미디어사 관리</h1>
          <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-cyan-500/15 text-cyan-400 border border-cyan-500/20">
            {companies.length}개
          </span>
        </div>

        <div className="flex items-center gap-3">
          {/* 비활성 토글 */}
          <button
            onClick={() => setIncludeInactive((v) => !v)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs transition-colors ${
              includeInactive
                ? "bg-slate-600 text-slate-200"
                : "text-slate-500 hover:text-slate-300 hover:bg-slate-700"
            }`}
          >
            {includeInactive ? <Eye size={13} /> : <EyeOff size={13} />}
            {includeInactive ? "비활성 숨기기" : "비활성 포함"}
          </button>

          {/* 등록 버튼 */}
          <button
            onClick={handleCreate}
            className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-medium bg-cyan-600 hover:bg-cyan-500 text-white transition-colors"
          >
            <Plus size={15} />
            미디어사 등록
          </button>
        </div>
      </div>

      {/* ── 테이블 ── */}
      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-700 bg-slate-800/50">
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-400 uppercase tracking-wide">미디어사명</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-400 uppercase tracking-wide">연락처</th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-slate-400 uppercase tracking-wide">총 주문</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-400 uppercase tracking-wide">완료율</th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-slate-400 uppercase tracking-wide">평균 처리일</th>
                <th className="px-4 py-3 text-center text-xs font-semibold text-slate-400 uppercase tracking-wide">상태</th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-slate-400 uppercase tracking-wide">액션</th>
              </tr>
            </thead>
            <tbody>
              {isLoading && (
                [...Array(4)].map((_, i) => (
                  <tr key={i} className="border-b border-slate-800">
                    {[...Array(7)].map((_, j) => (
                      <td key={j} className="px-4 py-3">
                        <div className="h-4 bg-slate-800 rounded animate-pulse" />
                      </td>
                    ))}
                  </tr>
                ))
              )}

              {!isLoading && companies.length === 0 && (
                <tr>
                  <td colSpan={7} className="px-4 py-12 text-center text-slate-500">
                    등록된 미디어사가 없습니다
                  </td>
                </tr>
              )}

              {!isLoading &&
                companies.map((mc) => {
                  const completionRate =
                    mc.order_count > 0
                      ? Math.round((mc.completed_count / mc.order_count) * 100)
                      : 0;

                  return (
                    <tr
                      key={mc.id}
                      className={`border-b border-slate-800 hover:bg-slate-800/40 transition-colors ${
                        !mc.is_active ? "opacity-50" : ""
                      }`}
                    >
                      {/* 이름 */}
                      <td className="px-4 py-3">
                        <div className="font-medium text-slate-200">{mc.name}</div>
                        {mc.bank_account && (
                          <div className="text-xs text-slate-600 truncate max-w-[180px]">
                            💳 {mc.bank_account}
                          </div>
                        )}
                      </td>

                      {/* 연락처 */}
                      <td className="px-4 py-3">
                        {mc.contact_email && (
                          <div className="text-xs text-slate-400 truncate max-w-[160px]">
                            ✉️ {mc.contact_email}
                          </div>
                        )}
                        {mc.contact_phone && (
                          <div className="text-xs text-slate-400">
                            📱 {mc.contact_phone}
                          </div>
                        )}
                        {!mc.contact_email && !mc.contact_phone && (
                          <span className="text-slate-600 text-xs">—</span>
                        )}
                      </td>

                      {/* 총 주문 */}
                      <td className="px-4 py-3 text-right">
                        <span className="text-slate-200 font-medium">{mc.order_count}</span>
                        <span className="text-slate-500 text-xs ml-1">건</span>
                      </td>

                      {/* 완료율 */}
                      <td className="px-4 py-3">
                        {mc.order_count > 0 ? (
                          <CompletionBar rate={completionRate} />
                        ) : (
                          <span className="text-slate-600 text-xs">신규</span>
                        )}
                      </td>

                      {/* 평균 처리일 */}
                      <td className="px-4 py-3 text-right">
                        {mc.avg_completion_days != null ? (
                          <span className="text-slate-300 text-sm">
                            {mc.avg_completion_days}일
                          </span>
                        ) : (
                          <span className="text-slate-600 text-xs">—</span>
                        )}
                      </td>

                      {/* 상태 */}
                      <td className="px-4 py-3 text-center">
                        <span
                          className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium border ${
                            mc.is_active
                              ? "bg-emerald-500/15 text-emerald-400 border-emerald-500/20"
                              : "bg-slate-500/15 text-slate-500 border-slate-600/20"
                          }`}
                        >
                          {mc.is_active ? "활성" : "비활성"}
                        </span>
                      </td>

                      {/* 액션 */}
                      <td className="px-4 py-3">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => handleEdit(mc)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-700 transition-colors"
                            title="수정"
                          >
                            <Edit2 size={14} />
                          </button>
                          {mc.is_active && (
                            <button
                              onClick={() => handleDelete(mc)}
                              disabled={deleteMutation.isPending}
                              className="p-1.5 rounded-lg text-slate-500 hover:text-red-400 hover:bg-red-500/10 transition-colors"
                              title="삭제 (비활성)"
                            >
                              <Trash2 size={14} />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
            </tbody>
          </table>
        </div>

        {/* 하단 요약 */}
        {!isLoading && companies.length > 0 && (
          <div className="px-4 py-3 border-t border-slate-700 bg-slate-800/30">
            <p className="text-xs text-slate-500">
              활성 {companies.filter((c) => c.is_active).length}개 /
              총 {companies.length}개 미디어사 ·
              총 누적 주문 {companies.reduce((s, c) => s + c.order_count, 0)}건 ·
              완료 {companies.reduce((s, c) => s + c.completed_count, 0)}건
            </p>
          </div>
        )}
      </div>

      {/* ── 등록/수정 모달 ── */}
      {modalOpen && (
        <MediaCompanyModal
          mode={editTarget ? "edit" : "create"}
          target={editTarget ?? undefined}
          onClose={() => {
            setModalOpen(false);
            setEditTarget(null);
          }}
        />
      )}
    </div>
  );
}
