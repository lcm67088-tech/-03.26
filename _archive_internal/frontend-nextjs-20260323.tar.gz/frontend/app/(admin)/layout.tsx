/**
 * 어드민 레이아웃 (Sprint 6 업데이트)
 *
 * - isAdmin=true Sidebar 사용 (어드민 전용 메뉴)
 * - 서버 컴포넌트에서 redirect 처리 (미구현 — middleware.ts에서 처리)
 * - 비어드민 접근은 middleware.ts의 adminRequired 설정으로 차단
 */
import { Sidebar } from "@/components/layout/Sidebar";
import { Header } from "@/components/layout/Header";

export const metadata = {
  title: "어드민 - nplace.io",
};

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="flex h-screen overflow-hidden bg-brand-dark">
      {/* 어드민 전용 사이드바 */}
      <Sidebar isAdmin />

      {/* 메인 콘텐츠 영역 */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header isAdmin />
        <main className="flex-1 overflow-y-auto p-6">
          {children}
        </main>
      </div>
    </div>
  );
}
