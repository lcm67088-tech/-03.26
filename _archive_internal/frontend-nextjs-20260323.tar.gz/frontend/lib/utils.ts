/**
 * 공통 유틸리티 함수 (Sprint 4 정리)
 *
 * - Tailwind 클래스 병합 (cn)
 * - 날짜 포매팅 (formatDate, formatDateOnly, formatRelativeTime)
 * - 금액 포매팅 (formatKRW, formatKRWShort)
 * - 순위 포매팅 (formatRank, formatRankChange, formatRankChangeText)
 * - 문자열 유틸 (truncate, extractNaverPlaceId, maskEmail)
 * - 페이지네이션 (getPageRange)
 */
import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";
import { format } from "date-fns";
import { ko } from "date-fns/locale";

// =====================
// Tailwind 클래스 병합
// =====================

/**
 * Tailwind 클래스 병합 유틸리티 (shadcn/ui 표준)
 */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// =====================
// 날짜 포매팅
// =====================

/**
 * 날짜 포매팅 (한국 형식)
 * @example "2024-01-15 14:30"
 */
export function formatDate(date: string | Date | null | undefined): string {
  if (!date) return "-";
  try {
    return format(new Date(date), "yyyy-MM-dd HH:mm", { locale: ko });
  } catch {
    return "-";
  }
}

/**
 * 날짜만 포매팅
 * @example "2024-01-15"
 */
export function formatDateOnly(date: string | Date | null | undefined): string {
  if (!date) return "-";
  try {
    return format(new Date(date), "yyyy-MM-dd", { locale: ko });
  } catch {
    return "-";
  }
}

/**
 * 상대적 시간 포매팅 (크롤링 시각 등 표시용)
 * date-fns 의존 없이 직접 계산 → "방금 전", "n분 전", "n시간 전", "n일 전"
 *
 * @example
 *   formatRelativeTime(new Date()) → "방금 전"
 *   formatRelativeTime(dateMinusOneHour) → "1시간 전"
 *   formatRelativeTime(dateMinusTwoDays) → "2일 전"
 */
export function formatRelativeTime(date: string | Date | null | undefined): string {
  if (!date) return "-";
  try {
    const diff = Date.now() - new Date(date).getTime();
    const minutes = Math.floor(diff / 60_000);
    if (minutes < 1) return "방금 전";
    if (minutes < 60) return `${minutes}분 전`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours}시간 전`;
    const days = Math.floor(hours / 24);
    if (days < 7) return `${days}일 전`;
    // 7일 이상이면 날짜 직접 표시
    return format(new Date(date), "MM/dd", { locale: ko });
  } catch {
    return "-";
  }
}

// =====================
// 금액 포매팅
// =====================

/**
 * 한국 원화 포매팅
 * @example 1234567 → "1,234,567원"
 */
export function formatKRW(amount: number | null | undefined): string {
  if (amount === null || amount === undefined) return "-";
  return `${amount.toLocaleString("ko-KR")}원`;
}

/**
 * 만원 단위 포매팅 (큰 금액용)
 * @example 1234567 → "약 123만원"
 */
export function formatKRWShort(amount: number | null | undefined): string {
  if (amount === null || amount === undefined) return "-";
  if (amount >= 100000000) {
    return `약 ${(amount / 100000000).toFixed(1)}억원`;
  }
  if (amount >= 10000) {
    return `약 ${(amount / 10000).toFixed(0)}만원`;
  }
  return `${amount.toLocaleString("ko-KR")}원`;
}

// =====================
// 순위 포매팅
// =====================

/**
 * 순위 표시
 * @example 1 → "1위", null → "미진입"
 */
export function formatRank(rank: number | null | undefined): string {
  if (rank === null || rank === undefined) return "미진입";
  return `${rank}위`;
}

/**
 * 순위 변동 표시 — 텍스트 + CSS color 반환
 *
 * rank_change 의미: 양수 = 순위 상승 (숫자 낮아짐), 음수 = 하락
 *
 * @example
 *   formatRankChange(3)  → { text: "▲3", color: "text-green-400" }
 *   formatRankChange(-2) → { text: "▼2", color: "text-red-400" }
 *   formatRankChange(0)  → { text: "-",  color: "text-slate-500" }
 */
export function formatRankChange(change: number | null | undefined): {
  text: string;
  color: string;
} {
  if (change === null || change === undefined || change === 0) {
    return { text: "-", color: "text-slate-500" };
  }
  if (change > 0) {
    return { text: `▲${change}`, color: "text-green-400" };
  }
  return { text: `▼${Math.abs(change)}`, color: "text-red-400" };
}

/**
 * 순위 변동 텍스트만 반환 (요약 표시용)
 * @example formatRankChangeText(3) → "▲3 상승"
 */
export function formatRankChangeText(change: number | null | undefined): string {
  if (change === null || change === undefined) return "-";
  if (change === 0) return "변동없음";
  if (change > 0) return `▲${change} 상승`;
  return `▼${Math.abs(change)} 하락`;
}

// =====================
// 문자열 유틸
// =====================

/**
 * 텍스트 자르기 (말줄임표)
 */
export function truncate(text: string, maxLength: number): string {
  if (text.length <= maxLength) return text;
  return `${text.slice(0, maxLength)}...`;
}

/**
 * 네이버 플레이스 URL에서 place_id 추출
 * @example "https://map.naver.com/v5/entry/place/12345678" → "12345678"
 */
export function extractNaverPlaceId(url: string): string | null {
  const patterns = [
    /place\/(\d+)/,
    /entry\/place\/(\d+)/,
    /\/(\d{8,})/,
  ];

  for (const pattern of patterns) {
    const match = url.match(pattern);
    if (match) return match[1];
  }
  return null;
}

/**
 * 이메일 마스킹
 * @example "hello@example.com" → "he***@example.com"
 */
export function maskEmail(email: string): string {
  const [local, domain] = email.split("@");
  if (!local || !domain) return email;
  const masked = local.slice(0, 2) + "***";
  return `${masked}@${domain}`;
}

// =====================
// 페이지네이션 유틸
// =====================

/**
 * 페이지 범위 계산
 */
export function getPageRange(currentPage: number, totalPages: number, delta = 2): number[] {
  const range: number[] = [];
  const left = Math.max(2, currentPage - delta);
  const right = Math.min(totalPages - 1, currentPage + delta);

  for (let i = left; i <= right; i++) {
    range.push(i);
  }

  if (left > 2) range.unshift(-1); // ... 구분자
  if (right < totalPages - 1) range.push(-1);

  return [1, ...range, totalPages].filter((v, i, arr) => arr.indexOf(v) === i);
}
