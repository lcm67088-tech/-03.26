/**
 * 인증 토큰 관리 유틸리티 (Sprint 2 완성)
 * localStorage + cookie 이중 저장
 * - localStorage: API 요청 인터셉터에서 사용
 * - cookie: Next.js middleware에서 SSR/edge에서 읽기 위해
 */

const ACCESS_TOKEN_KEY = "access_token";
const REFRESH_TOKEN_KEY = "refresh_token";

// ============================
// tokenStorage 객체
// ============================

export const tokenStorage = {
  /**
   * 액세스 토큰 조회
   */
  getAccessToken(): string | null {
    if (typeof window === "undefined") return null;
    return localStorage.getItem(ACCESS_TOKEN_KEY);
  },

  /**
   * 리프레시 토큰 조회
   */
  getRefreshToken(): string | null {
    if (typeof window === "undefined") return null;
    return localStorage.getItem(REFRESH_TOKEN_KEY);
  },

  /**
   * 토큰 저장 (localStorage + cookie)
   *
   * @param access  - 액세스 토큰
   * @param refresh - 리프레시 토큰
   */
  setTokens(access: string, refresh: string): void {
    if (typeof window === "undefined") return;

    // localStorage 저장
    localStorage.setItem(ACCESS_TOKEN_KEY, access);
    localStorage.setItem(REFRESH_TOKEN_KEY, refresh);

    // cookie 저장 (Next.js middleware에서 읽기 위해)
    // SameSite=Lax: CSRF 방지, max-age=3600 (1시간)
    document.cookie = `access_token=${access}; path=/; max-age=3600; SameSite=Lax`;
  },

  /**
   * 액세스 토큰만 갱신
   */
  setAccessToken(access: string): void {
    if (typeof window === "undefined") return;
    localStorage.setItem(ACCESS_TOKEN_KEY, access);
    document.cookie = `access_token=${access}; path=/; max-age=3600; SameSite=Lax`;
  },

  /**
   * 모든 토큰 삭제 (로그아웃 시)
   */
  clearTokens(): void {
    if (typeof window === "undefined") return;
    localStorage.removeItem(ACCESS_TOKEN_KEY);
    localStorage.removeItem(REFRESH_TOKEN_KEY);
    // cookie 만료 처리
    document.cookie = "access_token=; path=/; max-age=0; SameSite=Lax";
  },

  /**
   * 인증 여부 확인
   */
  isAuthenticated(): boolean {
    const token = this.getAccessToken();
    if (!token) return false;
    return !isTokenExpired(token);
  },
};

// ============================
// JWT 유틸리티 함수
// ============================

/**
 * JWT 페이로드 디코딩 (서명 검증 없음 - 클라이언트용)
 */
export function decodeJwtPayload(token: string): Record<string, unknown> | null {
  try {
    const parts = token.split(".");
    if (parts.length !== 3) return null;

    const base64Url = parts[1];
    const base64 = base64Url.replace(/-/g, "+").replace(/_/g, "/");
    const padded = base64.padEnd(base64.length + ((4 - (base64.length % 4)) % 4), "=");
    const jsonPayload = decodeURIComponent(
      atob(padded)
        .split("")
        .map((c) => "%" + ("00" + c.charCodeAt(0).toString(16)).slice(-2))
        .join("")
    );
    return JSON.parse(jsonPayload);
  } catch {
    return null;
  }
}

/**
 * 토큰 만료 여부 확인
 * @param token - JWT 문자열
 * @param bufferSeconds - 만료 전 여유 시간 (기본 30초)
 */
export function isTokenExpired(token: string, bufferSeconds = 30): boolean {
  const payload = decodeJwtPayload(token);
  if (!payload || typeof payload.exp !== "number") return true;
  return Date.now() / 1000 >= payload.exp - bufferSeconds;
}

/**
 * 토큰에서 user_id 추출
 */
export function getUserIdFromToken(token: string): string | null {
  const payload = decodeJwtPayload(token);
  if (!payload) return null;
  return payload.sub as string | null;
}

/**
 * 토큰에서 role 추출 (middleware edge runtime용)
 */
export function getRoleFromToken(token: string): string | null {
  const payload = decodeJwtPayload(token);
  if (!payload) return null;
  return payload.role as string | null;
}

// 하위 호환을 위한 개별 export
export const getAccessToken = () => tokenStorage.getAccessToken();
export const getRefreshToken = () => tokenStorage.getRefreshToken();
export const setTokens = (access: string, refresh: string) =>
  tokenStorage.setTokens(access, refresh);
export const clearAuth = () => tokenStorage.clearTokens();
export const isAuthenticated = () => tokenStorage.isAuthenticated();
