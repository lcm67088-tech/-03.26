/**
 * axios 인스턴스 + 인터셉터 (Sprint 2 완성)
 * 401 응답 시 자동 토큰 갱신 + 요청 큐잉 로직
 */
import axios, {
  AxiosError,
  AxiosResponse,
  InternalAxiosRequestConfig,
} from "axios";
import { tokenStorage } from "@/lib/auth";

const BASE_URL = process.env.NEXT_PUBLIC_API_URL
  ? `${process.env.NEXT_PUBLIC_API_URL}/api/v1`
  : "/api/v1";

// ============================
// axios 기본 인스턴스
// ============================
const api = axios.create({
  baseURL: BASE_URL,
  timeout: 15000,
  headers: {
    "Content-Type": "application/json",
  },
});

// ============================
// Refresh 토큰 갱신 상태 관리
// ============================

/** 현재 토큰 갱신 진행 중 여부 */
let isRefreshing = false;

/** 갱신 중 대기 중인 요청 큐 */
let failedQueue: Array<{
  resolve: (token: string) => void;
  reject: (error: unknown) => void;
}> = [];

/**
 * 대기 큐 처리
 * @param error - 에러 (null이면 성공)
 * @param token - 새 액세스 토큰 (성공 시)
 */
function processQueue(error: unknown, token: string | null = null): void {
  failedQueue.forEach(({ resolve, reject }) => {
    if (error) {
      reject(error);
    } else if (token) {
      resolve(token);
    }
  });
  failedQueue = [];
}

// ============================
// 요청 인터셉터
// ============================
api.interceptors.request.use(
  (config: InternalAxiosRequestConfig) => {
    if (typeof window !== "undefined") {
      const token = tokenStorage.getAccessToken();
      if (token) {
        config.headers.Authorization = `Bearer ${token}`;
      }
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// ============================
// 응답 인터셉터
// ============================
api.interceptors.response.use(
  (response: AxiosResponse) => response,
  async (error: AxiosError) => {
    const originalRequest = error.config as InternalAxiosRequestConfig & {
      _retry?: boolean;
    };

    // 401 에러이고 아직 재시도 안 한 경우에만 갱신 시도
    if (error.response?.status === 401 && !originalRequest._retry) {
      // 이미 갱신 중이면 큐에 추가하고 대기
      if (isRefreshing) {
        return new Promise<AxiosResponse>((resolve, reject) => {
          failedQueue.push({
            resolve: (token: string) => {
              originalRequest.headers.Authorization = `Bearer ${token}`;
              resolve(api(originalRequest));
            },
            reject,
          });
        });
      }

      originalRequest._retry = true;
      isRefreshing = true;

      try {
        const refreshToken = tokenStorage.getRefreshToken();

        if (!refreshToken) {
          throw new Error("리프레시 토큰이 없습니다");
        }

        // 토큰 갱신 요청 (인터셉터 없이 직접 호출)
        const { data } = await axios.post(`${BASE_URL}/auth/refresh`, {
          refresh_token: refreshToken,
        });

        const newAccessToken: string = data.access_token;
        const newRefreshToken: string = data.refresh_token;

        // 새 토큰 저장
        tokenStorage.setTokens(newAccessToken, newRefreshToken);

        // 대기 큐 성공 처리
        processQueue(null, newAccessToken);

        // 원래 요청 재시도
        originalRequest.headers.Authorization = `Bearer ${newAccessToken}`;
        return api(originalRequest);
      } catch (refreshError) {
        // 갱신 실패 → 큐 실패 처리 + 로그아웃
        processQueue(refreshError, null);
        tokenStorage.clearTokens();

        // 로그인 페이지로 리다이렉트 (클라이언트 사이드에서만)
        if (typeof window !== "undefined") {
          window.location.href = "/login";
        }

        return Promise.reject(refreshError);
      } finally {
        isRefreshing = false;
      }
    }

    return Promise.reject(error);
  }
);

export default api;

// ============================
// API 헬퍼 함수
// ============================

/**
 * GET 요청
 */
export async function get<T>(
  url: string,
  params?: Record<string, unknown>
): Promise<T> {
  const { data } = await api.get<T>(url, { params });
  return data;
}

/**
 * POST 요청
 */
export async function post<T>(url: string, body?: unknown): Promise<T> {
  const { data } = await api.post<T>(url, body);
  return data;
}

/**
 * PUT 요청
 */
export async function put<T>(url: string, body?: unknown): Promise<T> {
  const { data } = await api.put<T>(url, body);
  return data;
}

/**
 * PATCH 요청
 */
export async function patch<T>(url: string, body?: unknown): Promise<T> {
  const { data } = await api.patch<T>(url, body);
  return data;
}

/**
 * DELETE 요청
 */
export async function del<T>(url: string): Promise<T> {
  const { data } = await api.delete<T>(url);
  return data;
}

/**
 * axios 에러에서 메시지 추출
 */
export function getApiErrorMessage(error: unknown): string {
  if (axios.isAxiosError(error)) {
    const detail = error.response?.data?.detail;
    if (typeof detail === "string") return detail;
    if (Array.isArray(detail)) {
      return detail.map((d) => d.msg || d).join(", ");
    }
    return error.message;
  }
  if (error instanceof Error) return error.message;
  return "알 수 없는 오류가 발생했습니다";
}
