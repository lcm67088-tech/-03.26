import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: ["class"],
  content: [
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      // =====================
      // nplace.io 디자인 토큰
      // =====================
      colors: {
        // 브랜드 컬러
        brand: {
          primary: "#00d4ff",     // 시안 (메인 액션)
          secondary: "#7c3aed",   // 퍼플 (포인트)
          dark: "#0a0a0f",        // 배경
          darker: "#06060a",      // 더 어두운 배경
          card: "rgba(255,255,255,0.04)",
          border: "rgba(0,212,255,0.15)",
          "border-hover": "rgba(0,212,255,0.35)",
        },
        // 주문 상태 컬러
        status: {
          pending: "#f59e0b",      // 주황 (결제완료/대기)
          confirmed: "#3b82f6",   // 파랑 (어드민 확인)
          in_progress: "#8b5cf6", // 보라 (진행 중)
          completed: "#10b981",   // 초록 (완료)
          cancelled: "#6b7280",   // 회색 (취소)
          refunded: "#ef4444",    // 빨강 (환불)
          disputed: "#f97316",    // 주황 (분쟁)
        },
        // 플랜 컬러
        plan: {
          free: "#6b7280",
          starter: "#3b82f6",
          pro: "#8b5cf6",
          enterprise: "#f59e0b",
        },
      },
      // 폰트
      fontFamily: {
        sans: [
          "Pretendard Variable",
          "Pretendard",
          "-apple-system",
          "BlinkMacSystemFont",
          "system-ui",
          "Roboto",
          "Helvetica Neue",
          "Segoe UI",
          "Apple SD Gothic Neo",
          "Noto Sans KR",
          "Malgun Gothic",
          "Apple Color Emoji",
          "Segoe UI Emoji",
          "Segoe UI Symbol",
          "sans-serif",
        ],
      },
      // 배경 그라디언트
      backgroundImage: {
        "gradient-brand": "linear-gradient(135deg, #00d4ff 0%, #7c3aed 100%)",
        "gradient-dark": "linear-gradient(180deg, #0a0a0f 0%, #06060a 100%)",
        "gradient-card": "linear-gradient(135deg, rgba(0,212,255,0.05) 0%, rgba(124,58,237,0.05) 100%)",
      },
      // 애니메이션
      animation: {
        "fade-in": "fadeIn 0.2s ease-in-out",
        "slide-up": "slideUp 0.3s ease-out",
        "pulse-brand": "pulseBrand 2s cubic-bezier(0.4, 0, 0.6, 1) infinite",
      },
      keyframes: {
        fadeIn: {
          "0%": { opacity: "0" },
          "100%": { opacity: "1" },
        },
        slideUp: {
          "0%": { transform: "translateY(10px)", opacity: "0" },
          "100%": { transform: "translateY(0)", opacity: "1" },
        },
        pulseBrand: {
          "0%, 100%": { opacity: "1" },
          "50%": { opacity: "0.5" },
        },
      },
      // 박스 쉐도우
      boxShadow: {
        brand: "0 0 20px rgba(0,212,255,0.3)",
        "brand-lg": "0 0 40px rgba(0,212,255,0.2)",
        card: "0 4px 24px rgba(0,0,0,0.4)",
      },
      // 테두리 반지름
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
    },
  },
  plugins: [],
};

export default config;
