"use client";

/**
 * Zustand 인증 스토어 (Sprint 2 완성)
 * login / logout / refreshAccessToken 액션 포함
 */
import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import axios from "axios";

import { tokenStorage } from "@/lib/auth";
import { getApiErrorMessage } from "@/lib/api";
import type { User, Workspace, AuthTokens } from "@/types";

// ============================
// 타입 정의
// ============================

interface RegisterData {
  email: string;
  password: string;
  name: string;
  phone?: string;
}

interface RegisterResponse {
  user: {
    id: string;
    email: string;
    name: string;
    role: string;
    phone?: string | null;
    is_active: boolean;
    email_verified: boolean;
  };
  workspace: {
    id: string;
    name: string;
    plan: string;
  };
  message: string;
}

interface AuthStore {
  // 상태
  user: User | null;
  workspace: Workspace | null;
  accessToken: string | null;
  refreshToken: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;

  // 액션
  login: (email: string, password: string) => Promise<void>;
  register: (data: RegisterData) => Promise<RegisterResponse>;
  logout: () => void;
  refreshAccessToken: () => Promise<void>;
  setWorkspace: (ws: Workspace) => void;
  updateUser: (updates: Partial<User>) => void;
  updateWorkspace: (updates: Partial<Workspace>) => void;
  _setAuthData: (user: User, workspace: Workspace, tokens: AuthTokens) => void;
}

// ============================
// API 기본 URL
// ============================
const API_BASE =
  typeof window !== "undefined"
    ? `${process.env.NEXT_PUBLIC_API_URL || ""}/api/v1`
    : "/api/v1";

// ============================
// Zustand 스토어
// ============================
export const useAuthStore = create<AuthStore>()(
  persist(
    (set, get) => ({
      // 초기 상태
      user: null,
      workspace: null,
      accessToken: null,
      refreshToken: null,
      isAuthenticated: false,
      isLoading: false,

      // ============================
      // 로그인
      // ============================
      login: async (email: string, password: string) => {
        set({ isLoading: true });
        try {
          const { data } = await axios.post(`${API_BASE}/auth/login`, {
            email,
            password,
          });

          const { access_token, refresh_token, user, workspace } = data;

          // 토큰 저장 (localStorage + cookie)
          tokenStorage.setTokens(access_token, refresh_token);

          // 상태 업데이트
          set({
            user: {
              id: user.id,
              email: user.email,
              name: user.name,
              role: user.role,
              phone: user.phone,
              is_active: user.is_active,
              email_verified: user.email_verified,
              created_at: "",
              updated_at: "",
            },
            workspace: {
              id: workspace.id,
              owner_id: user.id,
              name: workspace.name,
              plan: workspace.plan,
              is_active: true,
              created_at: "",
              updated_at: "",
            },
            accessToken: access_token,
            refreshToken: refresh_token,
            isAuthenticated: true,
          });
        } catch (error) {
          throw new Error(getApiErrorMessage(error));
        } finally {
          set({ isLoading: false });
        }
      },

      // ============================
      // 회원가입
      // ============================
      register: async (data: RegisterData): Promise<RegisterResponse> => {
        set({ isLoading: true });
        try {
          const { data: responseData } = await axios.post(
            `${API_BASE}/auth/register`,
            data
          );
          return responseData as RegisterResponse;
        } catch (error) {
          throw new Error(getApiErrorMessage(error));
        } finally {
          set({ isLoading: false });
        }
      },

      // ============================
      // 로그아웃
      // ============================
      logout: () => {
        const accessToken = tokenStorage.getAccessToken();

        // 서버에 로그아웃 알림 (비동기, 실패해도 무시)
        if (accessToken) {
          axios
            .post(
              `${API_BASE}/auth/logout`,
              {},
              {
                headers: { Authorization: `Bearer ${accessToken}` },
              }
            )
            .catch(() => {
              // 서버 에러 무시 (클라이언트 토큰만 삭제해도 됨)
            });
        }

        // 토큰 삭제
        tokenStorage.clearTokens();

        // 상태 초기화
        set({
          user: null,
          workspace: null,
          accessToken: null,
          refreshToken: null,
          isAuthenticated: false,
        });

        // 로그인 페이지로
        if (typeof window !== "undefined") {
          window.location.href = "/login";
        }
      },

      // ============================
      // 액세스 토큰 갱신
      // ============================
      refreshAccessToken: async () => {
        const refreshToken = tokenStorage.getRefreshToken();

        if (!refreshToken) {
          get().logout();
          return;
        }

        try {
          const { data } = await axios.post(`${API_BASE}/auth/refresh`, {
            refresh_token: refreshToken,
          });

          const { access_token, refresh_token: new_refresh_token } = data;

          // 새 토큰 저장
          tokenStorage.setTokens(access_token, new_refresh_token);

          set({
            accessToken: access_token,
            refreshToken: new_refresh_token,
          });
        } catch {
          // 갱신 실패 → 로그아웃
          get().logout();
        }
      },

      // ============================
      // 워크스페이스 설정
      // ============================
      setWorkspace: (ws: Workspace) => set({ workspace: ws }),

      // ============================
      // 유저 정보 부분 업데이트
      // ============================
      updateUser: (updates: Partial<User>) =>
        set((state) => ({
          user: state.user ? { ...state.user, ...updates } : null,
        })),

      // ============================
      // 워크스페이스 정보 부분 업데이트
      // ============================
      updateWorkspace: (updates: Partial<Workspace>) =>
        set((state) => ({
          workspace: state.workspace
            ? { ...state.workspace, ...updates }
            : null,
        })),

      // ============================
      // 내부용: 인증 데이터 한번에 설정
      // ============================
      _setAuthData: (user: User, workspace: Workspace, tokens: AuthTokens) => {
        tokenStorage.setTokens(tokens.access_token, tokens.refresh_token);
        set({
          user,
          workspace,
          accessToken: tokens.access_token,
          refreshToken: tokens.refresh_token,
          isAuthenticated: true,
        });
      },
    }),
    {
      name: "nplace-auth",
      storage: createJSONStorage(() =>
        typeof window !== "undefined" ? localStorage : ({} as Storage)
      ),
      // 민감 정보 제외 (토큰은 lib/auth.ts가 별도 관리)
      partialize: (state) => ({
        user: state.user,
        workspace: state.workspace,
        isAuthenticated: state.isAuthenticated,
      }),
    }
  )
);
